<?php

namespace App\Listeners;

use App\Events\HvsEvent;
use App\Models\Fgp\HighVolumeHeaders;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;

class ReorderHvsListener implements ShouldQueue
{
   
    /**
     * Handle the event.
     *
     * @param  HvsEvent  $event
     * @return void
     */       

    public function handle(HvsEvent $event){

        $allHVH = HighVolumeHeaders::where('is_deleted', 0)->orderBy('seq_num')->get();

        if($event->updateSequence)
            $this->updateSequence();

        $allHVH = $this->getHvms();

        $alphabets = range(65,90); 

        $startingAlphabets = range(67, 90);

        $columnsArray = [];

        $length = ceil(count($allHVH)/ 26);

        for($i = 0; $i < $length; $i++){

            $prefix = '';

            $char = $i - 1;

            if($char >= 0){

                $prefix = chr($alphabets[$char]);

            }

            if($i === 0){

                $starter = $startingAlphabets;

            }else{

                $starter = $alphabets;

            }

            foreach ($starter as $key => $asciiCode) {

                
                $columnsArray[] = $prefix.chr($asciiCode);

            }

        }

        foreach ($allHVH as $key => $highVols) {                               

            $highVols->update([
                "column" => $columnsArray[$key],
            ]);  

        }        

    }

    private function getHvms(){
        return HighVolumeHeaders::where('is_deleted', 0)->orderBy('seq_num')->get();
    }

    private function updateSequence(){

        $seq_num = 1;

        $allHVH = $this->getHvms();

        foreach ($allHVH as $key => $highVols) {                               

            $highVols->update([
                "seq_num" => $seq_num,
            ]);  

            $seq_num++;

        }
    }

}
