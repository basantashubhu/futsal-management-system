<?php

namespace App\Listeners;

use App\Lib\SessionHandler\SessionHandler;
use Illuminate\Auth\Events\Attempting;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;

class LogAuthenticationAttempt
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  Attempting $event
     * @return void
     */
    public function handle(Attempting $event)
    {
        $session = new SessionHandler();
        $session->checkSessions($event->credentials);
    }
}
