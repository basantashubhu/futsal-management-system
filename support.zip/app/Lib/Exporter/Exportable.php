<?php
/**
 * DEVELOPERS
 * ----------------------------------------------
 * SUMAN  THAPA - LEAD  (NEPALNME@GMAIL.COM)
 * ----------------------------------------------
 * - PRABHAT GURUNG
 * - BASANTA TAJ
 * - RAKESH SHRESTHA
 * - LEKHRAJ RAI
 * - MANISH BUDDHACHARYA
 * - ASCOL PARAJULI
 * -----------------------------------------------
 * Created On: 2019
 *
 * THIS INTELLECTUAL PROPERTY IS COPYRIGHT Ⓒ 2018
 * ZEUSLOGIC, INC. ALL RIGHT RESERVED
 */

namespace App\Lib\Exporter;


interface Exportable
{
    public function export();

    public function getFile();
}