<?php
/**
 * DEVELOPERS
 * ----------------------------------------------
 * SUMAN  THAPA - LEAD  (NEPALNME@GMAIL.COM)
 * ----------------------------------------------
 * - PRABHAT GURUNG
 * - BASANTA TAJ
 * - RAKESH SHRESTHA
 * - LEKHRAJ RAI
 * - MANISH BUDDHACHARYA
 * -----------------------------------------------
 * Created On: 2019
 *
 * THIS INTELLECTUAL PROPERTY IS COPYRIGHT Ⓒ 2018
 * ZEUSLOGIC, INC. ALL RIGHT RESERVED
 */

namespace App\Lib\Exporter;


class Exporter
{

    public $exporter;

    public function __construct(Exportable $exporter)
    {
        $this->exporter = $exporter;
    }

    public function export()
    {
        $this->exporter->export();
        return $this->exporter->getFile();
    }

    public function getFilename(){
        return $this->exporter->getFilename();

    }
}