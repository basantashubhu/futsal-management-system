<?php
/**
 * DEVELOPERS
 * ----------------------------------------------
 * SUMAN  THAPA - LEAD  (NEPALNME@GMAIL.COM)
 * ----------------------------------------------
 * - RUNA SIDDHI BAJRACHARYA
 * - RABIN BHANDARI
 * - SHIVA THAPA
 * - PRABHAT GURUNG
 * - KIRAN CHAULAGAIN
 * -----------------------------------------------
 * Created On: 5/14/2018
 *
 * THIS INTELLECTUAL PROPERTY IS COPYRIGHT Ⓒ 2018
 * ZEUSLOGIC, INC. ALL RIGHT RESERVED
 */

namespace App\Lib\Prints;


use App\Lib\Capture\ScreenCapture;

class MainPrint
{
    public function makePdf($content)
    {
        $screenCapture = new ScreenCapture();
        $path = $screenCapture->load(htmlspecialchars_decode($content));
        $abPath = storage_path('uploads' . DIRECTORY_SEPARATOR);
        $path = str_replace($abPath, '', $path);
        return $path;

    }
}