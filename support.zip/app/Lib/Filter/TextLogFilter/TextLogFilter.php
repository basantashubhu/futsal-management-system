<?php
/**
 * DEVELOPERS
 * ----------------------------------------------
 * SUMAN  THAPA - LEAD  (NEPALNME@GMAIL.COM)
 * ----------------------------------------------
 * - RUNA SIDDHI BAJRACHARYA
 * - RABIN BHANDARI
 * - SHIVA THAPA
 * - PRABHAT GURUNG
 * - KIRAN CHAULAGAIN
 * -----------------------------------------------
 * Created On: 6/13/2018
 *
 * THIS INTELLECTUAL PROPERTY IS COPYRIGHT Ⓒ 2018
 * ZEUSLOGIC, INC. ALL RIGHT RESERVED
 */

namespace App\Lib\Filter\TextLogFilter;


use App\Lib\Filter\AbstractFilter;

class TextLogFilter extends AbstractFilter
{
    public function user($query = false)
    {
        if ($query) {
            return $this->builder->where('users.name', $query);
        }
        return $this->builder;
    }

    public function file($query = false)
    {
        if ($query) {
            return $this->builder->where('file_name', 'LIKE', "%$query%");
        }
        return $this->builder;
    }

}