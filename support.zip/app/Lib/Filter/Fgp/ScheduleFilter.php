<?php
/**
 * DEVELOPERS
 * ----------------------------------------------
 * SUMAN  THAPA - LEAD  (NEPALNME@GMAIL.COM)
 * ----------------------------------------------
 * - PRABHAT GURUNG
 * - BASANTA TAJPURIYA
 * - RAKESH SHRESTHA
 * - MANISH BUDDHACHARYA
 * - LEKH RAJ RAI
 * - ASCOL PARAJULI
 * -----------------------------------------------
 * Created On: 4/26/2019
 *
 * THIS INTELLECTUAL PROPERTY IS COPYRIGHT Ⓒ 2019
 *  SHUBHU TECH PVT LTD , NEPAL. ALL RIGHT RESERVED
 */

namespace App\Lib\Filter\Fgp;


use App\Lib\Filter\AbstractFilter;

class ScheduleFilter extends AbstractFilter
{

}