<?php
/**
 * DEVELOPERS
 * ----------------------------------------------
 * SUMAN  THAPA - LEAD  (NEPALNME@GMAIL.COM)
 * ----------------------------------------------
 * - RUNA SIDDHI BAJRACHARYA
 * - RABIN BHANDARI
 * - SHIVA THAPA
 * - PRABHAT GURUNG
 * - KIRAN CHAULAGAIN
 * -----------------------------------------------
 * Created On: 6/13/2018
 *
 * THIS INTELLECTUAL PROPERTY IS COPYRIGHT Ⓒ 2018
 * ZEUSLOGIC, INC. ALL RIGHT RESERVED
 */

namespace App\Lib\Filter\UserFilter;


use App\Lib\Filter\AbstractFilter;

class UserlogFilter extends AbstractFilter
{

    public function name($name = false)
    {
        if ($name) {
            return $this->builder->where('users.name', 'LIKE', '%'.$name.'%');
        }
        return $this->builder;
    }

    public function fingerprint($query = false)
    {
        if ($query) {
            return $this->builder->where('fingerprint', 'LIKE', "%$query%");
        }
        return $this->builder;
    }

    public function browser($query = false)
    {
        if ($query) {
            return $this->builder->where('browser', 'LIKE', "%$query%");
        }
        return $this->builder;
    }

    public function os($query = false)
    {
        if ($query) {
            return $this->builder->where('os', 'LIKE', "%$query%");
        }
        return $this->builder;
    }

}