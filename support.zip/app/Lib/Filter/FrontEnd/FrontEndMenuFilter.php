<?php
/**
 * DEVELOPERS
 * ----------------------------------------------
 * SUMAN  THAPA - LEAD  (NEPALNME@GMAIL.COM)
 * ----------------------------------------------
 * - RUNA SIDDHI BAJRACHARYA
 * - RABIN BHANDARI
 * - SHIVA THAPA
 * - PRABHAT GURUNG
 * - KIRAN CHAULAGAIN
 * -----------------------------------------------
 * Created On: 6/13/2018
 *
 * THIS INTELLECTUAL PROPERTY IS COPYRIGHT Ⓒ 2018
 * ZEUSLOGIC, INC. ALL RIGHT RESERVED
 */

namespace App\Lib\Filter\FrontEnd;

use App\Lib\Filter\AbstractFilter;

class FrontEndMenuFilter extends AbstractFilter
{
	public function menu_name($menu = false)
	{
		if ($menu) {
            return $this->builder->where('menu_name', 'LIKE', "%$menu%");
        }
        return $this->builder;
	}
}