<?php
/**
 * DEVELOPERS
 * ----------------------------------------------
 * SUMAN  THAPA - LEAD  (NEPALNME@GMAIL.COM)
 * ----------------------------------------------
 * - RUNA SIDDHI BAJRACHARYA
 * - RABIN BHANDARI
 * - SHIVA THAPA
 * - PRABHAT GURUNG
 * - KIRAN CHAULAGAIN
 * -----------------------------------------------
 * Created On: 6/13/2018
 *
 * THIS INTELLECTUAL PROPERTY IS COPYRIGHT Ⓒ 2018
 * ZEUSLOGIC, INC. ALL RIGHT RESERVED
 */

namespace App\Lib\Filter\SiteSettingFilter;


use App\Lib\Filter\AbstractFilter;

class SiteSettingFilter extends AbstractFilter
{
    public function code($query = false)
    {
        if ($query) {
            return $this->builder->where('code', 'LIKE', "%$query%");
        }
        return $this->builder;
    }

    public function value($query = false)
    {
        if ($query) {
            return $this->builder->where('value', 'LIKE', "%$query%");
        }
        return $this->builder;
    }
}