<?php
/**
 * DEVELOPERS
 * ----------------------------------------------
 * SUMAN  THAPA - LEAD  (NEPALNME@GMAIL.COM)
 * ----------------------------------------------
 * - RUNA SIDDHI BAJRACHARYA
 * - RABIN BHANDARI
 * - SHIVA THAPA
 * - PRABHAT GURUNG
 * - KIRAN CHAULAGAIN
 * -----------------------------------------------
 * Created On: 6/13/2018
 *
 * THIS INTELLECTUAL PROPERTY IS COPYRIGHT Ⓒ 2018
 * ZEUSLOGIC, INC. ALL RIGHT RESERVED
 */

namespace App\Lib\Filter\DefaultTemplateFilter;


use App\Lib\Filter\AbstractFilter;

class DefaultTemplateFilter extends AbstractFilter
{
//    public function temp_name($query = false)
//    {
//        if ($query) {
//            return $this->builder->where('temp_name', "LIKE", "%$query%");
//        }
//        return $this->builder;
//    }
//
//    public function section($query = false)
//    {
//        if ($query) {
//            return $this->builder->where('section', 'LIKE', "%$query%");
//        }
//        return $this->builder;
//    }

    public function template_name($query = false) {
        if ($query) {
            return $this->builder->where('template_name',"LIKE","%$query%");
        }
        return $this->builder;
    }


}