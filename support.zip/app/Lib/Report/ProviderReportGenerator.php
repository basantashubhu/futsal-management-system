<?php
/**
 * DEVELOPERS
 * ----------------------------------------------
 * SUMAN  THAPA - LEAD  (NEPALNME@GMAIL.COM)
 * ----------------------------------------------
 * - RUNA SIDDHI BAJRACHARYA
 * - RABIN BHANDARI
 * - SHIVA THAPA
 * - PRABHAT GURUNG
 * - KIRAN CHAULAGAIN
 * -----------------------------------------------
 * Created On: 4/26/2018
 *
 * THIS INTELLECTUAL PROPERTY IS COPYRIGHT Ⓒ 2018
 * ZEUSLOGIC, INC. ALL RIGHT RESERVED
 */

namespace App\Lib\Report;


use App\Models\Organization;
use Illuminate\Support\Facades\DB;

class ProviderReportGenerator
{
    protected $provider;
    protected $applications = 0;

    public function __construct($provider)
    {
        $this->provider = $provider;
    }

    public function generateReport()
    {

    }

    protected function totalApplicaton()
    {
        return DB::table('applications')->count();
    }

    protected function allReport()
    {
        $providers = Organization::all();
        foreach ($providers as $provider):
            dd($provider);
        endforeach;
    }
}