<?php

namespace App\Timesheet;

use App\Models\Fgp\PayPeriod;
use App\Models\Fgp\Timesheet;
use App\Models\Fgp\Volunteer;
use Carbon\Carbon;

class TimesheetContainer
{

    protected $timesheet;

    /**
     * Service container resolve dependency
     * @param Timesheet $timesheet App\Models\Timesheet
     */
    public function __construct(Timesheet $timesheet)
    {

        $this->timesheet = $timesheet;

    }

    public function isTimelineValid(PayPeriod $period, string $date, Volunteer $volunteer, string $time_in, string $time_out)
    {

        $hasTimeline = $this->timesheetCounts($period, $date, $volunteer, $time_in, $time_out) ? true : false;

        return $hasTimeline;

    }

    /**
     * Get Timesheet Counts
     * @param  PayPeriod $period    App\Models\PayPeriod
     * @param  string    $date         For which date timesheet was created
     * @param  Volunteer $volunteer Timesheet volunteer
     * @param  string    $time_in   Timesheet to create with timein
     * @return INT                  Integer
     */
    public function timesheetCounts(

        PayPeriod $period,
        string $date,
        Volunteer $volunteer,
        string $time_in,
        string $time_out

    ): int {

        $carbonTime = Carbon::createFromFormat("H:i", $time_in);

        $allTimesheets = $this->timesheet::where([

            'date' => $date,
            'period_id' => $period->id,
            'volunteer_id' => $volunteer->id,

        ])
            ->where(function ($query) use ($time_in, $time_out) {
                $query->orWhereRaw("? between time_in AND time_out", [$time_in])
                    ->orWhereRaw("(? = time_in or ? = time_out)", [$time_in, $time_in])
                    ->orWhereRaw("? between time_in AND time_out", [$time_out])
                    ->orWhereRaw("(? = time_in or ? = time_out)", [$time_out, $time_out]);
            })
            ->count();

        return $allTimesheets;
    }

    /**
     * Create Error Bag Of time and site that already existed.
     * @param  array  $timesheet
     * @return Array
     */
    public function createErrorBag(array $timesheet): array
    {

        return [
            "date" => $timesheet['date'],
            "site" => $timesheet['site'],
        ];

    }

}
