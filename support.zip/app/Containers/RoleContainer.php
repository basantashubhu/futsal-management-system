<?php

namespace App\Container;

use App\Models\Role;

class RoleContainer{

	protected $role;

	public function __construct(Role $role){

		$this->role = $role;

		$this->user = auth()->user();

	}

	public function hasRole(array $roles) : bool{

	    $givenRolesID = $this->role::whereIn('name', $roles)->pluck('id');

	    return $givenRolesID->contains($this->user->role_id);

	}

}