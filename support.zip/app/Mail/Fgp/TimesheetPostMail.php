<?php

namespace App\Mail\Fgp;

use App\Models\EmailLog;
use App\Models\EmailTemplate;
use App\Models\File;
use App\Models\User;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class TimesheetPostMail extends Mailable
{
    use Queueable, SerializesModels;
    private $file, $user, $counties, $periods;
    /**
     * Create a new message instance.
     * @param string $xlsm generated xlsm file path
     * @param string $subject mail subject
     * @param string|bool $link file download link | bool as no link
     * @param User $user Posted by user object
     * @return void
     */
    public function __construct($data)
    {
        $this->file = $data['file'];
        $this->subject = $data['subject'];
        $this->user = $data['user'];
        $this->counties = $data['counties'];
        $this->periods = $data['periods'];
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $html = EmailTemplate::where('temp_code', 'timesheets_post_email')->first()->temp_html ?? '';
        $data = [
            'first_name' => $this->user->first_name,
            'middle_name' => $this->user->middle_name,
            'last_name' => $this->user->last_name,
            'period_no' => $this->periods->pluck('period_no')->implode(', Period #'),
            'counties' => $this->counties->implode(', '),
        ];

        foreach ($data as $key => $value) {
            $html = str_replace('{' . $key . '}', $value, $html);
        }
        $block = $this->periods->map(function ($period) {
            $row = '';
            $date = implode(' to ', [date_create($period->start_date)->format('m/d'), date_create($period->end_date)->format('m/d/Y')]);
            $postDate = date('m/d/Y');
            foreach ($period->supervisors as $supervisor) {
                $row .= "<tr><td>$supervisor</td><td>$date</td><td>$postDate</td></tr>";
            }
            return $row;
        })->implode('');

        $html = str_replace('<tr><td>{supervisor_list}</td></tr>', $block, $html);

        $dispatch = $this->html($html)
            ->subject($this->subject);
        if (file_exists($this->file)) {
            $dispatch->attach($this->file, ['as' => basename($this->file)]);
        }
        $this->log_email($user = auth()->user(), $user->email, $this->subject, $html, $this->file);
        return $dispatch;
    }

    protected function log_email($model, $email, $sub, $message, $file = null)
    {
        $emailLog = new EmailLog();
        $emailLog->table = $model->getTable();
        $emailLog->table_id = $model->id;
        $emailLog->from = config('mail.from.address');
        $emailLog->to = $email;
        $emailLog->sub = $sub;
        $emailLog->msg = $message;
        $emailLog->sent_status = 'Success';
        $emailLog->sent_date = date('Y-m-d');
        $emailLog->save();
        if ($file && file_exists($file)) {
            File::create([
                'table' => $emailLog->getTable(),
                'table_id' => $emailLog->id,
                'document_segment' => 'Mail file',
                'file_name' => basename($file),
                'document_type' => 'xlsm',
            ]);
        }
    }
}
