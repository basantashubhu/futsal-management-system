<?php

namespace App\Mail\Fgp;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class ApprovalMail extends Mailable implements ShouldQueue
{
    use Queueable, SerializesModels;
    public $user;
    public $data;
    public $stipend;
    public $created_user;
    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($created_user, $user, $stipend, $data)
    {
        $this->user = $user;
        $this->data = $data;
        $this->stipend = $stipend;
        $this->created_user = $created_user;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->view('default.fgp.mailer_template.timesheetApproval')->with(['data' => $this->data, 'period'=>$this->stipend, 'created_user'=>$this->created_user, 'user'=>$this->user])
                    ->subject('eStipend Alert - Timesheets for Approvals for Period #'.$this->stipend->period_no.' - '.ucfirst($this->user->member->first_name). ' '. ucfirst($this->user->member->last_name) .' APPROVED')
                    ->from('noreply@zeuslogic.com', emailNameFrom('email_from_name'));
    }
}
