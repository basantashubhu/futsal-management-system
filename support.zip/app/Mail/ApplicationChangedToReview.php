<?php

namespace App\Mail;

use App\Lib\Template\TemplateMerge;
use App\Models\EmailTemplate;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class ApplicationChangedToReview extends Mailable
{
    use Queueable, SerializesModels;
    private $application;
    public $template;

    /**
     * ApplicationChangedToReview constructor.
     * @param $application
     */
    public function __construct($application)
    {
        $this->application = $application;
        if(EmailTemplate::where('temp_code', 'Status change to review')->where('temp_type', 'Custom_Email')->first()){
            $this->template = EmailTemplate::where('temp_code', 'Status change to review')->where('temp_type', 'Custom_Email')->first();
        }
        else{
            $this->template = EmailTemplate::where('temp_code', 'Status change to review')->first();
        }
        $this->merge();
    }

    /**
     * Merge Template
     */
    public function merge()
    {
        $this->template = TemplateMerge::makeTemplate($this->template, $this->application);
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->view('default.emails.statusChange')
            ->with([
                'template' => $this->template,
            ])->from('noreplay@zeuslogic.com',emailNameFrom('email_from_name'));
    }
}
