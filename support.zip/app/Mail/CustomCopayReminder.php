<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class CustomCopayReminder extends Mailable
{
    use Queueable, SerializesModels;

    public $template,$subject;


    /**
     * ApplicationApproved constructor.
     * @param $data
     * @param $subject
     */
    public function __construct($template,$subject='Copay Reminder')
    {

        $this->template = $template;
        $this->subject = $subject;
    }


    /**
     * Build the message.
     *
     * @return mixed
     */
    public function build()
    {
        $email = $this
            ->subject($this->subject)
            ->view('default.emails.statusChange')
            ->with([
                'template' => $this->template,
            ])->from('noreplay@zeuslogic.com',emailNameFrom('email_from_name'));
        return $email;
    }
}
