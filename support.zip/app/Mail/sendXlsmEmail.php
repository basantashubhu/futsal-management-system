<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class sendXlsmEmail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public $obj;

    public function __construct($obj)
    {
        $this->obj = $obj;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $email = $this->subject($this->obj->subject)
            ->view('default.emails.demo');

        foreach ($this->obj->attachment as $value):
            $path = storage_path('reports' . DIRECTORY_SEPARATOR . $value);

            if (!file_exists($path)) {
                continue;
            }

            $email->attach($path, [
                'as' => $value,
            ]);
        endforeach;
        return $email;
    }
}
