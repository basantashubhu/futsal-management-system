<?php

namespace App\Mail;

use App\Lib\Template\TemplateMerge;
use App\Models\EmailTemplate;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class SurgeryCertificateIssue extends Mailable
{
    use Queueable, SerializesModels;
    private $application;
    public $template;
    public $attachment;


    /**
     * ApplicationApproved constructor.
     * @param $application
     * @param $attachment
     */
    public function __construct($application, $attachment)
    {
        $this->application = $application;
        $this->attachment = $attachment;
        if(EmailTemplate::where('temp_code', 'SP Cert Mail')->where('temp_type', 'Custom_Email')->first()){
            $this->template = EmailTemplate::where('temp_code', 'SP Cert Mail')->where('temp_type', 'Custom_Email')->first();
        }
        else{
            $this->template = EmailTemplate::where('temp_code', 'SP Cert Mail')->first();
        }
        $this->merge();
    }

    public function merge()
    {
        $this->template = TemplateMerge::makeTemplate($this->template, $this->application);
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $email = $this->view('default.emails.statusChange')
            ->subject('New Application Received')
            ->with([
                'template' => $this->template,
            ])->from('noreplay@zeuslogic.com',emailNameFrom('email_from_name'));
        $this->attachment=json_decode($this->attachment);
        foreach ($this->attachment as $attach):
            $path=storage_path('uploads'.DIRECTORY_SEPARATOR.$attach->file_name);
            $ext = pathinfo($path, PATHINFO_EXTENSION);
            $email->attach($path, [
                    'as'=>$attach->document_title.'.'.$ext,
                    'mime' => 'application/pdf'
                ]
            );
        endforeach;
        return $email;
    }
}
