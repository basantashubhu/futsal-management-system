<?php

// namespace Helpers;

use App\Models\Fgp\Holiday;
use App\Models\Fgp\StipendItem;
use App\Models\Fgp\Volunteer;
use App\Models\LayoutBuilder;
use App\Models\Role;
use App\Models\User;
use Illuminate\Support\Facades\DB;

/**
 * DEVELOPERS
 * ----------------------------------------------
 * SUMAN  THAPA - LEAD  (NEPALNME@GMAIL.COM)
 * ----------------------------------------------
 * - PRABHAT GURUNG
 * - BASANTA TAJPURIYA
 * - RAKESH SHRESTHA
 * - MANISH BUDDHACHARYA
 * - LEKH RAJ RAI
 * - ASCOL PARAJULI
 * -----------------------------------------------
 * Created On: 3/12/2019
 *
 * THIS INTELLECTUAL PROPERTY IS COPYRIGHT Ⓒ 2019
 *  SHUBHU TECH PVT LTD , NEPAL. ALL RIGHT RESERVED
 */

//

/**
 * loop through data array and set property to target object
 * @param       $target
 * @param array $data
 * @param bool  $save
 * @return mixed $target
 */
function save_update($target, $data = array(), $save = true)
{
    foreach ($data as $key => $value) {
        $target->$key = $value;
    }

    $save = $save ? $target->save() : false;
    return $target;
}

/**
 * custom debugger function which simply print data and end execution
 * @param mixed ...$args
 */
function debugger(...$args)
{
    echo '<pre>';
    foreach ($args as $arg) {
        print_r($arg);
    }

    echo '</pre>';
    exit;
}

/**
 * format given date to default format configured in config/app.php
 * @param        $date
 * @param string|bool $format
 * @return false|string
 */
function newDate($date, $format = false)
{
    $config_format = config('app.date-format') ?: 'm/d/Y';
    $format = $format ?: $config_format;
    if ($date instanceof \Carbon\Carbon) {
        return $date->format($format);
    }

    $date = is_string($date) ? strtotime($date) : $date;
    return date($format, $date ?: strtotime('today'));
}

/**
 * automatic dateRange generator
 * @param $year
 * @return string
 */
function dateRange($year)
{
    return newDate(strtotime("1 january $year")) . ' - ' . newDate(strtotime("31 dec $year"));
}

/**
 * numeric format with default 2 decimal points
 * @param     $number
 * @param int $decimals
 * @return string
 */
function numeric_format($number, $decimals = 2)
{
    if (!is_numeric($number)) {
        return '';
    }

    return number_format($number, $decimals, '.', '');
}

/**
 * carbon helper for carbon instance
 * @param $dateString
 * @return \Carbon\Carbon
 */
function carbon($dateString)
{
    if (gettype($dateString) === 'integer') {
        return \Carbon\Carbon::createFromTimestamp($dateString);
    }

    return \Carbon\Carbon::parse($dateString);
}

/**
 * finds the key in $collection and returns the value if not returns $default value
 * @param      $collection
 * @param      $key
 * @param null $default
 * @return null|$property->value|$property->value2
 */
function program($collection, $key, $default = null)
{
    $property = $collection->firstWhere('property', $key);
    return $property ? ($property->value ?: $property->value2): $default;
}

/**
 * converts decimal to numeric total hours i.e hh:mm
 * @param $dec
 * @return string
 */
function total_hrs($dec)
{
    if (!is_numeric($dec)) {
        return $dec;
    }

    $hour = floor($dec);
    $min = round(60 * ($dec - $hour));
    $hour = preg_replace('/(\d)(?=(\d{3})+(?!\d))/', '$1,', $hour);
    return sprintf('%s:%s', $hour, $min < 10 ? "0$min" : $min);
}

/**
 * format cell in us standard
 * @param $cell
 * @return string
 */
function format_cell($cell): string
{
    return preg_replace('#(\d{3})(\d{3})(\d{4})#', '($1) $2-$3', $cell);
}

function is_super_admin()
{
    if (!auth()->check()) {
        return false;
    }

    if (auth()->user()->role_id === 1) {
        return true;
    }

    return false;
}

function override_timesheet()
{
    return strtolower(getSiteSettings('timesheets_override')) === "all";
}

function site_assigned($volunteer_site_id, $timesheet_override = false)
{

    $timesheet_override = $timesheet_override ?: override_timesheet();

    if (auth()->user()->role_id === 1 || auth()->user()->role_id === 7 || $timesheet_override) {
        return true;
    }

    return auth()->user()->hasSite($volunteer_site_id);
}

function holiday_name($date)
{

    $hol_name = Holiday::where('hol_date', $date)->where('is_deleted', 0)->first();

    return $hol_name ? ucfirst($hol_name->name) : '';
}

function consistsOfRole($role_name)
{

    $auth_id = auth()->id();

    return User::find($auth_id)->role_id === Role::where('name', $role_name)->first()->id;
}

function fetch_auth_name($id)
{

    $user = User::find($id);

    return $user->fullName();
}

if (!function_exists('format_to_us_date')) {
    function format_to_us_date($dateToFormat)
    {
        return date_create($dateToFormat)->format('m/d/Y');
    }
}

function filter_join($super, $props, $delimeter = ', ')
{
    $arrayFunc = function ($props, $super) {
        $result = [];
        foreach ($props as $index) {
            if (isset($super[$index]) && trim($super[$index])) {
                $result[] = trim($super[$index]);
            }
        }
        return $result;
    };

    $objectFunc = function ($props, $super) {
        $result = [];
        foreach ($props as $index) {
            if (isset($super->$index) && trim($super->$index)) {
                $result[] = trim($super->$index);
            }
        }
        return $result;
    };

    $result = getType($super) == 'array' ? $arrayFunc($props, $super) : $objectFunc($props, $super);
    return implode($delimeter, $result);
}

function base64_logo()
{
    return require 'base64logo.php';
}

/**
 * Finds most reliable item
 *
 * @param string $item_name
 * @param string $category
 * @return App\Models\Fgp\StipendItem
 */
function IntelligentItemLookup($item_name, $category)
{
    if (strpos(strtolower($category), 'food') !== false) {
        return item_food($item_name);
    }
    if (strpos(strtolower($category), 'mileage') !== false) {
        return item_mileage($item_name);
    }
}

function item_food($item_name)
{
    $item = app('App\Models\Fgp\StipendItem')->where('category', 'Food Service')
        ->where('item_name', 'like', "%$item_name%")
        ->orderByDesc('created_at')
        ->first();
    if ($item) {
        return $item;
    }
    $cases = explode(' ', preg_replace('/[^\D]/', '', $item_name));
    $selectQuery = '';
    foreach ($cases as $i => $v) {
        $selectQuery .= ($i != 0 ? '+' : '') . " ( item_name like  '%$v%' ) ";
    }
    $raw = app('App\Models\Fgp\StipendItem')->select('*')->selectRaw($selectQuery . 'as total_cases')
        ->where('category', 'Food Service')
        ->orderByDesc('total_cases')->first();
    if ($raw) {
        return $raw;
    }

    throw new Exception('Timesheet item "' . $item_name . '" doesn\'t exists.', 404);
}

function item_mileage($item_name)
{
    $item = app('App\Models\Fgp\StipendItem')->where('category', 'Mileage Reimbursements')
        ->where('item_name', 'like', "%$item_name%")
        ->orderByDesc('created_at')
        ->first();
    if ($item) {
        return $item;
    }
    $cases = explode(' ', preg_replace('/[^\D]/', '', $item_name));
    $selectQuery = '';
    foreach ($cases as $i => $v) {
        $selectQuery .= ($i != 0 ? '+' : '') . " ( item_name like  '%$v%' ) ";
    }
    $raw = app('App\Models\Fgp\StipendItem')->select('*')->selectRaw($selectQuery . 'as total_cases')
        ->where('category', 'Mileage Reimbursements')
        ->orderByDesc('total_cases')->first();
    if ($raw) {
        return $raw;
    }

    throw new Exception('Timesheet item "' . $item_name . '" doesn\'t exists.', 404);
}

function holiday_item()
{
    return StipendItem::where('item_code', 'Holiday')->firstOrFail();
}

/**
 * Old template formatter
 *
 * @param array $template
 * @return array
 */
function formatDefaultTemplate($template): array
{
// dd($template);
    $data = [];

    foreach ([$template] as $key => $temp) {

        foreach ($temp as $k => $items) {

            foreach ($items as $itemKey => $item) {

                if ($itemKey === "days") {
                    $data[$k][$itemKey] = $item;
                    continue;
                }

                if ($itemKey === "items") {
                    foreach ($item as $stipend_type => $stipends) {

                        //Stipend code = travel_code & stipend_item = array of site_id and type
                        foreach ($stipends as $stipend_code => $stipend_value_arr) {

                            foreach ($stipend_value_arr as $site_id => $val) {

                                foreach ($val as $kv => $v) {
                                    $data[$k]['sites'][$site_id]['items'][$stipend_type][$stipend_code] = $v;
                                }
                            }
                        }
                    }
                    continue;
                }

                foreach ($item as $site_id => $item_value) {

                    $data[$k]['sites'][$site_id][$itemKey] = is_array($item[$site_id]) ? $item[$site_id][0] : $item[$site_id];
                }
            }
        }
    }

    return $data;
}

/**
 * Calculates extended sick leave
 *
 * @param Volunteer $volunteer
 * @return string
 */
function extented_sick_leave(Volunteer $volunteer)
{
    $esl = siteSettingsValue('extented_sick_leave');
    $stipendItem = StipendItem::find($esl);
    if (!$stipendItem) {
        return false;
    }
    $esl_value = DB::table('timesheets')
        ->where('type_label', $stipendItem->id)
        ->where('status', 'posted')
        ->where('volunteer_id', $volunteer->id)
        ->sum(DB::raw('time_to_sec(total_hrs)/3600'));

    return total_hrs($esl_value);
}

if (!function_exists('globalFontSize')) {
    function globalFontSize()
    {
        $layout = LayoutBuilder::where('setting_label', "global_font_size")->where('user_id', auth()->id())->first();
        if ($layout) {
            if ($layout->applied_value == "default") {
                return null;
            } else {
                return $layout->applied_value;
            }
        } else {
            return null;
        }
    }
}

// let [startHour, startMin] = start.split(":");
// startHour = Number(startHour);
// const plusHour = this.time_in ? parseInt(this.time_in) >= 12 : false;
// if (startHour < 6 || plusHour) {
//     startHour += 12;
// }

// let [endHour, endMin] = end.split(":");
// endHour = Number(endHour);
// if (endHour - startHour < 0 || (endHour < 6 && startHour >= 6))
//     endHour += 12;

// end = [endHour, endMin].join(":");

if (!function_exists('intelligent_time')) {
    function intelligent_time($timeIn, $timeOut, $type)
    {

        $start = explode(":", $timeIn);
        $end = explode(":", $timeOut);

        $startHour = (int) $start[0];
        $endHour = (int) $end[0];

        if ($startHour >= 6 && $startHour < 12) {
            //timeIn is am
            $startStamp = " am";

        } else {
            //timeIn is pm
            $startStamp = " pm";
        }

        if ($endHour < $startHour && $endHour < 12) {
            $endStamp = " pm";

        } else if ($endHour >= 12) {
            $endStamp = " pm";
        } else {
            $endStamp = " am";
        }

        if ($type == "time_in") {
            return $startHour . ":" . $start[1] . $startStamp;
        }
        return $endHour . ":" . $end[1] . $endStamp;

    }
}
