<?php

use App\Models\Fgp\ApprovalFlow;
use App\Models\Fgp\ApprovalTable;
use App\Models\Fgp\PayPeriod;
use App\Models\Fgp\Timesheet;

function can_access_ts($timesheet = null){

	$role = auth()->user()->role_id;


	if($role === 1) return true;


	if(is_null($timesheet)){

		return $role === 3 ? true : false;


	} // i.e no timesheet is generated only supervisor can acess

	$ts = Timesheet::find($timesheet);

	$current_apprv_id = $ts->approval_flow_id;

	if(!$current_apprv_id){
		$current_apprv_id = 1;
	}

	switch ($ts->status) {
		case 'New':
		case 'In Process':

			$next_approval_flow_ids = ApprovalFlow::where('seq_num','>=', $current_apprv_id) //prevData = $current_apprv_id + 1
				->get() 
				->map(function($next_apprv_role){
					return $next_apprv_role->role_id;
				})->all();

			return isCurrentApprover($next_approval_flow_ids);

			break;

		case 'Closed':

			return false;

			break;

		case 'Posted':

			return false;

			break;

		case 'Decline':

			/* Declined is done by current approval_flow_id */

			$prev_approval_flow = ApprovalFlow::where('seq_num', $current_apprv_id - 1)->first();

			return $prev_approval_flow->role_id === $role ? true : false;
		
		default:
			break;
	}

	

}

function isCurrentApprover($next_approval_flows){

	if(in_array(auth()->user()->role_id, $next_approval_flows)){
		return true;
	}

	return false;

}

