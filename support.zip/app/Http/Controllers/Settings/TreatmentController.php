<?php

namespace App\Http\Controllers\Settings;

use App\Lib\Notification\Notification;
use App\Models\Application;
use App\Models\ApplicationPetTreatments;
use App\Models\Pet;
use App\Models\Rate;
use App\Models\RatePlan;
use Illuminate\Http\Request;
use App\Http\Controllers\BaseController;
use App\Http\Requests\TreatmentRequest;
use App\Repo\TreatmentRepo;
use App\Models\Treatment;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Invoice\InvoiceController;

class TreatmentController extends BaseController
{
    private static $repo = null;

    private $clayout = "";

    public function __construct()
    {
        parent::__construct();
        $this->clayout = $this->layout . '.pages.settings.treatment.';
    }

    /**
     * @param $model
     * @return TreatmentRepo|null
     */
    private static function getInstance($model)
    {
        if (self::$repo == null)
            self::$repo = new TreatmentRepo($model);
        return self::$repo;
    }

    public function index()
    {
        return view($this->clayout . 'index');
    }

    public function getAll(Request $request)
    {
        $data = self::getInstance('Treatment')->selectDataTable($request);
        return $data;
    }

    public function create()
    {
        return view($this->clayout . 'modal.add');
    }

    public function store(TreatmentRequest $request)
    {
        $res = self::getInstance('Treatment')->saveUpdate($request);
        if ($res)
            return $this->response("Treatment Added Successfully", "view", 200);
        else
            return $this->response("Treatment Cant Added.", "view", 422);
    }

    public function edit(Treatment $treatment)
    {
        return view($this->clayout . 'modal.edit', compact('treatment'));
    }

    public function update(TreatmentRequest $request, Treatment $treatment)
    {
        $res = self::getInstance($treatment)->saveUpdate($request);
        if ($res)
            return $this->response("Treatment Updated Successfully", "view", 200);
        else
            return $this->response("Treatment Can't Updated.", "view", 422);
    }

    public function delete(Treatment $treatment)
    {
        return view($this->clayout . 'modal.delete', compact('treatment'));
    }

    public function destroy(Treatment $treatment)
    {
        $res = self::getInstance($treatment)->softDelete();

        if ($res)
            return $this->response("Treatment Deleted Successfully", "view", 200);
        else
            return $this->response("Treatment Can't Delete.", "view", 422);
    }

    public function view(Treatment $treatment)
    {
        return view($this->clayout . 'modal.view', compact('treatment'));
    }

    public function getTreatments()
    {
        $treatments = self::getInstance('Treatment')->select();
        return $this->responseLookup($treatments, ["treatment_name"]);
    }

    /**
     * Treatments Complication
     */
    public function getComplication()
    {
        $clients = Treatment::where('is_deleted', false)->get();
        return $this->responseLookup($clients, ["treatment_name"]);
    }

    /*
     * Get Treatment By Id
     */
    public function getTreatmentById(Treatment $treatment, Pet $pet)
    {
        $species = $pet->species;
        $sex = $pet->sex;

        $ratePlan = DB::table('rate_plan')
            ->join('rates', 'rates.plan_id', 'rate_plan.id')
            ->join('rate_type', 'rate_type.id', 'rates.rate_type_id')
            ->select('cost', 'rate_metrics', 'rate_metrics_type')
            ->where([
                ['rate_plan.is_active', 1],
                ['rates.animal_type', $species],
                ['rates.sex', $sex],
                ['rates.treatment_id', $treatment->id]
            ])->get();


        $cost = 0;
        foreach ($ratePlan as $rate) {
            $res = $this->performComparision($pet->weight, $rate->rate_metrics);
            if ($res)
                $cost = $rate->cost;
        }
        return $cost;
    }


    //to perform Comparision
    protected function performComparision($data, $compareString)
    {
        $list = ['<=', '==', '>'];
        foreach ($list as $l) {
            if (hasOperator($compareString, $l)) {
                $d = (int)str_replace($l, '', $compareString);
                if (is_int($d) && $d != 0) {
                    switch ($l) {
                        case '<':
                            return $data < $d;
                        case '<=':
                            return $data <= $d;
                        case '>':
                            return $data > $d;
                        case '>=':
                            return $data >= $d;
                        case '==':
                            return $data == $d;
                        default:
                            return false;
                    }
                } else
                    return false;

            }
        }
        return false;
    }

    public function saveTreatment(Request $request, Application $application)
    {
        $result = [];
        $r = [];
        DB::beginTransaction();
        try {
            $datas = $request->pet_id;
            foreach ($datas as $key => $value):
                if ($request->treatment_name[$key] != '' || $request->treatment_name[$key] != null):
                    if ($request->treatment_date[$key] != '' || $request->treatment_date[$key] != null):
                        if ($request->approved_amt[$key] != '' || $request->approved_amt[$key] != null):
                            array_push($r, array(
                                'id' => $value,
                                'apt_id' => $request->treatment_id[$key],
                                'treatment_name' => $request->treatment_name[$key],
                                'treatment_date' => $request->treatment_date[$key],
                                'rate_amt' => $request->rate_amt[$key],
                                'billed_amt' => $request->billed_amt[$key],
                                'approved_amt' => $request->approved_amt[$key]
                            ));
                        endif;
                    endif;
                endif;
            endforeach;
            $prevApt = ApplicationPetTreatments::where([
                ['application_id', $application->id],
            ])->first();

            $invoice = new InvoiceController();

            foreach ($r as $v) {
                $treatmentId = '';
                $treatment = Treatment::where('treatment_name', $v['treatment_name'])->first();
                if (isset($treatment->id)):
                    $treatmentId = $treatment->id;
                    $treat = $treatment;
                else:
                    $treat = new Treatment;
                    $treat->treatment_name = $v['treatment_name'];
                    $treat->treatment_type = 'custom';
                    $treat->is_must = false;
                    $treat->userc_id = auth()->id();
                    $treat->save();

                    $treatmentId = $treat->id;

                    $rate = new Rate;
                    $rate->treatment_id = $treat->id;
                    $rate->cost = $v['rate_amt'];
                    $rate->plan_id = 1;
                    $rate->rate_type_id = 1;
                    $rate->userc_id = auth()->id();
                    $rate->save();
                endif;


                $vetId = '';
                if (isset($v['apt_id'])):
                    $apt = ApplicationPetTreatments::find($v['apt_id']);
                    $apt->treatment_id = $treat->id;
                    $apt->treatment_date = date('Y-m-d', strtotime($v['treatment_date']));
                    $apt->billed_amt = $v['billed_amt'];
                    $apt->approved_amt = $v['approved_amt'];
                    $apt->save();
                    $vetId = $apt->vet_id;;

                    ApplicationPetTreatments::where([
                        ['application_id', $application->id],
                        ['pet_id',$v['id']]
                    ])->whereNull('treatment_id')->delete();
                else:
                    $apt = new ApplicationPetTreatments;
                    $apt->pet_id = $v['id'];
                    $apt->application_id = $application->id;
                    $apt->treatment_id = $treat->id;
                    $apt->treatment_date = date('Y-m-d', strtotime($v['treatment_date']));
                    $apt->billed_amt = $v['billed_amt'];
                    $apt->approved_amt = $v['approved_amt'];
                    $apt->vet_id = $prevApt->vet_id;
                    $apt->save();

                    ApplicationPetTreatments::where([
                        ['application_id', $application->id],
                        ['pet_id',$v['id']]
                    ])->whereNull('treatment_id')->delete();

                    $vetId = $prevApt->vet_id;;
                endif;

                $pet = Pet::find($v['id']);
                $res=$invoice->generateByTreatmentCustom($application, $pet, $vetId, $treatmentId, $v['approved_amt']);
                if($res instanceof \Exception)
                    throw $res;
            }

            //pull up the count of treatment list
            $treatmentCount = ApplicationPetTreatments::where('application_id', $application->id)->count();

            //
            $invItemCount = $application->invoiceItem->count();

            if ($invItemCount >= $treatmentCount) {
                $application->status = 'Invoiced';

            } else {
                $application->status = 'Partial Invoiced';
            }

            $application->save();
            Notification::applicationStatusChanged($application, $application->status);

            DB::commit();
            return $this->response("Treatments added Successfully", 'view', 200);
        } catch (\Exception $e) {
            DB::rollBack();
            throw $e;
            return $this->response($e->getMessage(), 'view', 500);
        }

    }

    public function saveTreatmentPet(Request $request, Application $application, Pet $pet)
    {
        DB::beginTransaction();
        try {
            $invoice = new InvoiceController();
            $p = ApplicationPetTreatments::where([
                    ['application_id', $application->id],
                    ['pet_id', $pet->id]
                    ])->first();
            if($request->rabies == 1){
                $treatment = Treatment::where('treatment_name', 'Rabbies')->first();
                $rabies = new ApplicationPetTreatments;
                $rabies->application_id = $application->id;
                $rabies->vet_id = $p->vet_id;
                $rabies->pet_id = $pet->id;
                $rabies->treatment_id = $treatment->id;
                $rabies->treatment_date = date('Y-m-d', strtotime($request->rabies_date));
                $rabies->billed_amt = $request->rabbies_amt;
                $rabies->save();
                $res=$invoice->generateByTreatmentCustom($application, $pet, $p->vet_id, $treatment->id, $request->rabbies_amt);
                if($res instanceof \Exception)
                        throw $res;
            }
            if($request->complication == 'yes'){
                $treatment1 = Treatment::where('treatment_name', $request->complication_type)->first();
                $comp = new ApplicationPetTreatments;
                $comp->application_id = $application->id;
                $comp->vet_id = $p->vet_id;
                $comp->pet_id = $pet->id;
                $comp->treatment_id = $treatment1->id;
                $comp->billed_amt = $request->amt;
                $comp->save();
                $res1=$invoice->generateByTreatmentCustom($application, $pet, $p->vet_id, $treatment1->id, $request->amt);
                if($res1 instanceof \Exception)
                        throw $res1;
            }
        //pull up the count of treatment list
            $treatmentCount = ApplicationPetTreatments::where('application_id', $application->id)->count();

            //
            $invItemCount = $application->invoiceItem->count();

            if ($invItemCount >= $treatmentCount) {
                $application->status = 'Invoiced';

            } else {
                $application->status = 'Partial Invoiced';
            }

            $application->save();
            if (getSiteSettings('application_status_change') && getSiteSettings('application_status_change') == 'True') {
                Notification::applicationStatusChanged($application, $application->status);
            }

            DB::commit();
            return $this->response("Treatments added Successfully", 'view', 200);
        } catch (\Exception $e) {
            DB::rollBack();
            throw $e;
            return $this->response($e->getMessage(), 'view', 500);
        }

    }

    /*
     * Invoice By individual pet
     */
    public function generateInvoiceByPet(Application $application, Pet $pet, $multi = false)
    {
        $invoice = new InvoiceController();
        DB::beginTransaction();
        try {
            $invoice->storeByPet($application, $pet);
            DB::commit();
            return $this->response('Invoice generated successfully', 'view', 200);
        } catch (\Exception $e) {
            throw $e;
            DB::rollBack();
            if ($multi) {
                return true;
            } else {
                return $this->response($e->getMessage(), 'view', 422);
            }
        }
    }

    public function remoAppTreatment($id)
    {
        $apt = ApplicationPetTreatments::find($id);
        $apt->is_deleted = true;
        $apt->save();
        return $this->response('Treatments Deleted Successfully', 'view', 200);
    }

    protected function seperateTreatments($treatments)
    {
        if (array_key_exists('treatment_name', $treatments)) {
            $array = [];
            $count = count($treatments['treatment_name']);
            for ($i = 0; $i < $count; $i++) {
                foreach ($treatments as $key => $treatment) {
                    $array[$i][$key] = $treatment[$i];
                }
            }
            return $array;
        }
        return false;
    }

    public function storeTreatment($petId, Application $application, $treatments = array())
    {
        if (count($treatments) <= 0)
            return $this->response('Please select treatment first', 'view', 422);

        $prevApt = ApplicationPetTreatments::where([
            ['application_id', $application->id],
        ])->first();

        $treatArr = [];

        $aptInv = ApplicationPetTreatments::where([
            ['application_id', $application->id],
            ['pet_id', $petId],
        ])->first();

        ApplicationPetTreatments::where([
            ['application_id', $application->id],
            ['pet_id', $petId],
        ])->delete();
        foreach ($treatments as $treatment):
            $data = array(
                'application_id' => $application->id,
                'pet_id' => $petId,
                'vet_id' => $prevApt->vet_id,
                'treatment_id' => $treatment,
                'created_at' => date('Y-m-d H:i:s')
            );

            array_push($treatArr, $data);
        endforeach;
        ApplicationPetTreatments::insert($treatArr);
    }

    public function getTreatment($val = '')
    {
        $treatments = Treatment::where('treatment_name', 'like', $val . '%')->get();
        return $this->responseLookup($treatments, ["treatment_name"]);
    }

}
