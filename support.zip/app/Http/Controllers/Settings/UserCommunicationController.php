<?php

namespace App\Http\Controllers\Settings;

use App\Http\Controllers\BaseController;
use App\Models\CommunicationPrefrence;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\User;

class UserCommunicationController extends BaseController
{
    public function store(Request $request, $id)
    {
//        dd($request->all());
        $comm = $this->getSettings($id);
        $comm->table = 'users';
        $comm->table_id = $id;
        $comm->user_id = $id;
        $code = $request->code;
        $comm->$code = $request->is_true;
        $comm->save();
        return $this->response("Settings Added SuccessFully", "view", 200);
    }

    public function getSettings($id)
    {
        $user = User::find($id);
        if ($preference = $user->communicationpreference) return $preference;
        return new CommunicationPrefrence;
    }
}
