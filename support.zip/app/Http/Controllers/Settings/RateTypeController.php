<?php

namespace App\Http\Controllers\Settings;

use App\Http\Controllers\BaseController;
use App\Models\RateType;
use App\Repo\RateTypeRepo;
use App\Http\Requests\RateTypeRequest;
use Illuminate\Http\Request;


class RateTypeController extends BaseController
{
    private static $repo = null;
    private $clayout = "";

    public function __construct()
    {
        parent::__construct();
        $this->clayout = $this->layout . '.pages.settings.rateType';
    }

    /**
     * @param $model
     * @return RatePlanRepo|null
     */
    private static function getInstance($model)
    {
        if (self::$repo == null)
            self::$repo = new RateTypeRepo($model);
        return self::$repo;
    }

    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function index()
    {
        return view($this->clayout . '.index');
    }

    public function allRateType(Request $request)
    {
        return self::getInstance('RateType')->selectDataTable($request);
    }

    public function create()
    {
        return view($this->clayout . '.modal.add');
    }

    public function edit(RateType $rate_type)
    {
        return view($this->clayout . '.modal.edit', compact('rate_type'));
    }

    public function store(RateTypeRequest $request)
    {
        $res = self::getInstance('RateType')->saveUpdate($request);
        if ($res)
            return $this->response("Rate Type Added SuccessFully", "view", 200);
        else
            return $this->response("Can't Add Rate Type", 'view', 422);
    }

    public function update(RateTypeRequest $request, RateType $rate_type)
    {
        $res = self::getInstance($rate_type)->saveUpdate($request);
        if ($res)
            return $this->response("Rate Type Updated SuccessFully", "view", 200);
        else
            return $this->response("Can't Update Rate Type", 'view', 422);
    }

    public function delete(RateType $rate_type)
    {
        return view($this->clayout . '.modal.delete', compact('rate_type'));
    }

    public function destroy(RateType $rate_type)
    {
        $res = self::getInstance($rate_type)->softDelete();

        if ($res)
            return $this->response("Rate Type Deleted SuccessFully", "view", 200);
        else
            return $this->response("Can't Delete Rate Type", 'view', 422);
    }

    public function getRateTypes()
    {
        $rate_types = self::getInstance('RateType')->select();
        return $this->responseLookup($rate_types, ["name"]);
    }
}
