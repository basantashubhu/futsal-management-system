<?php

namespace App\Http\Controllers\Settings;

use App\Http\Controllers\BaseController;
use App\Models\RatePlan;
use App\Repo\RatePlanRepo;
use Illuminate\Http\Request;
use App\Http\Requests\RatePlanRequest;

class RatePlanController extends BaseController
{
    private static $repo = null;
    private $clayout = "";

    public function __construct()
    {
        parent::__construct();
        $this->clayout = $this->layout . '.pages.settings.ratePlan';
    }

    /**
     * @param $model
     * @return RatePlanRepo|null
     */
    private static function getInstance($model)
    {
        if (self::$repo == null)
            self::$repo = new RatePlanRepo($model);
        return self::$repo;
    }

    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function index()
    {
        $rate_plan = RatePlan::where('is_deleted', false)->where([
            ['is_active',1],['is_custom',0]
        ])->orderBy('created_at', 'asc')->first();
        return view($this->clayout . '.index', compact('rate_plan'));
    }

    public function allRatePlan(Request $request)
    {
        return self::getInstance('RatePlan')->selectDataTable($request);
    }

    public function create()
    {
        return view($this->clayout . '.modal.add');
    }

    public function edit(RatePlan $rate_plan)
    {
        return view($this->clayout . '.modal.edit', compact('rate_plan'));
    }

    public function store(RatePlanRequest $request)
    {
        $data=$request->all();

        $data['start_date']= date('Y-m-d',strtotime($data['start_date']));
        $data['end_date']= date('Y-m-d',strtotime($data['end_date']));
        $res = self::getInstance('RatePlan')->saveUpdate($data);
        $this->deactiveOther($res->id);
        if ($res)
            return $this->response("Rate Plan Added SuccessFully", "view", 200);
        else
            return $this->response("Can't Add Rate Plan", 'view', 422);
    }

    private function deactiveOther($id)
    {
        $res = RatePlan::where('id', '!=', $id)->where('is_custom',0)->get();
        foreach($res as $r):
            $r->is_active = false;
            $r->save();
        endforeach;
    }

    public function update(RatePlanRequest $request, RatePlan $rate_plan)
    {
        $data=$request->all();
        $data['start_date']= date('Y-m-d',strtotime($data['start_date']));
        $data['end_date']= date('Y-m-d',strtotime($data['end_date']));

        $res = self::getInstance($rate_plan)->saveUpdate($data);
        if ($res)
            return $this->response("Rate Plan Updated SuccessFully", "view", 200);
        else
            return $this->response("Can't Update Rate Plan", 'view', 422);
    }

    public function delete(RatePlan $rate_plan)
    {
        return view($this->clayout . '.modal.delete', compact('rate_plan'));
    }

    public function destroy(RatePlan $rate_plan)
    {
        $res = self::getInstance($rate_plan)->softDelete();

        if ($res)
            return $this->response("Rate Plan Deleted SuccessFully", "view", 200);
        else
            return $this->response("Can't Delete Rate Plan", 'view', 422);
    }

    public function singleRate(RatePlan $rate_plan)
    {
        return view($this->clayout . '.includes.single_rate_plan', compact('rate_plan'));
    }

    //change status of rate plan
    public function changeStatus(RatePlan $rate_plan)
    {
        return view($this->clayout.'.modal.changeStatus', compact('rate_plan'));
    }
    //update status of rate plan
    public function udpateStatus(RatePlan $rate_plan)
    {
        if($rate_plan->is_active):
            $rate_plan->is_active = false;
        else:
            $rate_plan->is_active = true;
            if(!$rate_plan->is_custom)
                $this->deactiveOther($rate_plan->id);
        endif;
        $rate_plan->save();

        if($rate_plan):
            return $this->response("SuccessFully Updated Status", "view", 200);
        else:
            return $this->response("Couldn't Update Status", "view", 500);
        endif;
    }
}
