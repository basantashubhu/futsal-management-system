<?php

namespace App\Http\Controllers\Settings;

use App\Http\Controllers\BaseController;
use App\Models\Application;
use App\Models\Organization;
use App\Models\Pet;
use App\Models\Rate;
use App\Models\RatePlan;
use App\Models\RateType;
use App\Repo\RateRepo;
use App\Models\ApplicationPetTreatments;
use Illuminate\Http\Request;
use App\Http\Requests\RateRequest;
use App\Models\Treatment;

class RateController extends BaseController
{
    private static $repo = null;
    private $clayout = "";

    public function __construct()
    {
        parent::__construct();
        $this->clayout = $this->layout . '.pages.settings.rates';
    }

    /**
     * @param $model
     * @return RateRepo|null
     */
    private static function getInstance($model)
    {
        self::$repo = new RateRepo($model);
        return self::$repo;
    }

    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function index()
    {
        return view($this->clayout . '.index');
    }

    public function allRates(Request $request, $id)
    {
        return self::getInstance('Rate')->selectDataTable($request, $id);
    }

    public function create($id)
    {
        $rate_types = self::getInstance('RateType')->select();
        $treatments = self::getInstance('Treatment')->select();
        return view($this->clayout . '.modal.add', compact('rate_types', 'treatments', 'id'));
    }

    public function multiple_add($id)
    {
        $rate_types = self::getInstance('RateType')->select();
        $treatments = self::getInstance('Treatment')->select();
        return view($this->clayout . '.modal.add_multiple', compact('rate_types', 'treatments', 'id'));
    }

    public function multiStore(Request $request, $id)
    {
        dd($request->all());
    }

    public function edit(Rate $rate)
    {
        $rate_types = self::getInstance('RateType')->select();
        $treatments = self::getInstance('Treatment')->select();
        return view($this->clayout . '.modal.edit', compact('rate', 'rate_types', 'treatments'));
    }

    public function store(RateRequest $request)
    {
        $rates = $request->all();
        $res = self::getInstance('Rate')->saveUpdate($rates);
        if ($res)
            return $this->response("Rate Added SuccessFully", "view", 200);
        else
            return $this->response("Can't Add Rate", 'view', 422);
    }

    public function update(RateRequest $request, Rate $rate)
    {
        $res = self::getInstance($rate)->saveUpdate($request);
        if ($res)
            return $this->response("Rate Updated SuccessFully", "view", 200);
        else
            return $this->response("Can't Update Rate", 'view', 422);
    }

    public function delete(Rate $rate)
    {
        return view($this->clayout . '.modal.delete', compact('rate'));
    }

    public function destroy(Rate $rate)
    {
        $res = self::getInstance($rate)->softDelete();

        if ($res)
            return $this->response("Rate Deleted SuccessFully", "view", 200);
        else
            return $this->response("Can't Delete Rate", 'view', 422);
    }

    public function getAllTreatmentRate(Application $application,Pet $pet)
    {
        $provider=$application->providers();
        $treatmentRate=self::getInstance('Rate')->getAllTreatmentList($application,$pet,$provider->plan_id);
        $data=[];
        $count=1;
        foreach ($treatmentRate as $treatment) {
            if($application->is_provider_view==1 && $treatment->checked=='false')
            {
                continue;
            }
            if ($treatment->rate_metrics_type == 'weight') {
                $res = $this->performComparision($pet->weight, $treatment->rate_metrics);
                if ($res) {
                    $treatment->sn=$count;
                    if ($treatment_performed = ApplicationPetTreatments::where('application_id', $application->id)->where('pet_id', $pet->id)->where('treatment_id', $treatment->id)->first()){
                        $treatment->treatment_date = $treatment_performed->treatment_date;
                        $treatment->comment = $treatment_performed->comment;
                        $treatment->approval_date = $application->approved_date;
                    }
                    array_push($data,$treatment);
                    $count++;
                }
            }
        }
        return $data;
    }

    public function getAllCustomTreatmentRate(Pet $pet)
    {
        $treatmentRate=self::getInstance('Rate')->getAllCustomTreatmentList($pet);
        dd($treatmentRate);
        $data=[];
        $count=1;
        foreach ($treatmentRate as $treatment) {
            if ($treatment->rate_metrics_type == 'weight') {
                $res = $this->performComparision($pet->weight, $treatment->rate_metrics);
                if ($res) {
                    $treatment->sn=$count;
                    array_push($data,$treatment);
                    $count++;
                }
            }

        }
        return $data;
    }

    public function storeRateTreatment(RateRequest $request)
    {
        $res=self::getInstance('rate')->saveRateWithTreatment($request);
        if ($res)
            return $this->response("Custom Treatment Plan Added Successfully", "view", 200);
        else
            return $this->response("Failed to Add Treatment Plan", 'view', 422);
    }

    public function getRate($val)
    {
        $treatment = Treatment::where('treatment_name', $val)->first();
        $rate = Rate::where('treatment_id', $treatment->id)->first();
        return $rate->cost;
    }

    public function getTreatmentRate(Pet $pet,Treatment $treatment)
    {
        $species=strtolower($pet->species);
        $sex=strtolower($pet->sex);
        $weight=$pet->weight;

        $ratePlan=RatePlan::where('is_active',1)->where('is_custom',0)->first();

        $rates=Rate::where([
            ['plan_id',$ratePlan->id],
            ['treatment_id',$treatment->id],
        ])
        ->whereRaw("lower(rates.animal_type)='$species'")
        ->whereRaw("lower(rates.sex)='$sex'")->get();

        foreach ($rates as $rate)
        {
            $rateType=RateType::find($rate->rate_type_id);
            $res = $this->performComparision($weight, $rateType->rate_metrics);
            if($res)
                return $rate->cost;
        }
        return 0;
    }

    protected function performComparision($data, $compareString)
    {
        $list = ['<=', '==', '>'];
        foreach ($list as $l) {
            if (hasOperator($compareString, $l)) {
                $d = (int)str_replace($l, '', $compareString);
                if (is_int($d) && $d != 0) {
                    switch ($l) {
                        case '<':
                            return $data < $d;
                        case '<=':
                            return $data <= $d;
                        case '>':
                            return $data > $d;
                        case '>=':
                            return $data >= $d;
                        case '==':
                            return $data == $d;
                        default:
                            return false;
                    }
                } else
                    return false;

            }
        }
        return false;
    }
}
