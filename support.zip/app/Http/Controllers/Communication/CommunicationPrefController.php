<?php
/**
 * DEVELOPERS
 * ----------------------------------------------
 * SUMAN  THAPA - LEAD  (NEPALNME@GMAIL.COM)
 * ----------------------------------------------
 * - RUNA SIDDHI BAJRACHARYA
 * - RABIN BHANDARI
 * - SHIVA THAPA
 * - PRABHAT GURUNG
 * - KIRAN CHAULAGAIN
 * -----------------------------------------------
 * Created On: 4/19/2018
 *
 * THIS INTELLECTUAL PROPERTY IS COPYRIGHT Ⓒ 2018
 * ZEUSLOGIC, INC. ALL RIGHT RESERVED
 */

namespace App\Http\Controllers\Communication;


use App\Http\Controllers\BaseController;
use App\Models\Application;
use App\Models\CommunicationPrefrence;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CommunicationPrefController extends BaseController
{

    public function __construct()
    {
        parent::__construct();
    }

    public function store($request,$model)
    {
        $commPref=new CommunicationPrefrence();
        foreach ($request as $key=>$value)
            $commPref->$key=$value;
        $commPref->table=$model->getTable();
        $commPref->table_id=$model->id;
        $commPref->userc_id=Auth::id();
        $commPref->save();
    }

}