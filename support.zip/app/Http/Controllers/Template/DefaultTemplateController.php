<?php

namespace App\Http\Controllers\Template;

use App\Models\Fgp\Volunteer;
use Illuminate\Http\Request;
use App\Http\Controllers\BaseController;
use App\Http\Requests\DefaultTemplateRequest;
use App\Repo\DefaultTemplateRepo;
use App\Models\EmailTemplate;
use App\Models\DefaultTemplate;

class DefaultTemplateController extends BaseController
{
	private static $repo = null;
	private $clayout = "";

    public function __construct()
    {
    	parent::__construct();
    	$this->clayout = $this->layout.'.pages.defaultTemplate';
    }
	public static function getInstance($model)
	{
		self::$repo = new DefaultTemplateRepo($model);
		return self::$repo;
	}
	public function index()
	{
		return view($this->clayout.'.index');
	}
	public function create()
	{
		return view($this->clayout.'.modal.add');
	}
    /**
     * @param Request $request
     * @return mixed
     */
    public function getAll(Request $request)
    {
        $data=self::getInstance('DefaultTemplate')->selectDataTable($request);
        return $data;
    }

    public function volunteerTemplate(Request $request,$vol_id){
        $data = self::getInstance('DefaultTemplate')->selectVolDefaultTemplate($request,$vol_id);
        return $data;
    }
     /**
     * @param Template $template
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function delete(DefaultTemplate $template)
    {
        return view($this->clayout . '.modal.delete', compact('template'));
    }
    /**
     * @param Template $teamplte
     * @return $this|\Illuminate\Http\JsonResponse
     */
    public function destroy(DefaultTemplate $template)
    {
        $res = self::getInstance($template)->softDelete();

        if ($res)
            return $this->response("Template deleted successFully", "view", 200);
        else
            return $this->response("Can't delete Template", 'view', 422);
    }

    /**
     * @param $id
     * @return bool|string
     */
    public function viewTemplate($id)
    {
        $datas = [];
        $template = DefaultTemplate::find($id);
        $template->email_template = EmailTemplate::find($template->temp_id);
        if($template->email_template->temp_json != null){
            $fields = explode(',', $template->email_template->temp_json);
            foreach($fields as $f):
                $data = explode(':', $f);
                array_push($datas, $data);
            endforeach;
        }
        return view($this->layout . '.pages.defaultTemplate.includes.single_template', compact('template', 'datas'));
    }
}
