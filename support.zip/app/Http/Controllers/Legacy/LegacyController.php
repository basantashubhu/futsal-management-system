<?php
/**
 * DEVELOPERS
 * ----------------------------------------------
 * SUMAN  THAPA - LEAD  (NEPALNME@GMAIL.COM)
 * ----------------------------------------------
 * - RUNA SIDDHI BAJRACHARYA
 * - RABIN BHANDARI
 * - SHIVA THAPA
 * - PRABHAT GURUNG
 * - KIRAN CHAULAGAIN
 * -----------------------------------------------
 * Created On: 5/18/2018
 *
 * THIS INTELLECTUAL PROPERTY IS COPYRIGHT Ⓒ 2018
 * ZEUSLOGIC, INC. ALL RIGHT RESERVED
 */

namespace App\Http\Controllers\Legacy;


use App\Http\Controllers\BaseController;

class LegacyController extends BaseController
{

    private $clayout;
    public function __construct()
    {
        parent::__construct();
        $this->clayout=$this->layout.'.pages.legacy.';
    }

    public function ieLegacy()
    {
        return view($this->clayout.'ie.index');
    }

    public function providerLegacy()
    {
        return view($this->clayout.'provider.index');
    }
}