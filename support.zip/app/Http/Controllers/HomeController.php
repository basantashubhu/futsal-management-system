<?php

namespace App\Http\Controllers;

use App\File;
use App\Lib\File\FileHandler;
use App\Models\Fgp\PayPeriod;
use App\Models\Fgp\StipendCalc;
use App\Models\Fgp\Timesheet;
use App\Models\Organization;
use App\Models\Settings\Lookups;
use App\Models\User;
use App\Repo\FGP\PayPeriodRepo;
use App\Repo\TimeSheetRepo;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class HomeController extends Controller
{
    const DS = DIRECTORY_SEPARATOR;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        if (!Auth::viaRemember()) {
            $this->middleware('auth');
        }

    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // $client = Member::where('user_id', auth()->id())->first();
        // if ($client) {
        //     $profile = File::where('table', 'members')->where('table_id', $client->id)->first();
        //     if (isset($profile)) {
        //         if (file_exists(storage_path('uploads/') . $profile->file_name)):
        //             $profile->image = base64_encode(file_get_contents(storage_path('uploads/') . $profile->file_name));
        //         else:
        //             $profile->image = base64_encode(file_get_contents(storage_path('uploads/avatar.jpg')));
        //         endif;
        //     }
        // }

        // $client=auth()->user()->client;
        // if($client && $client!=null)
        //     $userName=$client->fname.' '.$client->mname.' '.$client->lname;
        // else
        //     $userName=auth()->user()->name;
        $layoutSettings = \DB::table('builder_setting')->get()->keyBy('setting_label')->toArray();
        // $volunteers = Volunteer::where('is_deleted', false)->get();
        // $days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
        // $supervisor_id = Volunteer::where('is_deleted', false)->distinct()->pluck('vol_supervisor_id');
        // $supervisors = [];
        // if(count($supervisor_id)>0){
        //     foreach($supervisor_id as $id){
        //         array_push($supervisors, User::find($id));
        //     }
        // }
        // $supervisor_id = Volunteer::select('vol_supervisor_id')->where('is_deleted', false)->distinct()->pluck('vol_supervisor_id')->toArray();
        // $vol_supervisors = User::with('member')->find($supervisor_id);
        // $finance = StipendCalc::orderBy('created_at', 'desc')->first();
        // if(isset($finance->id)){
        //     $finance->stipend_period = PayPeriod::find($finance->period_unq_id);
        // }
        // $approvedPeriods =  StipendCalc::where('is_deleted', false)->orderBy('created_at', 'desc')->pluck('period_unq_id');
        // $datas = [];
        // foreach($approvedPeriods as $period){
        //     array_push($datas, PayPeriod::find($period));
        // }
        return view('default.master', compact('profile', 'finance', 'datas', 'userName', 'layoutSettings', 'vol_supervisors', 'supervisors', 'days', 'volunteers'));

    }

    public function fileDownload(File $file)
    {
        try {
            $file = $file->file_name;
            $path = storage_path('uploads' . self::DS . $file);

            if (file_exists($path)):
                $headers = [
                    'Content-Description' => 'File Transfer',
                    'Content-Disposition' => 'attachment; filename="' . $file . '"',
                    'Content-Transfer-Encoding' => 'binary',
                    'Content-Type' => 'application/pdf',
                ];
                return response()->download($path, $file, $headers);

            else:
                return back()->with('fileError', 'File not Found');
            endif;
        } catch (\Exception $e) {
            return back()->with('fileError', 'File not Found');
        }

    }

    public function responseFile(File $file)
    {

        if (file_exists(storage_path('uploads/' . $file->file_name))) {
            if (($file->fileInfo("extension") != "jpg" || $file->fileInfo("extension") != "jpeg" || $file->fileInfo("extension") != "png")) {
                return response()->file(storage_path('uploads/' . $file->file_name));
            } else {
                return response()->file(storage_path('uploads/' . $file->file_name));
            }
        } else {
            return back();
        }
    }

    public function getFile($folder, $filename)
    {
        if ($folder !== "framework" && $folder !== "logs"):
            $path = storage_path($folder . DIRECTORY_SEPARATOR . $filename);
            $file = FileHandler::returnFile($path);
            return $file;
        endif;
        abort(404);
    }

    public function notFound()
    {
        return view('errors.404Page');
    }

    public function dashboard(Request $request)
    {
        return view('default.pages.dashboard2.index');
    }

    // table data
    public function getTableData(Request $request)
    {
        return (new TimeSheetRepo('Fgp\Timesheet'))
            ->selectDataTable($request);
    }
}
