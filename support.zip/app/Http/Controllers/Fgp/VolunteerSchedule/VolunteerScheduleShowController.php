<?php

namespace App\Http\Controllers\Fgp\VolunteerSchedule;

use App\Http\Controllers\BaseController;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class VolunteerScheduleShowController extends BaseController
{
    private $clayout = "";
    public function __construct(){
        parent::__construct();
        $this->clayout = $this->layout.'.fgp.volunteer_schedule';
    }

    public function __invoke()
    {
        return view($this->clayout.'.index');
    }

    public function addVolSchedule(){
         $validations = validation_value('pay_period_form');
        return view($this->clayout.'.modals.add',compact('validations'));
    }

}
