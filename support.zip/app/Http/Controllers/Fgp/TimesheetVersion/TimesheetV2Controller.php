<?php

namespace App\Http\Controllers\Fgp\TimesheetVersion;

use App\Http\Controllers\BaseController;
use App\Models\Fgp\Holiday;
use App\Models\Fgp\PayPeriod;
use App\Models\Fgp\Site;
use App\Models\Fgp\StipendItem;
use App\Models\Fgp\TimeSheetItem;
use App\Models\Fgp\Timesheet;
use App\Models\Fgp\Volunteer;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TimesheetV2Controller extends BaseController
{
    private $clayout;

    public function __construct()
    {
        parent::__construct();
        $this->clayout = $this->layout . '.fgp.timesheetV2';
    }

	public function __invoke(){
		 $supervisors = User::where('role_id', 3)->where('is_deleted', false)->get();
		return view($this->clayout. '.index',compact('supervisors'));

	}

    public function formatData(Request $request){


        $this->validate($request, [

            'time_type' => 'required',
            'time_in'   => 'required',
            'time_out'   => 'required',

        ]);

        $data = $request->all();

        $site = Site::where('id',$request->sites)->select(['id', 'site_name'])->first();

        $data['sites'] = (object)["id" => $site->id, "name" => $site->site_name];

        foreach ($data['vols'] as $key => $vol) {

            $volunteer = Volunteer::find($vol);

            $data['vols'][$key] = (object)["id" => $volunteer->id, "name" => $volunteer->name()];            

        }

        $items = [];

        foreach ($data['item'] as $type => $valueArr) {

            if(is_null($valueArr[0])) continue; //Escape amount of item if no labels

            foreach ($valueArr as $index => $value) {
                
                $items[$index][$type] = $value;

            }

        }

        $data['item'] = $items;

        return $data;

    }


    public function getStipendItemCode($item_name){
        return StipendItem::where('item_name', $item_name)->first()->item_code;
    }

    public function getStipendItemId($category, $item_name){
        return StipendItem::where('item_name', $item_name)->where('category', $category)->first()->id;
    }

    private function getStipendRate(){
        return getSiteSettings('stipend_rate');
    }

    private function calculateAmount($total_hrs){

        $stipend_rate = getSiteSettings('stipend_rate');

        $total_hr = explode(':', $total_hrs);

        if(!isset($total_hr[1])){ // if totalhr is stored in decimal 1.20

            $total_hr = explode('.', $total_hrs);

        }


        $actual_hr = $total_hr[0]+ ((isset($total_hr[1]) ? $total_hr[1] : 0)/60);
        
        return $actual_hr * $stipend_rate;

    }

    private function getTimesheetUnqId($period){       

        $has_uniq_id = Timesheet::where('period_id', $period)->latest()->first();

        if( $has_uniq_id ){

            return $has_uniq_id->timesheets_unq_id;

        }else{

            $latestTs = Timesheet::orderByDesc('id')->first();

            return $latestTs ? $latestTs->timesheets_unq_id + 1 : 1;

        }

    }

    private function holidayExists($date){

        $holiday = Holiday::where('hol_date', $date)->first();

        return $holiday ? true : false;

    }

    private function getHolidayName($date){

        $holiday = Holiday::where('hol_date', $date)->first();

        return $holiday->name;

    }

    private function storeCurrentSiteToVol($vol, $site){

        $volunteer = Volunteer::find($vol)->sites()->attach($site,[

            "date" => now(),
            "choosed_site_id"   => $site,

        ]);

        return $volunteer;
    }

    private function checkAndAssignSite($vol, $site){

        $hasCurrentSite = Volunteer::find($vol)->assignedSites->pluck('site_id')->contains($site);

        if($hasCurrentSite){
            return true;
        }

        return $this->storeCurrentSiteToVol($vol, $site);

    }
    
    public function scheduleTsV2(Request $request, PayPeriod $period){

        DB::beginTransaction();

        try{

            $start_date = $period->start_date;
            $total_days  = \carbon($period->start_date)->diffInDays($period->end_date) + 1;                    

            $dataSets = $this->bulkFormatter($request);

            for($i = 0; $i < $total_days; $i++){

                $day_of_week = date("w", strtotime($start_date)); 

                foreach ($dataSets as $row_id => $tsDataArray) {

                    $ts_unq_id = $this->getTimesheetUnqId($period->id); 

                    /*
                    if(is_array($tsDataArray['days'])){
                        // Multple volunteers multiple days 
                       foreach ($tsDataArray as $dayKeyPair => $d) {
                           foreach ($d as $dayKey => $actualDay) {
                                if($day_of_week === $actualDay){ 

                                    //old ts undone 
                                    $isHoliday = $this->holidayExists($start_date);
                                    PayPeriod::where('id', $period->id)->update(['pay_stat' => 'In Process']);
                                    $newTimesheet = Timesheet::create([

                                        'volunteer_id'=> $tsDataArray['vol'][$dayKey],
                                        'timesheets_unq_id' => $ts_unq_id,
                                        'site_id'=> $tsDataArray['site'][$dayKey],
                                        'period_id'=> $period->id,
                                        'date' => $start_date,
                                        'type_label' => $isHoliday ? 'Vacation Time' :$tsDataArray['time_type'][$dayKey],
                                        'type' => $isHoliday? 'vacation_time' :$this->getStipendItemCode($tsDataArray['time_type'][$dayKey]),
                                        'time_in' => $tsDataArray['time_in'][$dayKey],
                                        'time_out' => $tsDataArray['time_out'][$dayKey],
                                        'break_in' => $tsDataArray['break_in'][$dayKey],
                                        'break_out' => $tsDataArray['break_out'][$dayKey],
                                        'total_hrs' => $tsDataArray['total_hrs'][$dayKey],
                                        'comment' => $isHoliday ? $this->getHolidayName($start_date) : (isset($tsDataArray['comment'][$dayKey])?$tsDataArray['comment'][$dayKey]:''),
                                        'approval_status' => "supervisor",
                                        'userc_id'  => auth()->id(),
                                        'status' => "New",
                                        'next_approval' => "supervisor",
                                        'rates'    => $this->getStipendRate(),
                                        'total_amount'  => $this->calculateAmount($tsDataArray['total_hrs'][$dayKey])

                                    ]);                                                        


                                }
                           }
                       }
                       continue;
                    }    
                    */            


                    if($day_of_week === $tsDataArray['days']){ 

                        $this->checkAndAssignSite($tsDataArray['vol'], $tsDataArray['site']);

                        //old ts undone 
                        $isHoliday = $this->holidayExists($start_date);
                        PayPeriod::where('id', $period->id)->update(['pay_stat' => 'In Process']);

                        $newTimesheet = Timesheet::create([

                            'volunteer_id'=> $tsDataArray['vol'],
                            'timesheets_unq_id' => $ts_unq_id,
                            'site_id'=> $tsDataArray['site'],
                            'period_id'=> $period->id,
                            'date' => $start_date,
                            'type_label' => $isHoliday ? 'Vacation Time' :$tsDataArray['time_type'],
                            'type' => $isHoliday? 'vacation_time' :$this->getStipendItemCode($tsDataArray['time_type']),
                            'time_in' => $tsDataArray['time_in'],
                            'time_out' => $tsDataArray['time_out'],
                            'break_in' => $tsDataArray['break_in'],
                            'break_out' => $tsDataArray['break_out'],
                            'total_hrs' => $tsDataArray['total_hrs'],
                            'comment' => $isHoliday ? $this->getHolidayName($start_date) : (isset($tsDataArray['comment'])?$tsDataArray['comment']:''),
                            'approval_status' => "supervisor",
                            'userc_id'  => auth()->id(),
                            'status' => "New",
                            'next_approval' => "supervisor",
                            'rates'    => $this->getStipendRate(),
                            'total_amount'  => $this->calculateAmount($tsDataArray['total_hrs'])

                        ]);


                        if(isset($tsDataArray['items'])){

                            foreach ($tsDataArray['items'] as $item) {

                               TimeSheetItem::create([

                                   'time_sheet_id' => $newTimesheet->id,
                                   'type'  =>  $item['label'],
                                   'code'  => $item['label'],
                                   'stipend_item_id'   => $this->getStipendItemId($item['label'], $item['value']),
                                   'value' => $item['value'],
                                   'amount' => $item['amount']

                               ]);

                            }

                        }                           


                    }                    

                }
                $start_date = date('Y-m-d',strtotime($start_date . "+1 days"));
            }

            DB::commit();

            return response("Timesheet scheduled", 200);

        }catch(\Exception $e){

            DB::rollback();

            return response(["message" => $e->getMessage(), "line" => $e->getLine()], 500);

        }


    }
    

    public function bulkFormatter($data){

        if($data instanceOf Request) $data = $data->all();

        $formatted_data = [];

        foreach ($data as $key => $first_arrray) {

            if($key === "item"){

                foreach ($first_arrray as $label => $labelArray) {
                    foreach ($labelArray as $k => $valArray) {
                        foreach ($valArray as $ind => $actualData) {
                            
                            $formatted_data[$k]['items'][$ind][$label] = $actualData;
                            
                        }
                        
                    }
                }
                continue;

            }

            if(is_array($first_arrray)){

                foreach ($first_arrray as $index => $value) {

                    $formatted_data[$index][$key] = $value;

                }
            }

        }

        return $formatted_data;

    }


}
