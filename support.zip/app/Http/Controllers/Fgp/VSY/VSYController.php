<?php

namespace App\Http\Controllers\Fgp\VSY;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class VSYController extends Controller
{
    private $layout = 'default.fgp.vsy';

    protected function view(string $view, array $compact = [])
    {
        $compact['layout'] = $this->layout;
        return view($this->layout .'.'. $view, $compact);
    }
}
