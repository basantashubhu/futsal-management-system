<?php

namespace App\Http\Controllers\Fgp\VSY;

use App\Models\Fgp\VsyCalendar;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class VsyCalendarStoreController extends Controller
{
    public function calendarStore(Request $request) {
        $validate = $request->validate([
            'calendar_name' =>'required',
            'date_range'=>'required',

        ]);

        if ($validate){

            $data = [];
            $dateRange = explode(" - ",$request->date_range);
            $data["start_date"] = date('Y-m-01',strtotime($dateRange[0]));
            $data["end_date"] = date('Y-m-t',strtotime($dateRange[1]));
            $data["calendar_name"] = $request->calendar_name;
            $data["userc_id"] = Auth::id();
            $data["created_at"] = now();

            $save = DB::table('vsy_calendars')->insert($data);
            if ($save) {
                $data = VsyCalendar::where('is_deleted',0)
                    ->select('id','start_date','end_date','calendar_name')
                    ->orderBy('start_date','des')
                    ->get();
                return response(["message"=>"Successfully Added","data"=>$data],200);
            }
            else return response(['errors' => ['message' => "Failed"]], 422);
        }else{
            return response(['errors' => ['message' => "Invalid Input"]], 422);
        }
    }

    public function deleteCalendar(Request $request) {
       $vsyCalendar = VsyCalendar::find($request->id)->delete();
       if ($vsyCalendar){
           $vsy_calendars = VsyCalendar::where('is_deleted',0)
               ->select('id','start_date','end_date','calendar_name')
               ->orderBy('start_date','des')
               ->get();
           return response(["message"=>"Successfully Deleted","data"=>$vsy_calendars],200);
       }
     return response(["message"=>"Failed to delete"],422);
    }

}
