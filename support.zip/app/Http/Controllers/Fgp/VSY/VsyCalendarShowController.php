<?php

namespace App\Http\Controllers\Fgp\VSY;

use App\Models\Fgp\VsyCalendar;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class VsyCalendarShowController extends VSYController
{
    /*----------- annual claendar ------*/

    public function calendarAdd(){
        return $this->view('modals.modal-calendar');
    }

    public function deleteCalendarModal(VsyCalendar $vsyCalendar) {
        return $this->view('modals.modal-calendar-delete',compact('vsyCalendar'));
    }

    public function fetchAllCalendar(){
        $data = VsyCalendar::where('is_deleted',0)->get();
        return response(["data"=>$data]);
    }

    public function getCalendarData($input) {

        if ($input === "all"){
            $data = VsyCalendar::select('id','calendar_name','start_date','end_date')
                ->where('is_deleted',0)
                ->get();
        }
        else{
            $data = VsyCalendar::where('calendar_name','like','%'.$input.'%')
            ->select('id','calendar_name','start_date','end_date')
            ->where('is_deleted',0)
            ->get();
        }
        return response($data);
    }
}
