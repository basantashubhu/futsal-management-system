<?php

namespace App\Http\Controllers\Fgp\VSY;

use function foo\func;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use PHPUnit\Framework\Exception;
use function GuzzleHttp\json_encode;

class AnnualVSYStoreController extends Controller
{
    public function store(Request $request)
    {
         $formattedData = [];
         $data = $request->all();
         unset($data['_token']);
         $temp = [];
         for ($i=0; $i<sizeof($data["year"]); $i++) {
             foreach ($data as $key=> $datum) {
                 $temp[$key] = $datum[$i];
             }
             array_push($formattedData,$temp);
         }

         try{
             DB::beginTransaction();
             foreach ($formattedData as $data) {

                 $check = DB::table('annual_vsy_goal')
                     ->where('year',$data["year"])
                     ->where('months',$data['months'])
                     ->first();
                 if (!$check):
                    $save =  DB::table('annual_vsy_goal')->insert([
                       'year' => $data["year"],
                       'months' => $data["months"],
                       'goal' => $data["goal"],
                       'created_at' => now()
                     ]);
                     if ($save){
                         $this->vsyUnitStore($data);
                     }else{
                         return response(['errors' => ['message' => "Cound not store vsy unit"]], 422);
                     }
                 else:
//                    return response(["message"=>"Year $check->year of $check->months already exists"],422);
                     return response(['errors' => ['message' => "Year $check->year of $check->months already exists"]], 422);
                 endif;
             }
             DB::commit();
             return response(["message"=>"Successfull"],200);
         }catch (\Exception $e) {
             DB::rollBack();
             return response(['errors' => ['message' => [$e->getMessage()]]], 422);
         }



//       try {
//           $year = $request->input('year');
//           $all_months = $request->input('all_month', false);
//           $months = $all_months ? range(1, 12) : $request->input('months', false);
//           $goal = $request->input('goal', false);
//           if (!$months || !$goal) {
//               throw new  \Exception('Fill required inputs.');
//           }
//
//           DB::table('annual_vsy_goal')->insert([
//               'year' => $year,
//               'months' => implode(',', $months),
//               'goal' => $goal,
//               'created_at' => now()
//           ]);
//           $unit_save_status = $this->vsyStore($request);
//           throw_if($unit_save_status != 'success', new Exception(json_encode($unit_save_status)));
//           return 'success';
//       } catch (\Exception $e) {
//           return response(['errors' => ['message' => [$e->getMessage()]]], 422);
//       }
    }

    public function vsyUnitStore(Array $data)
    {
        try {
            DB::table('vsy_unit')->insert([
                'year' => $data["year"],
                'months' => $data["months"],
                'unit' => $data["unit"],
                'created_at' => now()
            ]);
        } catch (\Exception $e) {
            return response(['errors' => ['message' => [$e->getMessage()]]], 422);
        }
    }

    public function update(Request $request, $id)
    {
        try {
            $year = $request->input('year');
            $months = $request->input('months');
//            $months = $all_months ? range(1, 12) : $request->input('months', false);
            $goal = $request->input('goal', false);
            if (!$months || !$goal) {
                throw new  \Exception('Fill required inputs.');
            }

            DB::table('annual_vsy_goal')->where('id', $id)->update([
                'year' => $year,
                'months' => $months,
                'goal' => $goal,
                'updated_at' => now()
            ]);
            $vsy_update = $this->vsyUpdate($request);
            throw_if($vsy_update != 'success', new Exception(json_encode($vsy_update)));
            return 'success';
        } catch (\Exception $e) {
            return response(['errors' => ['message' => [$e->getMessage()]]], 422);
        }
    }

    public function delete($id)
    {
        DB::table('annual_vsy_goal')->where('id', $id)->delete();
        return 'success';
    }

    public function vsyStore(Request $request)
    {
        try {
            $year = $request->input('year', false);
            $month = $request->input('months', false);
            $unit = $request->input('unit', false);
            if (!$year || !$unit) {
                throw new  \Exception('Fill required inputs.');
            }

            DB::table('vsy_unit')->insert([
                'year' => $year,
                'months' => $month,
                'unit' => $unit,
                'created_at' => now()
            ]);
            return 'success';
        } catch (\Exception $e) {
            return response(['errors' => ['message' => [$e->getMessage()]]], 422);
        }
    }

    public function vsyUpdate(Request $request, $id = null)
    {
        try {
            $year = $request->input('year', false);
            $months = $request->input('months', false);
            $unit = $request->input('unit', false);
            if (!$year || !$unit) {
                throw new  \Exception('Fill required inputs.');
            }


//            if ($id)
//                DB::table('vsy_unit')->where('id', $id)->update([
//                    'year' => $year,
//                    'months' => $months,
//                    'unit' => $unit,
//                    'updated_at' => now()
//                ]);

//            else {
//                $unitItem = DB::table('vsy_unit')->where('year', $request->year)->first();
                $unitItem = DB::table('vsy_unit')->where('year', $year)->where('months',$months)->first();
                if ($unitItem)
                    DB::table('vsy_unit')->where('id', $unitItem->id)->update([
                        'year' => $year,
                        'months' => $months,
                        'unit' => $unit,
                        'updated_at' => now()
                    ]);

                else
                    DB::table('vsy_unit')->insert([
                        'year' => $year,
                        'months' => $months,
                        'unit' => $unit,
                        'created_at' => now(),
                        'updated_at' => now(),
                    ]);
//            }

            return 'success';
        } catch (\Exception $e) {
            return response(['errors' => ['message' => [$e->getMessage()]]], 422);
        }
    }

    public function vsyDelete($id)
    {
        DB::table('vsy_unit')->where('id', $id)->delete();
        return 'success';
    }


    //bulk store
    public function calendarBulkStore(Request $request) {
        $data = $request->data;

        $tempData = [];
        foreach ($data as $key => $value) {
            $test = [];
            foreach ($value['row_data'] as $key1=> $row_datum) {
                $test[$row_datum["name"]]  = $row_datum["value"];
            }
            array_push($tempData,$test);
        }

        $formattedData = [];
        foreach ($tempData as $tempDatum) {
            $format = [];
            foreach ($tempDatum as $key => $item) {
                if ($key === "months"){
                    $format["months"] = $this->getMonthNumber($item);
                }
                $format["id"] = $tempDatum["actions"];
                $format["goal"] = $tempDatum["goal"];
                $format["unit"] = $tempDatum["unit"];
                $format["year"] = $tempDatum["year"];
            }
            array_push($formattedData,$format);
        }
        //update data


            try {
                DB::beginTransaction();

                foreach ($formattedData as $vsyData){

                    //update vsyGoal
                        $saveGoal = DB::table('annual_vsy_goal')->where('id', $vsyData["id"])
                        ->update([
                            'goal' => $vsyData["goal"],
                            'updated_at' => now()
                        ]);


                        if ($saveGoal){
                            //find vsy unit
                            $aa = DB::table('vsy_unit')
                                ->where('year', $vsyData["year"])
                                ->where('months', $vsyData["months"])
                                ->first();
                            if ($aa){
                               DB::table('vsy_unit')
                                    ->where('year', $vsyData["year"])
                                    ->where('months', $vsyData["months"])
                                    ->update([
                                        'unit' => $vsyData['unit'],
                                        'updated_at' => now()
                                    ]);
                            }else{
                                DB::table('vsy_unit')->insert([
                                   "year" => $vsyData["year"],
                                   "months" => $vsyData["months"],
                                   "unit" => $vsyData["unit"],
                                ]);
                            }

                        }
                }
                DB::commit();
                return 'success';
            } catch (\Exception $e) {
                DB::rollBack();
                return response(['errors' => ['message' => [$e->getMessage()]]], 422);
            }

    }

    private function getMonthNumber($monthName){
        $month = strtolower($monthName);
        $monthNumber = ["jan"=>1,"feb"=>2,"mar"=>3,"apr"=>4,"may"=>5,"jun"=>6,"jul"=>7,"aug"=>8,"sep"=>9,"oct"=>10,"nov"=>11,"dec"=>12];
        return $monthNumber[$month];
    }
}
