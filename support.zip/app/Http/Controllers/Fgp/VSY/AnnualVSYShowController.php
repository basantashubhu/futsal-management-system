<?php

namespace App\Http\Controllers\Fgp\VSY;

use App\Models\Fgp\VsyCalendar;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class AnnualVSYShowController extends VSYController
{

    public function index()
    {
        $vsy_calendars = VsyCalendar::where('is_deleted',0)
            ->select('id','start_date','end_date','calendar_name')
            ->orderBy('start_date','des')
            ->get();
        return $this->view('index',compact('vsy_calendars'));
    }

    public function vsyIndex()
    {
        return $this->view('unit.index');
    }

    public function getData(Request $request)
    {
        $perpage = $request->pagination['perpage'];
        $offset = ($request->pagination['page'] - 1) * $perpage;
        $totalResult = 0;

        $searchData =isset($_COOKIE['vsy_calendar_search'])?json_decode($_COOKIE['vsy_calendar_search']):[];
        if(sizeof($searchData)>0){

          foreach ($searchData as $d){
              $calendar_id = (int)($d->calendar_id);
          }

          $vsyCalendar = VsyCalendar::find($calendar_id);
            $vsyCalendar->start_date = date_create($vsyCalendar->start_date)->format('Y-m-01');
            $vsyCalendar->end_date = date_create($vsyCalendar->end_date)->format('Y-m-t');

            $result = DB::table('annual_vsy_goal')
                ->select([
                    'annual_vsy_goal.*',
                    DB::raw('(select unit from vsy_unit where year = annual_vsy_goal.year and months = annual_vsy_goal.months limit 1) as unit'),
                    DB::raw('concat(annual_vsy_goal.year,"-",annual_vsy_goal.months,"-", "15") as vsy_date')
                ])
                ->havingRaw("date(vsy_date) between '{$vsyCalendar->start_date}' and '{$vsyCalendar->end_date}'")
                ->get()->map(function ($avg) {
                    $months = [];
                    foreach (explode(',', $avg->months) as $m)
                        array_push($months, date('M', strtotime("$m/15/2019")));
                    $avg->months = implode(', ', $months);
                    $avg->created_at = newDate($avg->created_at);
                    return $avg;
                });

        }else{
            $result = DB::table('annual_vsy_goal')
                ->select('annual_vsy_goal.*', DB::raw('(select unit from vsy_unit where year = annual_vsy_goal.year and months = annual_vsy_goal.months limit 1) as unit'))

                ->get()->map(function ($avg) {
                    $months = [];
                    foreach (explode(',', $avg->months) as $m)
                        array_push($months, date('M', strtotime("$m/15/2019")));
                    $avg->months = implode(', ', $months);
                    $avg->created_at = newDate($avg->created_at);
                    return $avg;
                });
        }
            $data = [
                'meta' => [
                    'page' => (int) $request->pagination['page'],
                    'pages' => $totalResult ? (int) ceil($totalResult / ($perpage ?: $totalResult)) : $totalResult,
                    'perpage' => (int) $perpage,
                    'total' => (int) $totalResult,
                    'sort' => $request->sort['sort'],
                    'field' => $request->sort['field']
                ],
                'data' => $result
            ];
        return $data;
    }

    public function vsyGetData(Request $request)
    {
        $perpage = $request->pagination['perpage'];
        $offset = ($request->pagination['page'] - 1) * $perpage;
        $totalResult = 0;
        $result = DB::table('vsy_unit')
            ->get()->map(function ($avg) {

                $avg->created_at = newDate($avg->created_at);
                return $avg;
            });
        $data = [
            'meta' => [
                'page' => (int) $request->pagination['page'],
                'pages' => $totalResult ? (int) ceil($totalResult / ($perpage ?: $totalResult)) : $totalResult,
                'perpage' => (int) $perpage,
                'total' => (int) $totalResult,
                'sort' => $request->sort['sort'],
                'field' => $request->sort['field']
            ],
            'data' => $result
        ];
        return $data;
    }

    public function addModal()
    {
//        return $this->view('modals.addModal');
         return $this->view('modals.add-modal-new');
    }

    public function editModal($id)
    {
        $item = DB::table('annual_vsy_goal')->select('*', DB::raw('(select unit from vsy_unit where year = annual_vsy_goal.year and months = annual_vsy_goal.months limit 1) as unit'))->where('id', $id)->first();
//        return $this->view('modals.editModal', compact('item'));
        return $this->view('modals.edit-modal-new', compact('item'));
    }

    public function vsyAddModal()
    {
        return $this->view('unit.modals.addModal');
    }
    public function vsyEditModal($id)
    {
        $item = DB::table('vsy_unit')->where('id', $id)->first();
        return $this->view('unit.modals.editModal', compact('item'));
    }




}
