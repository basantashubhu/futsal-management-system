<?php

/**
 * DEVELOPERS
 * ----------------------------------------------
 * SUMAN  THAPA - LEAD  (NEPALNME@GMAIL.COM)
 * ----------------------------------------------
 * - PRABHAT GURUNG
 * - BASANTA TAJ
 * - RAKESH SHRESTHA
 * - LEKHRAJ RAI
 * - MANISH BUDDHACHARYA
 * - ASCOL PARAJULI
 * -----------------------------------------------
 * Created On: 2019
 *
 * THIS INTELLECTUAL PROPERTY IS COPYRIGHT Ⓒ 2018
 * ZEUSLOGIC, INC. ALL RIGHT RESERVED
 */

namespace App\Http\Controllers\Fgp\Calendar;

use App\Http\Controllers\Controller;
use App\Models\Fgp\StipendItem;
use App\Models\Fgp\TimeSheetItem;
use App\Models\Fgp\Timesheet;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CalendarAddController extends Controller
{
    
	public function storeSiteVol(Request $request, Timesheet $timesheet){

		DB::beginTransaction();

		try{

			$items = $this->bulkFormatter($request);

			$timesheet->update([

				'type_label' 		=> $request->time_type,
				'type' 				=> $this->getStipendItemCode($request->time_type),
				'time_in'			=>	$request->time_in,
				'time_out'			=>	$request->time_out,
				'break_in'			=>	$request->break_in,
				'break_out'			=>	$request->break_out,
				'total_hrs'			=>	$request->total_hrs,
				'rates'				=> 	getSiteSettings('stipend_rate'),
				'total_amount'		=> 	$this->calculateAmount($request->total_hr),
				'comment'			=>	$request->comment,

			]);

			/* Update the items */

			$this->removeAllPrevitems($timesheet->id);

			$this->storeTsitems($items, $timesheet->id);					

			DB::commit();

			return Timesheet::find($timesheet->id)->where([
				'site_id' => $timesheet->site_id,
				'volunteer_id' => $timesheet->volunteer_id,
				'period_id' => $timesheet->period_id,
				'date' => $timesheet->date,
			])->with('timesheetItems')->first();	

			return response(["message" => "succesfully updated ts"], 200);

		}catch(\Exception $e){


			DB::rollback();

			return response(["message" => $e->getMessage()], 500);

		}


	}

	public function storeTsitems($items, $timesheet){

		foreach ($items as $key => $item) {

			TimeSheetItem::create([

				'time_sheet_id'	=> $timesheet,
				'type'			=> $item['label'],
				'code'			=> $item['label'],
				'stipend_item_id'   => $this->getStipendItemId($item['label'], $item['value']),
				'value'			=> $item['value'],
				'amount'		=> $item['amount'],

			]);
		}

		return $items;

	}

	public function removeAllPrevitems($timesheet){

		$items = TimeSheetItem::where('time_sheet_id', $timesheet)->get()?: [];

		foreach ($items as $key => $item) {
			$item->delete();
		}

		return true;

	}

	public function getStipendItemCode($item_name){
	    return StipendItem::where('item_name', $item_name)->first()->item_code;
	}

	public function getStipendItemId($category, $item_name){
	    return StipendItem::where('item_name', $item_name)->where('category', $category)->first()->id;
	}

	private function getStipendRate(){
	    return getSiteSettings('stipend_rate');
	}

	private function calculateAmount($total_hrs){


	    $stipend_rate = getSiteSettings('stipend_rate');

	    $total_hr = explode(':', $total_hrs);

	    if(!isset($total_hr[1])){ // if totalhr is stored in decimal 1.20

	        $total_hr = explode('.', $total_hrs);

	    }

	    $actual_hr = $total_hr[0]+ ($total_hr[1]/60);
	    
	    return $actual_hr * $stipend_rate;

	}

	public function bulkFormatter($data){


	    if($data instanceOf Request) $data = $data->all();

	    $formatted_data = [];

	    foreach ($data as $key => $first_arrray) {

	        if(is_array($first_arrray)){

	            foreach ($first_arrray as $index => $value) {

	                $formatted_data[$index][$key] = $value;

	            }
	        }

	    }

	    return $formatted_data;

	}

}
