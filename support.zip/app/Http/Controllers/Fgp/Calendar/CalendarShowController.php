<?php

namespace App\Http\Controllers\Fgp\Calendar;

use App\Http\Controllers\BaseController;
use App\Http\Controllers\Fgp\Timesheet\TimesheetShowController;
use App\Models\Fgp\Holiday;
use App\Models\Fgp\PayPeriod;
use App\Models\Fgp\Site;

use App\Models\Fgp\Timesheet;
use App\Models\Fgp\Volunteer;
use App\Models\User;
use App\Traits\AssignedVolunteerTrait;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class CalendarShowController extends BaseController
{

    private static $path;

    use AssignedVolunteerTrait;

    public function __construct()
    {
        parent::__construct();

        self::$path = $this->layout . '.fgp.calendar';
    }

    public function __invoke()
    {

        return view(self::$path . '.index');

    }

    private function getSupervisorVolunteers()
    {

        return auth()->user()->role_id === 1 ? Volunteer::where('is_deleted', 0)->get() : auth()->user()->getVolunteers();

    }

    private function getSupervisorSites()
    {

        return auth()->user()->role_id === 1 ? Site::where('is_deleted', 0)->get() : auth()->user()->sites();

    }

    public function managedSitesTsDetails()
    {

        if (auth()->user()->role_id !== 1):
            $rptMgr = auth()->user()->hierarchyIds()->all();

            return User::join('site_managers', 'site_managers.user_id', 'users.id')
                ->join('sites', 'site_managers.site_id', 'sites.id')
                ->join('timesheets as ts', 'ts.site_id', 'sites.id')
                ->join('volunteers', 'volunteers.id', 'ts.volunteer_id')
                ->join('volunteers_supervisors as vs', function ($join) {
                    $join->on('vs.supervisor_id', 'users.id');
                    $join->on('vs.volunteer_id', 'volunteers.id');
                })
                ->select('sites.id as site_id', 'ts.date', 'ts.id as timesheet_id', 'ts.period_id',
                    DB::raw('(select count(distinct sites.id)) as total_sites'),
                    DB::raw('(select count(distinct ts.volunteer_id) from timesheets tss where tss.id = ts.id) as vol_tot'),
                    DB::raw('SUM( TIME_TO_SEC(total_hrs) ) as total_hrs')
                )
                ->groupBy('ts.date')
                ->whereIn('site_managers.user_id', $rptMgr);

        else:

            return Site::join('timesheets as ts', 'ts.site_id', 'sites.id')
                ->join('volunteers', 'volunteers.id', 'ts.volunteer_id')
                ->select('sites.id as site_id', 'ts.date', 'ts.id as timesheet_id', 'ts.period_id',
                    DB::raw('count(*) as total_sites'),
                    DB::raw('(select count(distinct ts.volunteer_id) from timesheets tss where tss.id = ts.id) as vol_tot'),
                    DB::raw('SUM( TIME_TO_SEC(total_hrs) ) as total_hrs')
                )
                ->groupBy('ts.date');
        endif;

    }

    private function classAccordingToTimeTense($date)
    {

        if (Carbon::today()->lessThan(Carbon::parse($date))) {

            /* Future date */

            return ['m-fc-event--light', 'm-fc-event--solid-future'];

        } else if (Carbon::today()->greaterThan(Carbon::parse($date))) {

            /* Past Date */

            return ['m-fc-event--accent', 'm-fc-event--solid-past'];

        } else {

            /* Today */

            return ['m-fc-event--light', 'm-fc-event--solid-success']; // green

            // return ['m-fc-event--light', 'm-fc-event--solid-today'];   // warning

        }

    }

    public function isHoliday($date)
    {

        return Holiday::where('hol_date', $date)->where('is_deleted', 0)->first() ? true : false;

    }

    public function getHolidayName($date)
    {

        $holiday = Holiday::where('hol_date', $date)->where('is_deleted', 0)->first();

        return $holiday ? ucfirst($holiday->name) : '';

    }

    public function getTsCalendarData()
    {

        return [];

    }

    public function calendarBySite(Site $site)
    {

        $sites_data = $this->managedSitesTsDetails()->where('sites.id', $site->id)->get();

        $site_vols = array_map(function ($site) {

            $totalHrs = str_replace('.', ":", number_format($site['total_hrs'] / 3600, 2));
            $isHoliday = $this->isHoliday($site['date']);

            return [
                'title' => !$isHoliday ? "Total Volunteers : {$site['vol_tot']} \n Total Hrs: {$totalHrs}" : $this->getHolidayName($site['date']),
                // 'className' => ["m-fc-event--solid-info", "m-fc-event--light"],
                'className' => !$isHoliday ? $this->classAccordingToTimeTense($site['date']) : ['fc-event--holiday'],
                'rendering' => $isHoliday ? "background" : '',
                'type' => 'sites',
                'start' => $site['date'],
                'date' => $site['date'],
                'site_id' => $site['site_id'],
                'period_id' => $site['period_id'],
            ];

        }, $sites_data->toArray());

        return $site_vols;

    }

    public function calendarByVolunteer(Volunteer $volunteer)
    {

        if (!in_array(auth()->user()->role_id, [1, 2, 7])) {
            $rptMgr = auth()->user()->hierarchyIds()->all();

            $timesheets = Timesheet::select([
                'timesheets.time_in', 'timesheets.time_out', 'timesheets.date as start',
                'timesheets.volunteer_id', 'timesheets.id', 'timesheets.total_hrs',
                'timesheets.site_id', 'timesheets.approval_status',
            ])
                ->where('timesheets.volunteer_id', $volunteer->id)
                ->whereRaw('exists (select site_id from site_managers where user_id in (' . implode(',', $rptMgr) . ') and site_id = timesheets.site_id and site_managers.is_deleted = 0)')
                ->with('site')
                ->get();

        } else {

            $timesheets = Timesheet::select('time_in', 'time_out', 'date as start', 'volunteer_id', 'id', 'total_hrs', 'site_id', 'approval_status')->where('volunteer_id', $volunteer->id)
                ->with('site')
                ->get();

        }

        foreach ($timesheets as $timesheet) {

            $time_in = $this->convertToHrMin($timesheet->time_in);
            $time_out = $this->convertToHrMin($timesheet->time_out);
            $total_hrs = $this->convertToHrMin($timesheet->total_hrs);
            $site_name = ucfirst($timesheet->site->site_name);

            $isHoliday = $this->isHoliday($timesheet->start);

            $timesheet->title = !$isHoliday ? "{$site_name} \n Time in : {$time_in} \n Time out: {$time_out}" : $this->getHolidayName($timesheet->start);
            // $timesheet->className = ["m-fc-event--solid-primary", "m-fc-event--light"];
            // $timesheet->className = $this->classAccordingToTimeTense( $timesheet->start );

            $timesheet->className = !$isHoliday ? $this->classAccordingToTimeTense($timesheet->start) : ['fc-event--holiday'];
            $timesheet->rendering = $isHoliday ? "background" : '';
            $timesheet->type = "volunteer";
            $timesheet->description = "Time in : {$time_in} <br> Time out: {$time_out} <br> Total hrs: {$total_hrs}";
            $timesheet->vol_id = $timesheet->volunteer_id;
            $timesheet->site_id = $timesheet->site_id;
        }

        return $timesheets;

    }

    private function convertToHrMin($time)
    {

        return date_create($time)->format('G:i');

    }

    public function viewVolTs(Volunteer $volunteer, Timesheet $timesheet)
    {

        $timesheetShowController = new TimesheetShowController;

        $apprvs = $timesheetShowController->get_appr_flow($timesheet->period_id);

        return view(self::$path . '.volunteer.index', [

            'vol' => $volunteer,
            'timesheet' => $timesheet,
            'site' => $timesheet->site,
            'apprvs' => $apprvs,

        ]);
    }

    private function getTimesheetByDate($site_id, $vol_id, $period_id, $date)
    {

        return Timesheet::where('site_id', $site_id)->where('period_id', $period_id)
            ->where('volunteer_id', $vol_id)
            ->where('date', $date)
            ->first();

    }

    public function viewSiteTs(Site $site, PayPeriod $period, $date)
    {

        $timesheetShowController = new TimesheetShowController;

        $apprvs = $timesheetShowController->get_appr_flow($period->id);

        $assignedVol = $this->getTsAssignedVolunteers($site->volunteers->toArray(), $site->id, $period->id, $date);

        $vol = count($assignedVol) ? $assignedVol[0] : ''; //First volunteer to display
        //        dd($assignedVol);

        $timesheet = $this->getTimesheetByDate($site->id, $vol['id'], $period->id, $date);

        return view(self::$path . '.site.index', [

            'site' => $site,
            'apprvs' => $apprvs,
            'assignedVolunteers' => $assignedVol,
            'period_id' => $period->id,
            'timesheet' => $timesheet,
            'vol' => $vol,
            'date' => $date,
        ]);

    }

    public function viewVolSiteTs(Site $site, Volunteer $volunteer, PayPeriod $period, $date)
    {

        $timesheet = $this->getTimesheetByDate($site->id, $volunteer->id, $period->id, $date);

        return view(self::$path . '.site.right-section', [
            'vol' => $volunteer->toArray(),
            'date' => $date,
            'timesheet' => $timesheet,
        ]);

    }

    /* Old */

    public function showDayDetail()
    {
        return view($this->layout . '.pages.calendar.calendar_day_detail');
    }

    public function volunteerDetail($volunteer)
    {
        return view($this->layout . '.pages.calendar.calendar_day_detail');
    }

    public function fetchAllCalendarData()
    {
        $vols = Volunteer::orderByDesc('created_at')->where('is_deleted', 0)->get();
        foreach ($vols as $key => $vol):
            $vols[$key]['contact'] = $vol->contact();
        endforeach;
        return $vols;
    }

    public function memberCalendarDetail($volunteer)
    {
        return view($this->layout . '.pages.calendar.volunteer-calendar');
    }
}
