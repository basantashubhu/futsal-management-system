<?php
    
/**
 * DEVELOPERS
 * ----------------------------------------------
 * SUMAN  THAPA - LEAD  (NEPALNME@GMAIL.COM)
 * ----------------------------------------------
 * - PRABHAT GURUNG
 * - BASANTA TAJ
 * - RAKESH SHRESTHA
 * - LEKHRAJ RAI
 * - MANISH BUDDHACHARYA
 * -----------------------------------------------
 * Created On: 2019
 *
 * THIS INTELLECTUAL PROPERTY IS COPYRIGHT Ⓒ 2018
 * ZEUSLOGIC, INC. ALL RIGHT RESERVED
 */

namespace App\Http\Controllers\Fgp\Volunteer;

use Carbon\Carbon;
use App\Models\File;
use App\Models\User;
use App\Models\Address;
use App\Models\Contact;
use App\Models\Fgp\Site;
use App\Repo\AddressRepo;
use App\Repo\ContactRepo;
use App\Models\Fgp\Template;
use Illuminate\Http\Request;
use App\Models\Fgp\Timesheet;
use App\Repo\FGP\VolunteerRepo;
use App\Models\Settings\Lookups;
use App\Lib\Exporter\CSVExporter;
use App\Lib\Exporter\PDFExporter;
use App\Lib\Exporter\TxtExporter;
use App\Lib\Exporter\JSONExporter;
use App\Models\Fgp\TemplateDetail;
use App\Models\Fgp\VolunteerSites;
use Illuminate\Support\Facades\DB;
use App\Models\Fgp\VolunteerDetail;
use Illuminate\Support\Facades\Crypt;
use App\Http\Controllers\BaseController;
use App\Http\Requests\Fgp\VolunteerRequest;
use App\Http\Controllers\Fgp\Calendar\CalendarShowController;
use App\Http\Controllers\Fgp\Timesheet\TimesheetShowController;
use App\Models\Fgp\{ Volunteer, StipendItem, TemplateComponent, TemplateItems, ReadOnlySite};

class VolunteerController extends BaseController
{

	private $clayout = "";
	private static $repo;

	public function __construct()
	{
		parent::__construct();
		$this->clayout = $this->layout.'.fgp.volunteer';
	}

    public function __invoke(){
        $supervisor_id = Volunteer::where('is_deleted', false)->distinct()->pluck('vol_supervisor_id');
        $supervisors = [];
        if(count($supervisor_id)>0){
            foreach($supervisor_id as $id){
                array_push($supervisors, User::find($id));
            }
        }
        $advData=isset($_COOKIE['volunteers_advanced'])?json_decode($_COOKIE['volunteers_advanced']):[];
        $openData=isset($_COOKIE['volunteers_quick'])?json_decode($_COOKIE['volunteers_quick']):[];
    	return view($this->clayout.".index", compact('advData', 'openData', 'supervisors'));
    }
    
    public static function getRepo($model){
        self::$repo = new VolunteerRepo($model);
        return self::$repo;
    }

    public function getVolCalendarData(Volunteer $volunteer){

        $calendarController = new CalendarShowController;

        return $calendarController->calendarByVolunteer($volunteer);

        return $calendarController;

    }

    public function viewVolTs(Volunteer $volunteer, Timesheet $timesheet, Site $site){

        $timesheetShowController = new TimesheetShowController;

        $apprvs = $timesheetShowController->get_appr_flow($timesheet->period_id);

        return view($this->clayout.'.profile.calendar.cal-view', [

            'vol' => $volunteer,
            'timesheet' => $timesheet,
            'site' => $timesheet->site,
            'apprvs' => $apprvs

        ]);

    }
    
    /**
     * Fetch volunteer data for mdatatable
     */

    public function allVolunteers(Request $request){    
    	
        $data = self::getRepo('Fgp\Volunteer')->selectDataTable($request);
        return $data;
    }

    public function allVolunteersWiteSite(Request $request, $site){
        $data = self::getRepo('Fgp\Volunteer')->selectDataTableWithAssignedSite($request,$site);
        return $data;
    }

    public function exportData(Request $request, $type)
    {
        if(isset($_COOKIE['volunteers_advanced']) || isset($_COOKIE['volunteers_quick'])){
            $advData=isset($_COOKIE['volunteers_advanced'])?json_decode($_COOKIE['volunteers_advanced']):[];
            $quickData=isset($_COOKIE['volunteers_quick'])?json_decode($_COOKIE['volunteers_quick']):[];
            $mergeData=array_merge($advData,$quickData);
        }else{
            $mergeData = [];
        }
        $data = self::getRepo('Fgp\Volunteer')->getReportData($request);
        $fields = array('Name', 'Email', 'Phone', 'Primary Address', 'City');
        $mapField = array('full_name', 'email', 'cell_phone', 'add1', 'city');
        $data = cleaner($mapField, $data);
        $data['table'] = 'Report of Volunteers';
        $data['request'] = '';
        if(empty($mergeData)){
            $data['request'] = ['Search' => 'All'];
        }else{
            $data['request'] = [];
            foreach($mergeData as $d):
                if($d->name=='vol_name'){
                    $data['request']['Name'] = $d->value;
                }
                if($d->name=='email'){
                    $data['request']['Email'] = $d->value;
                }
                if($d->name=='cellPhone'){
                    $data['request']['Cell Phone'] = $d->value;
                }
                if($d->name=='ssnFilter'){
                    $data['request']['SSN'] = $d->value;
                }
                if($d->name=='add1'){
                    $data['request']['Primary Address'] = $d->value;
                }
                if($d->name=='city'){
                    $data['request']['City'] = $d->value;
                }
                if($d->name=='zipCode'){
                    $data['request']['Zip Code'] = $d->value;
                }
            endforeach;
        }
        if (count($data) > 0) {
            $export = $this->reportFactory($type, $fields, $data);
            $exporter = new \App\Lib\Exporter\Exporter($export);
            $filename = $exporter->export();
            return response()->download($filename)->deleteFileAfterSend(true);
        }{
            return 'No Data Available For Current Filter';
        }
    }

    /**
     * @param $type
     * @param $data
     * @return CSVExporter|JSONExporter|PDFExporter|TxtExporter
     * @throws \Exception
     */
    public function reportFactory($type, $fields, $data)
    {
        switch ($type) {
            case 'csv':
                return new CSVExporter($data, $fields, 'VolunteerReports');
                break;
            case 'json':
                return new JSONExporter($data);
                break;
            case 'txt':
                return new TxtExporter($data);
                break;
            case 'pdf':
                return new PDFExporter($data, $fields, 'print');
                break;
            default:
                throw new \Exception("Method Not Allowed " . $type);
                break;
        }
    }

    public function viewVolunteer(Volunteer $volunteer){
        $templates = Template::where('table_name', 'volunteers')->where('table_id', $volunteer->id)->where('is_deleted', false)->get();
        $profile = File::where('table', 'volunteers')->where('table_id', $volunteer->id)->where('is_deleted', 0)->first();
        if (!is_null($profile)) {
            if (file_exists(storage_path('uploads/'. $profile->file_name))):
                $volunteer->image = base64_encode(file_get_contents(storage_path('uploads/') . $profile->file_name));
            else:
                $volunteer->image = base64_encode(file_get_contents(storage_path('uploads/avatar.jpg')));
            endif;
        }else{
            $volunteer->image = base64_encode(file_get_contents(storage_path('uploads/avatar.jpg')));
        }
        // $volunteerDetail = $volunteer->details;
        $sitesss = $volunteer->assignedSites;
        $reg_hrs = Timesheet::where('volunteer_id', $volunteer->id)->where('status', 'Posted')->sum(DB::raw('time_to_sec(total_hrs)'));
        $reg_hrs /= 3600;
        $volunteer->regular_hrs_worked = total_hrs($reg_hrs);
        return view($this->clayout.'.profile.index', compact('volunteer', 'templates', 'sitesss'));
    }

   public function getAssignedSites($request = false){
       $is_admin = \Auth::user()->role_id == 1;
       if ($request instanceof Request) {
            $cat = $request->input('query.site_cat', 'default');
            if ($cat === 'default') return auth()->user()->sites(function($query) use($request){
                $query->select(['id', 'site_name'])
                ->when($request->input('query.SearchSites', false), function($q, $searchString) {
                    $q->where('site_name', 'like', "%$searchString%");
                });
            }, ['table_id', 'county', 'region', 'district']);
            if ($cat === 'county') return ReadOnlySite::select('id', 'site_name')->with(['address' => function($ad) {
                    return $ad->select('table_id', 'county', 'region');
                }])->whereHas('address', function($add) {
                    $counties = auth()->user()->settings()->where('type', 'default_counties')->pluck('value')->all();
                    $add->whereIn('county', $counties);
                })
                ->when($request->input('query.SearchSites', false), function($q, $searchString) {
                    $q->where('site_name', 'like', "%$searchString%");
                })->get();
            if ($cat === 'all') return ReadOnlySite::select('id', 'site_name')->with(['address' => function($ad) {
                    return $ad->select('table_id', 'county', 'region');
                }])
                ->when($request->input('query.SearchSites', false), function($q, $searchString) {
                    $q->where('site_name', 'like', "%$searchString%");
                })->get();
        }

       return !$is_admin ? \Auth::user()->sites() : ReadOnlySite::with('address')->get();

   }

   public function getSiteData(Request $request, Volunteer $volunteer)
   {
       $v_sites = $volunteer->readOnlySites()->select('sites.id', 'sites.site_name')
           ->with(['address' => function($add) {
               $add->select('table_id', 'region', 'county');
           }])
           ->get();
       $sitesss = $this->getAssignedSites($request);
       /* if(!$sitesss->count() && $request->input('query.site_cat') == 'county') {
           $sitesss->push(new ReadOnlySite([
                'id' => '',
                'site_name' => 'Assign Default Site'
           ]));
       } */
       if($request->input('sync') != 'false')
            $sitesss = $sitesss->merge($v_sites);
       $sitesss = $sitesss->map(function($site) use($v_sites){
               $site->assinged_site = $v_sites->contains('id', $site->id);
               if($add = $site->address) {
                   $site->county = $add->county;
                   $site->region = $add->region;
               }
            //    unset($site->address, $site->pivot);
               return $site;
           })->unique();
       return ['data' => $sitesss, 'meta' => [
           'page' => 1,
           'pages' => 1,
           'total' => $sitesss->count(),
           'sort' => 'asc',
           'field' => 'site_name'
       ]];
   }

   public function siteList(Volunteer $volunteer) {
       $sitesss = $volunteer->sites;
        return view('default.fgp.volunteer.profile.include.site_list', compact('sitesss'));
   }

   public function tableBody(Request $request, Volunteer $volunteer)
   {
       $v_sites = $volunteer->sites()->pluck('sites.id');
//       dd($this->getAssignedSites($request));
       $sitesss = $this->getAssignedSites($request)->map(function($site) use($v_sites){
           if ($v_sites->contains($site->id))
               $site->assinged_site = true;
           return $site;
       });
       return view($this->clayout . '.profile.include.siteTableBody', compact('sitesss', 'v_sites', 'volunteer'));
   }

    public function addSites(Volunteer $volunteer)
    {
        $v_sites = $volunteer->sites()->pluck('sites.id');
        $sitesss = $this->getAssignedSites()->map(function($site) use($v_sites){
            if ($v_sites->contains($site->id))
                $site->assinged_site = true;
            return $site;
        });

        return view($this->clayout.'.profile.modal.addSite', compact('sitesss', 'volunteer', 'v_sites'));
    }

    public function storeSites(Request $request, Volunteer $volunteer)
    {
        if($request->has('selected_sites')){

            if ($request->input('sync', 'true') != 'false')
            VolunteerSites::where('volunteer_id', $volunteer->id)->delete();

            $bulk_data = [];
            foreach($request->selected_sites as $site){
                $bulk_data[$site] = array(
                    'volunteer_id' => $volunteer->id,
                    'date' => date('Y-m-d'),
                    'alt_site_id1' => $site,
                    'alt_site_id2' => $site,
                    'alt_site_id3' => $site,
                    'choosed_site_id' => $site
                );
            }
            $volunteer->sites()->attach($bulk_data);
            $sites = Site::find(array_keys($bulk_data));
            return $this->response("Sites add successfully", $sites, 200);
        }else{
            return $this->response("Sites are not selected", "error", 422);
        }
    }

    public function addVolunteer(){
        $validations = validation_value('volunteer_register');
    	return view($this->clayout.'.modals.add', compact('validations'));
    }  

    protected function create_code_from_label($string){
        return str_replace('"','',str_replace(' ', '_',mb_strtolower($string)));        
    }  

    private function detailsFormatter(Request $request, $volunteer = null){

        if($volunteer){
            $prevDetails = VolunteerDetail::where('volunteer_id', $volunteer->id)->get();
            foreach ($prevDetails as $prevDetail) {
                VolunteerDetail::find($prevDetail)->first()->delete();
            }
        }

        $details = [];
        if($request->input('label') && $request->input('value')){    

            foreach ($request->input('label',[]) as $key => $code) {
                $details[] = [
                    'label' => $code,
                    'value' => $request->values[$key],
                ];
            }
        }

        foreach ($request->input('vlt_dtl', []) as $key => $value) {
            $details[] = [ 'label' => $key , 'value' => $value ];
        }
        return $details;
    }

    private function volGenerals(Request $request, $volunteer = null){
        $vol_general_details = $request->only([
             'salutation','first_name', 'middle_name', 'last_name',
             'vol_supervisor_id', 'title', 'payment_code', 'department', 'alt_id', 
            //  'active_date'
        ]);
        
        if($request->vol_ssn !== ''){
            $ssn = preg_replace('/[^A-Za-z0-9]/','', $request->vol_ssn);
            $vol_general_details['vol_ssn'] = Crypt::encryptString(Crypt::encryptString($ssn));
        }

        if($request->vol_supervisor_id == ''){
            $vol_general_details['vol_ssn'] = '1';
        }
 
        if($volunteer){
            $v = Volunteer::find($volunteer->id);
            return self::getRepo($v)->saveUpdate($vol_general_details);
        }else{
            return self::getRepo('Fgp\Volunteer')->saveUpdate($vol_general_details);
        }        
    }

    private function volAddress(Request $request, $created_vol, $volunteer = null){
        $address = $request->only([
            'add1', 'add2', 'county', 'city', 'state', 'zip_code', 'district'
        ]);
        $address['table_name'] = "volunteers";
        $address['table_id'] = $created_vol->id;
        if($volunteer){
            $addr = Address::where('table_name', 'volunteers')->where('table_id', $volunteer->id)->first();
            return self::getRepo($addr)->saveUpdate($address);
        }
        return self::getRepo('Address')->saveUpdate($address);
    }

    private function volContact(Request $request, $created_vol, $volunteer = null){
        $contact = $request->only([
            'tel_phone', 'cell_phone', 'alt_phone', 'email', 'phone_ext'
        ]);
        $contact['table_name'] = "volunteers";
        $contact['table_id'] = $created_vol->id;
        if($volunteer){
            $prevContact = Contact::where('table_name', 'volunteers')->where('table_id', $volunteer->id)->first();
            return (new ContactRepo())->updateContact($contact, $created_vol);
        }
        return (new ContactRepo())->storeContact($contact, $created_vol);
    }

    public function storeVolunteer(VolunteerRequest $request, Volunteer $volunteer = null)
    { //VolunteerRequest   
        DB::beginTransaction();
        try{
            if($request->has('email') && $request->email != ''){
                $volunteer = self::getRepo('Fgp\Volunteer')->findByEmail($request->email);
            }
            $created_vol = $this->volGenerals($request, $volunteer);

            // $details = $this->detailsFormatter($request, $volunteer);
            if($request->has('label')){
                foreach($request->label as $k=>$v){
                    if($v != null){
                        $c = strtolower($v);
                        $c = str_replace(" ", "_", $c);
                        $detail['volunteer_id'] = $created_vol->id;
                        $detail['label'] = $v;
                        $detail['code'] = $c;
                        $detail['value'] = $request->value[$k];
                        $detail['lookup_id'] = $request->lookup_id[$k];
                        $details = self::getRepo('Fgp\VolunteerDetail')->updateVolunteerDetail($detail, $created_vol->id);
                    }
                }
                
            } 
            // foreach ($details as $k => $detail) {
            //     if($detail['value']):
            //         $code = $this->create_code_from_label($detail['code']);

            //         $detail_data['volunteer_id'] = $created_vol->id;
            //         $detail_data['label'] = $detail['code'];
            //         $detail_data['code'] = $code;
            //         $detail_data['value'] = $detail['value'];
            //         $detail_date['data_type'] = isset($detail['data_type'])?:'string';
            //         $detail_date['has_lookup'] = isset($detail['has_lookup'])?:'0';

            //         $details = self::getRepo('Fgp\VolunteerDetail')->saveUpdate($detail_data);
            //     endif;
            // }


            $this->volAddress($request, $created_vol, $volunteer);

            $this->volContact($request, $created_vol, $volunteer);

            DB::commit();   
            return $this->response("Volunteer successfully created", ['volunteer_id' => $volunteer->id],200);

        }catch(\Exception $e){
            DB::rollback();
            return response(["message" => $e->getMessage()], 500);
        }    	    	
    }

    public function deleteVolunteerModal(Volunteer $volunteer){
        return view($this->clayout.".modals.delete", compact('volunteer'));
    }

    public function deleteVolunteer(Volunteer $volunteer){
        $volunteer->deleted_at = now();
        $volunteer->is_deleted = 1;
        $volunteer->userd_id = auth()->id();
        $volunteer->save();
        return $this->response("Successfully volunteer deleted", "view", 200);
    }

    public function editVolunteer(Volunteer $volunteer){
        $validations = validation_value('volunteer_register');
        return view($this->clayout.'.modals.edit', compact('volunteer', 'validations'));
    }

    public function getData($code, $val = false)
    {
        // dd($val);

        if($val){
            $data = Lookups::where('code', $code)->where('value', 'LIKE', '%' . $val . '%')->get();
        }else{
            $data = Lookups::where('code', $code)->get();
        }
        $cData = isset($_COOKIE['volunteer_detail'])?$_COOKIE['volunteer_detail']:"";
        if($cData != ""){
            $d = [];
            $cData = explode(',',$cData);
            foreach($data as $dat){
                if(!in_array($dat->value, $cData)){
                    array_push($d, $dat);
                }
            }
            return $this->responseLookup($d, ["value"]);
        }else{

            return $this->responseLookup($data, ["value"]);
        }
    }

    public function getVolunteerDetails($id)
    {
        $data = Lookups::find($id);
        return $data;
    }

    public function getSupervisor($val = false)
    {
        if($val){
            $data = User::where('role_id', 3)->where('name', 'LIKE', '%' . $val . '%')->get();
        }else{
            $data = User::where('role_id', 3)->get();
        }
        return $this->responseLookup($data, ["name"]);
    }

    public function checkAltID($alt_id)
    {
        $volExists = Volunteer::where('alt_id', $alt_id)->first();

        if($volExists){


            if(request()->has('volunteer')){

                return (int)request()->volunteer === $volExists->id ? "false" : 'exist';


            }else{

                return 'exist';

            }

        }

        return "false";
    }

    public function eSTipendIdValidation($eStipendId){
        return Volunteer::where('eStipend_id', \DB::raw($eStipendId))->first() ? "true" : "false";
    }

    public function checkEmail(Request $request)
    {
        $e = Contact::where('email', $request->email)->first();
        if(isset($e->id)){
            return $e->id;
        }else{
            return 'not';
        }
    }

    public function getEmailInfo($id)
    {
        $email = Contact::find($id);
        $detail = DB::table($email->table_name)->where('id', $email->table_id)->first();
        $detail->address = Address::where('table_name', $email->table_name)->where('table_id', $email->table_id)->first();
        $detail->contact = $email;
        $detail->supervisor = User::find($detail->vol_supervisor_id);
        return view($this->clayout.'.modals.info', compact('detail'));
    }

    public function contactEdit(Volunteer $volunteer)
    {
        return view($this->clayout.'.profile.modal.contactEdit', compact('volunteer'));
    }

    public function contactUpdate(Request $request, Volunteer $volunteer)
    {   
        DB::beginTransaction();
        try{
            $contact = $request->only([
                'tel_phone', 'cell_phone', 'alt_phone', 'email', 'phone_ext', 'fax', 'url'
            ]);
            $contact['table_name'] = "volunteers";
            $contact['table_id'] = $volunteer->id;
            if($volunteer){
                $prevContact = Contact::where('table_name', 'volunteers')->where('table_id', $volunteer->id)->first();
                $res = (new ContactRepo())->updateContact($contact, $volunteer);
            }
            $res = (new ContactRepo())->storeContact($contact, $volunteer);
            DB::commit();
            return $this->response("Contact Updated successFully", "view", 200);
        }
        catch(\Exception $e){
            DB::rollBack();
            dd($e);
            return $this->response("Can't update contact", 'view', 422);
        }
    }

    public function addressEdit(Volunteer $volunteer)
    {
        return view($this->clayout.'.profile.modal.addressEdit', compact('volunteer'));
    }

    public function addressUpdate(Request $request, Volunteer $volunteer)
    {   
        DB::beginTransaction();
        try{
            $address = $request->only([
                'add1', 'add2', 'county', 'city', 'state', 'zip_code', 'district'
            ]);
            $address['table_name'] = "volunteers";
            $address['table_id'] = $volunteer->id;
            if($volunteer){
                $addr = Address::where('table_name', 'volunteers')->where('table_id', $volunteer->id)->first();
                $res = self::getRepo($addr)->saveUpdate($address);
            }
            $res = self::getRepo('Address')->saveUpdate($address);
            DB::commit();
            return $this->response("Address Updated successFully", "view", 200);
        }
        catch(\Exception $e){
            DB::rollBack();
            dd($e);
            return $this->response("Can't update Address", 'view', 422);
        }
    }

    public function personalEdit(Volunteer $volunteer)
    {
        $supervisors = User::where('role_id', 3)->where('is_deleted', false)->get();
        return view($this->clayout.'.profile.modal.personalEdit', compact('volunteer', 'supervisors'));
    }

    /**
     * update volunteer details from volunteer profile
     * @param Request $request
     * @param         $id
     * @return VolunteerController|\Illuminate\Http\JsonResponse
     */
    public function update_det(Request $request, $id)
    {
        DB::beginTransaction();
        try
        {
            Volunteer::where('id', $id)->update($request->only('vol_status', 'is_active'));
            if ($request->input('deactivate_reason', false)) {
                VolunteerDetail::create([
                    'volunteer_id' => $id,
                    'code' => 'deactivate_reason',
                    'label' => 'Reason',
                    'value' => $request->input('deactivate_reason')
                ]);
            }
            if ($request->input('deactivate_remarks', false)) {
                VolunteerDetail::create([
                    'volunteer_id' => $id,
                    'code' => 'deactivate_remarks',
                    'label' => 'Remarks',
                    'value' => $request->input('deactivate_remarks')
                ]);
            }
            DB::commit();
            return $this->response('Volunteer updated successfully.', 'success', 200);
        }
        catch (\Exception $e)
        {
            DB::rollBack();
            return $this->response($e->getMessage(), 'error', 422);
        }
    }


    public function personalUpdate(Request $request, Volunteer $volunteer)
    {
        DB::beginTransaction();
        try{
            $vol_general_details = $request->only([
                'salutation','first_name', 'middle_name', 'last_name', 'vol_ssn', 'alt_id'
           ]);
           
           if($request->vol_ssn !== ''){
               $ssn = preg_replace('/[^A-Za-z0-9]/','', $request->vol_ssn);
               $vol_general_details['vol_ssn'] = Crypt::encryptString(Crypt::encryptString($ssn));
           }
           $vol_general_details['vol_supervisor_id'] = '1';
           if($volunteer){
//                $v = Volunteer::find($volunteer->id);
                $res = self::getRepo($volunteer)->saveUpdate($vol_general_details);
                $ids = $request->vol_supervisor_id?:[];
                if (is_array($ids)) {
                    $res->supervisors()->detach();
                    $sup = array_map(function($v) { return ['updated_at'=>now()];}, array_flip($ids));
                    $res->supervisors()->attach($sup);
                }
           }else{
                $res = self::getRepo('Fgp\Volunteer')->saveUpdate($vol_general_details);
                if($request->has("vol_supervisor_id")){
                    foreach($request->vol_supervisor_id as $sup){
                        $res->supervisors()->attach($sup);
                    }
                }
           }  
           DB::commit();
           return $this->response("Volunteer updated Successfully", 'view', 200);
        }
        catch(\Exception $e){
            DB::rollBack();
            dd($e);
            return $this->response("Can't update Address", 'error', 422);
        }
    }

    //personal detail update
    public function personalDetail(Volunteer $volunteer)
    {
        return view($this->clayout.'.profile.modal.personalDetail', compact('volunteer'));
    }

    //
    public function personalDetailUpdate(Request $request, Volunteer $volunteer)
    {
        if($request->has('value')){
            $details = VolunteerDetail::where('volunteer_id', $volunteer->id)->get();
            foreach($details as $de){
                $de->delete();
            }
            foreach($request->value as $k=>$v){
                if($v != null){
                    $c = strtolower($v);
                    $c = str_replace(" ", "_", $c);
                    $detail['volunteer_id'] = $volunteer->id;
                    $detail['value'] = $v;
                    $detail['code'] = $c;
                    $detail['label'] = $request->label[$k];
                    $details = self::getRepo('Fgp\VolunteerDetail')->updateVolunteerDetail($detail, $volunteer->id);
                }
            } 
            return $this->response("Volunteer Detail updated Successfully", 'view', 200);
        }else{
            return $this->response("Can't update detail", 'error', 422);
        }
    }

    public function VolunteerTemplateView($vol, Template $template){

        if(request()->has('temporary')){

            $volunteer = $vol;
            
        }else{
            $volunteer = Volunteer::find($vol);
        }

        $sortedWithWeek = [];

        foreach ($template->details as $detail) {
            
            $sortedWithWeek[$this->getWeekIndex($detail->days)][] = [
                "id" => $detail->id,
                "days" => $detail->days,
                "site" => $detail->site,
                "time_type" => $detail->timeType,
                "time_in" => $detail->time_in,
                "time_out" => $detail->time_out,
                "break_out" => $detail->break_out,
                "break_in" => $detail->break_in,
                "total_hr" => $detail->total_hours,
                "items" => $detail->items
            ];
        }


       $templateDetails = $sortedWithWeek;

       ksort($templateDetails);
        
        $weeks = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        return $this->view($this->clayout.'.profile.modal.viewTemplate', compact('volunteer', 'template', 'templateDetails'));
        

    }

   //old volunteer template
//    public function volunteerTemplateView(Volunteer $volunteer, Template $template)
//    {
//        $temp = TemplateDetail::where('template_id', $template->id)->first();
//        $sitesDetail = VolunteerSites::where('volunteer_id', $volunteer->id)->get();
//        $data = json_decode($temp->value, 1);

//        $prevData = [];

//        foreach ($data as $key => $dataArray) {

//            foreach ($dataArray as $label => $valueArr) {                

//                foreach ($dataArray['days'] as $dayIndex => $days) {

//                    if($label === "days") break;

//                    foreach ($valueArr as $site => $labelVal) {

//                        if($label === "items"){

//                            /* Here $site is travel / meal */

//                            $type = $site;

//                            foreach ($labelVal as $itemLabel => $itemLabelValArray) {
                               
//                                foreach ($itemLabelValArray as $itemSite => $itemValArray) {
//                                    $prevData[$key][$days][$itemSite]['items'][$type][$itemLabel] = $itemValArray[0];
//                                }

//                            }
//                            continue;
//                        }
//                        $currentSite = Site::find($site); 
//                        $prevData[$key][$days][$site][$label]  =  isset($labelVal[0]) ? $labelVal[0] : $labelVal;
//                        $prevData[$key][$days][$site]['site_name']    = ucfirst($currentSite->site_name);                  
//                        $prevData[$key][$days][$site]['id']    = $currentSite->id;                 
                       
//                    }

//                }                

//            }

//        }
//        $sortedWithWeek = [];

//        foreach($prevData as $index => $dataArray){
//            foreach ($dataArray as $weekDay => $originalData) {
//                $sortedWithWeek[$this->getWeekIndex($weekDay)][] = $dataArray;
//            }
//        }

//        $prevData = $sortedWithWeek;

//        ksort($prevData);

//        $weeks = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
//        return $this->view($this->clayout.'.profile.modal.viewTemplate', compact('data', 'weeks', 'sitesDetail','volunteer', 'template', 'temp', 'prevData'));
//    }

   public function getWeekIndex($weekday){
       $sortingDirecton = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

       return array_search(ucfirst($weekday), $sortingDirecton);       

   }

    // public function checkTimeValidation($data){
    //     $formatted_temp = $this->formatDefaultTemplate($data);

    //     $exception_occured = false;

    //     foreach ($formatted_temp as $d) {
    //         if($d['day']=== "Sunday") continue;
    //         $otherDay = array_filter($formatted_temp, function($cur) use($d){

    //             if($d['uniqid'] === $cur['uniqid']) return false;

    //             if($cur['day'] === $d['day']) {
    //                 if( date_create($cur['time_in'])->format("h:i:s") >= date_create($d['time_in'])->format("h:i:s") && 
    //                     date_create($cur['time_in'])->format("h:i:s") <= date_create($d['time_out'])->format("h:i:s")
    //                 ){
    //                     return true;
    //                 }

    //                 return false;
    //             }

    //         });

    //         if(count($otherDay)){
    //             $exception_occured = true;
    //             break;

    //         }

    //     }

    //     if($exception_occured){
    //         throw new \Exception(json_encode($d), 405);
            
    //     }


    // }

    private function removeNonExistantTemplates( array $existingComponents, Template $template){
        $toDeleteTemplateComponents = TemplateComponent::whereNotIn('id', $existingComponents)->where('template_id', $template->id)->get()->each(function($oldComponent){
            if($oldComponent->items){
                $oldComponent->items()->each(function($item){
                    $item->delete();
                });
            }
            $oldComponent->delete();
        });
        
    }

    // private function updateCategory(Request $request, $volunteerID){

    // }

    //update template
    public function volunteerTemplateUpdate(Request $request, $vol, Template $template, $isTemporary = null)
    {
        
        $details = $request->except(['template_name', 'category_id']);
        $templateDetails = $this->bulkFormatter($details);         

        $templateComponents = $request->template_component_id;

        if($isTemporary){

            $volunteer = $vol;
            
        }else{
            $volunteer = Volunteer::find($vol);
        }

        DB::beginTransaction();
        try{
           
            // $this->checkTimeValidation($data);

            $this->storeTemplate($request, $volunteer, $template, $isTemporary);
            $this->removeNonExistantTemplates($templateComponents, $template);
            $this->storeTemplateComponents($templateDetails, $template);

            DB::commit();
            
            if(request()->has('requester') && request()->requester === "timesheet" || !$isTemporary){

                if($isTemporary){
                    return $this->temporaryTemplates($request, $volunteer);
                }else{
                    return $volunteer->allTemplates;

                }

            }
            return $this->response("Template updated Successfully", 'view', 200);
        }catch(\Exception $e){
            DB::rollBack();
            throw new \Exception($e->getMessage());
            
            return response($e->getMessage(), $e->getCode());
        }
    }
     //volunteer template
     public function addTemplateVolunteer($vol)
     {
        if(request()->has('temporary') && request()->temporary){
            $volunteer = $vol; //where $vol is alternative id
            $sitesDetail = [];
        }else{
            $volunteer = Volunteer::find($vol);
            $sitesDetail = VolunteerSites::where('volunteer_id', $volunteer->id)->get();
        }       

        $weeks = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        return $this->view($this->clayout.'.profile.modal.addTemplate', compact('volunteer', 'weeks', 'sitesDetail'));
     }

    
     private function filterIrregularItemsData($formattedData){
        return array_map(function($detail){
            $detail['items'] =  array_filter($detail['items'], function($item){
                return array_key_exists("code", $item) && array_key_exists('value', $item) && array_key_exists('amount', $item);
            });

            return $detail;
        }, $formattedData);
     }

     public function bulkFormatter($data){

        if($data instanceOf Request) $data = $data->all();        

        $formatted_data = [];        

    	foreach ($data as $key => $first_arrray) {

    		if(is_array($first_arrray)){   

	    		foreach ($first_arrray as $index => $value) { //index is rowIndex
                    if(!is_array($value))
                        $formatted_data[$index][$key] = $value;
                    else{
                       foreach($value as $site => $codeArray){
                           foreach($codeArray as $k => $item){
                                $formatted_data[$index]['items'][$k][$key] = $item;
                           }
                       }


                    }

	    		}
	    	}

    	}

        return $this->filterIrregularItemsData($formatted_data);
    	// return $formatted_data;

    }

    private function defaultTemporaryTemplate($alternative_id){
        return Template::where([

            "code" => "temporary_template",
            "table_name" => "temporary",
            "co_no" => 2,
            "userc_id" => auth()->id(),
			"table_id" => $alternative_id,
			'is_default' => 1

        ])->first();
	}

    /**
     * Store Volunteer Template
     *
     * @param Request $request
     * @param Volunteer $volunteer
     * @return Template $template
     */
    private function storeTemplate(Request $request, $vol, ?Template $oldTemplate, $isTemporary) :Template{
        
        if($isTemporary){

            $volunteer = $vol;

        }else{
            $volunteer = $vol->id;
        }
        if($request->has('is_default')){

            if($isTemporary){

                $temp = $this->defaultTemporaryTemplate($volunteer);

            }else{
                $temp = Template::where('table_name', 'volunteers')->where('table_id', $volunteer)->where('is_default', true)->first();

            }
            $temp ? $temp->update(["is_default" => 0]) : '';
            
            $default = true;
        }else{
            $default = false;
        }

        if($oldTemplate){

            $oldTemplate->update([

                'template_name' => $request->template_name ?: "Blank",
                'category_id'   => (int)$request->category_id ?: null,
                'is_default'    => $default

            ]);

            return $oldTemplate;

        }else{
            $template = new Template();
            $template->template_name = $request->template_name ?: 'Blank';
            $template->section = "Volunteer";
            $template->code = $isTemporary ? "temporary_template" :"volunteer_template";
            $template->table_name = $isTemporary? "temporary" : "volunteers";
            $template->table_id = $volunteer;
            $template->is_default = $default;
            $template->category_id = (int)$request->category_id ?: null;
            $template->userc_id = auth()->id();
            $template->co_no = $isTemporary? 2 : 0;
            $template->save();
        }
        

        return $template;
    }

    /**
     * Stores Template Components / Details
     *
     * @param array $templateDetails
     * @param Template $template
     * @return void
     */
    private function storeTemplateComponents(array $templateDetails, Template $template){

        foreach($templateDetails as $templateDetail){

            $oldTemplate = TemplateComponent::find($templateDetail['template_component_id']);

            if($oldTemplate){

                // Update Template Component

                $oldTemplate->update([
                    "days"          => $templateDetail['days'],
                    "site_id"       => $templateDetail['site_id'],
                    "time_type"     => $templateDetail['time_type'],
                    "time_in"       => $templateDetail['time_in'],
                    "time_out"      => $templateDetail['time_out'],
                    "break_out"     => $templateDetail['break_out'],
                    "break_in"      => $templateDetail['break_in'],
                    "total_hours"   => $templateDetail['total_hr']
                ]);


                // Remove All Previous Items

                TemplateItems::where('template_component_id', $oldTemplate->id)->delete();

                $templateComponent = $oldTemplate;    

            }else{

                // Save New Template Component

                $templateDetail['template_id'] = $template->id;
                $newComponent = new TemplateComponent();
                $templateComponent = $newComponent->create([
                    "template_id"   => $template->id,
                    "days"          => $templateDetail['days'],
                    "site_id"       => $templateDetail['site_id'],
                    "time_type"     => $templateDetail['time_type'],
                    "time_in"       => $templateDetail['time_in'],
                    "time_out"      => $templateDetail['time_out'],
                    "break_out"     => $templateDetail['break_out'],
                    "break_in"      => $templateDetail['break_in'],
                    "total_hours"   => $templateDetail['total_hr']
                ]);

            }
            
            if(!isset($templateDetail['items'])) continue;

            foreach($templateDetail['items'] as $item){
                
                $this->storeComponentItems($item, $templateComponent);
                
            }
        }
    }

    /**
     * Store Components Items
     *
     * @param array $item
     * @param TemplateComponent $templateComponent
     * @return TemplateItems $templateItems
     */
    private function storeComponentItems(array $item, TemplateComponent $templateComponent) : TemplateItems{
        $templateItem = new TemplateItems();

        $stipendItem = StipendItem::where([
            "category"      => $item['code'],
            "item_name"     => $item['value']

        ])->first() ?? null;

        if($stipendItem){
            $templateItem->create([

                "template_component_id" => $templateComponent->id,
                "stipend_item_id"       => $stipendItem->id,
                "amount"                => $item['amount']

            ]);
        }

        return $templateItem;
    }

    private function temporaryTemplates($request, $alternative_id){
        return Template::where([

            "code" => "temporary_template",
            "table_name" => "temporary",
            "co_no" => 2,
            "userc_id" => auth()->id(),
            "table_id" => $alternative_id,
        ])->get();
    }

     //update template
     public function storeTemplateVolunteer(Request $request, $vol, $requester = null, $isTemporary = null)
     {
        if($isTemporary){
            $volunteer = $vol;            
        }else{
            $volunteer = Volunteer::find($vol);
        }

        $details = $request->except('template_name');
        $templateDetails = $this->bulkFormatter($details); 
        
        DB::beginTransaction();
        try{         

            $template = $this->storeTemplate($request, $volunteer, null, $isTemporary);
            
            $this->storeTemplateComponents($templateDetails, $template);

            DB::commit();

            if($requester === "timesheet" || $requester === "volEdit" || !$isTemporary){

                if($isTemporary){
                    return $this->temporaryTemplates($request, $volunteer);
                }else{
                    return $volunteer->allTemplates;

                }

            }

            return $this->response("Template added Successfully", 'view', 200);
         }catch(\Exception $e){
            DB::rollBack();
            return response($e->getMessage(), $e->getCode());
         }
     }

     public function formatDefaultTemplate($temp){

         $data = [];

         unset($temp['template_name']);

        $hasRanOnce = false;        

        $sites = [];

         foreach ($temp as $k => $items) {

            $sites = array_merge($sites, array_keys($items['time_type']));

         }

         $sites = array_unique($sites);

         $fData = [];

         foreach ($sites as $site) {
            foreach ($temp as $items) {
                unset($items['items']);
                unset($items['time_type']);
                unset($items['total_hr']);
                unset($items['break_in']);
                unset($items['break_out']);
                foreach ($items['days'] as $day) {
                    foreach ($items as $key => $val) {
                        if ($key === 'days') {
                            continue;
                        }
                        if(!isset($val[$site])) continue;
                        $fData[$site.$day]['day'] = $day;
                        $fData[$site.$day][$key] = $val[$site][0];
                        $fData[$site.$day]['uniqid'] = $site.$day;
                        $fData[$site.$day]['site']  = $site;
                    }
                }
            }
         }

        return $fData;

        return $data;

     }

    public function getModernTemplateData(Request $request){

        $this->validate($request, [
            'time_type' => 'required',
            'time_in'   => 'required',
            'time_out'   => 'required',
            // 'break_in'   => 'required',
            // 'break_out'   => 'required',
            'total_hrs'   => 'required',
            'sites' => 'required'
        ]);

        $data = $request->all();  

        $data['time_type'] = StipendItem::find($request->time_type);

        $request->break_in ? '' : $data['break_in ']= "0:00";
        $request->break_out ? '' : $data['break_out'] = "0:00";

        $findSite = Site::find($data['sites']);

        $data['sites'] = (object) $findSite;

        $items = [];


        foreach ($data['item'] as $type => $valueArr) {

            if(is_null($valueArr[0])) continue;

            foreach ($valueArr as $index => $value) {                
                $items[$index][$type] = $value;

            }

        }


        $itemCollection = collect($items)->filter(function($item){
            if( !array_key_exists('label', $item) || !array_key_exists('value', $item) || !array_key_exists('amount', $item) ){
                return false;
            }
            return true;
        })->map(function($item){
            
            return StipendItem::where([

                'category' => $item['label'],
                'item_name' => $item['value']

            ])->first();
        });

        $data['item'] = $itemCollection;

        return $data;


    }

    public function getWidgetModernTemplateData(Request $request){

        $this->validate($request, [
            'w_time_type' => 'required',
            'w_time_in'   => 'required',
            'w_time_out'   => 'required',
            // 'w_break_in'   => 'required',
            // 'w_break_out'   => 'required',
            'w_total_hrs'   => 'required',
            'w_sites' => 'required'
        ]);


        $data = $request->all(); 

        $request->w_break_in ? '' : $data['w_break_in ']= "0:00";
        $request->w_break_out ? '' : $data['w_break_out'] = "0:00";       

        $findSite = Site::find($data['w_sites']);

        $data['sites'] = (object) $findSite;

        $items = [];

        foreach ($data['w_item'] as $type => $valueArr) {

            if(is_null($valueArr[0])) continue;

            foreach ($valueArr as $index => $value) {
                
                $items[$index][$type] = $value;

            }

        }

        $data['item'] = $items;


        return $data;


    }

}
