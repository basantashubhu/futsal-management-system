<?php

/**
 * DEVELOPERS
 * ----------------------------------------------
 * SUMAN  THAPA - LEAD  (NEPALNME@GMAIL.COM)
 * ----------------------------------------------
 * - PRABHAT GURUNG
 * - BASANTA TAJ
 * - RAKESH SHRESTHA
 * - LEKHRAJ RAI
 * - MANISH BUDDHACHARYA
 * - ASCOL PARAJULI
 * -----------------------------------------------
 * Created On: 2019
 *
 * THIS INTELLECTUAL PROPERTY IS COPYRIGHT Ⓒ 2018
 * ZEUSLOGIC, INC. ALL RIGHT RESERVED
 */

namespace App\Http\Controllers\Fgp\Volunteer;

use App\Http\Controllers\BaseController;
use App\Http\Controllers\Fgp\Volunteer\VolunteerController;
use App\Http\Requests\Fgp\VolunteerRequest;
use App\Lib\Exporter\CSVExporter;
use App\Lib\Exporter\JSONExporter;
use App\Lib\Exporter\PDFExporter;
use App\Lib\Exporter\TxtExporter;
use App\Lib\File\FileUploader;
use App\Lib\Log\Log;
use App\Models\Address;
use App\Models\Contact;
use App\Models\Fgp\Site;
use App\Models\Fgp\Template;
use App\Models\Fgp\TemplateDetail;
use App\Models\Fgp\VolunteerDetail;
use App\Models\Fgp\VolunteerSites;
use App\Models\Fgp\{Volunteer, EmergencyContact};
use App\Models\File;
use App\Models\Settings\Lookups;
use App\Models\User;
use App\Repo\AddressRepo;
use App\Repo\ContactRepo;
use App\Repo\FGP\VolunteerRepo;
use App\Services\StipendService;
use App\Traits\UpdatedVolProfileTrait;
use App\Traits\WidgetTraits\VolunteerEditWidgetTrait;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class VolunteerAddController extends BaseController
{

    private $clayout = "";
    private static $repo;

    /**
     * Stipend rate / Base pay rate
     */

    private const STIPEND_CODE = "stipends";

    /**
     * Traits for volunteer updated profile & volunteer edit wizard
     */
    use UpdatedVolProfileTrait, VolunteerEditWidgetTrait;

    public function __construct()
    {
        parent::__construct();
        $this->clayout = $this->layout . '.fgp.volunteer';
    }

    public function __invoke()
    {

        $supervisor_id = Volunteer::where('is_deleted', false)->distinct()->pluck('vol_supervisor_id');
        $supervisors = [];
        if (count($supervisor_id) > 0) {
            foreach ($supervisor_id as $id) {
                array_push($supervisors, User::find($id));
            }
        }
        $advData = isset($_COOKIE['volunteers_advanced']) ? json_decode($_COOKIE['volunteers_advanced']) : [];
        $openData = isset($_COOKIE['volunteers_quick']) ? json_decode($_COOKIE['volunteers_quick']) : [];
        return view($this->clayout . ".index", compact('advData', 'openData', 'supervisors'));
    }

    public static function getRepo($model)
    {
        self::$repo = new VolunteerRepo($model);
        return self::$repo;
    }

    public function addWidget()
    {

        $validations = validation_value('volunteer_register');
        $sitesss = $this->getAllSites();

        $lastVolunteerId = Volunteer::latest()->first()->id ?? 1;

        $eStipendId = str_pad($lastVolunteerId, 10, 0, STR_PAD_LEFT);

        $stipends = app(StipendService::class);

        return view($this->clayout . '.widget.add', compact('validations', 'sitesss', 'eStipendId', 'stipends'));
    }
    public function editWidget(Volunteer $volunteer)
    {
        $validations = validation_value('volunteer_register');
        $sitesss = $this->getAllSites();

        // $max_vendor = DB::table('volunteer_details')->where('code', 'vendor_id')->max(DB::raw('CAST(value AS UNSIGNED)'));
        // $eStipendId = $volunteer->details()->where('code', 'vendor_id')->first()->value ?? '';
        $eStipendId = str_pad($volunteer->id, 10, 0, STR_PAD_LEFT);


        $details = $volunteer->details->map(function ($detail) {
            return [$detail->code => $detail->value];
        })->collapse();

        // $template = Template::where('table_name', 'volunteers')->where('table_id', $volunteer->id)->where('is_default', true)->first();
        // if (!is_null($template)) {
        //     $temp = TemplateDetail::where('template_id', $template->id)->first();
        //     $sitesDetail = VolunteerSites::where('volunteer_id', $volunteer->id)->where('is_deleted', 0)->get();
        //     $data = json_decode($temp->value, 1);

        //     $prevData = [];

        //     foreach ($data as $key => $dataArray) {

        //         foreach ($dataArray as $label => $valueArr) {

        //             foreach ($dataArray['days'] as $dayIndex => $days) {

        //                 if ($label === "days") break;

        //                 foreach ($valueArr as $site => $labelVal) {

        //                     if ($label === "items") {

        //                         /* Here $site is travel / meal */

        //                         $type = $site;

        //                         foreach ($labelVal as $itemLabel => $itemLabelValArray) {

        //                             foreach ($itemLabelValArray as $itemSite => $itemValArray) {
        //                                 $prevData[$key][$days][$itemSite]['items'][$type][$itemLabel] = $itemValArray[0];
        //                             }
        //                         }
        //                         continue;
        //                     }
        //                     $currentSite = Site::find($site);
        //                     $prevData[$key][$days][$site][$label]  =  isset($labelVal[0]) ? $labelVal[0] : $labelVal;
        //                     $prevData[$key][$days][$site]['site_name']    = ucfirst($currentSite->site_name);
        //                     $prevData[$key][$days][$site]['id']    = $currentSite->id;
        //                 }
        //             }
        //         }
        //     }

        //     $sortedWithWeek = [];

        //     foreach ($prevData as $index => $dataArray) {
        //         foreach ($dataArray as $weekDay => $originalData) {
        //             $sortedWithWeek[$this->getWeekIndex($weekDay)][] = $dataArray;
        //         }
        //     }

        //     $prevData = $sortedWithWeek;

        //     ksort($prevData);
        // } else {
        //     $prevData = [];
        // }

        $sitesDetail = VolunteerSites::where('volunteer_id', $volunteer->id)->where('is_deleted', 0)->get();
        // $weeks = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

        $templates = Template::where('table_name', "volunteers")->where('table_id', $volunteer->id)->get();

        $profile = File::where('table', 'volunteers')->where('table_id', $volunteer->id)->where('document_type', "profile_picture")->first();

        if (!is_null($profile)) {
            if (file_exists(storage_path('uploads/') . $profile->file_name)) :
                $volunteer->image = base64_encode(file_get_contents(storage_path('uploads/') . $profile->file_name));
            endif;
        }

        $stipends = app(StipendService::class);

        return view($this->clayout . '.widget.edit', compact('validations', 'sitesss', 'volunteer', 'sitesDetail', 'data', 'eStipendId', 'temp', 'templates', 'details', 'stipends'));
    }

    public function getEditWidgetSups(Volunteer $volunteer)
    {
        $assignedSups = $volunteer->supervisors;
        $supVols = User::where('role_id', 3)->select('id')->with('self')->get()->map(function ($supervisor) use ($assignedSups) {
            $supervisor->fullname = $supervisor->self->fullName();
            $supervisor->selected = $assignedSups->contains('id', $supervisor->id);
            return $supervisor;
        });
        return $supVols;
    }

    public function getWeekIndex($weekday)
    {
        $sortingDirecton = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

        return array_search(ucfirst($weekday), $sortingDirecton);
    }
    public function getVolunteerValidation(VolunteerRequest $request)
    { }

    public function formatDocuments(Request $request)
    {


        $doc = [];

        foreach ($request->documents as $key => $document) {
            $doc[$key]['name'] = $request->document_name[$key];
            $doc[$key]['document'] = $document;
        }

        return $doc;
    }

    public function storeDocuments(Request $request, $volunteer)
    {

        $docs = $this->formatDocuments($request);

        $file_name = [];
        $file_title = [];

        foreach ($docs as $key => $document) {
            $file_name[] = FileUploader::upload($document['document'], false, 'uploads/documents');
            $file_title[] = $document['name'];
        }
        self::getRepo('Fgp\Volunteer')->storeUploadedFilePath($file_name, $volunteer, $file_title);
    }


    private function storeTemporaryTemplates($volunteer, $alternative_id){

        return Template::where([
            "code" => "temporary_template",
            "table_name" => "temporary",
            "table_id" => $alternative_id,
            "co_no" => 2,
            "userc_id" => auth()->id()
        ])->get()->each(function($temporaryTemplates) use($volunteer){
            $temporaryTemplates->update([
                "code" => "volunteer_template",
                "table_name" => "volunteers",
                "table_id" => $volunteer,
                "co_no" => 0,
            ]);
        });


    }

    public function store(VolunteerRequest $request) //VolunteerRequest
    {
        DB::beginTransaction();
        try {
            $repo = self::getRepo('Fgp\Volunteer');
            if ($request->has('email') && $request->email != '') {
                $volunteer = self::getRepo('Fgp\Volunteer')->findByEmail($request->email);
            } else {
                $volunteer = null;
            }
            $created_vol = $this->volGenerals($request, $volunteer);
            //Upload attachment
            $fileName = $this->uploadAttachment($request->file());
            $fileTitle = [];
            if ($request->has('photoIdProofTitle'))
                array_push($fileTitle, $request->photoIdProofTitle);

            $repo->storeUploadedFilePath($fileName, $created_vol, $fileTitle, "", "profile");

            if ($request->has('documents')) {

                $this->storeDocuments($request, $created_vol);
            }

            $this->volAddress($request, $created_vol, $volunteer);

            $this->volContact($request, $created_vol, $volunteer);
            if ($request->has('dob')) {
                $volDetail = new VolunteerDetail;
                $volDetail->create([
                    "volunteer_id" => $created_vol->id,
                    "label" => "Dob",
                    "code" => "dob",
                    "value" => $request->dob
                ]);
            }

            if ($request->has('label')) {
                foreach ($request->label as $k => $v) {
                    if ($v != null) {
                        $c = strtolower($v);
                        $c = str_replace(" ", "_", $c);
                        $detail['volunteer_id'] = $created_vol->id;
                        if (array_key_exists($k, $request->value)) {
                            $detail['value'] = $request->value[$k];
                        } else {
                            $detail['value'] = ' ';
                        }
                        $detail['code'] = $c;
                        $detail['label'] = $v;
                        $details = self::getRepo('Fgp\VolunteerDetail')->updateVolunteerDetail($detail, $created_vol->id);
                    }
                }
            }
            if ($request->has("site_id")) {
                foreach ($request->site_id as $site) {
                    $sv = new VolunteerSites();
                    if (array_key_exists('default_site',$request->all())) {
                        $site == $request->default_site?$sv->is_default = 1: $sv->is_default = 0;
                    }
                    $sv->volunteer_id = $created_vol->id;
                    $sv->site_id = $site;
                    $sv->date = date("Y-m-d");
                    $sv->choosed_site_id = $site;
                    $sv->save();
                }
            }
            $this->storeTemporaryTemplates($created_vol->id, $request->alt_id);
            // $this->storeTemplate($request, $created_vol->id);

            $volunteerController = new VolunteerController;
            if ($request->time_type) {
                $volunteerController->storeTemplateVolunteer($request, $created_vol);
            }

            DB::commit();
            return $this->response("Volunteer added Successfully", ['volunteer_id' => $created_vol->id], 200);
        } catch (\Exception $e) {
            DB::rollBack();
            throw  $e;
            return $this->response("Volunteer Can't submitted", 'view', 422);
        }
    }

    /**
     * Update file upload  only // Used to update all the edits 
     * @param  VolunteerRequest $request  
     * @param  Volunteer        $volunteer 
     * @return [JSON]                      
     */

    public function edit(VolunteerRequest $request, Volunteer $volunteer)
    {
        DB::beginTransaction();
        try {

            $repo = self::getRepo('Fgp\Volunteer');

            //Upload attachment
            $fileName = $this->uploadAttachment($request->file());
            $fileTitle = [];

            //Delete previous files 
            $previous_docs = $request->input('prev_doc', []);

            $volunteer->documents()->whereNotIn('id', $previous_docs)->update(["is_deleted" => 1]);

            if ($request->has('photoIdProofTitle'))
                array_push($fileTitle, $request->photoIdProofTitle);

            $repo->storeUploadedFilePath($fileName, $volunteer, $fileTitle, "", "profile_picture");

            if ($request->has('documents')) {

                $this->storeDocuments($request, $volunteer);
            }

            DB::commit();
            return $this->response("Volunteer Updated Successfully", ['volunteer_id' => $volunteer->id], 200);
        } catch (\Exception $e) {
            DB::rollBack();

            return response(["message" => $e->getMessage(), "line" => $e->getLine()], 500);
        }
    }

    private function storeTemplate(Request $request, $vol)
    {
        $data = [];
        foreach ($request->input("days", []) as $key => $day) {
            // dd($day);
            $data[$key]['days'] = $day;
            if ($request->has('time_type')) {
                if (array_key_exists($key, $request->time_type)) {
                    $data[$key]['time_type'] = $request->time_type[$key];
                }
            }
            if ($request->has('time_in')) {
                if (array_key_exists($key, $request->time_in)) {
                    $data[$key]['time_in'] = $request->time_in[$key];
                }
            }
            if ($request->has('time_out')) {
                if (array_key_exists($key, $request->time_out)) {
                    $data[$key]['time_out'] = $request->time_out[$key];
                }
            }
            if ($request->has('break_in')) {
                if (array_key_exists($key, $request->break_in)) {
                    $data[$key]['break_in'] = $request->break_in[$key];
                }
            }
            if ($request->has('break_out')) {
                if (array_key_exists($key, $request->break_out)) {
                    $data[$key]['break_out'] = $request->break_out[$key];
                }
            }
            if ($request->has('total_hr')) {
                if (array_key_exists($key, $request->total_hr)) {
                    $data[$key]['total_hr'] = $request->total_hr[$key];
                }
            }
            if ($request->has('travel_code')) {
                if (array_key_exists($key, $request->travel_code)) {
                    $data[$key]['items']['travel']['code'] = $request->travel_code[$key];
                }
            }
            if ($request->has('travel_value')) {
                if (array_key_exists($key, $request->travel_value)) {
                    $data[$key]['items']['travel']['value'] = $request->travel_value[$key];
                }
            }
            if ($request->has('travel_amt')) {
                if (array_key_exists($key, $request->travel_amt)) {
                    $data[$key]['items']['travel']['amt'] = $request->travel_amt[$key];
                }
            }
            if ($request->has('travel_stipend_item_id')) {
                if (array_key_exists($key, $request->travel_stipend_item_id)) {
                    $data[$key]['items']['travel']['stipend_item_id'] = $request->travel_stipend_item_id[$key];
                }
            }
            if ($request->has('meal_code')) {
                if (array_key_exists($key, $request->meal_code)) {
                    $data[$key]['items']['meal']['code'] = $request->meal_code[$key];
                }
            }
            if ($request->has('meal_value')) {
                if (array_key_exists($key, $request->meal_value)) {
                    $data[$key]['items']['meal']['value'] = $request->meal_value[$key];
                }
            }
            if ($request->has('meal_amt')) {
                if (array_key_exists($key, $request->meal_amt)) {
                    $data[$key]['items']['meal']['amt'] = $request->meal_amt[$key];
                }
            }
            if ($request->has('meal_stipend_item_id')) {
                if (array_key_exists($key, $request->meal_stipend_item_id)) {
                    $data[$key]['items']['meal']['stipend_item_id'] = $request->meal_stipend_item_id[$key];
                }
            }
        }
        // dd(json_encode($data))
        // dd($data);
        $temp = Template::where('table_name', 'volunteers')->where('table_id', $vol)->first();
        if (is_null($temp)) {
            $template = new Template();
            $template->template_name = "Default Template";
            $template->section = "Volunteer";
            $template->code = "volunteer_template";
            $template->table_name = "volunteers";
            $template->table_id = $vol;
            $template->is_default = true;
            $template->save();

            $template_detail = new TemplateDetail();
            $template_detail->template_id = $template->id;
            $template_detail->value = json_encode($data);
            $template_detail->save();
        } else {
            $temp->template_name = "Default Template";
            $temp->section = "Volunteer";
            $temp->code = "volunteer_template";
            $temp->table_name = "volunteers";
            $temp->table_id = $vol;
            $temp->is_default = true;
            $temp->save();

            $temp_d = TemplateDetail::where('template_id', $temp->id)->first();
            $temp_d->value = json_encode($data);
            $temp_d->save();
        }
    }
    public function getData($code, $val = false)
    {
        // dd($val);

        if ($val) {
            $data = Lookups::where('code', $code)->where('value', 'LIKE', '%' . $val . '%')->where('is_deleted', false)->get();
        } else {
            $data = Lookups::where('code', $code)->where('is_deleted', false)->get();
        }
        $cData = isset($_COOKIE['volunteer_detail']) ? $_COOKIE['volunteer_detail'] : "";
        if ($cData != "") {
            $d = [];
            $cData = explode(',', $cData);
            foreach ($data as $dat) {
                if (!in_array($dat->value, $cData)) {
                    array_push($d, $dat);
                }
            }
            return $this->responseLookup($d, ["value"]);
        } else {

            return $this->responseLookup($data, ["value"]);
        }
    }
    /***
     * @param $file
     * @return array
     * @throws \Exception
     */
    public function uploadAttachment($file)
    {
        $fileName = array();

        if (array_key_exists('photoIdProof', $file)) :
            $fname = FileUploader::upload($file['photoIdProof']);
            array_push($fileName, $fname);
        endif;

        if (array_key_exists('anualProof', $file)) :
            $fname = FileUploader::upload($file['anualProof']);
            array_push($fileName, $fname);
        endif;
        if (array_key_exists('addinationalPhotos', $file)) {
            foreach ($file['addinationalPhotos'] as $f) {
                $fname = FileUploader::upload($f);
                array_push($fileName, $fname);
            }
        }
        return $fileName;
    }

    private function getAllSites()
    {
        if (auth()->user()->role->name == "supervisor") {
            $sitesss = DB::table('site_managers as sm')->select([
                'sites.id', 'sites.site_name', 'sites.site_type as site_type', 'sites.id as site_id', //sites
                'ad.add1', 'ad.add2', 'ad.region', 'ad.county', 'ad.district', 'ad.city' // site address
            ])->join('sites', 'sites.id', 'sm.site_id') //sites table join
                ->join('address as ad', function ($join) {
                    $join->on('ad.table_id', 'sites.id'); // address table join with sites
                    $join->on('ad.table_name', DB::raw('"sites"'));
                })->where('sm.user_id', auth()->id()) // user filter
                ->where('sm.is_deleted', 0)
                ->orderBy('sites.site_name')
                // ->limit(20) // filter deleted rows
                ->get();
        } else {
            $sitesss = Site::where('is_deleted', false)->orderBy('site_name')->get();
        }
        // dd($sitesss->toArray());
        return $sitesss->toArray();
    }
    public function getSiteLocation(Request $request)
    {
        if (auth()->user()->role->name == "supervisor") {
            $sitesss = DB::table('site_managers as sm')->select([
                'sites.site_name', 'sites.site_type as site_type', 'sites.id as site_id', //sites
                'ad.add1', 'ad.add2', 'ad.region', 'ad.county', 'ad.district', 'ad.city' // site address
            ])->join('sites', 'sites.id', 'sm.site_id') //sites table join
                ->join('address as ad', function ($join) {
                    $join->on('ad.table_id', 'sites.id'); // address table join with sites
                    $join->on('ad.table_name', DB::raw('"sites"'));
                })->where('sm.user_id', auth()->id()) // user filter
                ->where('sm.is_deleted', 0)
                ->where('sites.site_name', 'like', "%$request->site%")
                ->limit(20) // filter deleted rows
                ->get();
        } else {
            $sitesss = Site::where('is_deleted', false)->where('site_name', 'like', "%$request->site%")->latest()->limit(20)->get();
        }
        return $this->view($this->clayout . '.widget.siteResult', compact('sitesss'));
    }

    public function choosenSites(Request $request): ?object
    {

        // $choosen_sites = request()->input('site_id', []);
        return $this->view($this->clayout . '.widget.choose-site-modal');
    }
    /**
     * Fetch default and all Sites
     * @param  Request $request
     * @return View           
     */
    public function getAllSiteLocation(Request $request)
    {
        $choosen_sites = json_decode(request()->sites_ ?: '[]', true) ?: [];

        if (auth()->user()->hasRole('superAdmin') || auth()->user()->hasRole('admin') || auth()->user()->hasRole('fiscal')) {
            $query = Site::where('is_deleted', 0);
        } else {
            $user = auth()->user();

            $query = Site::orderBy('site_name')->when($request->input('query.site_cat', "default"), function ($q, $v) {


                if ($v == 'default') {

                    $q->whereHas('managingUser', function ($u) {
                        $rptIds = auth()->user()->hierarchyIds()->all();
                        $u->whereIn('users.id', $rptIds);
                    });
                } elseif ($v = 'county') {

                    $counties = auth()->user()->settings()->where('type', 'default_counties')->get()->map(function ($defaultCounty) {
                        return $defaultCounty->value;
                    })->all();

                    $q->whereHas('address', function ($query) use ($counties) {

                        $query->whereIn("county", $counties);
                    });
                } else { //($v == 'all')

                }
            });
        }


        $user_sites = $query->when($request->input('query.SearchSites'), function ($q, $searchedText) {
            $q->where('site_name', "like", "%$searchedText%");
        })
            ->with('address')
            ->get()
            ->map(function ($site) use ($choosen_sites) {

                if (in_array($site->id, $choosen_sites)) :
                    $site->selected = 1;
                else :
                    $site->selected = 0;
                endif;

                return $site;
            });


        return $user_sites;
    }

    public function fetchSelectedSitesOnly(Request $request): ?Collection
    {

        $seletedSites = request()->input('sites', []);

        return Site::whereIn('id', json_decode($seletedSites, true))->get();
    }

    protected function create_code_from_label($string)
    {
        return str_replace('"', '', str_replace(' ', '_', mb_strtolower($string)));
    }

    protected function create_label_from_code($string)
    {
        return str_replace('"', '', str_replace('_', ' ', ucfirst($string)));
    }

    private function detailsFormatter(Request $request, $volunteer = null)
    {

        if ($volunteer) {
            $prevDetails = VolunteerDetail::where('volunteer_id', $volunteer->id)->get();
            foreach ($prevDetails as $prevDetail) {
                VolunteerDetail::find($prevDetail)->first()->delete();
            }
        }

        $details = [];
        if ($request->input('label') && $request->input('value')) {

            foreach ($request->input('label', []) as $key => $code) {
                $details[] = [
                    'label' => $code,
                    'value' => $request->values[$key],
                ];
            }
        }

        foreach ($request->input('vlt_dtl', []) as $key => $value) {
            $details[] = ['label' => $key, 'value' => $value];
        }
        return $details;
    }

    private function volGenerals(Request $request, $volunteer = null)
    {

        $vol_general_details = $request->only([
            'salutation', 'first_name', 'middle_name', 'last_name',
            'title', 'alt_id', 'expense_eligibility'
        ]);

        if ($request->active_date) {
            $vol_general_details['active_date'] = date('Y-m-d', strtotime($request->input('active_date')));
        } else $vol_general_details['active_date'] = NULL;

        if ($request->vol_ssn !== '') {
            // $ssn = preg_replace('/[^A-Za-z-1]/','', $request->vol_ssn);
            $vol_general_details['vol_ssn'] = $request->vol_ssn;
        }

        $vol_general_details['vol_supervisor_id'] = '1';
        if ($volunteer) {
            $v = Volunteer::find($volunteer->id);
            $vo = self::getRepo($v)->saveUpdate($vol_general_details);
            if ($request->has("vol_supervisor_id")) {
                $vo->supervisors()->detach();
                foreach ($request->vol_supervisor_id as $sup) {
                    $vo->supervisors()->attach($sup);
                }
            }
            return $vo;
        } else {
            // dd($vol_general_details);
            $vo = self::getRepo('Fgp\Volunteer')->saveUpdate($vol_general_details);
            if ($request->has("vol_supervisor_id")) {
                foreach ($request->vol_supervisor_id as $sup) {
                    $vo->supervisors()->attach($sup);
                }
            }
            return $vo;
        }
    }

    private function volAddress(Request $request, $created_vol, $volunteer = null)
    {
        $address = $request->only([
            'add1', 'add2', 'county', 'city', 'state', 'zip_code', 'district'
        ]);
        $address['table_name'] = "volunteers";
        $address['table_id'] = $created_vol->id;
        if ($request->has('zip')) {
            $address['zip_code'] = $request->zip;
        }
        if ($volunteer) {

            $addr = Address::where('table_name', 'volunteers')->where('table_id', $volunteer->id)->first();
            if ($addr)
                return self::getRepo($addr)->saveUpdate($address);
            return self::getRepo('Address')->saveUpdate($address);
        }
        return self::getRepo('Address')->saveUpdate($address);
    }

    private function formatPhoneType(Request $request): array
    {

        $contact = [];

        foreach ($request->input('phone_type', []) as $key => $value) {
            $contact[$value] = $request->number[$key];
        }

        $contact['email'] = $request->email;

        return $contact;
    }

    private function  volContact(Request $request, $created_vol, $volunteer = null)
    {

        $contact = $this->formatPhoneType($request);
        // $contact = $request->only([
        //     'tel_phone', 'cell_phone', 'alt_phone', 'email', 'phone_ext', 'phone_type'
        // ]);
        $contact['table_name'] = "volunteers";
        $contact['table_id'] = $created_vol->id;
        if ($volunteer) {
            $prevContact = Contact::where('table_name', 'volunteers')->where('table_id', $volunteer->id)->first();
            return (new ContactRepo())->updateContact($contact, $created_vol);
        }
        return (new ContactRepo())->storeContact($contact, $created_vol);
    }

    public function storeVolunteer(VolunteerRequest $request, Volunteer $volunteer = null)
    { //VolunteerRequest   
        DB::beginTransaction();
        try {
            if ($request->has('email') && $request->email != '') {
                $volunteer = self::getRepo('Fgp\Volunteer')->findByEmail($request->email);
            }
            $created_vol = $this->volGenerals($request, $volunteer);

            // $details = $this->detailsFormatter($request, $volunteer);
            if ($request->has('label')) {
                foreach ($request->label as $k => $v) {
                    if ($v != null) {
                        $c = strtolower($v);
                        $c = str_replace(" ", "_", $c);
                        $detail['volunteer_id'] = $created_vol->id;
                        $detail['label'] = $v;
                        $detail['code'] = $c;
                        $detail['value'] = $request->value[$k];
                        $detail['lookup_id'] = $request->lookup_id[$k];
                        $details = self::getRepo('Fgp\VolunteerDetail')->updateVolunteerDetail($detail, $created_vol->id);
                    }
                }
            }
            // foreach ($details as $k => $detail) {
            //     if($detail['value']):
            //         $code = $this->create_code_from_label($detail['code']);

            //         $detail_data['volunteer_id'] = $created_vol->id;
            //         $detail_data['label'] = $detail['code'];
            //         $detail_data['code'] = $code;
            //         $detail_data['value'] = $detail['value'];
            //         $detail_date['data_type'] = isset($detail['data_type'])?:'string';
            //         $detail_date['has_lookup'] = isset($detail['has_lookup'])?:'0';

            //         $details = self::getRepo('Fgp\VolunteerDetail')->saveUpdate($detail_data);
            //     endif;
            // }


            $this->volAddress($request, $created_vol, $volunteer);

            $this->volContact($request, $created_vol, $volunteer);

            DB::commit();
            if ($request->has('widget') && $request->widget == "widget") {
                return $created_vol->id;
            } else {
                return $this->response("Volunteer successfully created", "view", 200);
            }
        } catch (\Exception $e) {
            DB::rollback();
            return response(["message" => $e->getMessage()], 500);
        }
    }

    public function deleteVolunteerModal(Volunteer $volunteer)
    {
        return view($this->clayout . ".modals.delete", compact('volunteer'));
    }

    public function deleteVolunteer(Volunteer $volunteer)
    {
        $volunteer->deleted_at = now();
        $volunteer->is_deleted = 1;
        $volunteer->userd_id = auth()->id();
        $volunteer->save();
        return $this->response("Successfully volunteer deleted", "view", 200);
    }

    public function editVolunteer(Volunteer $volunteer)
    {
        $validations = validation_value('volunteer_register');
        return view($this->clayout . '.modals.edit', compact('volunteer', 'validations'));
    }

    public function getVolunteerDetails($id)
    {
        $data = Lookups::find($id);
        return $data;
    }

    public function getSupervisor($val = false)
    {
        if ($val) {
            $data = User::where('role_id', 3)->where('name', 'LIKE', '%' . $val . '%')->get();
        } else {
            $data = User::where('role_id', 3)->get();
        }
        return $this->responseLookup($data, ["name"]);
    }

    public function checkAltID($val, $id = false)
    {
        if ($id) {
            $v = Volunteer::where('id', $id)->where('alt_id', $val)->first();
            if (is_null($v)) {
                $v1 = Volunteer::where('alt_id', $val)->first();
                if (is_null($v1)) {
                    return 'false';
                } else {
                    return 'exist';
                }
            } else {
                return 'false';
            }
        } else {
            $v = Volunteer::where('alt_id', $val)->first();
            if (is_null($v)) {
                return 'false';
            } else {
                return 'exist';
            }
        }
    }

    public function checkEmail(Request $request)
    {
        $e = Contact::where('email', $request->email)->first();
        if (isset($e->id)) {
            return $e->id;
        } else {
            return 'not';
        }
    }

    public function getEmailInfo($id)
    {
        $email = Contact::find($id);
        $detail = DB::table($email->table_name)->where('id', $email->table_id)->first();
        $detail->address = Address::where('table_name', $email->table_name) > where('table_id', $email->table_id)->first();
        $detail->contact = $email;
        $detail->supervisor = User::find($detail->vol_supervisor_id);
        return view($this->clayout . '.modals.info', compact('detail'));
    }

    public function assignVolunteerToSelf(Request $request)
    {

        $vols = json_decode($request->vols, true);

        auth()->user()->volunteers()->sync($vols);

        return response(["message" => "succesfully assigned"], 200);
    }
}
