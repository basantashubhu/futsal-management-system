<?php

namespace App\Http\Controllers\Fgp\Volunteer;

use App\Models\File;
use App\Models\User;
use App\Models\Fgp\Site;
use Illuminate\View\View;
use App\Models\Fgp\Template;
use Illuminate\Http\Request;
use App\Models\Fgp\Timesheet;
use App\Models\Fgp\Volunteer;
use App\Repo\FGP\VolunteerRepo;
use Illuminate\Support\Facades\DB;
use App\Models\Fgp\EmergencyContact;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\BaseController;

class VolunteerShowController extends BaseController
{

    private $clayout = "";
    private static $repo;

    public function __construct()
    {
        parent::__construct();
        $this->clayout = $this->layout . '.fgp.volunteer';
    }

    public static function getRepo($model)
    {
        self::$repo = new VolunteerRepo($model);
        return self::$repo;
    }

    public function viewVolunteer(Volunteer $volunteer)
    {

        $templates = Template::where('table_name', 'volunteers')->where('table_id', $volunteer->id)->orderBy('is_default', 'desc')->where('is_deleted', false)->get();

        $volunteer->image = $this->volProfilePicture($volunteer);

        $vol_sites = $volunteer->sites()->orderBy('is_default', 'desc')->get();

        $volunteer->regular_hrs_worked = $this->volRegularHours($volunteer);

        // $max_vendor = DB::table('volunteer_details')->where('code', 'vendor_id')->max('value');
        // $eStipendId = $volunteer ? ($volunteer->details()->where('code', 'vendor_id')->first()->value ?? $max_vendor) + 1 : 1;
        $eStipendId = str_pad($volunteer->alt_id, 10, 0, STR_PAD_LEFT);

        return view($this->clayout . '.updatedProfile.index', compact('templates', 'volunteer', 'vol_sites', 'eStipendId'));

    }

    private function volProfilePicture($volunteer)
    {

        $dp = '';

        $profile = File::where('table', 'volunteers')->where('table_id', $volunteer->id)->where('document_type', "profile")->where('is_deleted', 0)->first();

        if (!is_null($profile)) {

            if (file_exists(storage_path('uploads/' . $profile->file_name))):

                $dp = base64_encode(file_get_contents(storage_path('uploads/') . $profile->file_name));

            else:

                $dp = base64_encode(file_get_contents(storage_path('uploads/avatar.jpg')));

            endif;

        } else {

            $dp = '';

        }

        return $dp;
    }

    private function volRegularHours($volunteer)
    {

        $reg_hrs = Timesheet::where('volunteer_id', $volunteer->id)->where('status', 'Posted')->sum(DB::raw('time_to_sec(total_hrs)'));

        $reg_hrs /= 3600;

        return total_hrs($reg_hrs);

    }

    public function editPersonalInfoModal(Volunteer $volunteer)
    {
        return view($this->clayout . '.updatedProfile.modal.edit-personal-info', compact('volunteer'));
    }
    
    public function addTemplateCategory(){
        return view($this->clayout.'.profile.modal.addCategory');
    }

    public function updateDpModal($type, $id)
    {
        return view($this->clayout . '.updatedProfile.modal.update-dp', compact('type', 'id'));
    }

    public function uploadDocs(Volunteer $volunteer)
    {
        return view($this->clayout . '.updatedProfile.modal.upload-documents', compact('volunteer'));
    }

    public function emergencyContacts(Volunteer $volunteer)
    {
        return view($this->clayout . '.updatedProfile.modal.emergency-contacts', compact('volunteer'));

    }

    public function updateEmergencyContacts(EmergencyContact $emergencyContact)
    {
        return view($this->clayout . '.updatedProfile.modal.up-emergency-contacts', compact('emergencyContact'));

    }

    public function updateHrBasics(Volunteer $volunteer)
    {
        return view($this->clayout . '.updatedProfile.modal.hr-basic', compact('volunteer'));

    }

    public function updateHrDetails(Volunteer $volunteer)
    {
        return view($this->clayout . '.updatedProfile.modal.hr-details', compact('volunteer'));

    }

    public function viewRemakrs(Volunteer $volunteer){
        return view($this->clayout. '.updatedProfile.modal.view-remarks', compact('volunteer'));
    }

    public function viewDocs($filename)
    {

        return response()->file(storage_path('uploads/documents/') . $filename);

    }

    public function downloadDocs($filename)
    {

        return response()->download(storage_path('uploads/documents/') . $filename);

    }

    public function volModalCalendar(Volunteer $volunteer)
    {

        return view($this->clayout . ".updatedProfile.modal.calendar", [
            'volunteer' => $volunteer,
        ]);

    }

    public function assignSupervisors(Volunteer $volunteer)
    {
        $supervisors = User::where('role_id', 3)->where('is_deleted', false)->get();

        return view($this->clayout . '.updatedProfile.modal.assign-supervisor', compact('volunteer', 'supervisors'));
    }

    public function assignSites(Volunteer $volunteer)
    {
        $v_sites = $volunteer->sites()->pluck('sites.id');
        $sitesss = $this->getAssignedSites()->map(function ($site) use ($v_sites) {
            if ($v_sites->contains($site->id)) {
                $site->assinged_site = true;
            }

            return $site;
        });

        return view($this->clayout . '.updatedProfile.modal.assign-sites', compact('sitesss', 'volunteer', 'v_sites'));
    }

    public function getAssignedSites($request = false)
    {
        $is_admin = \Auth::user()->role_id == 1;
        if ($request instanceof Request && !$is_admin) {
            $cat = $request->input('query.site_cat', 'default');
            if ($cat === 'default') {
                return auth()->user()->sites(function ($query) use ($request) {
                    $query->select(['id', 'site_name'])
                        ->when($request->input('query.SearchSites', false), function ($q, $searchString) {
                            $q->where('site_name', 'like', "%$searchString%");
                        });
                }, ['table_id', 'county', 'region', 'district']);
            }

            if ($cat === 'county') {
                return Site::select('id', 'site_name')->with(['address' => function ($ad) {
                    return $ad->select('table_id', 'county', 'region');
                }])->whereHas('address', function ($add) {
                    $counties = auth()->user()->settings()->where('type', 'default_counties')->pluck('value')->all();
                    $add->whereIn('county', $counties);
                })
                    ->when($request->input('query.SearchSites', false), function ($q, $searchString) {
                        $q->where('site_name', 'like', "%$searchString%");
                    })->get();
            }

            if ($cat === 'all') {
                return Site::select('id', 'site_name')->with(['address' => function ($ad) {
                    return $ad->select('table_id', 'county', 'region');
                }])
                    ->when($request->input('query.SearchSites', false), function ($q, $searchString) {
                        $q->where('site_name', 'like', "%$searchString%");
                    })->get();
            }

        }

        return !$is_admin ? \Auth::user()->sites() : Site::with('address')->get();

    }

    public function assignSupervisorModal(Request $request)
    {
        $vol_ids = $request->input('vol_ids', '');
        $selected_vols = Volunteer::select('id', 'first_name', 'middle_name', 'last_name')->find(explode(',', $vol_ids));
        return view($this->clayout . '.modals.assignSupervisorModal', compact('selected_vols'));
    }

    public function getAssignedVolLists(Request $request)
    {

        return self::getRepo('fgp\Volunteer')->getVolunteerSelfAssignedList($request);

    }

    /**
     * Assign Volunteers to own modal
     * @param  Request $request
     * @return Illuminate\View\View
     */
    public function assignVolunteerToSelf(Request $request): View
    {
        return view($this->clayout . '.modals.assign-vols.assign-vols-oneself', [

            "user" => auth()->user(),

        ]);

    }

}
