<?php

namespace App\Http\Controllers\Fgp\Schedule;

use App\Http\Controllers\BaseController;
use App\Lib\Exporter\CSVExporter;
use App\Lib\Exporter\JSONExporter;
use App\Lib\Exporter\PDFExporter;
use App\Lib\Exporter\TxtExporter;
use App\Models\Address;
use App\Models\Fgp\County;
use App\Models\Fgp\District;
use App\Models\Fgp\PayPeriod;
use App\Models\Fgp\Region;
use App\Models\Fgp\Site;
use App\Models\Fgp\Timesheet;
use App\Models\Fgp\Volunteer;
use App\Repo\FGP\ScheduleRepo;
use App\Repo\TimeSheetRepo;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\BinaryFileResponse;

class ScheduleShowController extends BaseController
{
    private $repo;

    public function __construct()
    {
        parent::__construct();
        $this->layout = $this->layout . '.fgp.schedule';
        $this->repo = new TimeSheetRepo('Fgp\Timesheet');
    }

    public function index()
    {
        return $this->view('index');
    }

    public function getData(Request $request)
    {
        return $this->repo->selectScheduleData($request);
    }

    public function getGroupData(Request $request)
    {
        return $this->repo->selectScheduleGroupData($request);
    }

    /**
     * Print schedule grouped by site
     * @param  Site   $site [description]
     * @return Binary File Response
     */
    public function printGroupSchedule(Site $site) : BinaryFileResponse{
       
        $ts = Timesheet::select('volunteer_id', 'site_id', 'period_id')
            ->distinct()
            ->where('site_id', $site->id)            
            ->get()
            ->map(function($ts){
                $ts->timesheets = Timesheet::where([
                    'volunteer_id' => $ts->volunteer_id,
                    'site_id' => $ts->site_id,
                    'period_id' => $ts->period_id,
                ])->with(['timesheetItems', 'volunteer', 'pay_period'])
                ->get()
                ->map(function($timesheet){

                    $timesheet->travel = $timesheet->timesheetItems->where('type', "Mileage Reimbursements")->first()->value ?? '';
                    $timesheet->meals = $timesheet->timesheetItems->where('type', "Food Service")->first()->value ?? '';

                    return $timesheet;

                });

                $ts->travelTotal = $ts->timesheets->sum(function($items){
                    return $items->timesheetItems->where('type', "Mileage Reimbursements")->sum('amount');
                });
                $ts->mealTotal = $ts->timesheets->sum(function($items){
                    return $items->timesheetItems->where('type', "Food Service")->sum('amount');
                });

                $ts->hoursTotal = $ts->volunteer->total_hrs($ts->period_id, $ts->site_id);

                return $ts;
            });


        $exporter = new \App\Lib\Exporter\Exporter(new PDFExporter($ts, null, 'printGroupSchedule'));
        $filename = $exporter->export();
        return response()->download($filename)->deleteFileAfterSend(true);         

    }

    public function printGroupSelectiveSchedule(Request $request){

        $sortedData = collect($request->data)->sortBy('period_id')->toArray();

        foreach ($sortedData as $key => $data) {

            $ts[$key]['volunteer'] = Volunteer::where('id',$data['volunteer_id'])->first();


            $ts[$key]['period']   = PayPeriod::where('id', $data['period_id'])->first();

            $ts[$key]['site']   = Site::where('id', $data['site_id'])->first();
        
            $ts[$key]['timesheets'] = Timesheet::where([
                'period_id' => $data['period_id'],
                'site_id'   => $data['site_id'],
                'volunteer_id'  => $data['volunteer_id']
            ])->get();

        }

        $exporter = new \App\Lib\Exporter\Exporter(new PDFExporter($ts, null, 'printGroupSelectiveSchedule'));
        $filename = $exporter->export();
        return $exporter->getfilename();

    }

    public function getPrintedSelectiveSchedule($filename){

        $file = $filename.'.pdf';

        return response()->file(storage_path("reports\\".$file));

        // return response()->download($pdf)->deleteFileAfterSend(true); 

    }

    /* Exports */

    public function exportGroupSchedule(Request $request, $type){

        $data = $this->repo->getTsScheduleGroupData($request);

        $fields = array('Volunteer', 'Site','Period#', 'Schedule Date', 'Total Hours', 'Total Items');

        $mapField = array('vol_name', 'site_name', 'period_no', 'schedule_date', 'total_hrs', 'total_item');

        $data = cleaner($mapField, $data);

        $data['table']  = "Schedules Reports";

        $data['request'] = ["Search"    =>  "All"];

        if(count($data) > 0){
            $export = $this->reportFactory($type, $fields, $data);

            $exporter = new \App\Lib\Exporter\Exporter($export);

            $filename   = $exporter->export();

            return response()->download($filename)->deleteFileAfterSend(true);
        }{
            return " No data available at the moment";
        }

    }

    /**
     * @param $type
     * @param $data
     * @return CSVExporter|JSONExporter|PDFExporter|TxtExporter
     * @throws \Exception
     */
    public function reportFactory($type, $fields, $data)
    {
        switch ($type) {
            case 'csv':
                return new CSVExporter($data, $fields, 'ScheduleReports');
                break;
            case 'json':
                return new JSONExporter($data);
                break;
            case 'txt':
                return new TxtExporter($data);
                break;
            case 'pdf':
                return new PDFExporter($data, $fields, 'print');
                break;
            default:
                throw new \Exception("Method Not Allowed " . $type);
                break;
        }
    }


}
