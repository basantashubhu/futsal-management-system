<?php

namespace App\Http\Controllers\Fgp\Payperiod;

use function GuzzleHttp\Psr7\str;
use Illuminate\Http\Request;
use App\Http\Requests\Fgp\PayperiodRequest;
use App\Models\Fgp\PayPeriod;
use App\Http\Controllers\BaseController;
use Illuminate\Support\Facades\DB;

class PayperiodStoreController extends BaseController
{
    private $startDate = null;
    private $endDate = null;

    public function storePayperiod(PayperiodRequest $request)
    {

        $validPayperiod = $request->only([
            'interval', 'fiscal_year', 'start_date', 'end_date', 'period_starts_from'
        ]);
        if ($validPayperiod) {
            DB::beginTransaction();
            try {
                $this->startDate = date("Y-m-d", strtotime($request->start_date));
                $this->endDate = date("Y-m-d", strtotime($request->end_date));
                $res = [];
                switch ($request->interval) {
                    case "single":
                        $res = $this->saveSingle($request);
                        break;
                    case "weekly":
                        $res = $this->saveWeekly($request);
                        break;
                    case "monthly":
                        $res = $this->saveMonthly($request);
                        break;
                    case "bimonth":
                        $res = $this->saveBimonthly($request);
                        break;
                }
                DB::commit();
                return $res;
            } catch (\Exception $e) {
                return $this->response($e->getMessage(), 'view', 500);
            }
        } else {
            return "not valid";
        }

    }

    /**
     * Opens a closed period
     *
     * @param PayPeriod $period
     * @return void
     */
    public function openPeriod(PayPeriod $period){

        //:todo check if its fiscal use laravel policies
        $period->update([

            'closed_date' => null,
            'closed_time' => null,
            'pay_stat'    => "Open"

        ]);
        return $period;
    }


    private function generatePaycodeWrtPeriod($fiscal_year, $period_no){
      
        return $period_no.date('y', strtotime($fiscal_year."-01-01"));


    }

    private function saveSingle(Request $request) {
        $start_date = $this->formatDate($request->start_date);
        $end_date = $this->formatDate($request->end_date);
        $payperiod = new PayPeriod();
        $payperiod->start_date = $start_date;
        $payperiod->end_date = $end_date;
        $payperiod->fiscal_year = $request->fiscal_year;
        $payperiod->pay_code = $request->pay_code?: $this->generatePaycodeWrtPeriod($request->fiscal_year, $request->period_starts_from);
        // $payperiod->pay_code = $request->pay_code?:$this->generatePaycode(...array_values($request->only('start_date', 'end_date')));
        $payperiod->pay_stat = 'New';
        $payperiod->period_no = $request->period_starts_from;
        $payperiod->save();
    }

    private function saveWeekly(Request $request)
    {

        if ($this->startDate < $this->endDate) {
            $days = ((strtotime($this->endDate) - strtotime($this->startDate)) / (60 * 60 * 24)) + 1;
            $period_starts = $request->period_starts_from;
            $newStartDate = $this->startDate;

            for ($i = 0; $i < ceil($days / 7); $i++) {

                $payperiod = new Payperiod();
                $temp_end_date = $this->intoDate($newStartDate, 7 - 1);
                $finalEndDate = ($this->endDate < $temp_end_date) ? $this->endDate : $temp_end_date;

                // $paycode = $request->pay_code?:$this->generatePaycode($newStartDate, $finalEndDate);
                $payperiod->pay_code = $request->pay_code?: $this->generatePaycodeWrtPeriod($request->fiscal_year, $period_starts + $i);

                $payperiod->pay_code = $paycode;

                $payperiod->end_date = $finalEndDate;
                $payperiod->start_date = $newStartDate;
                $payperiod->period_no = $period_starts + $i;
                $payperiod->fiscal_year = $request->fiscal_year;
                $payperiod->pay_stat = 'New';
                $payperiod->save();
                $newStartDate = $this->intoDate($temp_end_date, 1);
            }
            return "success";

        } else {
            return $this->response("Sory, start date must be smaller than end date !", "view", 500);
        }
    }
    function totalDays($date1, $date2)  
    { 
        $diff = strtotime($date2) - strtotime($date1); 
          
        return abs(round($diff / 86400)); 
    }

    private function formatDate($date) {
        return date('Y-m-d',strtotime($date));
    }

    private function saveMonthly(Request $request)
    {
        $startDate = date('Y-m-d',strtotime($request->start_date));
        $endDate = date('Y-m-d',strtotime($request->end_date));

        $this->startDate = $startDate;
        $this->endDate = $endDate;

        $fully_formatted_date = array();

       for ($i=0; $startDate < $endDate ;) { 

            $mydate = \Carbon($startDate)->addMonth($i);
            $formated_period = array();
        
            $firstDay = date('Y-m-01', strtotime($mydate));
            $lastDay = date('Y-m-t', strtotime($mydate));

            $totalDays = $this->totalDays($firstDay,$lastDay);
           
            $formated_period['start_date'] = date('Y-m-d', strtotime($startDate));
            $tempStartDate = $formated_period['start_date'];


            $formated_period['end_date'] = $this->intoDate($tempStartDate,$totalDays);
    

            array_push($fully_formatted_date, $formated_period);

            $startDate = Carbon($startDate)->addMonth($i+1);
          
       }


        $period_no = $request->period_starts_from;
        foreach ($fully_formatted_date as $key => $value) {
            PayPeriod::create([
                'start_date' => $value['start_date'],
                'end_date' => $value['end_date'],
                // 'pay_code' => $request->pay_code?:$this->generatePaycode(...array_values($request->only('start_date', 'end_date')))
                'pay_code' => $request->pay_code?: $this->generatePaycodeWrtPeriod($request->fiscal_year, $period_no),
                'fiscal_year' => $request->fiscal_year,
                'period_no' => $period_no,
                'pay_stat' => 'New',
            ]);
            $period_no++;
        }
    }



    private function saveBimonthly(Request $request)
    {
        
        $startDate = date('Y-m-d',strtotime($request->start_date));
        $endDate = date('Y-m-d',strtotime($request->end_date));
                $dateStartEnd = array();
        array_push($dateStartEnd,$startDate);
        array_push($dateStartEnd,$endDate);

        $fully_formatted_date = array();

        //format payperiod start and end date in array
       for ($i=0; $startDate < $endDate ;) { 

            $formated_period = array();
        
            $formated_period['start_date'] = date('Y-m-d', strtotime($startDate));
            $tempStartDate = $formated_period['start_date'];

            $formated_period['end_date'] = $this->intoDate_end($tempStartDate,14);
            
            array_push($fully_formatted_date, $formated_period);
            $startDate = $this->intoDate_start($tempStartDate,15);
          
       }
       //store period bimonthly
        $period_no = $request->period_starts_from;
        foreach ($fully_formatted_date as $item) {
            PayPeriod::create([
                'start_date' => $item['start_date'],
                'end_date' => $item['end_date'],
                // 'pay_code' => $request->pay_code?:$this->generatePaycode(...array_values($request->only('start_date', 'end_date'))),
                'pay_code' => $request->pay_code?: $this->generatePaycodeWrtPeriod($request->fiscal_year, $period_no),
                'fiscal_year' => $request->fiscal_year,
                'period_no' => $period_no,
                'pay_stat' => 'New',
            ]);
            $period_no++;
        }
    }

    private function checkPayCode($pay_code)
    {
        $check = PayPeriod::select('period_no')->where('pay_code', $pay_code)->first();
        return $check;
    }

    public function updatePayperiod(Request $request)
    {
        $request->validate([
            'end_date' => 'required|date',
            'start_date' => 'required|date',
            'period_no' => 'required',
            'fiscal_year' => 'required',
            'closed_date' => 'nullable|date',
            'closed_time' => 'nullable',
        ]);
        $closedDate = $request->closed_date?date('Y-m-d', strtotime($request->closed_date)):NULL;
        $closedTime = $request->closed_time?date('Y-m-d H:i:s', strtotime($request->closed_time)):NULL;
     
        $period = PayPeriod::find($request->id);
        save_update($period, $request->only('end_date','start_date', 'period_no', 'fiscal_year') + [
            // 'pay_code'  => $request->pay_code?: $this->generatePaycode(...array_values($request->only('start_date', 'end_date'))),
            'pay_code'  => $request->pay_code?: $this->generatePaycodeWrtPeriod($request->fiscal_year, $period->period_no),
            'closed_date' => $closedDate,
            'closed_time' => $closedTime,
        ]);
        if ($period):
            $this->response("Period Updated Successfully", "view", 200);
        else:
            $this->response("Failed to Update", "view", 200);
        endif;
    }

    private function generatePaycode($start_date, $end_date)
    {
        $first = str_replace('/', '', $start_date);
        $code = str_replace('-', '', $first);
        $second = str_replace('-', '', $end_date);
        $code1 = str_replace('/', '', $second);

        $pay_code = substr($code, 3, 7);
        $pay_code1 = substr($code1, 4, 7);
        return '#FGP' . $pay_code . $pay_code1;
    }

    private function intoDate($date, $interval)
    {
        $date = date('Y-m-d', strtotime($date . ' + ' . $interval . ' days'));
        return $date;
    }

    private function intoDate_end($date, $interval){

        $d = date('d', strtotime($date)); 

        if($d =="16"){
            $date = date('Y-m-t', strtotime($date));
             return $date;
        
        } else {
            $date = date('Y-m-d', strtotime($date . ' + ' . $interval . ' days'));
             return $date;
      
        }
    }    

    private function intoDate_start($date, $interval){

        $d = date('d', strtotime($date)); 

        if($d =="16"){
            $date = date('Y-m-01', strtotime($date.'+ 1 month'));
             return $date;
        
        } else {
            $date = date('Y-m-d', strtotime($date . ' + ' . $interval . ' days'));
             return $date;
      
        }
       
    }

    public function deletePayperiod(Request $request)
    {
        $deleted = PayPeriod::where('id', $request->id)
            ->update([
                'is_deleted' => 1,
                'useru_id' => $request->userd_id
            ]);
        if ($deleted) :
            return $this->response('Pay Period Deleted Successfully', 'view', '200');
        else:
            return $this->response('Failed to Delete Pay Period', 'view', '500');
        endif;
    }

    public function saveStipendList(Request $request) {
        foreach ($request->input('stipendP', []) as $pp) {
            if($this->isReOpenRequest($pp['stipend_id'])){
                $fields = [
                    'pay_stat' => $pp['pay_stat'],
                    'closed_date' => null,
                    'closed_time' => null,
                    'closed_user_id' => null

                ];
            }else{
                $fields = [
                    'pay_stat' => $pp['pay_stat']
                ];
            }
            
            PayPeriod::where('id', $pp['stipend_id'])->update($fields);
        }
        return 'success';
    }

    public function isReOpenRequest($periodID){
        return PayPeriod::find($periodID)->pay_stat === "Posted" ? true : false;
    }

}
