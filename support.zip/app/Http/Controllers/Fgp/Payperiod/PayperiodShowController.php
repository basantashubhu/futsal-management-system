<?php

namespace App\Http\Controllers\Fgp\Payperiod;

use App\Models\Fgp\Holiday;
use Illuminate\Http\Request;
use App\Http\Controllers\BaseController;
use App\Models\Fgp\PayPeriod;
use Illuminate\Support\Facades\DB;
use App\Lib\Exporter\CSVExporter;
use App\Lib\Exporter\JSONExporter;
use App\Lib\Exporter\PDFExporter;
use App\Lib\Exporter\TxtExporter;
use App\Http\Controllers\Controller;
use App\Repo\Fgp\PayPeriodRepo;

class PayperiodShowController extends BaseController
{
    private $clayout = "";
    private static $repo;

    public function __construct(){
		parent::__construct();
		$this->clayout = $this->layout.'.fgp.payperiod';
    } 

    public function __invoke(){
    	return view($this->clayout.".index");
    }

    public function addPayperiod(){     
        $fiscal_year = getSiteSettings('fiscal_year');
        $validations = validation_value('pay_period_form');
        $period_no = PayPeriod::max('period_no');

    	return view($this->clayout.'.models.add',compact('fiscal_year','validations','period_no'));
    }

    public static function getRepo($model){
        self::$repo = new PayPeriodRepo($model);
        return self::$repo;
    }

    public function allPayperiod(Request $request){
        $payperiod = self::getRepo('Fgp\PayPeriod')->selectDataTable($request);
        foreach($payperiod['data'] as $p){
            if($p->closed_time !=''){
                $p->closed_time = date("g:i A", strtotime($p->closed_time));
            }
        }
        return $payperiod;
    }

    public function getReportData(Request $request, $type)
    {
        if(isset($_COOKIE['pay_period_advanced']) || isset($_COOKIE['pay_period_quick'])){
            $advData=isset($_COOKIE['pay_period_advanced'])?json_decode($_COOKIE['pay_period_advanced']):[];
            $quickData=isset($_COOKIE['pay_period_quick'])?json_decode($_COOKIE['pay_period_quick']):[];
            $mergeData=array_merge($advData,$quickData);
        }else{
            $mergeData = [];
        }
        $data = self::getRepo('Fgp\PayPeriod')->getReportData($request);
        foreach($data as $p){
            if($p->closed_time !=''){
                $p->closed_time = date("g:i A", strtotime($p->closed_time));
            }
        }
        $fields = array('Pay Code', 'Period#', 'Fiscal Year', 'Start Date', 'End Date', 'Closed Date', 'Closed Time');
        $mapField = array('pay_code', 'period_no', 'fiscal_year', 'start_date', 'end_date', 'closed_date', 'closed_time');
        $data = cleaner($mapField, $data);
        $data['table'] = 'Report of Stipend Period';
        $data['request'] = '';
        if(empty($mergeData)){
            $data['request'] = ['Search' => 'All'];
        }else{
            $data['request'] = [];
            foreach($mergeData as $d):
                if($d->name=='pay_code'){
                    $data['request']['Pay Code'] = $d->value;
                }
                if($d->name=='date_range'){
                    $data['request']['Date Range'] = $d->value;
                }
            endforeach;
        }
        if (count($data) > 0) {
            $export = $this->reportFactory($type, $fields, $data);
            $exporter = new \App\Lib\Exporter\Exporter($export);
            $filename = $exporter->export();
            return response()->download($filename)->deleteFileAfterSend(true);
        }{
            return 'No Data Available For Current Filter';
        }
    }

            /**
     * @param $type
     * @param $data
     * @return CSVExporter|JSONExporter|PDFExporter|TxtExporter
     * @throws \Exception
     */
    public function reportFactory($type, $fields, $data)
    {
        switch ($type) {
            case 'csv':
                return new CSVExporter($data, $fields, 'PayPeriodReports');
                break;
            case 'json':
                return new JSONExporter($data);
                break;
            case 'txt':
                return new TxtExporter($data);
                break;
            case 'pdf':
                return new PDFExporter($data, $fields, 'print');
                break;
            default:
                throw new \Exception("Method Not Allowed " . $type);
                break;
        }
    }

    public function editPayperiod($id){
        $payperiod = PayPeriod::find($id);
        return view($this->clayout.'.models.update',compact('payperiod'));
    }
    public function deletePayperiod($payperiod_id){
       return view($this->clayout.'.models.delete',compact('payperiod_id'));
    }

    public function checkDate(Request $request){

        $exists = PayPeriod::max('end_date');
        $start_date = date("Y-m-d", strtotime($request->date));

        return "ok";

        if ($start_date < $exists)
            return $this->response("Start date must be more than ".date("m/d/Y", strtotime($exists)), "view", 500);
        else
            return "ok";
    }

    public function checkFiscalYear($year){
        return $year;
    }

    /*
     * dashboard
     * */
    public function stipendList() {
        return $this->view('default.fgp.dashboard.modals.stipend_list');
    }

    public function getData(Request $request) {
        return (new PayPeriodRepo('Fgp\PayPeriod'))->getStipendList($request);
    }

    public function checkPayperiodNo($no){

        if (!is_null($no)){

            $no= explode(':',$no);

            if(!isset($no[0]) || trim($no[0]) =="" ){
                return response(
                    ["message"=> " Period is Blank",
                    "county"=> "",
                    "max"=> $no[0]], 500);
            }


             if(!isset($no[1]) || trim($no[1]) =="") {
                return response(
                    ["message"=> " Fiscal Year is blank",
                    "county"=> "",
                    "max"=> $no[0]], 500);
            }


            
            $periodNo = PayPeriod::select('period_no')->where(['period_no'=>$no[0], 'fiscal_year'=>$no[1], 'is_deleted'=>0])->first();

            $max = PayPeriod::max('period_no');
            if ($periodNo){
                return response(["message"=>$no[0]." Already Exists","county"=>$periodNo,"max"=>$max+1],500);
            }
        }
    }
}
