<?php

namespace App\Http\Controllers\Fgp\Period;

use App\Models\Fgp\PayPeriod;
use Illuminate\Http\Request;
use App\Http\Controllers\BaseController;
use Illuminate\Support\Facades\DB;

class PeriodShowController extends BaseController
{
    private $layout_path = '';
    public function __construct()
    {
        parent::__construct();
        $this->layout_path = $this->layout . '.fgp.pay_period';
    }

    /**
     * current period
     */
    public function index()
    {
        $current_periods = PayPeriod::where([
            ['start_date', '<', DB::raw('CURDATE()')],
            ['end_date', '>', DB::raw('CURDATE()')]
        ])->get();
        return $this->view($this->layout_path . '.current_periods', compact('current_periods'));
    }
}
