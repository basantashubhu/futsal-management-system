<?php

namespace App\Http\Controllers\Fgp\ApprovalFlow;

use App\Http\Controllers\BaseController;
use App\Models\Fgp\ApprovalFlow;
use App\Models\Role;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class ApprovalFlowShowController extends BaseController
{

    private $clayout = "";
    private static $repo = null;
    public function __construct(){
        parent::__construct();
        $this->clayout = $this->layout.'.fgp.approval_flow';
    }
    public function __invoke()
    {
        // TODO: Implement __invoke() method.
        $approval_flows = ApprovalFlow::where('is_deleted',0)->orderBy('seq_num','asc')->get();
        return view($this->clayout.'.index',compact('approval_flows'));
    }

    public function modalAdd(){
        $validations = validation_value('approval_flow_create');
        $approval_flows = ApprovalFlow::where('is_deleted',0)->orderBy('seq_num','asc')->get();
        return view($this->clayout.'.modals.add',compact('validations','approval_flows'));
    }
    public function modalEdit($id){
        $approval = \ApprovalFlow::find($id);
        return view($this->clayout.'.modals.update',compact('approval'));
    }
    public function roleList(Request $request){

        $data = $request->data;
        $values = [];
        if ($data !=null):
            foreach ($data as $datum){
                array_push($values,$datum['value']);
            }
            array_push($values,1);
            $abc = Role::select('label as text', 'id')
                ->whereNotIn('id',$values)
                ->when($request->term, function($query) use($request){
                    $query->where('label', 'like', '%'. $request->term .'%');
                })
                ->get();
           return $abc;
        else:
            array_push($values,1);
            $abc = Role::select('label as text', 'id')
                ->whereNotIn('id',$values)
                ->when($request->term, function($query) use($request){
                    $query->where('label', 'like', '%'. $request->term .'%');
                })
                ->get();
            return $abc;

        endif;
    }

    public function approvalAll(){
        $data = Role::join('approval_flow','approval_flow.role_id','roles.id')
            ->select('roles.label as role','approval_flow.seq_num')
            ->orderBy('seq_num')
            ->get();
        return $data;
//        return ApprovalFlow::where('is_deleted',0)->orderBy('seq_num','asc')->get();
    }

    public function totalRole(){
        return Role::count();
    }
}
