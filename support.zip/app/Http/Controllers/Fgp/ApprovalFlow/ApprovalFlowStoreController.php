<?php

namespace App\Http\Controllers\Fgp\ApprovalFlow;

use App\Models\Fgp\ApprovalFlow;
use App\Models\Role;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class ApprovalFlowStoreController extends Controller
{
    public function store(Request $request){
        $data = $request->all();

        $finalData = $this->bulkFormatter($data);
        $approvalData = ApprovalFlow::where('is_deleted',0)->get();

        if (sizeof($finalData) > sizeof($approvalData)){
            $this->insertApprovalFlow($finalData);
            try{

                foreach ($finalData as $datum){
                    $check = ApprovalFlow::where('role_id',$datum['role_id'])->where('is_deleted',0)->first();

                    if ($check):
                        $role = Role::where('id',$check->role_id)->where('is_deleted',0)->first();
                        ApprovalFlow::where('id',$check->id)
                            ->update([
                                'seq_num'=>$datum['seq_num'],
                                'role'=>$role->name,
                                'code'=>substr($role->name,0,1),
                                'role_id'=>$role->id,
                            ]);
                    else:
//                        DB::table('approval_flow')->insert($datum);
                        $role = Role::where('id',$datum['role_id'])->first();
                        ApprovalFlow::create([
                            'seq_num'=>$datum['seq_num'],
                            'role'=>$role->name,
                            'code'=>substr($role->name,0,1),
                            'role_id'=>$role->id,
                        ]);
                    endif;
                }
                return response(["message"=>"Success.","view"=>200]);
            }catch (\Exception $e){
                return $e->getMessage();
            }
        }else{
            try{
                DB::statement('SET FOREIGN_KEY_CHECKS=0;');
                \DB::table('approval_flow')->truncate();
                foreach ($finalData as $data) {
//                    \DB::table('approval_flow')->insert($data);
                        $role = Role::where('id',$data['role_id'])->first();
                        ApprovalFlow::create([
                            'seq_num'=>$data['seq_num'],
                            'role'=>$role->name,
                            'code'=>substr($role->name,0,1),
                            'role_id'=>$role->id,
                        ]);
                }
                DB::statement('SET FOREIGN_KEY_CHECKS=1;');

            }catch (\Exception $e){
                return $e->getMessage();
            }
//            $this->insertApprovalFlow($finalData);
        }
    }

    public function bulkFormatter($data){


        if($data instanceOf Request) $data = $data->all();

        $formatted_data = [];

        foreach ($data as $key => $first_arrray) {

            if(is_array($first_arrray)){

                foreach ($first_arrray as $index => $value) {

                    $formatted_data[$index][$key] = $value;

                }
            }

        }

        return $formatted_data;

    }

    public function dragSort(Request $request)
    {

        $data = $request->data;
        $finalData = [];
        foreach ($data as $key => $datum) {

            $datum["seq_num"] = $key + 1;
            array_push($finalData,$datum);
        }

        $this->insertApprovalFlow($finalData);
    }

    public function insertApprovalFlow(Array $finalData){
        try{
            foreach ($finalData as $datum){
                $check = ApprovalFlow::where('role_id',$datum['role_id'])->where('is_deleted',0)->first();

                if ($check):
                    $role = Role::where('id',$check->role_id)->where('is_deleted',0)->first();
                    ApprovalFlow::where('id',$check->id)
                        ->update([
                            'seq_num'=>$datum['seq_num'],
                            'role'=>$role->name,
                            'code'=>substr($role->name,0,1),
                            'role_id'=>$role->id,
                        ]);
                else:
                    $role = Role::where('id',$datum['role_id'])->first();
                    ApprovalFlow::create([
                        'seq_num'=>$datum['seq_num'],
                        'role'=>$role->name,
                        'code'=>substr($role->name,0,1),
                        'role_id'=>$role->id,
                    ]);
                endif;
            }
            return response(["message"=>"Success.","view"=>200]);
        }catch (\Exception $e){
            return $e->getMessage();
        }
    }
}
