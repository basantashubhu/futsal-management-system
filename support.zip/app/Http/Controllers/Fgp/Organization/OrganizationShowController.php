<?php

namespace App\Http\Controllers\Fgp\Organization;

use App\Http\Controllers\BaseController;
use App\Models\Fgp\City;
use App\Models\Fgp\County;
use App\Models\Fgp\District;
use App\Models\Fgp\Organization;
use App\Models\Fgp\Region;
use App\Models\Fgp\State;
use App\Models\Settings\Lookups;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class OrganizationShowController extends BaseController
{
    private $clayout = "";
    private static $repo;

    public function __construct()
    {
        parent::__construct();
        $this->clayout = $this->layout.'.fgp.organization';
    }
    public function __invoke()
    {
        return $this->view($this->clayout.'.index');
    }

    public function addOrganization(){
        $validations = validation_value('organization_create');
        return $this->view($this->clayout.'.modals.add',compact('validations'));
    }
     public function editOrganization($id){
            $validations = validation_value('organization_create');
            $organization = Organization::find($id);
            return $this->view($this->clayout.'.modals.update',compact('validations','organization'));
        }
        public function deleteOrganization($id){

            return $this->view($this->clayout.'.modals.delete',compact('id'));
        }

    /*============ all data for data table =====*/
    public function fetchAll(){
        return Organization::where('is_deleted',0)->get();
    }
    /*===========lookup for industry type =====*/
    public function fetchLookupIndustryType(Request $request){

        return Lookups::select('value as text', 'value as val')
            ->where('code',$request->lookup)
            ->when($request->term, function($query) use($request){
                $query->where('value', 'like', '%'. $request->term .'%');
            })
            ->get();
    }

    /*============ address lookup ===========*/

    public function getAddress(Request $request){
        $address = array();
        if ($request->has('city')){
            $city = City::find($request->city);

            if ($city->district_id != null){
                $district = District::find($city->district_id);
            $address['district'] = $district['district_name'];
            }
            if ($city->region_id != null){
                $region = Region::find($city->region_id);
            $address['region'] = $region['region_name'];
            }
            if ($city->state_id != null){
                $state = State::find($city->state_id);
            $address['state'] = $state['state_name'];
            }
            if ($city->county_id != null){
                $county = County::find($city->county_id);
            $address['county'] = $county['county_name'];
            }

            $address['city'] = $city['city_name'];
            $address['zip_code'] = $city['zip_code'];

            return $address;
        }else{
            return "nth";
        }
    }

    /*================== lookup for detail ===========*/
     public function organizationDetail(Request $request) {
        $input = $request->input('formdata', array());
        $codes = array();
        foreach ($input as $key => $value) {
            $codes[] = $value['value'];
        }
        return Lookups::where('code', 'organization_detail')
            ->select('value as value', 'id','datatype as data_type', 'has_lookup')
            ->when($request->term, function($query) use($request){
                $query->where('value', 'like', '%'. $request->term .'%');
            })
            ->whereNotIn('value', $codes)
            ->get();
    }

}
