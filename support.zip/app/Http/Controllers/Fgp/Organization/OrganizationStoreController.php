<?php

namespace App\Http\Controllers\Fgp\Organization;

use App\Http\Controllers\BaseController;
use App\Http\Requests\Fgp\OrganizationRequest;
use App\Models\Address;
use App\Models\Contact;
use App\Models\Fgp\Organization;
use App\Models\Fgp\OrganizationDetail;
use App\Repo\FGP\OrganizatinRepo;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class OrganizationStoreController extends BaseController
{
    private $table_name = 'organizations';
    private static $repo = null;

    public static function getRepo($model){
        self::$repo = new OrganizatinRepo($model);
        return self::$repo;
    }

    public function storeOrganization(OrganizationRequest $request, Organization $organization = null)
    {

        DB::beginTransaction();
        try{
            $saveOrg = $this->saveBasicInfo($request,$organization);
            if ($request->has("label")){
                $this->saveDetail($request,$saveOrg, $organization);
            }

             $this->saveAddress($request,$saveOrg, $organization);

            $this->saveContact($request,$saveOrg, $organization);


            DB::commit();
        }catch(\Exception $e){
            DB::rollback();
            return response(["message" => $e->getMessage()], 500);
        }
    }

    private function saveBasicInfo(OrganizationRequest $request, Organization $organization = null){
        $organizationInfo = $request->only([
            'name', 'code', 'estd_date', 'no_of_emp', 'industry'
        ]);

        if ($organizationInfo) {

            $organizationInfo['estd_date'] = date('Y-m-d',strtotime($request->estd_date));

            if ($organization) {
               return  self::getRepo($organization)->saveUpdate($organizationInfo);
            }
                return self::getRepo('Fgp\Organization')->saveUpdate($organizationInfo);
        }
    }

    private function saveAddress(Request $request, $orgn_created, $orgn){

        $address_info = $request->only([
            'add1','add2','city','zip_code','county','region','district','state',
        ]);
        $address_info['table_name'] = $this->table_name;
        $address_info['table_id'] = $orgn_created->id;

        if($orgn){
            $addr = Address::where('table_name', $this->table_name)->where('table_id', $orgn->id)->first();
            return self::getRepo($addr)->saveUpdate($address_info);
        }
        return self::getRepo('Address')->saveUpdate($address_info);
    }

    private function saveContact(Request $request, $org_created, $orgn){
        $contact_info = $request->only([
            'tel_phone','fax','alt_phone','email','url'
        ]);
        $contact_info['table_name'] = $this->table_name;
        $contact_info['table_id'] = $org_created->id;
        if($orgn){
            $contact = Contact::where('table_name', $this->table_name)->where('table_id', $orgn->id)->first();
            return self::getRepo($contact)->saveUpdate($contact_info);
        }
        return self::getRepo('Contact')->saveUpdate($contact_info);

    }

    public function saveDetail(Request $request, $orgn_created, $orgn) {
        $detail = [];
        foreach ($request->label as $label){
            foreach ($request->value as $val){

//                $detail['code']=$val;
//                $detail['name']=$label;
//                $detail['value']=$val;
//                $detailorganization_id = $orgn_created->id;
//                $detail->save();
            }
        }
    }

    public function deleteOrganization(Request $request){
        $deleted = Organization::find($request->id)
            ->update([
                'is_deleted'=>1,
                'useru_id' => $request->userd_id
            ]);
        if ($deleted) :
            return $this->response('Deleted Successfully','view','200');
        else:
            return $this->response('Failed to Delete','view','500');
        endif;
    }

}
