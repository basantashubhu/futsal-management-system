<?php

namespace App\Http\Controllers\Fgp\Holiday;

use App\Http\Controllers\BaseController;
use App\Http\Requests\Fgp\HolidayRequest;
use App\Http\Controllers\Controller;

use App\Repo\FGP\HolidayRepo;
use Illuminate\Support\Facades\DB;
use App\Models\Fgp\Holiday;

class HolidayUpdateController extends BaseController
{
    private static $repo;

	public static function getRepo($model){
        self::$repo = new HolidayRepo($model);
        return self::$repo;
    }

    public function updateHoliday(HolidayRequest $request, Holiday $holiday){

        DB::beginTransaction();
        try{
    	// Date(sitedateformatphp(), strtotime($date))
            $data = $request->only([
                'name','description', 'cal_type', 'state_r','eto_eligibility','is_active','paid_flag','hol_date'
            ]);
            $timestamp = strtotime($request->hol_date);
            if ($timestamp === false) {
                throw new \Exception('Invalid date input.');
            }
            $data['hol_date'] = date('Y-m-d H:i:s', $timestamp);
            $deleted = Holiday::where('hol_date', $data['hol_date'])->where('is_deleted', 1)->delete();
            $exists = Holiday::where('hol_date', $data['hol_date'])->where('is_deleted', 0)->where('id', '!=', $holiday->id)->count() > 0;
            if ($exists) {
                throw new \Exception('Holiday already exists on '. $request->hol_date . '.');
            }
            if ($request->eto_eligibility) {
                $data['eto_eligibility'] = 1;
            }else {
                $data['eto_eligibility'] = 0;
            }
            if ($request->is_active) {
                $data['is_active'] = 1;
            }else {
                $data['is_active'] = 0;
            }
            if ($request->paid_flag) {
                $data['paid_flag'] = 1;
            }
            $holiday = self::getRepo($holiday)->saveUpdate($data);
            DB::commit();   
//            return response(["Volunteer successfully updated"], 200);
            if ($holiday):
                return $this->response($holiday, 'view', '200');
            else:
                return $this->response('Failed to Update', 'view', '500');
            endif;

        }catch(\Exception $e){
            DB::rollback();
            return response(['errors' => ["message" => $e->getMessage()]], 500);
        }    	    	
    }

    public function deleteHoliday(Holiday $holiday){
        DB::beginTransaction();
        try{
            $holiday->delete();
            DB::commit();   
            return response(["Volunteer successfully deleted"], 200);

        }catch(\Exception $e){
            DB::rollback();
            return response(["message" => $e->getMessage()], 500);
        }               
    }
}
