<?php

namespace App\Http\Controllers\Fgp\Holiday;

use App\Models\Settings\Lookups;
use Illuminate\Http\Request;
use App\Http\Controllers\BaseController;

use App\Models\Fgp\Timesheet;

use App\Models\Fgp\Holiday;
use App\Repo\FGP\HolidayRepo;
use Illuminate\Support\Facades\DB;
use App\Lib\Exporter\CSVExporter;
use App\Lib\Exporter\JSONExporter;
use App\Lib\Exporter\PDFExporter;
use App\Lib\Exporter\TxtExporter;


/**/
use App\Models\Fgp\PayPeriod;
use App\Models\Fgp\Volunteer;
use App\Repo\TimeSheetRepo;

class HolidayShowController extends BaseController
{

    // new time-sheet add form page
    public function assignTimeSheet(Request $request) {
        $validations = validation_value('timeSheetAddForm');
        $periods = PayPeriod::where('is_deleted', 0)->get();
        $volunteers = Volunteer::select('id', DB::raw('CONCAT(first_name, " ", last_name) as name'))
                            ->where('vol_supervisor_id', $request->user()->id)->get();
        return $this->view($this->layout . '.fgp.timesheet.includes.assignTimeSheet', compact('validations','periods', 'volunteers'));
    }

    public function findPeriod($id){
        return PayPeriod::find($id);
    }

    // new time-sheet add form page
    public function timesheetTemplate($sup_id) {
        $validations = validation_value('timeSheetAddForm');
        $templates = Null;
        return $this->view($this->layout . '.fgp.timesheet.includes.loadTimesheet', compact('validations','templates'));
    }

    /*holiday*/
    private static $repo;

    public static function getRepo($model){
        self::$repo = new HolidayRepo($model);
        return self::$repo;
    }

    public function index(){
        $cal_types = Holiday::select('cal_type')
            ->where('is_deleted',0)
            ->distinct()
            ->get();

        return view($this->layout.'.fgp.holiday.index',compact('cal_types'));
    }

    public function allHolidays(Request $request){
        $holidays = self::getRepo('Fgp\Holiday')->selectDataTable($request);
        return $holidays ;
    }

    public function addHoliday(Request $request){
        $date = '';
        if ($request->date) {
            $date =  date("d-m-Y",strtotime($request->date));
        }
    	return view($this->layout.'.fgp.holiday.models.addHoliday', compact('date'));
    }

    public function editHoliday(Holiday $holiday){
    	return view($this->layout.'.fgp.holiday.models.editHoliday',compact('holiday'));
    }

    public function detailHolidayView(Holiday $holiday){
        return view($this->layout.'.fgp.holiday.models.holidayDetail',compact('holiday'));
    }

    public function deleteHoliday(Holiday $holiday){
    	return view($this->layout.'.fgp.holiday.models.deleteHoliday',compact('holiday'));
    }

    public function getCalendarData(){
        $holidays = Holiday::orderByDesc('created_at')->where('is_deleted',0)->select('id','name as title','hol_date as starttime','description')->get();
        foreach ($holidays as $holiday) {
            $holiday->start = date('Y-m-d',strtotime($holiday->starttime));
            $holiday->className = 'fc-event--holiday';
        }
        return $holidays;
    }

    public function exportData(Request $request, $type)
    {
        if(isset($_COOKIE['holiday_advanced']) || isset($_COOKIE['holiday_quick'])){
            $advData=isset($_COOKIE['holiday_advanced'])?json_decode($_COOKIE['holiday_advanced']):[];
            $quickData=isset($_COOKIE['holiday_quick'])?json_decode($_COOKIE['holiday_quick']):[];
            $mergeData=array_merge($advData,$quickData);
        }else{
            $mergeData = [];
        }
        $data = self::getRepo('Fgp\Holiday')->exportData($request);
        $fields = array('Name', 'Date', 'Description', 'Type', 'State');
        $mapField = array('name', 'hol_date', 'description', 'cal_type', 'state_r');
        $data = cleaner($mapField, $data);
        $data['table'] = 'Report of Holiday';
        $data['request'] = '';
        if(empty($mergeData)){
            $data['request'] = ['Search' => 'All'];
        }else{
            $data['request'] = [];
            foreach($mergeData as $d):
                if($d->name=='name'){
                    $data['request']['Name'] = $d->value;
                }
                if($d->name=='type[]'){
                    $data['request']['Type'] = $d->value;
                }
                if($d->name=='site_phone'){
                    $data['request']['Cell Phone'] = $d->value;
                }
                if($d->name=='site_email'){
                    $data['request']['Email'] = $d->value;
                }
                if($d->name=='supervisior'){
                    $data['request']['Cupervisior'] = $d->value;
                }
            endforeach;
        }
        if (count($data) > 0) {
            $export = $this->reportFactory($type, $fields, $data);
            $exporter = new \App\Lib\Exporter\Exporter($export);
            $filename = $exporter->export();
            return response()->download($filename)->deleteFileAfterSend(true);
        }{
            return 'No Data Available For Current Filter';
        }
    }

    public function getCalType(Request $request) {
//    public function getCalType($term = null) {

//            $data =  Lookups::select('value', 'id')
//                ->where('code','holidayType')
//                ->when($term,function($qry, $term){
//                    $qry->where('value', 'like', $term .'%');
//                })
//                ->get();
//            return $data;
        return Lookups::select('value as text', 'value as val')
            ->where('code','holidayType')
            ->where('section','Holiday')
            ->when($request->term, function($query) use($request){
                $query->where('value', 'like', '%'. $request->term .'%');
            })
            ->get();

    }

    public function newHolidayType() {
       return view($this->layout.'.fgp.holiday.models.addHolType');
    }
            /**
     * @param $type
     * @param $data
     * @return CSVExporter|JSONExporter|PDFExporter|TxtExporter
     * @throws \Exception
     */
    public function reportFactory($type, $fields, $data)
    {
        switch ($type) {
            case 'csv':
                return new CSVExporter($data, $fields, 'HolidayReports');
                break;
            case 'json':
                return new JSONExporter($data);
                break;
            case 'txt':
                return new TxtExporter($data);
                break;
            case 'pdf':
                return new PDFExporter($data, $fields, 'print');
                break;
            default:
                throw new \Exception("Method Not Allowed " . $type);
                break;
        }
    }
}
