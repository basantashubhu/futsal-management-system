<?php
/**
 * @author Suman Thaapa -- Lead 
 * @author Prabhat gurung 
 * @author Basanta Tajpuriya 
 * @author Rakesh Shrestha 
 * @author Manish Buddhacharya 
 * @author Lekh Raj Rai 
 * @author Ascol Parajuli
 * @email NEPALNME@GMAIL.COM
 * @create date 2019-03-18 14:15:01
 * @modify date 2019-03-18 14:15:01
 * @desc [description]
 */


namespace App\Http\Controllers\Fgp\Templates;

use Illuminate\Http\Request;
use App\Http\Controllers\BaseController;
use App\Models\Fgp\Template;
use App\Models\Fgp\TemplateDetail;

class TemplateShowController extends BaseController
{
    private $clayout = "";
    public function __construct()
    {
        parent::__construct();
        $this->clayout = $this->layout . '.fgp.templates.';
    }
    public function template() {
        return $this->view($this->clayout.'modal.loadTemplate');
    }

    public function loadAllTemplate()
    {
        $templates = Template::where('is_deleted', false)->get();
        return view($this->clayout.'modal.loadAllTemplate', compact('templates'));
    }

    public function getTemplate(Template $temp)
    {
        $values = TemplateDetail::where('template_id', $temp->id)->first(); 
        $value = json_decode($values->value);
        return view($this->clayout.'modal.partialLoad', compact('temp', 'value', 'values'));
    }

    public function saveTemplate(Request $request)
    {
        $temp = new Template();
        $temp->section = 'pay period';
        $temp->table_name = 'users';
        $temp->table_name = auth()->id();
        $temp->save();

        $temp_details = new TemplateDetail();
        $temp_details->template_id = $temp->id;
        $temp_details->value = json_encode($request->all());
        $temp_details->save();
        return $temp->id;
    }   

    public function saveTemplateName($id)
    {
        return view($this->clayout.'modal.saveTemplateName', compact('id'));
    }

    public function storeTemplateName(Request $request, $id)
    {
        $temp = Template::find($id);
        $temp->template_name = $request->template_name;
        $c = strtolower($request->template_name);
        $temp->code = str_replace(" ", "_", $c);
        $temp->save();
        return $this->response("Templates Save Successfully", "view", 200);
    }

    public function cancelTemplateName(Request $request, $id)
    {
        $temp = Template::find($id);
        if(!is_null($temp)){
            $temp_details = TemplateDetail::where('template_id', $id)->first();
            $temp_details->delete();
            $temp->delete();
        }
        return "cancel";
    }
}
