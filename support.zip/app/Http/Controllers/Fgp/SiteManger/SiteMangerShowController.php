<?php

namespace App\Http\Controllers\Fgp\SiteManger;

use App\Models\Fgp\County;
use App\Models\Fgp\District;
use App\Models\Fgp\Region;
use App\Models\Fgp\Site;
use App\Models\Fgp\{State, City};
use App\Models\User;
use App\Repo\FGP\SiteRepo;
use Illuminate\Http\Request;
use App\Http\Controllers\BaseController;
use Faker\Generator as Faker;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class SiteMangerShowController extends BaseController
{
    private $c_layout = '';

    function __construct()
    {        
        parent::__construct();
        $this->c_layout = $this->layout . '.fgp.site_manager';
    }

    /**
     * site assign modal from user profile
     * @param $user_id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    function assignModal($user_id) {
        $user = User::with(['managerSites' => function($query) {
            $query->where('site_managers.is_deleted', 0);
        }])->where('id', $user_id)->first();
        $user_sites = $user->managerSites;

        $dataTable = '';

        if(request()->has('dataTable')){
            $dataTable = request()->dataTable;
        }

        // return $this->view($this->c_layout . '.user_assign_modal', compact('user', 'user_sites'));
        return $this->view($this->c_layout . '.assign_sites', compact('user', 'user_sites', 'dataTable'));
    }

   public function getSiteData(Request $request, User $user)
   {
        $user_sites = $user->sites()->map(function($x) {
            $x->assigned_site = true;
            return $x;
        });

        $sitess = $this->userSites($request, $user)
            ->merge($user_sites)
           ->map(function($site) {
                if($add = $site->address) {
                   $site->county = $add->county;
                   $site->region = $add->region;
                }
                return $site;
           });                
     
        return ['data' => $sitess];
   }

   public function userSites($request = false, $user){

       if ($request instanceof Request) {

            $cat = $request->input('query.site_cat', 'default');
            if ($cat === 'default') return $user->sites(function($query) use($request){
                $query->select(['id', 'site_name'])
                ->when($request->input('query.SearchSites', false), function($q, $searchString) {
                    $q->where('site_name', 'like', "%$searchString%");
                });
            }, ['table_id', 'county', 'region', 'district']);

            if ($cat === 'county') return Site::select('id', 'site_name')->with(['address' => function($ad) {
                    return $ad->select('table_id', 'county', 'region');
                }])->whereHas('address', function($add)  use($user){
                    $counties = $user->settings()->where('type', 'default_counties')->pluck('value')->all();
                    $add->whereIn('county', $counties);
                })
                ->when($request->input('query.SearchSites', false), function($q, $searchString) {
                    $q->where('site_name', 'like', "%$searchString%");
                })->get();

            if ($cat === 'all') return Site::select('id', 'site_name')
                ->with(['address' => function($ad) {
                    return $ad->select('table_id', 'county', 'region');
                }])
                ->when($request->input('query.SearchSites', false), function($q, $searchString) {
                    $q->where('site_name', 'like', "%$searchString%");
                })->get();
        }
       $is_admin = in_array(Auth::id(), [1,2,7]);
       return !$is_admin ? Auth::user()->sites() : Site::with('address')->get();

   }

    public function getAssignedSites(){

        return \Auth::user()->role_id != 1 ? \Auth::user()->managerSites()->with('address')->get() : Site::with('address')->get();

    }

    /**
     *  site assign form (fly)
     * @param Request $request
     * @param null    $user
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    function assign(Request $request, $user = null) {
        return $this->view($this->c_layout . '.assign_modal', array(
            'user_id' => $user,
            'selected_sites' => $request->input('selected_sites', '[]')
        ));
    }

    function hierarchy(Request $request) {
        /*
         * Region will filter for Delaware Valley
         * */
        $regions = Region::select('id', 'region_name')
            ->with([
                'county' => function($cn) {
                    $cn->whereHas('district', function($dis) {
                        $dis->has('sites');
                    })->orWhereHas('city', function($ct) {
                        $ct->has('sites');
                    });
                },
                'county.district' => function($ds) {
                    $ds->has('sites');
                },
                'county.district.city' => function($ct) {
                    $ct->has('sites');
                },
                'county.city' => function($ct) {
                    $ct->has('sites');
                }])
            ->has('county')
            ->get();


        $user_sites = json_decode($request->input('user_sites', '[]'));

        return $this->view($this->c_layout . '.hierarchy', compact('regions', 'user_sites'));
    }

    /**
     * basically gets all site_name and id of given county from site_details join(sites)
     * @param Request $request
     * @return \Illuminate\Support\Collection
     */
    function getSites(Request $request) {
        $site_ids = $request->input('selected_sites', []);
        return Site::select('site_name', 'id as site_id')
            ->whereIn('id', $site_ids) // column can vary after db changes (location hierarchy)
            ->get();
    }

    /**
     * user sites
     * @param Request $request
     * @param User    $user
     * @return \Illuminate\Support\Collection
     */
    function getUserSites(Request $request, User $user) {

        return DB::table('site_managers as sm')->select([
            'sites.site_name', 'sites.site_type as site_type', 'sites.id as site_id', //sites
            'ad.add1', 'ad.add2', 'ad.region', 'ad.county', 'ad.district', 'ad.city' // site address
        ])->join('sites', 'sites.id', 'sm.site_id') //sites table join
            ->join('address as ad', function($join) {
                $join->on('ad.table_id', 'sites.id'); // address table join with sites
                $join->on('ad.table_name', DB::raw('"sites"'));
            })->where('sm.user_id', $user->id) // user filter
            ->where('sm.is_deleted', 0) // filter deleted rows
            ->get();
    }

    function factory() {
        /*
         * factory method of region, district, city and county
         * uses Faker $faker
         * */
        $faker = app()->make(Faker::class);
        $state_ids = range(1, 6);
        $states = array_map(function($id) use($faker){
            return ['state_name' => $faker->state, 'state_code' => $faker->stateAbbr];
        }, $state_ids);
        State::insert($states);
         $region_ids = range(1, 4);
         $regions = array_map(function($r) use($faker, $state_ids){
             return ['id' => $r, 'state_id' => $state_ids[random_int(0, count($state_ids) - 1)], 'region_code' => strtolower(random_string(3)), 'region_name' => $faker->cityPrefix];
         }, $region_ids);
        Region::insert($regions);


         $county_ids = range(1, 4);
         $counties = array_map(function($c) use($faker, $region_ids){
             return ['id' => $c, 'region_id' => $region_ids[random_int(0, count($region_ids) - 1)], 'county_name' => $faker->streetSuffix];
         }, $county_ids);
         County::insert($counties);


         $district_ids = range(1, 12);
         $districts = array_map(function($d) use($faker, $county_ids) {
             return ['id' => $d, 'county_id' =>  $county_ids[random_int(0, count($county_ids) - 1)], 'district_name' => $faker->streetName];
         }, $district_ids);
         District::insert($districts);

        $city_ids = range(1, 100);
        $cities = array_map(function($id) use($district_ids, $faker){
            return ['id' => $id, 'district_id' => $district_ids[random_int(0, count($district_ids) - 1)], 'city_name' => $faker->city];
        }, $city_ids);
        City::insert($cities);

    }
}
