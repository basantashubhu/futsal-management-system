<?php
/**
 * DEVELOPERS
 * ----------------------------------------------
 * SUMAN  THAPA - LEAD  (NEPALNME@GMAIL.COM)
 * ----------------------------------------------
 * - PRABHAT GURUNG
 * - BASANTA TAJPURIYA
 * - RAKESH SHRESTHA
 * - MANISH BUDDHACHARYA
 * - LEKH RAJ RAI
 * - ASCOL PARAJULI
 * -----------------------------------------------
 * Created On: 4/2/2019
 *
 * THIS INTELLECTUAL PROPERTY IS COPYRIGHT Ⓒ 2019
 *  SHUBHU TECH PVT LTD , NEPAL. ALL RIGHT RESERVED
 */

namespace App\Http\Controllers\Fgp\SiteManger;


use App\Models\Fgp\Site;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SiteManagerAddUpdateController
{
    /**
     * un-assign site from user
     * @param $user_id
     * @param $site_id
     * @return string
     */
    function unassign($user_id, $site_id) {
        DB::table('site_managers')->where([
            'user_id' => $user_id, 'site_id' => $site_id
        ])->update([
            'is_deleted' => 1, 'deleted_at' => now(), 'is_active' => 0, 'userd_id' => auth()->id()
        ]);
        return 'Site is un-assigned successfully.';
    }

    /**
     * assign sites from user profile submit function
     * @param Request $request
     * @param User    $user
     */
    function assignSites(Request $request, User $user) {
        $user_sites = [];
        $sites = Site::whereIn('id', $request->input('sites', []))->get();
        foreach ($sites as $site):
            $user_sites[$site->id] = [
                'user_id' => $user->id, 'created_at' => now()
            ];
        endforeach;
        $user->managerSites()->sync($user_sites);
    }
}