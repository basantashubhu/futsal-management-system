<?php

namespace App\Http\Controllers\Fgp\Timesheet;

use App\Models\Fgp\ApprovalTable;
use App\Models\Fgp\Timesheet;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use \Exception;

class TimesheetUpdateController extends Controller
{
    public function delete(Request $request)
    {
        try {
            DB::beginTransaction();
            $map = ['period_id' => $request->period_id, 'site_id' => $request->site_id,];
            $approval = ApprovalTable::where($map)->where('vol_id', $request->vol_id)->count();
            if ($approval) {
                throw new Exception('Timesheets are already processing for approval.');
            }

            $ts = Timesheet::where($map)->where('volunteer_id', $request->vol_id)->get()
                ->each(function($x) {
                    $x->timesheetItems()->delete();
                    $x->delete();
                });

            DB::commit();
            return response(['success' => ['message' => $ts->count() . " timesheets removed."]]);
        } catch (Exception $e) {
            DB::rollBack();
            return response(['errors' => ['message' => $e->getMessage()]], 422);
        }
    }
}
