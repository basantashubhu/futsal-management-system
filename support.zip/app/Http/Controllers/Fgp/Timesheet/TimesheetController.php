<?php

namespace App\Http\Controllers\Fgp\Timesheet;

use App\Models\Fgp\PayPeriod;
use App\Models\Fgp\Timesheet;
use App\Models\Fgp\Volunteer;
use App\Models\Fgp\VolunteerSites;
use App\Models\Fgp\Site;
use App\Models\Fgp\ApprovalFlow;
use App\Models\Fgp\ApprovalTable;
use App\Models\User;
use App\Models\Note;
use App\Models\EmailSettingsModel;
use App\Repo\TimeSheetRepo;
use Illuminate\Http\Request;
use App\Http\Controllers\BaseController;
use Illuminate\Support\Facades\DB;
use App\Lib\Exporter\CSVExporter;
use App\Lib\Exporter\JSONExporter;
use App\Lib\Exporter\PDFExporter;
use App\Lib\Exporter\TxtExporter;
use App\Models\Settings\ZipCode;
use App\Mail\Fgp\ApprovalMail;
use App\Lib\Notification\Notification;
use App\Models\Notification as Notify;
use App\Lib\FileZipper\Config;
use App\Lib\SwiftMailer\SwiftMailer;
use App\Models\EmailLog;
use App\Models\Fgp\StipendCalc;
use App\Models\Fgp\StipendCalcItems;
use App\Models\Fgp\StipendCalcTypes;
use App\Models\Fgp\StipendCalcSites;
use App\Models\Fgp\StipendCalcVols;
use Illuminate\Support\Facades\Cookie;

class TimesheetController extends BaseController
{
    private $clayout;

    public function __construct()
    {
        parent::__construct();
        $this->clayout = $this->layout . '.fgp.timesheet';
    }

    // table data
    public function getTableData(Request $request) 
    {
        return (new TimeSheetRepo('Fgp\Timesheet'))
            ->selectDataTable1($request);
    }

    //get report data
    public function getReportData(Request $request, $type)
    {
        $data = (new TimeSheetRepo('Fgp\Timesheet'))->getReportData($request);
        if(isset($_COOKIE['time_sheet_advanced']) || isset($_COOKIE['time_sheet'])){
            $advData=isset($_COOKIE['time_sheet_advanced'])?json_decode($_COOKIE['time_sheet_advanced']):[];
            $quickData=isset($_COOKIE['time_sheet'])?json_decode($_COOKIE['time_sheet']):[];
            $mergeData=array_merge($advData,$quickData);
        }else{
            $mergeData = [];
        }
        $fields = array('Period', 'Start Date', 'End Date', 'Vol ID', 'Volunteer Name', 'Supervisor', 'County');
        $mapField = array('stipend_period_no', 'st_period_start_date', 'st_period_end_date', 'vol_alt_id', 'vol_name', 'vol_sup_name', 'site_county');
        $data = cleaner($mapField, $data);
        $data['table'] = 'Report of Time Sheets';
        $data['request'] = '';
        if(empty($mergeData)){
            $data['request'] = ['Search' => 'All'];
        }else{
            $data['request'] = [];
            foreach($mergeData as $d):
                if($d->name=='vol_name'){
                    $data['request']['Volunteer Name'] = $d->value;
                }
                if($d->name=='alt_id'){
                    $data['request']['Volunteer ID'] = $d->value;
                }
                if($d->name=='supervisor'){
                    $data['request']['Supervisor'] = $d->value;
                }
            endforeach;
            if (count($data) > 0) {
                $export = $this->reportFactory($type, $fields, $data);
                $exporter = new \App\Lib\Exporter\Exporter($export);
                $filename = $exporter->export();
                return response()->download($filename)->deleteFileAfterSend(true);
            }{
                return 'No Data Available For Current Filter';
            }
        }
    }
    /**
     * @param $type
     * @param $data
     * @return CSVExporter|JSONExporter|PDFExporter|TxtExporter
     * @throws \Exception
     */
    public function reportFactory($type, $fields, $data)
    {
        switch ($type) {
            case 'csv':
                return new CSVExporter($data, $fields, 'TimeSheetReports');
                break;
            case 'json':
                return new JSONExporter($data);
                break;
            case 'txt':
                return new TxtExporter($data);
                break;
            case 'pdf':
                return new PDFExporter($data, $fields, 'print');
                break;
            default:
                throw new \Exception("Method Not Allowed " . $type);
                break;
        }
    }

    // new time-sheet add form page
    public function addTimeSheet(Request $request) {
        $validations = validation_value('timeSheetAddForm');
        $period = $request->id ? PayPeriod::find($request->id) : null;
        $volunteers = Volunteer::select('id', DB::raw('CONCAT(first_name, " ", last_name) as name'))
                            ->where('vol_supervisor_id', $request->user()->id)->get();
        return $this->view($this->clayout . '.includes.addTimesheet', compact('validations','period', 'volunteers'));
    }

    // Load time-sheet Tempate Modal
    public function loadTemplate() {
        // $validations = validation_value('timeSheetAddForm');
        return $this->view($this->clayout . '.modals.load_template');
    }

    //time sheet 1
    public function timeSheet(Request $request)
    {
        $data = $this->getTableData($request);
        // dd($data);
        $supervisor_id = Volunteer::where('is_deleted', false)->distinct()->pluck('vol_supervisor_id');
        $supervisors = [];
        if(count($supervisor_id)>0){
            foreach($supervisor_id as $id){
                array_push($supervisors, User::find($id));
            }
        }
        $countys = [];
        $county = ZipCode::where('is_deleted',false)->get();
        foreach($county as $co){
            if(!in_array($co->county, $countys)){
                array_push($countys, $co->county);
            }
        }
        $states = ZipCode::where('is_deleted',false)->groupBy('state')->get();
        $city = ZipCode::where('is_deleted',false)->groupBy('city')->get();
        return $this->view($this->clayout.'.index1', compact('data', 'supervisors', 'countys', 'states', 'city'));
    }

    public function timesheetSearch(Request $request)
    {
        $data = (new TimeSheetRepo('Fgp\Timesheet'))->selectDataTable2($request);
        // dd($data);
        return $this->view($this->clayout.'.includes1.partial', compact('data'));
    }

    public function timesheetApprove($id)
    {
        $stipend = PayPeriod::find($id);
        $timesheets = Timesheet::where('period_id', $id)->get();
        $site_ids = [];
        $volunteer_ids = [];
        foreach($timesheets as $t){
            array_push($site_ids, $t->site_id);
            array_push($volunteer_ids, $t->volunteer_id);
        }
        $site_ids = array_unique($site_ids);
        $sitesAll = [];
        foreach($site_ids as $si){
            array_push($sitesAll, Site::find($si));
        }
        $volunteer_ids = array_unique($volunteer_ids);
        $volunteersAll = [];
        foreach($volunteer_ids as $vi){
            array_push($volunteersAll, Volunteer::find($vi));
        }
        $period= Timesheet::where('period_id', $id)->first();
        if($period->approval_flow_id != '' || $period->approval_flow_id != null){
            $approvalFlow = ApprovalFlow::where('seq_num', '<=', $period->approval_flow_id)->orderBy('seq_num', 'asc')->get();
            $approval = ApprovalTable::where('period_id', $stipend->id)->get();
        }else{
            $approvalFlow = false;
            $approval = false;
        }
        return $this->view($this->clayout.'.modals.timesheetApprove', compact('stipend', 'approval', 'approvalFlow', 'period', 'timesheets', 'sitesAll', 'volunteersAll'));
    }

    public function confirmation($id)
    {
        $stipend = PayPeriod::find($id);
        $timesheets = Timesheet::where('period_id', $id)->get();
        $users = [];
        if(auth()->user()->role->name == "supervisor"){
            //supervisor
            array_push($users,auth()->user());
            //manager
             foreach(auth()->user()->reportingMgr as $usersUp):
                $users = array_merge($users, $usersUp);
                //director
                 foreach($usersUp->reportingMgr as $usersUp1):
                    array_push($users, $usersUp1);
                     //fiscal
                     foreach($usersUp1->reportingMgr as $usersUp2):
                         array_push($users, $usersUp2);
                     endforeach;
                 endforeach;
            endforeach;
        }elseif(auth()->user()->role->name == "manager"){
            //manager
            array_push($users,auth()->user());
            //director
            foreach(auth()->user()->reportingMgr as $usersUp):
                array_push($users, $usersUp);
                //fiscal
                foreach($usersUp->reportingMgr as $usersUp1):
                    array_push($users, $usersUp1);
                endforeach;
            endforeach;

            //supervisor
            $usersDown = auth()->user()->reportingMgrOf;
            foreach($usersDown as $down){
                array_push($users, $down);
            }
            
        }elseif(auth()->user()->role->name == "director"){
            //director
            array_push($users, auth()->user());
            //fiscal
            foreach(auth()->user()->reportingMgr as $usersUp1):
                array_push($users, $usersUp1);
            endforeach;
            
            //manager
            $usersDown = auth()->user()->reportingMgrOf;
            foreach($usersDown as $down){
                array_push($users, $down);
                //supervisor
                foreach($down->reportingMgrOf as $d){
                    array_push($users, $d);
                }
            }
            
        }elseif(auth()->user()->role->name == "fiscal"){
            //fiscal;
            array_push($users, auth()->user());
            
            $usersDown = auth()->user()->reportingMgrOf;
            foreach($usersDown as $down){
                //direactor
                array_push($users, $down);
                //manager
                foreach($down->reportingMgrOf as $d){
                    array_push($users, $d);
                    //sup
                    foreach($d->reportingMgrOf as $c){
                        array_push($users, $c);
                    }
                }
            }
        }
        return $this->view($this->clayout.'.modals.approvalConfirmation', compact('stipend', 'timesheets', 'users'));
    }

    public function timesheetApprovalCondition(Request $request, $period)
    {
        DB::beginTransaction();
        try{
            $approval = ApprovalFlow::orderBy('seq_num', 'asc')->get();
            // dd($approval);
            foreach($approval as $flow){
                foreach($request->ids as $id){
                    $user = User::find($id);
                    if($flow->role==$user->role->name){
                        $a = $this->approvePeriodForAll1($request, $user, $period, true);
                    }
                }
            }
            DB::commit();
            return $this->response("Timesheet Approved Successfully", "view", 200);
        }catch(\Exception $e){
            DB::rollback();
            dd($e);
            return $this->response("TimeSheet cannot be approved", "error", 422);
        }
    }

    public function approvePeriodForAll1(Request $request, $user, $period, $return = false)
    {
        DB::beginTransaction();
        try{
            $b = $request->ip();
            $data = getBrowser();
            $timesheets = Timesheet::select('*', DB::raw('time_to_sec(total_hrs) as timestamp'))
            ->where('period_id', $period)->get();
            $firstP = Timesheet::where('period_id', $period)->first();
            $old_record = $firstP->__toString();
            
            $flow = ApprovalFlow::where('role', $user->role->name)->first();
            $seq = $flow->seq_num;
            
            // $ac = ApprovalFlow::where('seq_num', $seq)->first();
            $al = ApprovalTable::where('period_id', $firstP->period_id)->where('apprv_id', $user->id)->first();
            if(is_null($al)){
                $approval = new ApprovalTable();
                $approval->timesheet_id = $firstP->timesheets_unq_id;
                $approval->period_id = $firstP->period_id;
                $approval->approval_flow_id = $seq;
                $approval->apprv_date = date('Y-m-d');
                $approval->apprv_id = $user->id;
                $approval->user_approved_id = $user->id;
                if($user->role->id != 1){
                    if($user->role->name=="fiscal"){
                        $approval->next_approval = "Ready for HSV";
                    }else{
                        $approval->next_approval = ucfirst($user->reportingMgr->first()->role->name);
                    }
                }else{
                    $approval->next_approval = ucfirst($user->role->name);
                }
                foreach($data as $k=>$v){
                    $approval->$k = $v;
                }
                $approval->ip_address= $request->ip();
                $approval->appr_stat = "Success";
                $approval->save();
            }else{
                $approval =false;
            }
            foreach($timesheets as $time){
                if($user->role->id != 1){
                    $time->approval_status = ucfirst($user->role->name);
                    if($user->role->name!="fiscal"){
                        $time->next_approval = ucfirst($user->reportingMgr->first()->role->name);
                    }else{
                        $time->next_approval = "Ready For HSV";
                    }
                }else{
                    $time->approval_status = $firstP->next_approval;
                    $time->next_approval = ucfirst($user->role->name);
                }
                $time->approval_flow_id = $seq;
                
                $time->status = "In Process";
                
                $time->save();
            } 
            $new_record = Timesheet::where('period_id', $period)->first()->__toString();
            $stipend = PayPeriod::find($period);
            if($user->role->id != 1){
                if($user->role->name!="fiscal"){
                    $this->sendMail($stipend);
                    foreach ($user->reportingMgr as $mgr)
                    $this->makeLog($stipend, $mgr->email, 'Success');
                    Notification::timesheetApprovalNotifications($approval, $stipend);
                }else{
                    $this->makeLog($stipend, $user->email, 'Success');
                }
                // Notification::timesheetApprovalNote($stipend);
            }
            $this->timesheetApprovalNote($stipend);

            (new TimeSheetRepo('Fgp\Timesheet'))->audit($firstP->timesheets_unq_id, $old_record, $new_record, auth()->check() ? auth()->id() : 0);

            if($user->role->id == 7 && $firstP->next_approval=="Fiscal"){
                $this->prepareForStipencalc($firstP, $timesheets, $stipend);
            }
            // \Mail::to(auth()->user()->reportingMgr->email)->send(new ApprovalMail(auth()->user()->reportingMgr->email, $stipend));
            DB::commit();
            if($return){
                return true;
            }
            return $this->response("TimeSheet Approved Successfully", "view", 200);
        }catch(\Exception $e){
            DB::rollback();
            dd($e);
            return $this->response("TimeSheet cannot be approved", "error", 422);
        }
    }

    public function approvePeriodForAll(Request $request, $period, $return = false)
    {
        DB::beginTransaction();
        try{
            // dd($request->all());
            $allApproval = ApprovalFlow::orderBy('seq_num','asc')->get();
            // dd($allApproval);
            foreach($allApproval as $single){
                // dd($single);
                $b = $request->ip();
                $data = getBrowser();
                $timesheets = Timesheet::select('*', DB::raw('time_to_sec(total_hrs) as timestamp'))
                ->where('period_id', $period)->get();
                $firstP = Timesheet::where('period_id', $period)->first();
                $old_record = $firstP->__toString();
                
                if($firstP->approval_flow_id != '' || $firstP->approval_flow_id != null){
                    $flow = ApprovalFlow::where('role', auth()->user()->role->name)->first();
                    $seq = $firstP->approval_flow_id + 1;

                }else{
                    $flow = ApprovalFlow::where('is_deleted', false)->orderby('seq_num', 'desc')->first();
                    $seq = $flow->seq_num;

                    $approval = new ApprovalTable();
                    $approval->timesheet_id = $firstP->timesheets_unq_id;
                    $approval->period_id = $firstP->period_id;
                    $approval->approval_flow_id = $seq;;
                    $approval->apprv_date = date('Y-m-d');
                    $approval->apprv_id = auth()->id();
                    $approval->user_approved_id = auth()->id();
                    $approval->next_approval = "Ready for HSV";
                    foreach($data as $k=>$v){
                        $approval->$k = $v;
                    }
                    $approval->ip_address= $request->ip();
                    $approval->appr_stat = "Success";
                    $approval->save();

                    foreach($timesheets as $time){
                        $time->approval_status = 'fiscal';
                        $time->next_approval = "Ready For HSV";
                        $time->approval_flow_id = $seq;
                        $time->status = "Closed";
                        $time->save();
                    } 
                    $new_record = Timesheet::where('period_id', $period)->first()->__toString();
                    $stipend = PayPeriod::find($period);
                    
                    (new TimeSheetRepo('Fgp\Timesheet'))->audit($firstP->timesheets_unq_id, $old_record, $new_record, auth()->check() ? auth()->id() : 0);
                    
                }
                
            }
            $approval = ApprovalTable::where('period_id', $period)->orderBy('created_at', 'desc')->first();
            $this->sendMailToAll($stipend, $approval);
            $this->prepareForStipencalc($firstP, $timesheets, $stipend);
            // \Mail::to(auth()->user()->reportingMgr->email)->send(new ApprovalMail(auth()->user()->reportingMgr->email, $stipend));
            DB::commit();
            return $this->response("TimeSheet Approved Successfully", "view", 200);
        }catch(\Exception $e){
            DB::rollback();
            dd($e);
            return $this->response("TimeSheet cannot be approved", "error", 422);
        }
    }

    public function timesheetApprovalPeriod(Request $request, $period, $return = false)
    {
        DB::beginTransaction();
        try{
            // dd($request->all());
            $b = $request->ip();
            $data = getBrowser();
            $timesheets = Timesheet::select('*', DB::raw('time_to_sec(total_hrs) as timestamp'))
            ->where('period_id', $period)->get();
            $firstP = Timesheet::where('period_id', $period)->first();
            $old_record = $firstP->__toString();
            if($firstP->approval_flow_id != '' || $firstP->approval_flow_id != null){
                $flow = ApprovalFlow::where('seq_num', $firstP->approval_flow_id)->first();
                $seq = $firstP->approval_flow_id + 1;
            }else{
                $flow = ApprovalFlow::where('is_deleted', false)->orderby('seq_num', 'asc')->first();
                $seq = $flow->seq_num;
            }
            $ac = ApprovalFlow::where('seq_num', $seq+1)->first();
            $al = ApprovalTable::where('period_id', $firstP->period_id)->where('apprv_id', auth()->id())->first();
            if(is_null($al)){
                $approval = new ApprovalTable();
                $approval->timesheet_id = $firstP->timesheets_unq_id;
                $approval->period_id = $firstP->period_id;
                $approval->approval_flow_id = $seq;;
                $approval->apprv_date = date('Y-m-d');
                $approval->apprv_id = auth()->id();
                $approval->user_approved_id = auth()->id();
                if(auth()->user()->role->id != 1){
                    if(auth()->user()->role->name=="fiscal"){
                        $approval->next_approval = "Ready for HSV";
                    }else{
                        $approval->next_approval = ucfirst(auth()->user()->reportingMgr->first()->role->name);
                    }
                }else{
                    $approval->next_approval = ucfirst($ac->role);
                }
                foreach($data as $k=>$v){
                    $approval->$k = $v;
                }
                $approval->ip_address= $request->ip();
                $approval->appr_stat = "Success";
                $approval->save();
            }else{
                $approval =false;
            }
            foreach($timesheets as $time){
                if(auth()->user()->role->id != 1){
                    $time->approval_status = ucfirst(auth()->user()->role->name);
                    if(auth()->user()->role->name!="fiscal"){
                        $time->next_approval = ucfirst(auth()->user()->reportingMgr->first()->role->name);
                    }else{
                        $time->next_approval = "Ready For HSV";
                    }
                }else{
                    $time->approval_status = $firstP->next_approval;
                    $time->next_approval = ucfirst($ac->role);
                }
                $time->approval_flow_id = $seq;
                
                $time->status = "In Process";
                
                $time->save();
            } 
            $new_record = Timesheet::where('period_id', $period)->first()->__toString();
            $stipend = PayPeriod::find($period);
            if(auth()->user()->role->id != 1){
                if(auth()->user()->role->name!="fiscal"){
                    $this->sendMail($stipend);
                    foreach (auth()->user()->reportingMgr as $mgr)
                        $this->makeLog($stipend, $mgr->email, 'Success');
                    Notification::timesheetApprovalNotifications($approval, $stipend);
                }else{
                    $this->makeLog($stipend, auth()->user()->email, 'Success');
                }
                // Notification::timesheetApprovalNote($stipend);
            }
            $this->timesheetApprovalNote($stipend);

            (new TimeSheetRepo('Fgp\Timesheet'))->audit($firstP->timesheets_unq_id, $old_record, $new_record, auth()->check() ? auth()->id() : 0);

            if(auth()->user()->role->id == 7 && $firstP->next_approval=="Fiscal"){
                $this->prepareForStipencalc($firstP, $timesheets, $stipend);
            }
            // \Mail::to(auth()->user()->reportingMgr->email)->send(new ApprovalMail(auth()->user()->reportingMgr->email, $stipend));
            DB::commit();
            return $this->response("TimeSheet Approved Successfully", "view", 200);
        }catch(\Exception $e){
            DB::rollback();
            dd($e);
            return $this->response("TimeSheet cannot be approved", "error", 422);
        }
    }
    //volunteer wise approve
    public function timesheetApprovalBackuView(Request $request)
    {
        $data = explode(',', $request->data);
        $timesheets=[];
        $roles = [];
        foreach($data as $id){
            $timesheet = Timesheet::find($id);
            array_push($timesheets, $timesheet);
            array_push($roles, ucfirst($timesheet->next_approval));
        }
        foreach($timesheets as $t){
            $t->volunteer = Volunteer::find($t->volunteer_id);
            $t->site = Site::find($t->site_id);
            $t->period = PayPeriod::find($t->period_id);
            if($t->approval_flow_id != '' || $t->approval_flow_id != null){
                $t->approvalFlow = ApprovalFlow::where('seq_num', '<=', $t->approval_flow_id)->orderBy('seq_num', 'asc')->get();
                $t->approval = ApprovalTable::where('vol_id', $t->volunteer->id)->where('site_id', $t->site->id)->where('period_id', $t->period->id)->get();
                $a = ApprovalTable::where('vol_id', $t->volunteer->id)->where('site_id', $t->site->id)->where('period_id', $t->period->id)->orderBy('created_at', 'desc')->first();
                if(is_null($a)){
                    $t->current_user = false;
                    $t->next_user = false;
                }else{
                    $t->current_user = User::find($a->user_approved_id);
                    if(auth()->user()->role->name=="fiscal"){
                        $t->next_user = false;
                    }else{
                        $t->next_user = $t->current_user->reportingMgr()->first();
                    }
                }
            }else{
                $t->approvalFlow = false;
                $t->approval = false;
                $t->current_user = false;
                $t->next_user = false;
            }
        }
        return $this->view($this->clayout.'.modals.timesheetApprove1', compact('timesheets','roles'));
    }


    
    public function timesheetApproval(Request $request, $period)
    {
        DB::beginTransaction();
        try{
            // dd($request->all());
            $b = $request->ip();
            $data = getBrowser();
            $timesheets = Timesheet::where('period_id', $period)->whereIn('site_id', $request->site_id)->whereIn('volunteer_id', $request->volunteer_id)->get();
            // dd($timesheets);
            foreach($timesheets as $time){
                $al = ApprovalTable::where('period_id', $time->period_id)->where('site_id', $time->site_id)->where('vol_id', $time->volunteer_id)->where('apprv_id', auth()->id())->first();
                if(is_null($al)){
                    $approval = new ApprovalTable();
                    $approval->period_id = $time->period_id;
                    $approval->site_id = $time->site_id;
                    $approval->vol_id = $time->volunteer_id;
                    $approval->apprv_date = date('Y-m-d');
                    $approval->apprv_id = auth()->id();
                    $approval->user_approved_id = auth()->id();
                    if(auth()->id() != 1){
                        if(auth()->user()->role->name!="fiscal"){
                            $approval->next_approval = ucfirst(auth()->user()->reportingMgr->first()->role->name);
                        }else{
                            $approval->next_approval ="Ready For HSV";
                        }
                    }else{
                        $approval->next_approval = 'superAdmin';
                    }
                    foreach($data as $k=>$v){
                        $approval->$k = $v;
                    }
                    $approval->ip_address= $request->ip();
                    $approval->save();
                }
            }
            DB::commit();
            return $this->response("TimeSheet Approved Successfully", "view", 200);
        }catch(\Exception $e){
            DB::rollback();
            dd($e);
            return $this->response("TimeSheet cannot be approved", "error", 422);
        }
    }

    public function timesheetDecline(Request $request, $period)
    {
        DB::beginTransaction();
        try{
            // dd($request->all());
            $b = $request->ip();
            $data = getBrowser();
            $timesheets = Timesheet::where('period_id', $period)->get();
            $firstP = Timesheet::where('period_id', $period)->first();
            $old_record = $firstP->__toString();
            if($firstP->approval_flow_id != '' || $firstP->approval_flow_id != null){
                $flow = ApprovalFlow::where('seq_num', $firstP->approval_flow_id)->first();
                if($firstP->approval_flow_id == 4){
                    $seq = $firstP->approval_flow_id - 1;
                }else{
                    $seq = $firstP->approval_flow_id + 1;
                }
            }else{
                $flow = ApprovalFlow::where('is_deleted', false)->orderby('seq_num', 'asc')->first();
                $seq = $flow->seq_num;
            }
            $ac = ApprovalFlow::where('seq_num', $seq)->first();
            $reportTo = ApprovalTable::where('period_id', $period)->orderBy('created_at', 'desc')->first();
            $al = ApprovalTable::where('period_id', $firstP->period_id)->where('apprv_id', auth()->id())->first();
            if(is_null($al)){
                $approval = new ApprovalTable();
                $approval->timesheet_id = $firstP->timesheets_unq_id;
                $approval->period_id = $firstP->period_id;
                $approval->approval_flow_id = $seq;;
                $approval->apprv_date = date('Y-m-d');
                $approval->apprv_id = auth()->id();
                $approval->user_approved_id = auth()->id();
                $approval->next_approval = ucfirst($firstP->approval_status);
                
                foreach($data as $k=>$v){
                    $approval->$k = $v;
                }
                $approval->appr_stat = "Decline";
                $approval->ip_address= $request->ip();
                $approval->save();
            }else{
                $approval =false;
            }
            foreach($timesheets as $time){
                $time->next_approval = $time->approval_status;
                $time->approval_status = ucfirst($ac->role);
                $time->approval_flow_id = $seq;
                
                $time->status = "Decline";
                $time->save();
            } 
            // dd($timesheets);
            $new_record = Timesheet::where('period_id', $period)->first()->__toString();
            $stipend = PayPeriod::find($period);
            
            $userTo = User::find($reportTo->user_approved_id);
            if(auth()->user()->role->id != 1){
                $this->sendMail($stipend, $userTo);
                $this->makeLog($stipend, $userTo->id,"Decline");
                Notification::timesheetDeclineNotifications($approval, $stipend, $userTo);
            }

            (new TimeSheetRepo('Fgp\Timesheet'))->audit($firstP->timesheets_unq_id, $old_record, $new_record, auth()->check() ? auth()->id() : 0);

            if(auth()->user()->role->id == 7 && $firstP->next_approval=="Fiscal"){
                $this->prepareForStipencalc($firstP, $timesheets, $stipend);
            }
            // \Mail::to(auth()->user()->reportingMgr->email)->send(new ApprovalMail(auth()->user()->reportingMgr->email, $stipend));
            DB::commit();
            return $this->response("TimeSheet is Declined", "error", 200);
        }catch(\Exception $e){
            DB::rollback();
            dd($e);
            return $this->response("TimeSheet cannot be declined", "error", 422);
        }
    }

    public function getVolSite($period, $site)
    {
        $timesheets = Timesheet::where('period_id', $period)->where('site_id', $site)->get();
        if(is_null($timesheets)){
            return 'no';
        }else{
            $volunteer_ids = [];
            foreach($timesheets as $t){
                array_push($volunteer_ids, $t->volunteer_id);
            }
            $volunteer_ids = array_unique($volunteer_ids);
            $volunteersAll = [];
            foreach($volunteer_ids as $vi){
                array_push($volunteersAll, Volunteer::find($vi));
            }
            return $volunteersAll;
        }
    }

    public function getNotificationDetails($approval, $timesheet, $stipend_id)
    {
        // $process = ApprovalFlow::find($approval);
        $approvalTimesheet = ApprovalTable::where('timesheet_id', $timesheet)->where('period_id', $stipend_id)->where('approval_flow_id', $approval)->first();
        $first = Notify::where("table_name", $approvalTimesheet->getTable())->where('table_id', $approvalTimesheet->id)->first();
        $createdByMe = Notify::where('user_id', auth()->id())->get();
        $createdForMe = Notify::where('to', auth()->id())->get();
        $datas = [];
        foreach($createdForMe as $ForMe){
            $ForMe->toUser = User::find($ForMe->to); 
            $ForMe->fromUser = User::find($ForMe->user_id); 
            $a = ApprovalTable::find($ForMe->table_id);
            $ForMe->status = $a->appr_stat;
            if($a->period_id == $stipend_id && $a->timesheet_id == $timesheet){
                array_push($datas, $ForMe);
            }
        }
        foreach($createdByMe as $ByMe){
            $ByMe->toUser = User::find($ByMe->to); 
            $ByMe->fromUser = User::find($ByMe->user_id); 
            $a = ApprovalTable::find($ByMe->table_id);
            $ByMe->status = $a->appr_stat;
            if($a->period_id == $stipend_id && $a->timesheet_id == $timesheet){
                array_push($datas, $ByMe);
            }
        }
        $now = ApprovalFlow::where('role', auth()->user()->role->name)->first();
        $prev = ApprovalFlow::where('seq_num', $now->seq_num-1)->first();
        $next = ApprovalFlow::where('seq_num', $now->seq_num+1)->first();

        $approvalTimesheet1 = ApprovalTable::where('timesheet_id', $timesheet)->where('period_id', $stipend_id)->where('approval_flow_id', $approval+1)->first();

        return view('default.fgp.timesheet.modals.notificationDetails', compact('first', 'prev', 'next', 'datas', 'approvalTimesheet','approvalTimesheet1','createdByMe'));
    }

    public function postNotification(Request $request, $id)
    {
        DB::beginTransaction();
        try{
            // dd($request->all());
            $approvalTimesheet = ApprovalTable::find($id);
            $p = new Notify();
            $p->message = $request->message;
            $p->type = "Notification";
            $p->table_name = $approvalTimesheet->getTable();
            $p->table_id = $approvalTimesheet->id;
            $p->user_id = $request->user_id;
            $p->to = $request->reply_id;
            $p->url = 'time-sheets';
            $p->save();
            DB::commit();
            return $this->response("Message Sent Successfully", "view", 200);
        }catch(\Exception $e){
            DB::rollback();
//            dd($e);
            return $this->response("Message Cannot be Sent", "error", 422);
        }
    }
}
