<?php

namespace App\Http\Controllers\Fgp\Timesheet;

use App\Http\Controllers\BaseController;
use App\Lib\Exporter\CSVExporter;
use App\Lib\Exporter\JSONExporter;
use App\Lib\Exporter\PDFExporter;
use App\Lib\Exporter\TxtExporter;
use App\Models\Fgp\ApprovalFlow;
use App\Models\Fgp\ApprovalTable;
use App\Models\Fgp\PayPeriod;
use App\Models\Fgp\Site;
use App\Models\Fgp\Template;
use App\Models\Fgp\Timesheet;
use App\Models\Fgp\TimesheetFile;
use App\Models\Fgp\Volunteer;
use App\Models\Fgp\VolunteerSites;
use App\Models\Member;
use App\Models\User;
use App\Repo\FGP\PayPeriodRepo;
use App\Repo\TimeSheetRepo;
use App\Services\FileService;
use Illuminate\Database\Eloquent\Relations\Relation;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use App\Models\Fgp\StipendItem;

class TimesheetShowController extends BaseController
{
    private $clayout;

    private const UPLOAD_LOCATION = 'uploads/timesheetsDocs/';

    public function __construct()
    {
        parent::__construct();
        $this->clayout = $this->layout . '.fgp.timesheet';
    }

    public function index(Request $request)
    {
        return $this->view($this->clayout . '.timesheet', $this->table($request));
    }

    private function table(Request $request)
    {
        /*
         * formatted stipend period for new time-sheet view
         * */
        $stipend_periods = (new PayPeriodRepo('Fgp\PayPeriod'))->getStipendPeriods($request);
        // dd($stipend_periods);
        $vols = Timesheet::select('volunteer_id')->distinct()->whereIn('period_id', $stipend_periods->pluck('id')->all())->pluck('volunteer_id')->all();

        $vol_supervisors = User::whereRaw('id in (select supervisor_id from volunteers_supervisors where volunteer_id in (?))', implode(',', $vols))->get();
        $vol_supervisors->push(auth()->user());

        $vol_supervisors = $vol_supervisors->unique();

        foreach ($stipend_periods as $key => $val) {
            $timesheet = Timesheet::select('next_approval', 'approval_flow_id')->where('period_id', $key)
                ->join('approval_flow as af', 'af.role', 'timesheets.next_approval')
                ->orderBy('af.seq_num', 'desc')
                ->first();
            $val->flow = $timesheet ? $timesheet->approval_flow_id : 0;
            $val->next_approval = $timesheet ? $timesheet->next_approval : 'supervisor';
        }
        $approval_flow = ApprovalFlow::select('id', 'code', 'role')->where('is_deleted', false)->orderBy('seq_num', 'asc')->get();

        return compact('vol_supervisors', 'stipend_periods', 'approval_flow');
    }

    public function onlyTable(Request $request)
    {
        $data = $this->getTableData($request);
        //        dd($data);
        $id = $request->input('stipend_id');

        $approval_flow = ApprovalFlow::where('is_deleted', false)->orderBy('seq_num', 'asc')->pluck('seq_num');
        $approval_flow1 = ApprovalFlow::where('is_deleted', false)->orderBy('seq_num', 'asc')->get();
        foreach ($approval_flow1 as $flow) {
            $status1 = ApprovalTable::where('period_id', $id)->where('approval_flow_id', $flow->seq_num)->first();
            // dd($status1);
            if (!is_null($status1)) {
                $flow->status = $status1->appr_stat;
            } else {
                $flow->status = false;
            }
        }
        $approvals = ApprovalTable::where('period_id', $id)->get();
        return $this->view($this->clayout . '.includes.tableData', compact('data', 'approvals', 'id', 'seq', 'approval_flow', 'approval_flow1', 'timesheet'));
    }

    public function onlyStipend(Request $request)
    {
        // $approval_flow = ApprovalFlow::where('is_deleted', false)->orderBy('seq_num', 'asc')->pluck('id');
        return $this->view($this->clayout . '.includes.tableDataMultiLevel', $this->table($request));
    }

    public function index1(Request $request)
    {
        $data = $this->getTableData($request);
        $ids = $data['data']->pluck('stipend_id');
        $stipend_periods = PayPeriod::whereIn('id', $ids->unique())
            ->orderBy('start_date')
            ->where('closed_date', null)->get();
        foreach ($data['data'] as $timesheet) :
            $stipend_period = $stipend_periods->firstWhere('id', $timesheet->stipend_id);
            array_push($stipend_period->collection, $timesheet);
        endforeach;
        //          Empty stipend period filter
        //        $stipend_periods = $stipend_periods->filter(function($arr) {
        //            return count($arr->collection);
        //        });
        $supervisor_id = Volunteer::where('is_deleted', false)->distinct()->pluck('vol_supervisor_id');
        $supervisors = [];
        if (count($supervisor_id) > 0) {
            foreach ($supervisor_id as $id) {
                array_push($supervisors, User::find($id));
            }
        }
        return $this->view($this->clayout . '.timesheet', compact('stipend_periods', 'supervisors'));
    }

    // table data
    public function getTableData(Request $request)
    {
        return (new TimeSheetRepo('Fgp\Timesheet'))
            ->selectDataTable1($request);
    }

    //get report data
    public function getReportData(Request $request, $type)
    {
        $data = (new TimeSheetRepo('Fgp\Timesheet'))->getReportData($request);
        if (isset($_COOKIE['time_sheet_advanced']) || isset($_COOKIE['time_sheet'])) {
            $advData = isset($_COOKIE['time_sheet_advanced']) ? json_decode($_COOKIE['time_sheet_advanced']) : [];
            $quickData = isset($_COOKIE['time_sheet']) ? json_decode($_COOKIE['time_sheet']) : [];
            $mergeData = array_merge($advData, $quickData);
        } else {
            $mergeData = [];
        }
        $fields = array('Period', 'Start Date', 'End Date', 'Vol ID', 'Volunteer Name', 'Supervisor', 'County');
        $mapField = array('stipend_period_no', 'st_period_start_date', 'st_period_end_date', 'vol_alt_id', 'vol_name', 'vol_sup_name', 'site_county');
        $data = cleaner($mapField, $data);
        $data['table'] = 'Report of Time Sheets';
        $data['request'] = '';
        if (empty($mergeData)) {
            $data['request'] = ['Search' => 'All'];
        } else {
            $data['request'] = [];
            foreach ($mergeData as $d) :
                if ($d->name == 'vol_name') {
                    $data['request']['Volunteer Name'] = $d->value;
                }
                if ($d->name == 'alt_id') {
                    $data['request']['Volunteer ID'] = $d->value;
                }
                if ($d->name == 'supervisor') {
                    $data['request']['Supervisor'] = $d->value;
                }
            endforeach;
            if (count($data) > 0) {
                $export = $this->reportFactory($type, $fields, $data);
                $exporter = new \App\Lib\Exporter\Exporter($export);
                $filename = $exporter->export();
                return response()->download($filename)->deleteFileAfterSend(true);
            } {
                return 'No Data Available For Current Filter';
            }
        }
    }
    /**
     * @param $type
     * @param $data
     * @return CSVExporter|JSONExporter|PDFExporter|TxtExporter
     * @throws \Exception
     */
    public function reportFactory($type, $fields, $data)
    {
        switch ($type) {
            case 'csv':
                return new CSVExporter($data, $fields, 'TimeSheetReports');
                break;
            case 'json':
                return new JSONExporter($data);
                break;
            case 'txt':
                return new TxtExporter($data);
                break;
            case 'pdf':
                return new PDFExporter($data, $fields, 'print');
                break;
            default:
                throw new \Exception("Method Not Allowed " . $type);
                break;
        }
    }

    public function addTimeSheet(Request $request)
    {
        $selected_site = '';

        $validations = validation_value('timeSheetAddForm');

        $stipend_period = PayPeriod::find($request->id);
        if (!$stipend_period) {
            return response(['errors' => ["message" => ["Stipend Period not selected."]]], 422);
        }

        if (request()->has('site')) {

            $vols = Volunteer::select('volunteers.id',  DB::raw('CONCAT(first_name," ", COALESCE(middle_name, ""), " ",last_name) as name'))
                ->where('volunteers.is_active', 1)
                ->selectRaw('count(
                    (
                        select ts.id
                        from timesheets ts
                        where ts.volunteer_id = volunteers.id 
                        AND ts.period_id = ? 
                        AND ts.site_id = ?
                        LIMIT 1
                    )) as tsExists
                ', [$stipend_period->id, request()->site])

                ->when(request()->has('requester') && request()->requester === 'finance', function ($q) use ($stipend_period) {

                    $q->join(
                        DB::raw('(select * from timesheets 
                            where timesheets.period_id = ' . $stipend_period->id . ' 
                            AND site_id = ' . request()->site . ') as t'),
                        't.volunteer_id',
                        'volunteers.id'
                    );
                })

                ->join('volunteer_sites', function ($join) {
                    $join->on('volunteer_sites.site_id', \DB::raw(request()->site));
                    $join->on('volunteer_sites.volunteer_id', 'volunteers.id');
                })
                ->leftjoin('volunteers_supervisors', function ($join) {
                    $join->on('volunteers.id', 'volunteers_supervisors.volunteer_id');
                })

                ->when(auth()->user()->role_id != 1 && !auth()->user()->hasRole('fiscal'), function ($query) use ($request) {
                    $rptMgr = auth()->user()->hierarchyIds()->all();

                    $query->whereIn('volunteers_supervisors.supervisor_id', $rptMgr);
                })
                ->where('volunteers.is_deleted', 0)
                ->with(['assignedSites', 'assignedSites.sites'])
                ->groupBy('volunteers.id')
                ->get();


            $selected_site = Site::find(request()->site);
        } else if (request()->has('volunteer')) {
            $vols = Volunteer::select('volunteers.id', DB::raw('CONCAT(first_name," ", COALESCE(middle_name, ""), " ",last_name) as name'))

                ->where('volunteers.is_deleted', 0)
                ->where('volunteers.id', request()->volunteer)
                ->with(['assignedSites', 'assignedSites.sites'])
                ->first();
        } else { //When stipend view
            
            $vols = Volunteer::select('volunteers.id', DB::raw('CONCAT(volunteers.first_name," ", COALESCE(volunteers.middle_name, ""), " ",volunteers.last_name) as name'))
                ->selectRaw('count(
                    (
                        select ts.id
                        from timesheets ts
                        where ts.volunteer_id = volunteers.id 
                        AND ts.period_id = ? 
                        LIMIT 1
                    )) as tsExists
                ', [$stipend_period->id])
                ->when(request()->has('requester') && request()->requester === 'finance', function ($q) use ($stipend_period) {
                    $q->join(
                        DB::raw("(select * from timesheets where timesheets.period_id = {$stipend_period->id} ) as t"),
                        't.volunteer_id',
                        'volunteers.id'
                    );
                })
                ->leftjoin('volunteers_supervisors', function ($join) {
                    $join->on('volunteers.id', 'volunteers_supervisors.volunteer_id');
                })

                ->when(auth()->user()->role_id != 1 && auth()->user()->role_id != 2 && !auth()->user()->hasRole('fiscal'), function ($query) use ($request) {
                    $rptMgr = auth()->user()->hierarchyIds()->all();

                    $query->whereIn('volunteers_supervisors.supervisor_id', $rptMgr);
                })
                ->where('volunteers.is_deleted', 0)
                ->with('assignedSites', 'assignedSites.sites')
                ->groupBy('volunteers.id')
                ->get();
        }

        $all_sites = $this->getAssignedSites(request()->requester, $stipend_period->id);

        $apprvs = $this->get_appr_flow($stipend_period->id);

        return $this->view($this->clayout . '.includes.generate.generate', compact('validations', 'stipend_period', 'vols', 'all_sites', 'selected_site', 'apprvs'));
    }

    public function get_appr_flow($stipend_id)
    {
        $appr = ApprovalTable::where('period_id', $stipend_id)
            ->with('approver')
            ->get();

        $appr_flow = ApprovalFlow::select('role', 'role_id')->orderBy('seq_num')->get();

        $appr_flow->each(function ($role) use ($appr) {
            $role->user = $appr->firstWhere('approver.role_id', $role->role_id);
        });

        return $appr_flow;
    }

    public function getAssignedSites($requester = false, $period = false)
    {
        $user = auth()->user();
        $is_admin = in_array($user->role_id, [1, 2, 7]) ? true : false;
        $rptMgr =  $user->hierarchyIds()->all();
        return  $is_admin
            ? Site::with('address')->when($requester, function ($query) use ($period) {
                $query->whereHas('timesheets', function ($q) use ($period) {
                    $q->where('timesheets.period_id', $period);
                });
            })->get()
            : Site::select('sites.*')->leftjoin('site_managers as sm', 'sm.site_id', 'sites.id')
            ->whereIn('sm.user_id', $rptMgr)->groupBy('sites.id')->get();
    }

    /**
     *  Gives the template table
     * @param PayPeriod $stipend_period , $vol && request()->site
     * @param Volunteer $vol
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */

    public function volunteer(PayPeriod $stipend_period, Volunteer $vol)
    {
        try {

            $is_generated = [];

            $accesible = [];

            $ts_unq_id = [];

            $default_site_template = [];

            $default_template = [];

            $template_name = '';

            /* This condition is for the volunteer view */

            if (request()->has('associatedSite')) :
                $vol_assigned_sites = $vol->assignedSites->filter(function ($volSite) {
                    return intval(request()->associatedSite) === $volSite->site_id;
                });

                $vol->assignedSites = $vol_assigned_sites;

            else :
                $vol_assigned_sites = $vol->assignedSites;

            endif;

            foreach ($vol_assigned_sites as $site) {

                /* Check if the timesheet is already generated */
                $default_site_template[$site->site_id] = $this->getGeneratedTimeSheet($vol->id, $stipend_period->id, $site->site_id);

                $is_generated[$site->site_id] = 1;

                if (!count($default_site_template[$site->site_id])) {

                    unset($default_site_template[$site->site_id]);

                    $is_generated[$site->site_id] = null;

                    $template = $this->getVolunteerDefaultTemplate($vol);
                    $default_template = $template['template'];
                    $template_name = $template['temp_name'];
                    continue;
                } else {
                    // :todo this is no use i guess can be removed check
                    $ts_unq_id[$site->site_id] = $default_site_template[$site->site_id][0]->timesheets_unq_id;
                }

                if ($ts = $default_site_template[$site->site_id]->first()) {

                    if (can_access_ts($ts->id)) {
                        $accesible[] = $site->site_id;
                    }
                }
            }


            $all_sites = $this->getAssignedSites();

            $sup_assigned_sites = $all_sites->pluck('id')->all();

            $hasSupSite = $this->volHasSupSite($vol->assignedSites, $sup_assigned_sites);

            $gen = false;   // To lock default all sites if any of the sites are generated

            // $is_partially_generated = false;

            $allSiteTs = collect();
            /**
             * Generated Timesheets, if timesheets are generated then check if any of them are accessible
             */
            if (count($default_site_template)) {

                $gen = true;

                // if(count($accesible))
                //     $is_partially_generated =  true;

                $allSiteTs = collect($default_site_template)->collapse();
            }


            $isClosed = false;

            if (request()->has('requester') && request()->requester === "finance") {
                $isClosed = true;
            }

            $allSiteTs = $allSiteTs->sortBy('date')->all();

            $siteIncludedOnDefaultTemplate = $this->getSitesIncludedOnDefaultTemplate($default_template);

            return view($this->clayout . '.includes.generate.generate-right-section', compact(
                'vol',
                'ts_unq_id',
                'stipend_period',
                'default_template',
                'is_generated',
                'default_site_template',
                'template_name',
                'accesible',
                'hasSupSite',
                'gen',
                'allSiteTs',
                'siteIncludedOnDefaultTemplate',
                'isClosed'
            ));
        } catch (\Exception $e) {
            return $this->response(implode(', ', [$e->getMessage(), $e->getLine(), $e->getFile()]), 'error', 500);
        }
    }

    public function getSitesIncludedOnDefaultTemplate($default_template)
    {
        return array_keys($default_template);
    }

    public function supAssignedSites($sites)
    {

        return array_map(function ($site) {

            return $site['id'];
        }, $sites->toArray());
    }

    public function volHasSupSite($volSites, $supSites)
    {


        $atleast_one_site = false;

        foreach ($volSites as $key => $volSite) {

            in_array($volSite->site_id, $supSites) ? $atleast_one_site = true : '';
        }

        return $atleast_one_site;
    }

    public function isSiteGenerated($volunteer_id, $site_id)
    {

        return !!VolunteerSites::where('volunteer_id', $volunteer_id)->where('site_id', $site_id)->exists();
    }

    public function getGeneratedTimeSheet($vol_id, $stipend_period_id, $site_id)
    {
        $existing_timesheet = Timesheet::where('volunteer_id', $vol_id)
            ->where('period_id', $stipend_period_id)
            ->where('site_id', $site_id)
            ->with(['timesheetItems', 'item'])
            ->orderBy('date')
            ->with('site')
            ->get();
        return $existing_timesheet;
    }

    public function getVolunteerDefaultTemplate($volunteer)
    {

        $temp = Template::where([
            'table_name' => 'volunteers',
            'table_id'  => $volunteer->id,
            'is_default' => 1
        ])->first();


        if ($temp) :

            // $def['template'] = json_decode($temp->details->value, true);
            // $template['template'] = $this->formatDefaultTemplate($def);
            // 
            $template['template'] = $this->formatTableItems($temp);
            $template['temp_name'] = $temp->template_name;
        else :
            $template['template'] = [];
            $template['temp_name'] = "";
        endif;

        return $template;
    }

    public function formatTableItems($template)
    {
        $data = [];
        $template->details->load('timeType');
        foreach ($template->details as $detail) :
            $temp = $detail->only('time_in', 'time_out', 'break_out', 'break_in', 'total_hours', 'timeType');
            $temp['total_hr'] = $temp['total_hours'];
            $temp['items'] = $detail->items->map(function ($item) {
                $item->stipendItem["template_amount"] = $item->amount;
                return $item->stipendItem;
            });
            $data[$detail->site_id][$detail->days] = $temp;
        endforeach;
        return $data;
    }

    public function formatDefaultTemplate($template)
    {

        $data = [];
        foreach ($template as $key => $temp) {

            foreach ($temp as $k => $items) {

                foreach ($items as $itemKey => $item) {

                    if ($itemKey === "days") {
                        $data[$k][$itemKey] = $item;
                        continue;
                    }

                    if ($itemKey === "items") {
                        foreach ($item as $stipend_type => $stipends) {

                            //Stipend code = travel_code & stipend_item = array of site_id and type
                            foreach ($stipends as $stipend_code => $stipend_value_arr) {

                                foreach ($stipend_value_arr as $site_id => $val) {

                                    foreach ($val as $kv => $v) {
                                        $data[$k]['sites'][$site_id]['items'][$stipend_type][$stipend_code] = $v;
                                    }
                                }
                            }
                        }
                        continue;
                    }

                    foreach ($item as $site_id => $item_value) {

                        $data[$k]['sites'][$site_id][$itemKey] = is_array($item[$site_id]) ? $item[$site_id][0] : $item[$site_id];
                    }
                }
            }
        }
        return $data;
    }

    public function loadVolunteerTemplate(Request $request, PayPeriod $period, Volunteer $volunteer, Template $template)
    {


        $editables = []; //Sites which are editable and which should be able to load

        $datas = $request->data ? $request->data : []; // $request->data = [] means that default site is only editable

        foreach ($datas as $key => $site) {
            array_push($editables, $site['id']);
        }

        $is_generated = [];

        $accesible = [];

        $default_site_template = [];

        $default_template = [];

        $template_name = '';

        foreach ($volunteer->assignedSites as $site) {

            /*
            *   Filters out the sites which are editable
            */

            if (!in_array($site->site_id, $editables) && count($datas)) {
                $is_generated[$site->site_id] = 1;
                $default_site_template[$site->site_id] = $this->getGeneratedTimeSheet($volunteer->id, $period->id, $site->site_id);

                $is_generated[$site->site_id] = 1;

                if ($ts = $default_site_template[$site->site_id]->first()) {

                    if (can_access_ts($ts->id)) {
                        $accesible[] = $site->site_id;
                    }
                }
            } else {
                $is_generated[$site->site_id] = null;
                // $def['template'] = json_decode($template->details->value, true);
                $calib_template['template'] = $this->formatTableItems($template);
                $calib_template['temp_name'] = $template->template_name;

                $default_template = $calib_template['template'];

                $template_name = $calib_template['temp_name'];

                $vol = $volunteer;
                $stipend_period = $period;
            }
        }

        $gen = false;

        $all_sites = $this->getAssignedSites();

        $sup_assigned_sites = $this->supAssignedSites($all_sites);

        $hasSupSite = $this->volHasSupSite($volunteer->assignedSites, $sup_assigned_sites);

        $siteIncludedOnDefaultTemplate = $this->getSitesIncludedOnDefaultTemplate($default_template);

        $isClosed = false;

        return $this->view($this->clayout . '.includes.generate.generate-right-section', compact(
            'vol', 
            'stipend_period', 
            'default_template', 
            'is_generated', 
            'default_site_template', 
            'template_name', 
            'accesible', 
            'hasSupSite', 
            'gen', 
            'siteIncludedOnDefaultTemplate',
            'isClosed'
        ));
    }

    public function assignSitesWidget(Volunteer $volunteer)
    {

        return $this->view($this->clayout . '.includes.generate.modals.widget.index');
    }

    public function allSupervisorsLists(Volunteer $volunteer)
    {

        $sups = $volunteer->supervisors->map(function ($supervisor) {

            return ucfirst($supervisor->fullName());
        });


        return view('default.fgp.timesheet.includes.generate.modals.view-all-supervisors', compact('sups'));
    }

    // Load time-sheet Tempate Modal
    public function loadTemplate(Volunteer $vol)
    {
        return view('default.fgp.timesheet.includes.generate.modals.loadTemplate', [
            'templates' => $vol->allTemplates,
            'vol_id'    => request()->vol_id,
            'period_id' => request()->period_id,
        ]);
    }

    public function downloadFromTimesheet(Volunteer $volunteer, PayPeriod $period, Site $site)
    {

        $files = app(FileService::class)->getTimesheetFiles($volunteer, $period, $site);

        return view('default.fgp.timesheet.includes.generate.modals.file.uploaded-files', compact('files'));
    }

    /**
     * Download files from default sites
     * @param  Volunteer $volunteer [description]
     * @param  PayPeriod $period    [description]
     * @var   $requestedFromDefault If the file view is requested from default all sites
     * @return View              
     */
    public function downloadFromDefaultTimesheet(Volunteer $volunteer, PayPeriod $period)
    {

        $files = app(FileService::class)->getTimesheetFiles($volunteer, $period);

        $requestedFromDefault = true;

        return view('default.fgp.timesheet.includes.generate.modals.file.uploaded-files', compact('files', 'requestedFromDefault'));
    }

    public function uploadToTimesheet(Volunteer $volunteer, PayPeriod $period, Site $site)
    {
        return view('default.fgp.timesheet.includes.generate.modals.file.upload-ts-files', compact('volunteer', 'site', 'period'));
    }

    public function uploadToDefaultTimesheet(Volunteer $volunteer, PayPeriod $period)
    {
        return view('default.fgp.timesheet.includes.generate.modals.file.upload-default-ts-files', compact('volunteer', 'period'));
    }

    public function timeSheet()
    {
        return $this->view($this->clayout . '.index1');
    }

    public function viewTimesheet(Timesheet $timesheet)
    {
        $volunteer = Volunteer::find($timesheet->volunteer_id);
        $stipend_period = PayPeriod::find($timesheet->period_id);
        $timesheets =  Timesheet::where('volunteer_id', $timesheet->volunteer_id)
            ->where('period_id', $timesheet->period_id)
            ->where('site_id', $timesheet->site_id)
            ->get();

        return $this->view($this->clayout . '.includes.timesheetView', compact('volunteer', 'timesheet', 'stipend_period', 'timesheets'));
    }

    public function timesheetSiteFilter($vol, $site, $period)
    {
        $timesheets =  Timesheet::where('volunteer_id', $vol)
            ->where('period_id', $period)
            ->where('site_id', $site)
            ->get();
        return $this->view($this->clayout . '.includes.timesheetSiteFilter', compact('timesheets'));
    }

    /**
     * Find timesheet
     * @param  PayPeriod $period    [description]
     * @param  Site      $site      [description]
     * @param  Volunteer $volunteer [description]
     * @return $timesheet Timesheet               [description]
     */
    private function fetchTimesheet(PayPeriod $period, Site $site, Volunteer $volunteer): Collection
    {

        $wheres = [

            'period_id' => $period->id,
            'site_id' => $site->id,
            'volunteer_id'  => $volunteer->id

        ];

        return Timesheet::where($wheres)->with('timesheetItems')->get();
    }

    /**
     * Calculates the hour total $hourTotal, travel total $traveltotal and meal $mealTotal
     * @param  PayPeriod  $period    [description]
     * @param  Volunteer  $volunteer [description]
     * @param  Site       $site      [description]
     * @param  Collection $datas     collection of timesheets
     * @return Array                [description]
     */
    private function timesheetTotalsCalulator(PayPeriod $period, Volunteer $volunteer, Site $site, Collection $datas): array
    {

        $hourTotal = $volunteer->total_hrs($period->id, $site->id);

        $travelTotal = $datas->sum(function ($timesheet) {
            $travel_amt = $timesheet->timesheetItems->where('type', "Mileage Reimbursements")->first();
            return $travel_amt->amount ?? 0;
        });

        $mealTotal = $datas->sum(function ($timesheet) {

            $meal_amt = $timesheet->timesheetItems->where('type', "Food Service")->first();
            return $meal_amt->amount ?? 0;
        });

        return [

            'datas' => $datas,
            'totals' => [
                'travel' => $travelTotal,
                'meal'  => $mealTotal,
                'hours' => $hourTotal
            ]

        ];
    }

    /** Get Timesheets data and format timesheet items for print @return Collection */
    private function getTimesheetDataForPrint(PayPeriod $period, Site $site, Volunteer $volunteer): Collection
    {

        $datas = $this->fetchTimesheet($period, $site, $volunteer);

        $arr = ['type', 'Mileage Reimbursements', 'Food Service'];

        $typeMappers = ['type', 'travel', 'meals'];

        foreach ($datas as $key => $timesheet) {

            foreach ($arr as $typ) {
                $datas[$key][$typ] = '';
            }
            foreach ($timesheet->timesheetItems as $item) {
                foreach ($arr as $mapperKey => $type) {
                    if (strtolower($item['type']) == strtolower($type)) {
                        // dd($item, $key, $typeMappers, $mapperKey);
                        $datas[$key][$typeMappers[$mapperKey]] = $item['value'];
                    }
                }
            }
        }


        return $datas;
    }

    /**
     * Prints Timesheet
     * @param  PayPeriod $period    [description]
     * @param  Site      $site      [description]
     * @param  Volunteer $volunteer [description]
     * @return Binary File Response            
     */
    public function printTimesheet(PayPeriod $period, Site $site, Volunteer $volunteer)
    {

        $fields = Null;

        $timesheet = $this->getTimesheetDataForPrint($period, $site, $volunteer);

        $collection = $this->timesheetTotalsCalulator($period, $volunteer, $site, $timesheet);

        $exporter = new \App\Lib\Exporter\Exporter(new PDFExporter($collection, $fields, 'printTimesheet'));
        $filename = $exporter->export();
        return response()->download($filename)->deleteFileAfterSend(true);

        // return $this->view($this->layout . '.print.printTimesheet', ['datas'=> $collection]);
    }

    private function fetchDefaultSitePrintSites(array $generatedTs): Collection
    {

        return collect($generatedTs)->filter(function ($tsArray, $key) {
            return count($tsArray) ? $key : '';
        })
            ->keys()
            ->map(function ($id) {
                return Site::find($id);
            });
    }

    private function fetchDefaultSitePrintTimesheets(array $generatedTs): array
    {

        $timesheets = collect();

        if ($generatedTs) {

            $timesheets = collect($generatedTs)->collapse()->sortBy('date')->map(function ($ts) {

                $ts->travel = $ts->timesheetItems->where('type', "Mileage Reimbursements")->first()->value ?? '';
                $ts->meals = $ts->timesheetItems->where('type', "Food Service")->first()->value ?? '';

                return $ts;
            })->all();
        }

        return array_values($timesheets);
    }

    private function calculateDefaultPrintTotals(array $timesheetArray, Volunteer $volunteer, PayPeriod $period): array
    {

        $timesheets = collect(Arr::collapse($timesheetArray));

        $totalHours = $volunteer->total_hrs($period->id);

        $travelTotal = $timesheets->sum(function ($ts) {

            return $ts->timesheetItems->sum(function ($item) {
                return $item->where('type', 'Mileage Reimbursements')->first()->amount ?? 0;
            });
        });

        $mealTotal = $timesheets->sum(function ($ts) {

            return $ts->timesheetItems->sum(function ($item) {
                return $item->where('type', 'Food Service')->first()->amount ?? 0;
            });
        });


        return [
            "travelTotal" => $travelTotal,
            "mealTotal" => $mealTotal,
            "hoursTotal" => $totalHours
        ];
    }

    /**
     * Prints default site timesheet
     * @todo  move this to listeners or somewhere else
     * @param  PayPeriod $period    [description]
     * @param  Volunteer $volunteer [description]
     * @return [type]               [description]
     */
    public function printDefaultTimesheet(PayPeriod $period, Volunteer $volunteer)
    {

        foreach ($volunteer->assignedSites as $site) {
            //Get the generated timesheets
            $generatedTs[$site->site_id] = $this->getGeneratedTimeSheet($volunteer->id, $period->id, $site->site_id);
        }
        $collection = [

            'sites' => $this->fetchDefaultSitePrintSites($generatedTs),
            'timesheet' => $this->fetchDefaultSitePrintTimesheets($generatedTs),
            'period' => $period,
            'volunteer' => $volunteer,
            'totals' => $this->calculateDefaultPrintTotals($generatedTs, $volunteer, $period)

        ];

        $exporter = new \App\Lib\Exporter\Exporter(new PDFExporter($collection, [], 'printDefaultSiteSchedule'));
        $filename = $exporter->export();
        return response()->download($filename)->deleteFileAfterSend(true);

        // return $this->view($this->layout.'.print.printDefaultSiteSchedule', ['datas' => $collection]);

    }


    function selectStipendPeriod()
    {
        return $this->view($this->clayout . '.modals.choose_stipend_period', ['viewSchedule' => request()->has('viewSchedule')]);
    }

    function stipendPeriodList(Request $request)
    {
        $filter = $request->input('filtered', false);

        $sp = PayPeriod::select(
            'id',
            'period_no',
            'pay_stat',
            DB::raw('date_format(start_date, "%m/%d/%Y") as start_date'),
            DB::raw('date_format(end_date, "%m/%d/%Y") as end_date')
        )
            ->when($request->input('term', false), function ($query, $term) {
                $query->where('period_no', $term)
                    ->orWhereDay('start_date', $term)
                    ->orWhereMonth('start_date', $term)
                    ->orWhereYear('start_date', $term);
            })
            ->where('is_deleted', 0)
            ->when($filter && !in_array($filter, ['closed', 'both']), function ($query) {
                $query->whereNull('closed_date');
            });

        // $filter = $request->input('filtered', false);
        if ($filter === false) {
            switch ($filter) {
                case '0':
                    $sp->whereNotNull('closed_date')
                        ->orderBy('end_date')->has('timesheets');
                    break;
                case '1':
                    $sp->whereNull('closed_date')->whereDate('end_date', '>=', date('Y-m-d'))
                        ->orderBy('end_date')->has('timesheets')->limit(1);
                    break;
                default:
                    $sp->whereNull('closed_date')->where('pay_stat', '!=', 'Posted')
                        ->orderBy('end_date')->when($request->has('viewSchedule'), function ($q) {
                            $q->where('pay_stat', 'New');
                        })->doesnthave('timesheets');
                    break;
            }
        } else {
            $sp->when($filter == 'In Process', function ($q, $withTimesheet) {
                if (!$withTimesheet) $q->doesnthave('timesheets');
                $q->where('pay_stat', 'in process');
            })
                ->when(strtolower($filter) == 'open', function ($q) {
                    $q->whereIn('pay_stat', ['in process', 'open']);
                    $q->selectRaw('"Open" as override');
                })
                ->when(strtolower($filter) == 'both', function ($q) {
                    $q->whereIn('pay_stat', ['in process', 'closed', 'Posted']);
                    // $q->selectRaw('"Open" as override');
                })
                ->when(strtolower($filter) == 'closed', function ($q) {
                    $q->whereIn('pay_stat', ['closed', 'Posted']);
                });
        }


        // change into select2 structure
        $sp = $sp->get()->map(function ($stp) use ($filter) {
            $stp->pay_stat = $stp->override ?: $stp->pay_stat;
            if (!in_array($filter, ['closed', 'both'])) {
                return [
                    'id' => $stp->id,
                    'text' => "Period ({$stp->period_no}) : $stp->start_date - $stp->end_date <span class='pull-right'>($stp->pay_stat)</span>"
                ];
            } else {
                // echo($stp->pay_stat);
                if ($stp->pay_stat == "Closed" || $stp->pay_stat == "Posted") {
                    return [
                        'id' => $stp->id,
                        'text' => "Period ({$stp->period_no}) : $stp->start_date - $stp->end_date <span class='pull-right'>(Closed)</span>"
                    ];
                } else {
                    // :todo move it to top
                    return [
                        'id' => $stp->id,
                        'text' => "Period ({$stp->period_no}) : $stp->start_date - $stp->end_date <span class='pull-right'>($stp->pay_stat)</span>"
                    ];
                }
            }
        });

        return $sp;
    }

    public function tsSelectModal(Request $request)
    {

        $data = $request->all();
        return view($this->clayout . '.includes.generate.modals.single-vol-ts-save', compact('data'));
    }


    public function viewFile($file): BinaryFileResponse
    {

        return app(FileService::class)->viewFile($file, static::UPLOAD_LOCATION);
    }

    public function downloadFile($file): BinaryFileResponse
    {
        return app(FileService::class)->downloadFile($file, static::UPLOAD_LOCATION);
    }
}
