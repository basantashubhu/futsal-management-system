<?php

namespace App\Http\Controllers\Fgp\Timesheet;

use Exception;
use App\Models\Note;
use App\Models\User;
use App\Models\EmailLog;
use App\Models\Fgp\Site;
use App\Repo\TimeSheetRepo;
use App\Models\SiteSettings;
use Illuminate\Http\Request;
use App\Models\Fgp\PayPeriod;
use App\Models\Fgp\Timesheet;
use App\Models\Fgp\Volunteer;
use App\Lib\FileZipper\Config;
use App\Mail\Fgp\ApprovalMail;
use App\Models\Fgp\StipendCalc;
use App\Models\Fgp\StipendItem;
use App\Models\Fgp\ApprovalFlow;
use App\Models\Settings\ZipCode;
use App\Lib\Exporter\CSVExporter;
use App\Lib\Exporter\PDFExporter;
use App\Lib\Exporter\TxtExporter;
use App\Models\Fgp\ApprovalTable;
use App\Models\Fgp\TimeSheetItem;
use App\Lib\Exporter\JSONExporter;
use App\Models\EmailSettingsModel;
use App\Models\Fgp\VolunteerSites;
use Illuminate\Support\Facades\DB;
use App\Models\Fgp\StipendCalcVols;
use App\Lib\SwiftMailer\SwiftMailer;
use App\Models\Fgp\StipendCalcItems;
use App\Models\Fgp\StipendCalcSites;
use App\Models\Fgp\StipendCalcTypes;
use App\Jobs\TimesheetApprovalSingle;
use App\Lib\Notification\Notification;
use App\Models\Notification as Notify;
use Illuminate\Support\Facades\Cookie;
use App\Jobs\TimesheetApprovalAllLabel;
use App\Http\Controllers\BaseController;
use App\Jobs\TimesheetApprovalSingleLabel;

class TimesheetApprovalController extends BaseController
{
    private $clayout;
    private $eto_rate = 0.1724;
    private $request;

    public function __construct()
    {
        parent::__construct();
        $this->clayout = $this->layout . '.fgp.timesheet';
    }

    //volunteer wise approve
    public function timesheetApprovalView(Request $request)
    {
        $data = explode(',', $request->data);

        $data = array_unique($data);

        $timesheets = Timesheet::whereIn('id', $data)->with('volunteer', 'site', 'pay_period')
        /* ->groupBy(DB::raw('concat(site_id, volunteer_id, period_id)')) */
        ->get();
        // dd($timesheets->count());
        $timesheets->each(function ($t) {
            $t->approvals = $t->approvals->sortBy('approval_flow_id');
            if (is_numeric($t->approval_flow_id)) {
                $t->approvalFlow = ApprovalFlow::where('seq_num', '<=', $t->approval_flow_id)->orderBy('seq_num', 'asc')->get();

                $max = $t->approvals->max('approval_flow_id');

                $afterMax = $t->approvals->firstWhere('approval_flow_id', $max);

                if (!$afterMax) {
                    $t->current_user = false;
                    $t->next_user = false;
                } else {
                    $t->current_user = User::find($afterMax->user_approved_id);
                    // $t->next_user = true;
                    if (auth()->user()->hasRole('fiscal')) {
                        $t->next_user = false;
                    }
                }
            } else {
                $t->approvalFlow = false;
                $t->approval = false;
                $t->current_user = false;
                $t->next_user = false;
            }
        });

        $already = $timesheets->map(function ($ts) {
            return $ts->approvals->pluck('current_approval_role');
        })->collapse()->unique()->all();
        $next = $timesheets->map(function ($ts) {
            return $ts->approvals->pluck('next_approval');
        })->collapse()->unique()->all();

        return $this->view($this->clayout . '.modals.timesheetApprove2', compact('timesheets', 'already', 'next'));
    }

    public function confirmationForQueue(Request $request)
    {
        return $this->view($this->clayout . '.modals.confirmationForQueue');
    }

    public function confirmationForQueueSingle(Request $request)
    {
        return $this->view($this->clayout . '.modals.confirmationForQueueSingle');
    }

    public function confirmationForQueueAll(Request $request)
    {
        return $this->view($this->clayout . '.modals.confirmationForQueueAll');
    }

    public function runQueue(Request $request)
    {
        DB::beginTransaction();
        try {
            $flow = ApprovalFlow::where('role_id', auth()->user()->role_id)->first();
            if (!$flow) {
                throw new \Exception('You are not in approval flow.', 400);
            }
            $data = isset($_COOKIE['timesheet_approval']) ? json_decode($_COOKIE['timesheet_approval']) : [];
            $ts = collect($data);
            $sites = $ts->where('name', 'site')->pluck('value')->collapse()->unique()->all();
            $periods = $ts->where('name', 'period')->pluck('value')->collapse()->unique()->all();
            $volunteers = $ts->where('name', 'volunteer')->pluck('value')->collapse()->unique()->all();

            $timesheets = Timesheet::whereIn('period_id', $periods)->whereIn('site_id', $sites)->whereIn('volunteer_id', $volunteers)
                ->update(['is_queue' => 1]);

            TimesheetApprovalSingle::dispatch($periods, $sites, $volunteers, User::find(auth()->id()));
            DB::commit();
            return $this->response("Timesheet Approval Process is Running in Background", "view", 200);
        } catch (\Exception $e) {
            DB::rollback();
            if ($e->getCode() === 400) {
                return $this->response($e->getMessage(), "error", 422);
            }
            return $this->response("TimeSheet cannot be approved", "error", 422);
        }
    }

    public function runQueueSingle(Request $request)
    {
        DB::beginTransaction();
        try {
            $flow = ApprovalFlow::where('role_id', auth()->user()->role_id)->first();
            if (!$flow) {
                throw new \Exception('You are not in approval flow.', 400);
            }
            $datas = isset($_COOKIE['timesheet_approval']) ? json_decode($_COOKIE['timesheet_approval']) : [];
            // dd($datas);
            $sites = [];
            $periods = [];
            $volunteers = [];
            foreach ($datas as $da) {
                if ($da->name == "site") {
                    foreach ($da->value as $site) {
                        array_push($sites, $site);
                    }
                }
                if ($da->name == "period") {
                    foreach ($da->value as $period) {
                        array_push($periods, $period);
                    }
                }
                if ($da->name == "volunteer") {
                    foreach ($da->value as $volunteer) {
                        array_push($volunteers, $volunteer);
                    }
                }
            }
            $timesheets = Timesheet::whereIn('period_id', $periods)->whereIn('site_id', $sites)->whereIn('volunteer_id', $volunteers)->get();
            foreach ($timesheets as $timesheet) {
                $timesheet->is_queue = true;
                $timesheet->save();
            }
            $user = User::find(auth()->id());
            TimesheetApprovalSingleLabel::dispatch($periods, $sites, $volunteers, $user);
            DB::commit();
            return $this->response("Timesheet Approval Process is Running in Background", "view", 200);
        } catch (\Exception $e) {
            DB::rollback();
            if ($e->getCode() === 400) {
                return $this->response($e->getMessage(), 'error', 422);
            }
            return $this->response("TimeSheet cannot be approved", "error", 422);
        }
    }

    public function runQueueAll(Request $request)
    {
        DB::beginTransaction();
        try {
            $flow = ApprovalFlow::where('role_id', auth()->user()->role_id)->first();
            if (!$flow) {
                throw new \Exception('You are not in approval flow.', 400);
            }
            $datas = isset($_COOKIE['timesheet_approval']) ? json_decode($_COOKIE['timesheet_approval']) : [];
            // dd($datas);
            $sites = [];
            $periods = [];
            $volunteers = [];
            foreach ($datas as $da) {
                if ($da->name == "site") {
                    foreach ($da->value as $site) {
                        array_push($sites, $site);
                    }
                }
                if ($da->name == "period") {
                    foreach ($da->value as $period) {
                        array_push($periods, $period);
                    }
                }
                if ($da->name == "volunteer") {
                    foreach ($da->value as $volunteer) {
                        array_push($volunteers, $volunteer);
                    }
                }
            }
            $timesheets = Timesheet::whereIn('period_id', $periods)->whereIn('site_id', $sites)->whereIn('volunteer_id', $volunteers)->get();
            foreach ($timesheets as $timesheet) {
                $timesheet->is_queue = true;
                $timesheet->save();
            }
            $user = User::find(auth()->id());
            TimesheetApprovalAllLabel::dispatch($periods, $sites, $volunteers, $user);
            DB::commit();
            return $this->response("Timesheet Approval Process is Running in Background", "view", 200);
        } catch (\Exception $e) {
            DB::rollback();
            if ($e->getCode() === 400) {
                return $this->response($e->getMessage(), 'error', 422);
            }
            return $this->response("TimeSheet cannot be approved", "error", 422);
        }
    }

    public function approveSingle($periods, $sites, $volunteers, $user)
    {
        $request['period'] = $periods;
        $request['site'] = $sites;
        $request['volunteer'] = $volunteers;
        $r = new Request($request);
        $this->timesheetApprovalVolunteer1($r, $user, true);
    }

    public function approveSingleLabel($periods, $sites, $volunteers, $user)
    {
        try {
            $request['period'] = $periods;
            $request['site'] = $sites;
            $request['volunteer'] = $volunteers;
            $r = new Request($request);
            $this->timesheetAppr($r, $user, true);
        } catch (\Exception $e) { }
    }

    public function approveAllLabel($periods, $sites, $volunteers, $user)
    {
        try {
            $request['period'] = $periods;
            $request['site'] = $sites;
            $request['volunteer'] = $volunteers;
            $r = new Request($request);
            $this->timesheetApprovalCondition2($r, $user, true);
        } catch (\Exception $e) { }
    }

    public function timesheetApprCookie(Request $request)
    {
        DB::beginTransaction();
        try {
            $datas = isset($_COOKIE['timesheet_approval']) ? json_decode($_COOKIE['timesheet_approval']) : [];
            $data = collect($datas);
            $site = $data->where('name', 'site')->pluck('value')->collapse()->unique()->all();
            $period = $data->where('name', 'period')->pluck('value')->collapse()->unique()->all();
            $volunteer = $data->where('name', 'volunteer')->pluck('value')->collapse()->unique()->all();

            // dd($periods);
            $a = $this->timesheetAppr((object) compact('volunteer', 'site', 'period'), auth()->user(), true);
            DB::commit();
            if ($a) {
                return $this->response("TimeSheet Approved Successfully", "view", 200);
            } else {
                return $this->response("TimeSheet cannot be approved", "error", 422);
            }
        } catch (\Exception $e) {
            DB::rollback();
            if ($e->getCode() === 400) {
                return $this->response($e->getMessage(), "error", 422);
            }
            if ($e->getCode() === 403) {
                SiteSettings::firstOrNew([
                    'code' => 'eto_calculation_unit',
                    'is_deleted' => 0,
                    'section' => 'Timesheets'
                ]);
                return $this->response($e->getMessage(), 422);
            }
            return $this->response("TimeSheet cannot be approved", "error", 422);
        }
    }

    public function timesheetAppr($request, $user, $return = false)
    {
        DB::beginTransaction();
        try {
            $timesheets = Timesheet::select('*', DB::raw('time_to_sec(total_hrs) as timestamp'))
                ->whereIn('period_id', $request->period)
                ->whereIn('site_id', $request->site)
                ->whereIn('volunteer_id', $request->volunteer)->get();
            $approvals = ApprovalTable::whereIn('period_id', $request->period)
                ->whereIn('site_id', $request->site)
                ->whereIn('vol_id', $request->volunteer)
                ->where('user_approved_id', $user->id)
                ->where('current_approval_role', ucfirst($user->role->name))
                ->get();

            $flow = ApprovalFlow::where('role_id', $user->role_id)->first();
            
            if (!$flow) {
                throw new \Exception('You are not in approval flow.', 400);
            }
            foreach ($timesheets as $time) {
                $al = $approvals->where('period_id', $time->period_id)
                    ->where('site_id', $time->site_id)
                    ->where('vol_id', $time->volunteer_id)
                    ->where('user_approved_id', $user->id)
                    ->where('current_approval_role', ucfirst($user->role->name))->first();

                $oldData = $time->__toString();
                if ($user->role->name != "fiscal") {
                    $ac = ApprovalFlow::where('seq_num', $flow->seq_num + 1)->first();
                }
                $ac = isset($ac) ? $ac : $flow;
                if (!$al) {
                    $approval = new ApprovalTable();
                    $approval->timesheet_id = $time->timesheets_unq_id;
                    $approval->period_id = $time->period_id;
                    $approval->site_id = $time->site_id;
                    $approval->vol_id = $time->volunteer_id;
                    $approval->approval_flow_id = $flow->seq_num;
                    $approval->apprv_date = date('Y-m-d');
                    $approval->apprv_id = $user->id;
                    $approval->user_approved_id = $user->id;
                    if ($user->role->name == "fiscal") {
                        $approval->next_approval = "Ready For HSV";
                    } else {
                        $approval->next_approval = ucfirst($ac->role);
                    }
                    $approval->current_approval_role = ucfirst($user->role->name);

                    // foreach($data as $k=>$v){
                    //     $approval->$k = $v;
                    // }
                    // $approval->ip_address= $request->ip();
                    $approval->appr_stat = "Success";
                    $approval->save();
                } else {
                    $approval = false;
                }

                if ($user->role->id != 1) {
                    if ($user->role->name != "fiscal") {
                        $time->approval_status = ucfirst($user->role->name);
                        $time->next_approval = ucfirst($ac->role);
                        $time->status = "In Process";
                    } else {
                        $time->approval_status = "Fiscal";
                        $time->next_approval = "Ready For HSV";
                        $time->status = "Posted";
                    }
                } else {
                    $time->approval_status = ucfirst($user->role->name);
                    $time->next_approval = ucfirst($ac->role);
                }
                $time->approval_flow_id = $flow->seq_num;
                $time->is_queue = false;


                $time->save();
                $new_record = $time->__toString();
                (new TimeSheetRepo('Fgp\Timesheet'))->audit($time->id, $oldData, $new_record, $user->id);
            }
            
            $stipend = PayPeriod::find($request->period[0]);
            if (ucfirst($user->role->name) == "Fiscal") {
                $r = $request instanceof Request ? $request->only('period', 'site', 'volunteer') : (array) $request;
                $this->prepareForStipencalc($timesheets, $stipend, $r);
            }

            if ($user->role->id != 1) {
                $this->sendBulkMail($request, $user, $timesheets->first());
            }
            $this->timesheetApprovalNote($stipend, $user);
            DB::commit();

            if ($return) return true;
            return $this->response("TimeSheet Approved Successfully", "view", 200);
        } catch (\Exception $e) {
            DB::rollback();
            if ($e->getCode() === 400) {
                throw $e;
            }
            if ($e->getCode() === 403) {
                throw $e;
            }
            if ($return) return false;
            return $this->response("TimeSheet cannot be approved", "error", 422);
        }
    }

    public function timesheetApproveForAllLabel(Request $request)
    {
        $datas = isset($_COOKIE['timesheet_approval']) ? json_decode($_COOKIE['timesheet_approval']) : [];
        $data = collect($datas);
        // dd($datas);
        $sites = $data->where('name', 'site')->pluck('value')->collapse()->all();
        $periods = $data->where('name', 'period')->pluck('value')->collapse()->all();
        $volunteers = $data->where('name', 'volunteer')->pluck('value')->collapse()->all();

        $already = ApprovalTable::whereIn('period_id', $periods)->whereIn('site_id', $sites)->whereIn('vol_id', $volunteers)->orderBy('approval_flow_id')->pluck('approval_flow_id')->unique()->all();

        $flow = ApprovalFlow::where('role', auth()->user()->role->name)->first();
        if (!$flow) {
            $flow = ApprovalFlow::whereNotIn('seq_num', $already)->orderBy('seq_num')->first();
        }
        // $left = ApprovalFlow::whereNotIn('seq_num', $already)->orderBy('seq_num')->get();

        $roles = ApprovalFlow::whereNotIn('seq_num', $already)->where('seq_num', '<', $flow->seq_num)->get();
        
        
        $req = [];
        foreach ($roles as $r) {
            if ($r->role !== auth()->user()->role->name) {
                array_push($req, ucfirst($r->role));
            }
        }
        if (empty($r)) {
            $req = false;
        } else {
            $req = implode(',  ', $req);
        }
        return $this->view($this->clayout . '.modals.approvalConfirmation1', compact('roles', 'req'));
    }

    //timesheet approval conditiotn for volunteer wise
    public function timesheetApprovalCondition1(Request $request)
    {
        try {
            $datas = isset($_COOKIE['timesheet_approval']) ? json_decode($_COOKIE['timesheet_approval']) : [];
            $sites = [];
            $periods = [];
            $volunteers = [];
            $status = false;
            
            foreach ($datas as $da) {
                if ($da->name == "site") {
                    // json_decode($data, true);
                    foreach ($da->value as $site) {
                        array_push($sites, $site);
                    }
                }
                if ($da->name == "period") {
                    foreach ($da->value as $period) {
                        array_push($periods, $period);
                    }
                }
                if ($da->name == "volunteer") {
                    foreach ($da->value as $volunteer) {
                        array_push($volunteers, $volunteer);
                    }
                }
            }
            $request['period'] = array_unique($periods);
            $request['site'] = array_unique($sites);
            $request['volunteer'] = array_unique($volunteers);

            $a = $this->timesheetApprovalCondition2($request, auth()->user(), true);
            if ($a) {
                return $this->response("TimeSheet Approved Successfully", "view", 200);
            } else {
                return $this->response("TimeSheet Cannot be Approved", "error", 422);
            }
        } catch (\Exception $e) {
            if ($e->getCode() === 400) {
                return $this->response($e->getMessage(), "error", 422);
            }
            if ($e->getCode() === 403) {
                SiteSettings::firstOrCreate([
                    'code' => 'eto_calculation_unit',
                    'is_deleted' => 0,
                    'section' => 'TimeSheet'
                ]);
                return $this->response($e->getMessage(), "error", 422);
            }
            return $this->response("TimeSheet Cannot be Approved", "error", 422);
        }
    }

    public function timesheetApprovalCondition2(Request $request, $user, $return = false)
    {
        
        DB::beginTransaction();
        try {
            $status = false;
            // dd($request->all());
            $f = ApprovalFlow::where('role', $user->role->name)->first();
            if (!$f) {
                throw new \Exception('You are not in approval flow.', 400);
            }
            $approval_flows = ApprovalFlow::where('seq_num', '<=', $f->seq_num)->where('role', '!=', "supervisor")->get();
            // dd($approval_flows);
            foreach ($approval_flows as $flow) {
                $timesheets = Timesheet::whereIn('period_id', $request->period)->whereIn('site_id', $request->site)->whereIn('volunteer_id', $request->volunteer)->get();
                foreach ($timesheets as $time) {

                    $al = ApprovalTable::where('period_id', $time->period_id)->where('site_id', $time->site_id)->where('vol_id', $time->volunteer_id)->where('user_approved_id', $user->id)->where('current_approval_role', ucfirst($flow->role))->first();

                    $oldData = $time->__toString();
                    if ($flow->role != "fiscal") {
                        $ac = ApprovalFlow::where('seq_num', $flow->seq_num + 1)->first();
                    }
                    if (is_null($al)) {
                        $approval = new ApprovalTable();
                        $approval->timesheet_id = $time->timesheets_unq_id;
                        $approval->period_id = $time->period_id;
                        $approval->site_id = $time->site_id;
                        $approval->vol_id = $time->volunteer_id;
                        $approval->approval_flow_id = $flow->seq_num;
                        $approval->apprv_date = date('Y-m-d');
                        $approval->apprv_id = $user->id;
                        $approval->user_approved_id = $user->id;
                        if ($flow->role == "fiscal") {
                            $approval->next_approval = "Ready For HSV";
                            $status = true;
                        } else {
                            $approval->next_approval = ucfirst($ac->role);
                        }
                        $approval->current_approval_role = ucfirst($flow->role);

                        // foreach($data as $k=>$v){
                        //     $approval->$k = $v;
                        // }
                        // $approval->ip_address= $request->ip();
                        $approval->appr_stat = "Success";
                        $approval->save();
                    } else {
                        $approval = false;
                    }

                    if ($user->role->id != 1) {
                        if ($flow->role != "fiscal") {
                            $time->approval_status = ucfirst($flow->role);
                            $time->next_approval = ucfirst($ac->role);
                            $time->status = "In Process";
                        } else {
                            $time->approval_status = "Fiscal";
                            $time->next_approval = "Ready For HSV";
                            $time->status = "Posted";
                        }
                    } else {
                        $time->approval_status = ucfirst($flow->role);
                        $time->next_approval = ucfirst($ac->role);
                    }
                    $time->approval_flow_id = $flow->seq_num;
                    $time->is_queue = false;


                    $time->save();
                    $new_record = $time->__toString();
                    (new TimeSheetRepo('Fgp\Timesheet'))->audit($time->id, $oldData, $new_record, $user->id);
                }
                $stipend = PayPeriod::find($request->period[0]);
                if (ucfirst($flow->role) == "Fiscal" && $status) {
                    $this->prepareForStipencalc($timesheets, $stipend, $request->only('period', 'site', 'volunteer'));
                }
            }
            $stipend = PayPeriod::find($request->period[0]);
            if ($user->role->id != 1) {
                $this->sendBulkMail($request, $user);
            }
            $this->timesheetApprovalNote($stipend, $user);
            
            setCookie('timesheet_approval', '', time() - 100);
            DB::commit();
            return $this->response("Timesheet Approved Successfully", "view", 200);
        } catch (\Exception $e) {
            DB::rollback();
            if ($e->getCode() === 400) {
                throw $e;
            }
            if ($e->getCode() === 403) {
                throw $e;
            }
            return $this->response("TimeSheet cannot be approved", "error", 422);
        }
    }

    public function timesheetApprovalVolunteer(Request $request)
    {
        $data = isset($_COOKIE['timesheet_approval']) ? json_decode($_COOKIE['timesheet_approval']) : [];
        $ts = collect($data);

        $request['period'] = $ts->where('name', 'period')->pluck('value')->collapse()->unique()->all();
        $request['site'] = $ts->where('name', 'site')->pluck('value')->collapse()->unique()->all();
        $request['volunteer'] = $ts->where('name', 'volunteer')->pluck('value')->collapse()->unique()->all();

        $a = $this->timesheetApprovalVolunteer1($request, auth()->user(), true);
        if ($a) {
            return $this->response("TimeSheet Approved Successfully", "view", 200);
        } else {
            return $this->response("TimeSheet Cannot be Approved", "error", 422);
        }
    }

    public function timesheetApprovalVolunteer1(Request $request, $user, $return = false)
    {
        DB::beginTransaction();
        try {
            $timesheets = Timesheet::where('period_id', $request->period[0])
                ->whereIn('site_id', $request->site)
                ->whereIn('volunteer_id', $request->volunteer)
                ->get();

            foreach ($timesheets as $time) {
                $old_record = $time->__toString();

                $flow = ApprovalFlow::where('is_deleted', false)->where('role_id', $user->role_id)->first();
                $seq = $flow->seq_num;

                $ac = ApprovalFlow::firstOrNew(['seq_num' => $seq + 1]);
                $identity = [
                    'period_id' => $time->period_id,
                    'site_id' => $time->site_id,
                    'vol_id' => $time->volunteer_id,
                    'user_approved_id' => $user->id,
                ];
                $al = ApprovalTable::firstOrNew($identity);

                if (!$al->exists) {
                    $approval = save_update($al, [
                        'timesheet_id' => $time->timesheets_unq_id, 'approval_flow_id' => $flow->seq_num,
                        'current_approval_role' => ucfirst($flow->role),
                        'apprv_date' => date('Y-m-d'), 'appr_stat' => "Success",
                        'apprv_id' => $user->id, 'user_approved_id' => $user->id, 'next_approval' => ucfirst($ac->role),
                    ]);
                } else {
                    $approval = false;
                }

                if ($user->role->id != 1) {
                    $time->approval_status = ucfirst($user->role->name);
                    if ($user->role->name != "fiscal") {
                        $time->next_approval = $ac->role;
                    } else {
                        $time->next_approval = "Ready For HSV";
                    }
                } else {
                    //                    $time->approval_status = $first->next_approval;
                    $time->next_approval = ucfirst($ac->role);
                }
                $time->approval_flow_id = $seq;

                $time->status = "In Process";
                $time->is_queue = false;
                $time->save();
                $new_record = $time->__toString();

                (new TimeSheetRepo('Fgp\Timesheet'))->audit($time->timesheets_unq_id, $old_record, $new_record, $user->id);
            }
            $stipend = PayPeriod::find($request->period[0]);
            if ($user->role_id == 7) {
                $this->prepareForStipencalc($timesheets, $stipend, $request->only('period', 'site', 'volunteer'));
            }

            if ($user->role->id != 1) {
                $this->sendBulkMail($request, $user);
            }
            $this->timesheetApprovalNote($stipend, $user);
            DB::commit();
            //            dd($timesheets);
            if ($return) return true;
            return $this->response("TimeSheet Approved Successfully", "view", 200);
        } catch (\Exception $e) {
            DB::rollback();
            //            dd($e);
            if ($return) return false;
            return $this->response("TimeSheet cannot be approved", "error", 422);
        }
    }

    private function timesheetApprovalNote($stipend, $user = false)
    {
        $note = new Note();
        $note->period_id = $stipend->id;
        $note->note_code = "Timesheet Approval";
        $note->note_type = "Approval";
        $note->note_date = date('Y-m-d');
        $note->activity = "Timesheet Approval";
        $note->title = "Timesheet Approval of Stipend# " . $stipend->period_no . " by " . ucfirst($user->member->first_name) . ' ' . ucfirst($user->member->last_name) . '(' . $user->name . ')';
        $note->user_id = $user->id;
        $note->is_notification = true;
        $note->status = "Completed";
        $note->note_desc = 'Period ' . $stipend->period_no . ' from ' . date('m/d/Y', strtotime($stipend->start_date)) . ' - ' . date('m/d/Y', strtotime($stipend->end_date)) . ' of Timesheet has been approved by ' . ucfirst($user->member->first_name) . ' ' . ucfirst($user->member->last_name) . ' (' . ucfirst($user->role->name) . ')';
        $note->save();
    }

    protected function sendMail($timesheets, $stipend, $user = false)
    {
        try {
            $vol = [];
            $created_user = false;
            foreach ($timesheets as $tim) {
                $v = Volunteer::find($tim->volunteer_id);
                $v->his_site = Site::find($tim->site_id);
                $v->his_period = PayPeriod::find($tim->period_id);
                array_push($vol, $v);
                if (!$created_user) $created_user = User::find($tim->userc_id);
            }
            $vol = array_unique($vol);
            if ($user) {
                \Mail::to($user->email)->send(new ApprovalMail($created_user, $user, $stipend, $vol));
            } else {
                if (auth()->user()->role->name != "fiscal") {
                    foreach (auth()->user()->reportingMgr as $mgr) \Mail::to($mgr->email)->send(new ApprovalMail($created_user, $mgr, $stipend, $vol));
                }
            }
        } catch (\Exception $e) {
            //            throw $e;
            return $this->response($e->getMessage(), 'view', 422);
        }
    }

    private function sendBulkMail($request, $user, $timesheets = null)
    {
        $stipend = PayPeriod::find($request->period[0]);
        $sites = array_unique($request->site);

        $vols = Volunteer::whereIn('id', $request->volunteer)->with(['sites' => function ($s) use ($sites) {
            $s->select('sites.id', 'sites.site_name')->whereIn('volunteer_sites.site_id', $sites);
        }])->get();

        $created_user = $timesheets ?: Timesheet::where('period_id', $stipend->id)->whereIn('site_id', $sites)->whereIn('volunteer_id', $vols)->first();
        $created_user1 = User::find($created_user->userc_id);
        foreach ($vols as $vol) {
            $vol->site = implode(',', $vol->sites->pluck('site_name')->unique()->all());
        }

        $emails = $this->sendMailToAll($user);
        foreach ($emails as $email) {
            if ($email !== $user->email) {
                \Mail::to($email)->send(new ApprovalMail($created_user1, $user, $stipend, $vols));
                //                sleep(5);
            }
        }
        $this->makeLogForAll($stipend, $user, $emails, 'Success');
        Notification::timesheetApprovalNotificationsToAll($stipend, $user, $emails);
    }

    protected function sendMailToAll(User $user)
    {
        try {
            $emails = [];
            if ($user->role->name == "supervisor") {

                // supervisor // manager // director // fiscal
                $emails = $user->reportingMgr()->with(['reportingMgr' => function ($dir) {
                    $dir->with('reportingMgr');
                }])->get()->map(function ($manager) {
                    // fiscals + director + manager
                    return $manager->reportingMgr->map(function ($director) {
                        //fiscals + director
                        return $director->reportingMgr->pluck('email')->merge($director->email);
                    })->collapse()->merge($manager->email);
                })->collapse()->merge($user->email)->unique()->all();
            } elseif ($user->role->name == "manager") {
                // manager // fiscal // director
                $emails = $user->reportingMgr()->with('reportingMgr')->get()->map(function ($director) {
                    // fiscals + director
                    return $director->reportingMgr->pluck('email')->merge($director->email);
                })->collapse()->merge($user->email);

                $sup_emails = $user->reportingMgrOf->pluck('email');
                $emails = $emails->merge($sup_emails)->unique()->all();
            } elseif ($user->role->name == "director") {
                // director // fiscal
                $emails = $user->reportingMgr->pluck('email')->merge($user->email)->unique();

                $managers = $user->reportingMgrOf()->with('reportingMgrOf')->get()->map(function ($manager) {
                    // supervisors + manager
                    return $manager->reportingMgrOf->pluck('email')->merge($manager->email);
                })->collapse();

                $emails = $emails->merge($managers)->unique()->all();
            } elseif ($user->role->name == "fiscal") {
                //fiscal // director // manager // supervisor
                $emails = $user->reportingMgrOf()->with(['reportingMgrOf' => function ($mgr) {
                    $mgr->with('reportingMgrOf');
                }])->get()->map(function ($director) {
                    // supervisor + manager + director
                    return $director->reportingMgrOf->map(function ($manager) {
                        // supervisor + manager
                        return $manager->reportingMgrOf->pluck('email')->merge($manager->email);
                    })->collapse()->merge($director->email);
                })->collapse()->unique()->all();
            }
            return $emails;
        } catch (\Exception $e) {
            throw $e;
            //            return $this->response($e->getMessage(), 'view', 422);
        }
    }

    protected function makeLogForAll($stipend, $from, $emails, $status)
    {
        foreach ($emails as $email) {
            $emailLog = new EmailLog();
            $emailLog->table = $stipend->getTable();
            $emailLog->table_id = $stipend->id;
            $emailLog->from = $from->email;
            $emailLog->to = $email;
            $emailLog->sub = "Timesheet Approval";
            $emailLog->msg = "Stipend period of " . $stipend->period_no . " from " . date('m/d/Y', strtotime($stipend->start_date)) . " - " . date('m/d/Y', strtotime($stipend->end_date)) . " of timesheet has been " . $status . " by " . ucfirst($from->member->first_name) . ' ' . ucfirst($from->member->last_name) . " (" . ucfirst($from->role->name) . ")";
            $emailLog->sent_status = $status;
            $emailLog->sent_date = date('Y-m-d');
            $emailLog->save();
        }
    }

    protected function getConfig()
    {
        $emailsettings = EmailSettingsModel::first();
        $config = ['driver' => 'smtp', 'host' => $emailsettings->server, 'username' => $emailsettings->email, 'password' => $emailsettings->password, 'port' => '587', 'encryption' => 'tls'];
        return $config;
        throw  new \Exception('Email Setting Not Found');
    }

    protected function makeLog($stipend, $to, $status)
    {
        $emailLog = new EmailLog();
        $emailLog->table = $stipend->getTable();
        $emailLog->table_id = $stipend->id;
        $emailLog->from = auth()->user()->email;
        $emailLog->to = $to;
        $emailLog->sub = "Timesheet Approval";
        $emailLog->msg = "Stipend period of " . $stipend->period_no . " from " . date('m/d/Y', strtotime($stipend->start_date)) . " - " . date('m/d/Y', strtotime($stipend->end_date)) . " of timesheet has been " . $status . " by " . ucfirst(auth()->user()->member->first_name) . ' ' . ucfirst(auth()->user()->member->last_name) . " (" . ucfirst(auth()->user()->role->name) . ")";
        $emailLog->sent_status = $status;
        $emailLog->sent_date = date('Y-m-d');
        $emailLog->save();
    }

    protected function prepareForStipencalc($timesheets, $stipend, $request)
    {
        // new methods to calc
        $this->request = $request;
        $calcStipend = $this->calcStipend($stipend);
        $this->calcStipendSites($calcStipend);
        $this->calcStipendVols($calcStipend);
        return true;

        $sites = [];
        $vols = [];
        $hr = 0;
        $amt = [];
        $eto_earned = 0;
        $calc = new StipendCalc();
        $calc->period_unq_id = $stipend->id;
        $calc->start_date = $stipend->start_date;
        $calc->end_date = $stipend->end_date;
        $datas = [];

        $stipend_calc_type = []; // stipend calc type

        foreach ($timesheets as $time) {
            array_push($sites, $time->site_id);
            array_push($vols, $time->volunteer_id);
            $hr = $hr + $time->timestamp;
            array_push($amt, $time->total_amount);
            $datas[$time->site_id] = $time->volunteer_id;

            // if ($time->type === 'regular_time') $eto_earned += $time->timestamp;
            if (strtolower($time->type) === 'stipends') $eto_earned += $time->timestamp;

            // stipend calc type
            if (!isset($stipend_calc_type[$time->type])) {
                $stipend_calc_type[$time->type] = 0;
            }
            $calc_type =  &$stipend_calc_type[$time->type];

            $calc_type += $time->timestamp;
        }
        $calc->time_total = $hr / 3600;
        $calc->eto_earned = ($eto_earned / 3600) * 0.1724;
        $calc->time_total_amt = array_sum($amt);
        $sitess = array_unique($sites);
        $volss = array_unique($vols);
        $calc->save();

        /* stipend calc type */
        $hold_bulk = [];
        foreach ($stipend_calc_type as $c_type => $hrs_value) :
            array_push($hold_bulk, array('table_name' => 'stipend_calcs', 'table_id' => $calc->id, 'type_name' => $c_type, 'total_hrs' => $hrs_value / 3600));
        endforeach;
        StipendCalcTypes::insert($hold_bulk);
        /* end stipend calc type */

        $totals = [];
        foreach ($timesheets as $time) {
            if (isset($time->timesheetItems)) {
                foreach ($time->timesheetItems as $items) {
                    $calcItem = new StipendCalcItems();
                    $calcItem->stipend_calc_id = $calc->id;
                    $calcItem->stipend_item_id = $items->stipend_item_id;
                    $calcItem->item_type = $items->type;
                    $calcItem->item_name = $items->value;
                    $calcItem->totals = $items->amount;
                    $calcItem->save();
                }
                array_push($totals, $time->timesheetItems->sum('amount'));
            }
        }

        foreach ($sitess as $site) {
            $hr1 = 0;
            $amt1 = [];
            $itemtotal = [];
            $eto_earned = 0;
            $eto_used = 0;
            $site_stipend_calc_type = []; // stipend calc type
            $s = new StipendCalcSites();
            $s->site_id = $site;
            $s->period_id = $stipend->id;
            $s->stipend_calc_id = $calc->id;
            $items = Timesheet::select('*', DB::raw('time_to_sec(total_hrs) as timestamp'))->where('period_id', $stipend->id)->where('site_id', $site)->get();
            foreach ($items as $item) {
                array_push($itemtotal, $item->timesheetItems->sum('amount'));
                $hr1 = $hr1 + $item->timestamp;
                array_push($amt1, $item->total_amount);

                if (strtolower($item->type) === 'stipends') $eto_earned += $item->timestamp;

                if (!isset($site_stipend_calc_type[$item->type])) {
                    $site_stipend_calc_type[$item->type] = 0;
                }
                $site_calc_type = &$site_stipend_calc_type[$item->type];
                $site_calc_type += $item->timestamp;
            }

            /* site stipend calc type */
            $hold_bulk = [];
            foreach ($site_stipend_calc_type as $c_type => $hrs_value) :
                array_push($hold_bulk, array('table_name' => 'sites', 'table_id' => $site, 'stipend_calc_id' => $calc->id, 'type_name' => $c_type, 'total_hrs' => $hrs_value / 3600));
            endforeach;
            StipendCalcTypes::insert($hold_bulk);
            /* end site stipend calc type */

            $s->eto_earned = ($eto_earned / 3600) * 0.1724;


            $s->time_total = $hr1 / 3600;
            $s->time_total_amt = array_sum($amt1);
            $s->items_amount_total = array_sum($itemtotal);
            $s->total = $s->time_total_amt + $s->items_amount_total;
            $s->save();
        }

        $stipendTimesheets = Timesheet::select('volunteer_id', 'site_id', 'period_id')->distinct()->where('period_id', $stipend->id)->whereIn('site_id', $sitess)->whereIn('volunteer_id', $volss)->with('volunteer')->get();
        foreach ($stipendTimesheets as $time) {
            $hr2 = 0;
            $amt2 = [];
            $itemtotal = [];
            $eto_earned = 0;
            $eto_used = 0;
            $vol_stipend_calc_type = [];

            $vol = StipendCalcVols::where('period_id', $time->period_id)->where('site_id', $time->site_id)->where('vol_id', $time->volunteer_id)->first();
            if (true) {
                $v = $vol ?: new StipendCalcVols();
                $volunteer = $time->volunteer;
                $v->period_id = $stipend->id;
                $v->site_id = $time->site_id;
                $v->vol_id = $time->volunteer_id;
                $v->stipend_calc_id = $calc->id;
                $items = Timesheet::select('*', 'type as time_type', DB::raw('time_to_sec(total_hrs) as timestamp'))->where('period_id', $stipend->id)->where('site_id', $time->site_id)->where('volunteer_id', $time->volunteer_id)->get();
                foreach ($items as $item) {
                    array_push($itemtotal, $item->timesheetItems->sum('amount'));
                    $hr2 = $hr2 + $item->timestamp;
                    array_push($amt2, $item->total_amount);

                    if (strtolower($item->type) === 'stipends') $eto_earned += $item->timestamp;
                    elseif ($item->type === 'ETO') $eto_used += $item->timestamp;

                    // vol stipend calc type
                    if (!isset($vol_stipend_calc_type[$item->time_type])) {
                        $vol_stipend_calc_type[$item->time_type] = 0;
                    }
                    $vol_stipend_calc_type[$item->time_type] += $item->timestamp;
                }
                $v->time_total = $hr2 / 3600;

                /* volunteers eto */
                $v->eto_earned = ($eto_earned / 3600) * 0.1724;
                $eto_balance = $vol;
                $eto_balance = $eto_balance ? $eto_balance->eto_balance : $volunteer->opening_eto_bal;
                $v->eto_used = $eto_used / 3600;
                $v->eto_balance = ($eto_balance + $v->eto_earned) - $v->eto_used;
                $v->fiscal_year = $stipend->fiscal_year;
                /* end volunteers eto */

                /* vol stipend calc type */
                $hold_bulk = [];
                foreach ($vol_stipend_calc_type as $c_type => $hrs_value) :
                    array_push($hold_bulk, array('table_name' => 'volunteers', 'table_id' => $time->volunteer_id, 'stipend_calc_id' => $calc->id, 'type_name' => $c_type, 'total_hrs' => $hrs_value / 3600));
                endforeach;
                StipendCalcTypes::insert($hold_bulk);
                /* end vol stipend calc type */

                $v->time_total_amt = array_sum($amt2);
                $v->items_amount_total = array_sum($itemtotal);
                $v->total = $v->time_total_amt + $v->items_amount_total;
                $v->save();
            }
        }
        $calc->amt_total = array_sum($totals);
        $calc->total = $calc->amt_total + $calc->time_total_amt;
        $calc->save();
    }

    private function calcStipend($stipend)
    {
        $period_id = $stipend->id;
        $stipend_calc_type = [];
        $eto_types = StipendItem::where('is_eto', 1)->where('is_deleted', 0)->pluck('id')->all();
        $eto_unit = SiteSettings::firstOrNew([
            'code' => 'eto_calculation_unit',
            'is_deleted' => 0,
        ]);

        throw_if(!is_numeric($eto_unit->value), new Exception('ETO calculation unit is not configured.', 403));
        $eto_unit = (float) $eto_unit->value;

        $total = Timesheet::where('period_id', $period_id)->where('next_approval', 'Ready For HSV')->where('type_label', '!=', 'Vacation Time')->sum(DB::raw('time_to_sec(total_hrs)'));
        $amt_total = Timesheet::where('period_id', $period_id)->where('next_approval', 'Ready For HSV')->where('type_label', '!=', 'Vacation Time')->sum(DB::raw('total_amount'));
        $eto_earned = Timesheet::where('period_id', $period_id)->where('next_approval', 'Ready For HSV')->whereIn('type_label', $eto_types)->sum(DB::raw('time_to_sec(total_hrs)'));
        $items_total = Timesheet::select('id')->where('next_approval', 'Ready For HSV')->whereIn('type_label', $eto_types)->withCount(['timesheetItems'  => function ($items) {
            $items->select(DB::raw('sum(amount)'));
        }])->where('period_id', $period_id)->where('type_label', '!=', 'Vacation Time')->get()->sum('timesheet_items_count');

        $total /= 3600;
        $eto_earned /= 3600;
        $eto_earned *= $eto_unit;

        $calc = save_update(new StipendCalc, [
            'period_unq_id' => $period_id, 'start_date' => $stipend->start_date, 'end_date' => $stipend->end_date,
            'eto_earned' => numeric_format($eto_earned),
            'time_total' => numeric_format($total),
            'amt_total' => numeric_format($items_total),
            'time_total_amt' => numeric_format($amt_total),
            'total' => numeric_format($amt_total + $items_total),
            'approved_id' => auth()->id(), 'approved_date' => date('Y-m-d'),
        ]);

        $this->saveTypes(['table_id' => $calc->id, 'table_name' => 'stipend_calcs'], ['period_id' => $period_id]);

        $this->saveItems($calc);
        return $calc;
    }

    private function calcStipendSites($calcStipend)
    {
        $period_id = $calcStipend->period_unq_id;
        $sites = Timesheet::select('site_id')->distinct()->where('period_id', $period_id)->where('next_approval', 'Ready For HSV')->whereIn('site_id', $this->request['site'])->pluck('site_id');
        $calcSites = [];

        $eto_types = StipendItem::where('is_eto', 1)->where('is_deleted', 0)->pluck('id')->all();
        $eto_unit = SiteSettings::firstOrNew([
            'code' => 'eto_calculation_unit',
            'is_deleted' => 0,
        ]);
        
        throw_if(!is_numeric($eto_unit->value), new Exception('ETO calculation unit is not configured.', 403));
        $eto_unit = (float) $eto_unit->value;

        foreach ($sites as $site) :
            $total = Timesheet::where(['period_id' => $period_id, 'site_id' => $site])->where('next_approval', 'Ready For HSV')
            ->where('type_label', '!=', 'Vacation Time')->sum(DB::raw('time_to_sec(total_hrs)'));
            $amt_total = Timesheet::where(['period_id' => $period_id, 'site_id' => $site])->where('next_approval', 'Ready For HSV')
            ->where('type_label', '!=', 'Vacation Time')->sum(DB::raw('total_amount'));
            $eto_earned = Timesheet::where(['period_id' => $period_id, 'site_id' => $site])->where('next_approval', 'Ready For HSV')->whereIn('type_label', $eto_types)->sum(DB::raw('time_to_sec(total_hrs)'));
            $items_total = Timesheet::select('id')->where('type_label', '!=', 'Vacation Time')->where('next_approval', 'Ready For HSV')->withCount(['timesheetItems'  => function ($items) {
                $items->select(DB::raw('sum(amount)'));
            }])->where(['period_id' => $period_id, 'site_id' => $site])->get()->sum('timesheet_items_count');

            $total /= 3600;
            $eto_earned /= 3600;
            $eto_earned *= $eto_unit;
            $calcStipendSite = save_update(new StipendCalcSites, ['period_id' => $period_id, 'stipend_calc_id' => $calcStipend->id, 'site_id' => $site, 'eto_earned' => number_format($eto_earned, 2, '.', ''), 'time_total' => number_format($total, 2, '.', ''), 'time_total_amt' => number_format($amt_total, 2, '.', ''), 'items_amount_total' => number_format($items_total, 2, '.', ''), 'total' => number_format($amt_total + $items_total, 2, '.', '')]);

            $this->saveTypes(['table_id' => $calcStipendSite->id, 'table_name' => 'sites', 'stipend_calc_id' => $calcStipend->id], ['period_id' => $period_id, 'site_id' => $site]);

            $calcSites[] = $calcStipendSite;
        endforeach;
        return $calcSites;
    }

    /* stipend calc type */
    private function saveTypes($data, $cond = [])
    {
        $hold_bulk = [];
        $time_types = StipendItem::where(['is_deleted' => 0, 'category' => 'Type'])->pluck('item_name', 'id');
        foreach ($time_types as $key => $title) :
            $time = Timesheet::where($cond)->where('next_approval', 'Ready For HSV')->where('type_label', $key)->sum(DB::raw('time_to_sec(total_hrs)'));
            array_push($hold_bulk, array('type_name' => $title, 'total_hrs' => numeric_format($time / 3600)) + $data);
        endforeach;
        StipendCalcTypes::insert($hold_bulk);
    }

    // stipend items
    private function saveItems($calc)
    {
        $period_id = $calc->period_unq_id;
        $items = Timesheet::select('tsi.type', 'tsi.stipend_item_id', 'tsi.value', DB::raw('sum(tsi.amount) as amount'))
            ->join('time_sheet_items as tsi', 'tsi.time_sheet_id', 'timesheets.id')
            ->where('timesheets.period_id', $period_id)
            ->where('timesheets.next_approval', 'Ready For HSV')
            ->groupBy('tsi.type')
            ->get();
        $itemArr = [];
        foreach ($items as $item) {
            $itemArr[] = [
                'stipend_calc_id' => $calc->id,
                'stipend_item_id' => $item->stipend_item_id,
                'item_type' => $item->type,
                'item_name' => $item->value,
                'totals' => numeric_format($item->amount),
                'created_at' => now(),
                'updated_at' => now(),
            ];
        }
        StipendCalcItems::insert($itemArr);
    }

    private function calcStipendVols($calcStipend)
    {
        $calcVols = [];
        $periods = Timesheet::select('period_id', 'site_id', 'volunteer_id', 'userc_id')->with('pay_period', 'user')->where('period_id', $calcStipend->period_unq_id)->where('next_approval', 'Ready For HSV')->whereIn('site_id', $this->request['site'])->whereIn('volunteer_id', $this->request['volunteer'])->distinct()->get();

        $eto_types = StipendItem::where('is_eto', 1)->where('is_deleted', 0)->pluck('id')->all();
        $eto_unit = SiteSettings::firstOrNew([
            'code' => 'eto_calculation_unit',
            'is_deleted' => 0,
        ]);
        
        throw_if(!is_numeric($eto_unit->value), new Exception('ETO calculation unit is not configured.', 403));
        $eto_unit = (float) $eto_unit->value;

        foreach ($periods as  $loop => $p) :
            $period_id = $p->period_id;
            $site = $p->site_id;
            $vol = $p->volunteer_id;
            $volunteer = Volunteer::find($vol);
            $createdByUser = $p->user->role_id == 3 ? $p->user->id : (($d_site = $volunteer->defaultSite()) ? $d_site->users()->first()->id??'0' : '0');

            // $svol = StipendCalcVols::where('period_id', $period_id)->where('site_id', $site)->where('vol_id', $vol)->first();
            $svol = StipendCalcVols::where('vol_id', $vol)->orderByDesc('created_at')->first();

            $total = Timesheet::where(['period_id' => $period_id, 'site_id' => $site, 'volunteer_id' => $vol])->where('next_approval', 'Ready For HSV')->sum(DB::raw('time_to_sec(total_hrs)'));
            $amt_total = Timesheet::where(['period_id' => $period_id, 'site_id' => $site, 'volunteer_id' => $vol])->where('next_approval', 'Ready For HSV')->sum(DB::raw('total_amount'));
            $eto_earned = Timesheet::where(['period_id' => $period_id, 'site_id' => $site, 'volunteer_id' => $vol])->where('next_approval', 'Ready For HSV')->whereIn('type_label', $eto_types)->sum(DB::raw('time_to_sec(total_hrs)'));
            $eto_used = Timesheet::where(['period_id' => $period_id, 'site_id' => $site, 'volunteer_id' => $vol])->where('next_approval', 'Ready For HSV')->where('type', 'eto')->sum(DB::raw('time_to_sec(total_hrs)'));
            $items_total = Timesheet::select('id')->where('next_approval', 'Ready For HSV')->withCount(['timesheetItems'  => function ($items) {
                $items->select(DB::raw('sum(amount)'));
            }])->where(['period_id' => $period_id, 'site_id' => $site, 'volunteer_id' => $vol])->get()->sum('timesheet_items_count');

            $total /= 3600;
            $eto_earned /= 3600;
            $eto_earned *= $eto_unit;
            $eto_used /= 3600;
            $eto_bal = $svol ? $svol->eto_balance : $volunteer->opening_eto_bal;
            $eto_bal += $eto_earned;
            $eto_bal -= $eto_used;

            $calcVol  = save_update(new StipendCalcVols, ['period_id' => $period_id, 'site_id' => $site, 'vol_id' => $vol, 'stipend_calc_id' => $calcStipend->id, 'fiscal_year' => $p->pay_period->fiscal_year, 'time_total' =>  numeric_format($total), 'eto_earned' =>  numeric_format($eto_earned), 'eto_used' =>  numeric_format($eto_used), 'eto_balance' =>  numeric_format($eto_bal), 'time_total_amt' =>  numeric_format($amt_total), 'items_amount_total' =>  numeric_format($items_total), 'total' =>  numeric_format($amt_total + $items_total), 'userc_id' => $createdByUser]);

            save_update($volunteer, ['eto_calc' =>  numeric_format($eto_bal)]);

            $this->saveTypes(
                ['table_id' => $calcVol->id, 'table_name' => 'volunteers', 'stipend_calc_id' => $calcStipend->id], 
                ['period_id' => $period_id, 'site_id' => $site, 'volunteer_id' => $vol]
            );

            $calcVols[] = $calcVol;
        endforeach;
        return $calcVols;
    }
}
