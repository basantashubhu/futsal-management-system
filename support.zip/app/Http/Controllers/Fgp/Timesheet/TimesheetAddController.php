<?php

namespace App\Http\Controllers\Fgp\Timesheet;

use App\Http\Controllers\BaseController;
use App\Models\Fgp\Holiday;
use App\Models\Fgp\PayPeriod;
use App\Models\Fgp\Site;
use App\Models\Fgp\StipendItem;
use App\Models\Fgp\Template;
use App\Models\Fgp\Timesheet;
use App\Models\Fgp\TimeSheetItem;
use App\Models\Fgp\Volunteer;
use App\Models\Settings\Lookups;
use App\Models\UserSettings;
use App\Repo\TimeSheetRepo;
use App\Services\FileService;
use App\Timesheet\TimesheetContainer;
use Exception;
use Illuminate\Http\Request;use Illuminate\Http\Response;use Illuminate\Support\Facades\DB;

class TimesheetAddController extends BaseController
{

    private static $repo;

    public function __construct()
    {
        parent::__construct();
        $this->layout .= '.fgp.timesheet';
    }

    public static function getRepo($model)
    {

        self::$repo = new TimesheetRepo($model);

        return self::$repo;

    }

    private function timesheetItemDetail($type, $value)
    {

        $stipenditems = StipendItem::where('category', $type)->where('item_name', $value)->first();

        return $stipenditems;
    }

    /**
     * Create Timesheet item
     *
     * @param $type
     * @param $value
     * @param $template_id
     * @return void
     */
    protected function createTimeSheetItem($type, $value, $template_id)
    {

        $stipendItem = $this->timesheetItemDetail($type, $value);

        $timesheetItem = new TimeSheetItem;

        $timesheetItem->create([

            'time_sheet_id' => $template_id,
            'type' => $stipendItem->category,
            'code' => $stipendItem->fund_code,
            'name' => $stipendItem->item_name,
            'value' => $stipendItem->item_name,

        ]);

    }

    private function getTimesheetUnqId($period)
    {

        $has_uniq_id = Timesheet::where('period_id', $period)->latest()->first();

        if ($has_uniq_id) {

            return $has_uniq_id->timesheets_unq_id;

        } else {

            $latestTs = Timesheet::orderByDesc('id')->first();

            return $latestTs ? $latestTs->timesheets_unq_id + 1 : 1;

        }

    }

    private function getStipendRate()
    {
        return getSiteSettings('stipend_rate');
    }

    private function calculateAmount($total_hrs)
    {

        if ($total_hrs == 0) {
            $total_hrs = '0:00';
        }

        $stipend_rate = getSiteSettings('stipend_rate');

        $total_hr = explode(':', $total_hrs);

        if (!isset($total_hr[1])) { // if totalhr is stored in decimal 1.20

            $total_hr = explode('.', $total_hrs);

        }

        $actual_hr = $total_hr[0] + ((isset($total_hr[1]) ? ($total_hr[1] / 60) : 0));

        return $actual_hr * $stipend_rate;

    }

    public function getStipendItemCode($id)
    {
        return StipendItem::findOrFail($id)->item_code;
    }

    public function getStipendItemId($category, $uuid)
    {
        return $uuid;
    }

    public function getStipendLookupId($category, $uuid)
    {

        $lookup = Lookups::where('value', $category)->where('code', "CodeCategory")->first();
        if (!$lookup) {
            $item = StipendItem::find($uuid);
            $lookup = Lookups::where('value', $item->category)->where('code', "CodeCategory")->first();
        }
        return $lookup->id;
    }

    public function saveSingleTimesheet(Request $request, Volunteer $volunteer, $period)
    {

        $timesheetContainer = app(TimesheetContainer::class);
        DB::beginTransaction();

        try {

            $items = $request->item;

            $stipend_items = [];

            $existing_ts = [];

            if (isset($items['label'])) {
                /* Transforming into siteid[date][item_name]->value & amount*/
                foreach ($items['label'] as $site_id => $ts_items) {
                    foreach ($ts_items as $date => $value) {

                        foreach ($value as $key => $stipend_item) {
                            // Format date just in case

                            $stipend_items[$site_id][date_create($date)->format("m/d/y")][$stipend_item]['value'] = isset($items['value'][$site_id][$date][$key]) ? $items['value'][$site_id][$date][$key] : '';

                            $stipend_items[$site_id][date_create($date)->format("m/d/y")][$stipend_item]['amount'] = isset($items['amount'][$site_id][$date][$key]) ? $items['amount'][$site_id][$date][$key] : '';
                        }
                    }
                }
            }

            unset($request['item']);

            $timesheets = $this->bulkFormatter($request->all());
            $per = PayPeriod::find($period);

            if (request()->has('is_loaded')) {

                $ts_unq_id = $this->getTimesheetUnqId($period);

                foreach ($timesheets as $key => $ts) {

                    $old_ts = $this->checkTimesheetExists($per, $volunteer, $ts['site'], date('Y-m-d', strtotime($ts['date'])));
                    

                    //Update the old timesheet

                    if ($old_ts) {

                        $this->updateTs($old_ts, $ts);

                        $existing_ts[$ts['site']][] = [$old_ts->timesheets_unq_id, $old_ts->id, $volunteer->id];

                        $current_stp_itm = isset($stipend_items[$ts['site']][$ts['date']]) ? $stipend_items[$ts['site']][$ts['date']] : [];

                        foreach ($current_stp_itm as $type => $value_arr) {
                            $stipendItem = StipendItem::findOrFail($value_arr['value']);

                            TimeSheetItem::create([
                                'time_sheet_id' => $old_ts->id,
                                'type' => $type,
                                'code' => $stipendItem['item_code'],
                                'stipend_item_id' => $stipendItem['id'],
                                'stipend_lookup_id' => $this->getStipendLookupId($type, $value_arr['value']),
                                'value' => $stipendItem['id'],
                                'amount' => $value_arr['amount'] ?? $stipendItem['unit_amount'],
                            ]);
                        }

                        continue;
                    }

                    /* Create new timesheet if ts doesn't exits */

                    $args = [

                        'volunteer' => $volunteer,
                        'ts_unq_id' => $ts_unq_id,
                        'site_id' => $ts['site'],
                        'period_id' => $period,
                        'template' => $ts,
                        'start_date' => date('Y-m-d', strtotime($ts['date'])),

                    ];

                    $newTimesheetId = $this->saveNewTs($args);

                    $newTs = Timesheet::find($newTimesheetId);

                    $existing_ts[$ts['site']][] = [$newTs->timesheets_unq_id, $newTs->id, $volunteer->id];

                    $current_stp_itm = isset($stipend_items[$ts['site']][$ts['date']]) ? $stipend_items[$ts['site']][$ts['date']] : [];

                    foreach ($current_stp_itm as $type => $value_arr) {

                        $stipendItem = StipendItem::findOrFail($value_arr['value']);
                        TimeSheetItem::create([
                            'time_sheet_id' => $newTimesheetId,
                            'type' => $type,
                            'code' => $stipendItem['item_code'],
                            'stipend_item_id' => $stipendItem['id'],
                            'stipend_lookup_id' => $this->getStipendLookupId($type, $value_arr['value']),
                            'value' => $stipendItem['id'],
                            'amount' => $value_arr['amount'] ?? $stipendItem['unit_amount'],
                        ]);
                    }

                }

                $this->removeNonExistingTs($existing_ts);

                DB::commit();
                return response(["message" => "timesheet Successfully created"], 200);

            }

            /* Save update here */
            $ts_unq_id = $this->getTimesheetUnqId($period);

            $invalidErrorBag = []; //Array of Time In's that are already existed

            foreach ($timesheets as $key => $timesheet) {
                
                if (array_key_exists('template_id', $timesheet)) {

                    $old_ts = Timesheet::find($timesheet['template_id']);

                    /*

                    if timesheet already exists then update
                    if it doesnt exists then create
                    push both id's remaining templates should be deleted

                     */

                    if ($old_ts) {

                        $tempStipend = StipendItem::findOrFail($timesheet['time_type']);

                        $old_ts_string = "$old_ts";

                        $old_ts->update([
                            'type_label' => $tempStipend['id'],
                            'type' => $tempStipend['item_code'],
                            'time_in' => $timesheet['time_in'],
                            'time_out' => $timesheet['time_out'],
                            'break_in' => $timesheet['break_in'],
                            'break_out' => $timesheet['break_out'],
                            'site_id' => $timesheet['site'],
                            'total_hrs' => $timesheet['total_hr'],
                            'comment' => $timesheet['comment'],
                            'date' => date('Y-m-d', strtotime($timesheet['date'])),
                            'rates' => getSiteSettings('stipend_rate'),
                            'total_amount' => $this->calculateAmount($timesheet['total_hr']),
                        ]);

                        $new_ts_string = "$old_ts";

                        (new TimeSheetRepo('Fgp\Timesheet'))->audit($old_ts->id, $old_ts_string, $new_ts_string, auth()->id());

                        /* Delete old ts items*/

                        $ts_items = TimeSheetItem::where('time_sheet_id', $old_ts->id)->delete();

                        $existing_ts[$timesheet['site']][] = [$old_ts->timesheets_unq_id, $old_ts->id, $volunteer->id];

                        $current_stp_itm = isset($stipend_items[$timesheet['site']][$timesheet['date']]) ? $stipend_items[$timesheet['site']][$timesheet['date']] : [];

                        foreach ($current_stp_itm as $type => $value_arr) {
                            if ($type) {

                                $stipendItem = StipendItem::findOrFail($value_arr['value']);

                                TimeSheetItem::create([

                                    'time_sheet_id' => $timesheet['template_id'],
                                    'type' => $type,
                                    'code' => $stipendItem['item_code'],
                                    'stipend_item_id' => $stipendItem['id'],
                                    'stipend_lookup_id' => $this->getStipendLookupId($type, $value_arr['value']),
                                    'value' => $stipendItem['id'],
                                    'amount' => $value_arr['amount'] ?? $stipendItem['unit_amount'],

                                ]);
                            }

                        }

                    } else {

                        // insert newly added ts row
                        $timesheetDate = date('Y-m-d', strtotime($timesheet['date']));

                        // $updated_ts_unq_id = $generated_unq_id;

                        $args = [

                            'volunteer' => $volunteer,
                            'ts_unq_id' => $ts_unq_id,
                            'site_id' => $timesheet['site'],
                            'period_id' => $period,
                            'template' => $timesheet,
                            'start_date' => $timesheetDate,

                        ];
                        $isTime_InValid =
                        $timesheetContainer
                            ->isTimelinevalid(
                                PayPeriod::find($period),
                                $timesheetDate,
                                $volunteer,
                                $timesheet['time_in'],
                                $timesheet['time_out']

                            );

                        if ($isTime_InValid) {

                            $invalidErrorBag[] = $timesheetContainer->createErrorBag($timesheet);

                            continue;

                        }

                        $newTimesheetId = $this->saveNewTs($args);

                        $current_stp_itm = isset($stipend_items[$timesheet['site']][$timesheet['date']]) ? $stipend_items[$timesheet['site']][$timesheet['date']] : [];

                        foreach ($current_stp_itm as $type => $value_arr) {
                            $stipendItem = StipendItem::findOrFail($value_arr['value']);
                            TimeSheetItem::create([
                                'time_sheet_id' => $newTimesheetId,
                                'type' => $type,
                                'code' => $stipendItem['item_code'],
                                'stipend_item_id' => $stipendItem['id'],
                                'stipend_lookup_id' => $this->getStipendLookupId($type, $value_arr['value']),
                                'value' => $stipendItem['id'],
                                'amount' => $value_arr['amount'] ?? $stipendItem['unit_amount'],
                            ]);
                        }

                        // $existing_ts[$timesheet['site']][] = [$ts_unq_id, $newTimesheetId];

                    }

                } else {
                    /* Save */

                    $timesheetDate = date('Y-m-d', strtotime($timesheet['date']));

                    $args = [

                        'volunteer' => $volunteer,
                        'ts_unq_id' => $ts_unq_id,
                        'site_id' => $timesheet['site'],
                        'period_id' => $period,
                        'template' => $timesheet,
                        'start_date' => $timesheetDate,

                    ];
                    $isTime_InValid =
                    $timesheetContainer
                        ->isTimelinevalid(
                            PayPeriod::find($period),
                            $timesheetDate,
                            $volunteer,
                            $timesheet['time_in'],
                            $timesheet['time_out']

                        );


                    if ($isTime_InValid) {

                        $invalidErrorBag[] = $timesheetContainer->createErrorBag($timesheet);

                        continue;

                    }

                    $newTimesheetId = $this->saveNewTs($args);

                    $existing_ts[$timesheet['site']][] = [$ts_unq_id, $newTimesheetId, $volunteer->id];

                    $current_stp_itm = isset($stipend_items[$timesheet['site']][$timesheet['date']]) ? $stipend_items[$timesheet['site']][$timesheet['date']] : [];

                    foreach ($current_stp_itm as $type => $value_arr) {
                        $stipendItem = StipendItem::findOrFail($value_arr['value']);
                        TimeSheetItem::create([
                            'time_sheet_id' => $newTimesheetId,
                            'type' => $type,
                            'code' => $stipendItem['item_code'],
                            'stipend_item_id' => $stipendItem['id'],
                            'stipend_lookup_id' => $this->getStipendLookupId($type, $value_arr['value']),
                            'value' => $stipendItem['id'],
                            'amount' => $value_arr['amount'] ?? $stipendItem['unit_amount'],
                        ]);
                    }
                }

            }

            /* Remove non existing ts only execute if update is done */
            $this->removeNonExistingTs($existing_ts);

            /** Executes when there are unresolved time_in */
            if (count($invalidErrorBag)) {

                throw new \Exception(json_encode($invalidErrorBag), 422);

            }

            DB::commit();
            return response(["message" => "timesheet Successfully created"], 201);

        } catch (\Exception $e) {

            DB::rollback();
            // throw $e;

            if ($e->getCode() === 422) {
                return response(["errorBag" => $e->getMessage()], 422);
            }
            if ($e->getCode() === 404) {
                return response($e->getMessage(), 404);
            }

            return response(["message" => $e->getMessage(), "line" => $e->getLine()], 500);

        }

    }

    public function removeNonExistingTs($existing_ts)
    {

        foreach ($existing_ts as $site => $uts) {
            $updated_ids = [];
            $unq_id = null;
            $vol = null;
            foreach ($uts as $tss) {
                $updated_ids[] = $tss[1];
                $unq_id = $tss[0];
                $vol = $tss[2];
            }

            $all_ts = Timesheet::where([
                'timesheets_unq_id' => $unq_id,
                'site_id' => $site, 'volunteer_id' => $vol,
            ])->pluck('id');
            $should_delete = $all_ts->diff($updated_ids)->toArray();

            Timesheet::whereIn('id', $should_delete)->delete();

        }

        return true;
    }

    public function bulkFormatter($data)
    {

        if ($data instanceof Request) {
            $data = $data->all();
        }

        $formatted_data = [];

        foreach ($data as $key => $first_arrray) {

            if (is_array($first_arrray)) {

                foreach ($first_arrray as $index => $value) {

                    $formatted_data[$index][$key] = $value;

                }
            }

        }

        return $formatted_data;

    }

    public function checkTimesheetExists($period, $volunteer, $site_id, $date)
    {

        return Timesheet::where([
            'period_id' => $period->id,
            'volunteer_id' => $volunteer->id,
            'site_id' => $site_id,
            'date' => $date,
        ])->first();

    }

    private function updateTs($old_ts, $template): Timesheet
    {

        /* Delete old ts items*/

        $timesheet_items = TimeSheetItem::where('time_sheet_id', $old_ts->id)->delete();

        $stipendItem = isset($template['timeType']) ? $template['timeType'] : $template['time_type'];
        
        if (is_numeric($stipendItem)) {
            $stipendItem = StipendItem::findOrFail($stipendItem);
        }

        $old_ts_string = "$old_ts";

        $old_ts->update([

            'type_label' => $stipendItem['id'],
            'type' => $stipendItem['item_code'],
            'time_in' => $template['time_in'],
            'time_out' => $template['time_out'],
            'break_in' => $template['break_in'],
            'break_out' => $template['break_out'],
            'total_hrs' => $template['total_hr'],
            'comment' => isset($template['comment']) ? $template['comment'] : '',
            'rates' => getSiteSettings('stipend_rate'),
            'total_amount' => $this->calculateAmount($template['total_hr']),
        ]);

        $new_ts_string = "$old_ts";

        (new TimeSheetRepo('Fgp\Timesheet'))->audit($old_ts->id, $old_ts_string, $new_ts_string, auth()->id());

        return $old_ts;

    }

    private function holidayExists($date)
    {

        $holiday = Holiday::where('hol_date', $date)->first();

        return $holiday ? true : false;

    }

    private function getHolidayName($date)
    {

        $holiday = Holiday::where('hol_date', $date)->first();

        return $holiday->name;

    }

    private function saveNewTs($args)
    {

        extract($args);

        $isHoliday = $this->holidayExists($start_date);

        PayPeriod::where('id', $period_id)->update(['pay_stat' => 'In Process']);

        $newTimesheet = new Timesheet;

        // $template = $this->validateTimes($template);

        $stipendItem = isset($template['timeType']) ? $template['timeType'] : $template['time_type'];
        
        if (is_numeric($stipendItem)) {
            $stipendItem = StipendItem::findOrFail($stipendItem);
        }

        $newTimesheetId = $newTimesheet->create([
            'volunteer_id' => $volunteer->id,
            'timesheets_unq_id' => $ts_unq_id,
            'site_id' => $site_id,
            'period_id' => $period_id,
            'date' => $start_date,
            'type_label' => $isHoliday ? "Vacation Time" : $stipendItem['id'],
            'type' => $isHoliday ? 'vacation_time' : $stipendItem['item_code'],
            'time_in' => $template['time_in'],
            'time_out' => $template['time_out'],
            'break_in' => $template['break_in'],
            'break_out' => $template['break_out'],
            'total_hrs' => $template['total_hr'],
            'comment' => $isHoliday ? $this->getHolidayName($start_date) : (isset($template['comment']) ? $template['comment'] : ''),
            'approval_status' => "supervisor",
            'status' => "New",
            'next_approval' => "supervisor",
            'rates' => $this->getStipendRate(),
            'total_amount' => $this->calculateAmount($template['total_hr']),
            'userc_id' => auth()->id(),

        ])->id;

        return $newTimesheetId;
    }

    /**
     *   Saves / Schedules multiple timesheet by site or by volunteer
     *   @param $request['site_id']['vol_id'], $period, $type : "volunteer"/ "site"
     *   @return HTML
     */

    public function saveMultipleTimesheet(Request $request, PayPeriod $period, $type)
    {
        DB::beginTransaction();
        try {
            if ($type === "volunteer") {

                foreach ($request->data as $vol) {

                    $volunteer = Volunteer::find($vol);

                    $default_template = self::volDefaultTemplate($volunteer);

                    $template = $this->formatTemplateToTimesheetData($default_template, $volunteer, $period) ?: [];

                    /* Insert all timesheet for each volunteer each sites */

                    $start_date = $period->start_date;

                    $total_days = \carbon($period->start_date)->diffInDays($period->end_date) + 1;

                    foreach ($volunteer->assignedSites as $vol_sites) {

                        $has_ts = $this->checkTimesheetExists($period, $volunteer, $vol_sites->site_id, $start_date);

                        if ($request->is_clear === "false" && $has_ts) {

                            //If default template is not loaded on all then dont update instead escape

                            continue;

                        }

                        $ts_unq_id = $this->getTimesheetUnqId($period->id);

                        for ($i = 0; $i < $total_days; $i++) {

                            $day_of_week = date("l", strtotime($start_date));

                            foreach ($template['template'] as $key => $temp) {

                                $existingDaysOnDefaultTemplate = array_keys($temp);

                                /* If current day doesn't exist in default template */

                                if (!in_array($day_of_week, $existingDaysOnDefaultTemplate)) {

                                    continue;

                                }

                                if (in_array($day_of_week, array_keys($temp)) && $key == $vol_sites->site_id) {

                                    $day_template = $temp[$day_of_week];

                                    $old_ts = $this->checkTimesheetExists($period, $volunteer, $vol_sites->site_id, $start_date);

                                    //Update the old timesheet

                                    if ($old_ts) {

                                        $this->updateTs($old_ts, $day_template);

                                        if (!isset($day_template['items'])) {
                                            continue;
                                        }

                                        foreach ($day_template['items'] as $value_arr) {

                                            TimeSheetItem::create([
                                                'time_sheet_id' => $old_ts->id,
                                                'type' => $value_arr['category'],
                                                'code' => $value_arr['item_code'],
                                                'stipend_item_id' => $value_arr['id'],
                                                'value' => $value_arr['id'],
                                                'amount' => $value_arr['amount'] ?? $value_arr['unit_amount'],
                                            ]);

                                        }

                                        continue;
                                    }

                                    /* Create new timesheet with default template */

                                    $args = [

                                        'volunteer' => $volunteer,
                                        'ts_unq_id' => $ts_unq_id,
                                        'site_id' => $vol_sites->site_id,
                                        'period_id' => $period->id,
                                        'template' => $day_template,
                                        'start_date' => $start_date,

                                    ];

                                    $newTimesheetId = $this->saveNewTs($args);

                                    /* Insert to Timesheet Items */

                                    if (!isset($day_template['items'])) {
                                        continue;
                                    }

                                    foreach ($day_template['items'] as $value_arr) {

                                        TimeSheetItem::create([
                                            'time_sheet_id' => $newTimesheetId,
                                            'type' => $value_arr['category'],
                                            'code' => $value_arr['item_code'],
                                            'stipend_item_id' => $value_arr['id'],
                                            'value' => $value_arr['id'],
                                            'amount' => $value_arr['amount'] ?? $value_arr['unit_amount'],
                                        ]);

                                    }

                                }

                            }

                            $start_date = date('Y-m-d', strtotime($start_date . "+1 days"));

                        }

                        $start_date = $period->start_date;

                    }

                }

                DB::commit();

                return response()->json(["Successfully scheduled mass timesheet"], 200);

            } else {

                foreach ($request->data as $site => $vol_array) {

                    foreach ($vol_array as $vol) {

                        $volunteer = Volunteer::find($vol);

                        $default_template = self::volDefaultTemplate($volunteer);

                        $template = $this->formatTemplateToTimesheetData($default_template, $volunteer, $period) ?: [];

                        /* Insert all timesheet for each volunteer each sites */

                        $start_date = $period->start_date;
                        $total_days = \carbon($period->start_date)->diffInDays($period->end_date) + 1;

                        $has_ts = $this->checkTimesheetExists($period, $volunteer, $site, $start_date);

                        if ($request->is_clear === "false" && $has_ts) {

                            //If default template is not loaded on all then dont update instead escape

                            continue;

                        }

                        $ts_unq_id = $this->getTimesheetUnqId($period->id);

                        for ($i = 0; $i < $total_days; $i++) {

                            $day_of_week = date("l", strtotime($start_date));

                            foreach ($template['template'] as $key => $temp) {

                                $existingDaysOnDefaultTemplate = array_keys($temp);

                                /* If current day doesn't exist in default template */

                                if (!in_array($day_of_week, $existingDaysOnDefaultTemplate)) {

                                    continue;

                                }

                                if (in_array($day_of_week, array_keys($temp)) && $key == $site) {

                                    $day_template = $temp[$day_of_week];

                                    $old_ts = $this->checkTimesheetExists($period, $volunteer, $site, $start_date);

                                    //Update the old timesheet

                                    if ($old_ts) {

                                        $this->updateTs($old_ts, $day_template);

                                        if (!isset($day_template['items'])) {
                                            continue;
                                        }

                                        foreach ($day_template['items'] as $value_arr) {

                                            TimeSheetItem::create([
                                                'time_sheet_id' => $old_ts->id,
                                                'type' => $value_arr['category'],
                                                'code' => $value_arr['item_code'],
                                                'stipend_item_id' => $value_arr['id'],
                                                'value' => $value_arr['id'],
                                                'amount' => $value_arr['amount'] ?? $value_arr['unit_amount'],
                                            ]);

                                        }

                                        continue;
                                    }

                                    /* Create new timesheet with default template */

                                    $args = [

                                        'volunteer' => $volunteer,
                                        'ts_unq_id' => $ts_unq_id,
                                        'site_id' => $site,
                                        'period_id' => $period->id,
                                        'template' => $day_template,
                                        'start_date' => $start_date,

                                    ];

                                    $newTimesheetId = $this->saveNewTs($args);

                                    /* Insert to Timesheet Items */

                                    if (!isset($day_template['items'])) {
                                        continue;
                                    }

                                    foreach ($day_template['items'] as $value_arr) {
                                        TimeSheetItem::create([
                                            'time_sheet_id' => $newTimesheetId,
                                            'type' => $value_arr['category'],
                                            'code' => $value_arr['item_code'],
                                            'stipend_item_id' => $value_arr['id'],
                                            'value' => $value_arr['id'],
                                            'amount' => $value_arr['amount'] ?? $value_arr['unit_amount'],
                                        ]);

                                    }

                                }

                            }

                            $start_date = date('Y-m-d', strtotime($start_date . "+1 days"));

                        }

                    }

                }

                DB::commit();

                return response()->json(["Successfully scheduled mass ts with site"], 200);

            }
        } catch (\Exception $e) {

            DB::rollback();

            if ($e->getCode() === 404) {
                return response($e->getMessage(), 404);
            }

            return response()->json(["message" => $e->getMessage(), "line" => $e->getLine()], 500);

        }

    }

    protected static function volDefaultTemplate($volunteer)
    {

        return $volunteer->defaultTemplate;

    }

    public function formatTableItems($template)
    {
        $data = [];
        $template->details->load('timeType');
        foreach ($template->details as $detail):
            $temp = $detail->only('time_in', 'time_out', 'break_out', 'break_in', 'total_hours', 'timeType');
            $temp['total_hr'] = $temp['total_hours'];
            $temp['items'] = $detail->items->map(function ($item) {
                $item->stipendItem['amount'] = $item->amount;
                return $item->stipendItem;
            });
            $data[$detail->site_id][$detail->days] = $temp;
        endforeach;
        return $data;
    }

    protected function formatTemplateToTimesheetData($temp, $volunteer, $period)
    {

        if ($temp):
            $template['template'] = $this->formatTableItems($temp);
            // $template['template'] = $def['template'];
            $template['temp_name'] = $temp->template_name;
        else:
            $template['template'] = [];
            $template['temp_name'] = "";
        endif;

        return $template;
    }

    public function setDefaultTemplate(Template $template, Volunteer $volunteer)
    {

        /*
         *   Check if the volunteer has already a default if exits set it to 0
         *
         */

        $hasDefaultTemp = self::volDefaultTemplate($volunteer);

        if ($hasDefaultTemp) {

            $hasDefaultTemp->update([

                'is_default' => 0,

            ]);

        }

        $template->update([

            'is_default' => 1,

        ]);

        return $volunteer->allTemplates;

    }

    /**
     * Saves cascading search  query for user
     * @param Request $request
     */
    public function saveQuery(Request $request)
    {
        UserSettings::insert([
            'user_id' => $request->user()->id,
            'type' => 'cascading_search_query',
            'code' => str_slug($request->input('name')),
            'name' => $request->input('name'),
            'value' => $request->input('value'),
        ]);
    }

    public function loadQuery(Request $request)
    {
        $queries = UserSettings::select('id', 'name', 'value')->where(['type' => 'cascading_search_query', 'user_id' => $request->user()->id])->get();
        return $this->view('includes.search.queryModal', compact('queries'));
    }

    /**
     * Upload files uploaded from sites i.e has site
     * @param  Request   $request   [description]
     * @param  Volunteer $volunteer [description]
     * @param  PayPeriod $period    [description]
     * @param  Site $site
     * @method FileService storeTimesheetFiles
     * @return response
     */
    public function uploadFilesToTimesheet(Request $request, Volunteer $volunteer, PayPeriod $period, Site $site)
    {

        $file_service = app(FileService::class);

        $totalInsertedFiles = $file_service->storeTimesheetFiles($request, $volunteer, $period, $site);

        return response()->json(["data" => ["files" => $totalInsertedFiles], "message" => "files success"], 200);

    }

    /**
     * Upload files uploaded from default sites i.e no site id
     * @param  Request   $request   [description]
     * @param  Volunteer $volunteer [description]
     * @param  PayPeriod $period    [description]
     * @method FileService storeTimesheetFiles
     * @return response
     */
    public function uploadDefaultTimesheetFiles(Request $request, Volunteer $volunteer, PayPeriod $period): Response
    {

        app(FileService::class)->storeTimesheetFiles($request, $volunteer, $period);

        return response(['messsage' => "Files successfully inserted"], 200);

    }

    private function validateTimes($template)
    {
        // time_in , time_out, break_in, break_out
        extract($template);
        $base = function ($time) use ($date) {
            return strtotime($date . ' ' . $time);
        };
        $newData = [];
        if ($base($time_in) > strtotime($date . ' 6am') && $base($time_in) < strtotime($date . ' 11.59am')) {
            $newData['time_in'] = $time_in;
            if ($base($time_out) < strtotime($date . ' 11:59am')) {
                $newData['time_out'] = date('H:i', strtotime("$date $break_out" . 'pm'));
            }
        }
    }


    // Remove Timesheet

    public function removeTimesheet(Request $request, Payperiod $period, Volunteer $volunteer){

        $sites = json_decode($request->sites, true);

        if($sites){

            foreach($sites as $site){
                Timesheet::where([

                    "site_id" => $site,
                    "period_id" => $period->id,
                    "volunteer_id" => $volunteer->id

                ])->get()->every(function($ts){
                    $ts->timesheetItems()->delete();
                    $ts->delete();
                });

            }

        }

        return "deleted";

    }

}
