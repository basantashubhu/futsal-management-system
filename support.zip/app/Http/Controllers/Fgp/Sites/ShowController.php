<?php

/**
 * @author Suman Thaapa -- Lead
 * @author Prabhat gurung
 * @author Basanta Tajpuriya
 * @author Rakesh Shrestha
 * @author Manish Buddhacharya
 * @author Lekh Raj Rai
 * @author Ascol Parajuli
 * @email NEPALNME@GMAIL.COM
 * @create date 2019-03-18 14:15:26
 * @modify date 2019-03-18 14:15:26
 * @desc [description]
 */

namespace App\Http\Controllers\Fgp\Sites;

use App\Http\Controllers\BaseController;
use App\Http\Requests\Fgp\SiteRequest;
use App\Lib\Exporter\CSVExporter;
use App\Lib\Exporter\JSONExporter;
use App\Lib\Exporter\PDFExporter;
use App\Lib\Exporter\TxtExporter;
use App\Models\Address;
use App\Models\Contact;
use App\Models\Fgp\County;
use App\Models\Fgp\Site;
use App\Models\Fgp\SiteDetail;
use App\Models\Fgp\Volunteer;
use App\Models\Settings\Lookups;
use App\Models\User;
use App\Repo\Fgp\SiteRepo;
use App\Repo\FGP\VolunteerRepo;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ShowController extends BaseController
{
    private $clayout = "";
    private static $repo = null;
    public function __construct()
    {
        parent::__construct();
        $this->clayout = $this->layout . '.fgp.sites';
    }

    public function __invoke()
    {
        $zoom = 11;
        $address = $this->getLocation();
        // $address = [['name'=>'Prabhat gurung', 'address'=> '757 Pulaski Highway Bear', 'phone'=>'9805346778']];
        // $zip = '19701';
        $supervisor_id = Volunteer::where('is_deleted', false)->distinct()->pluck('vol_supervisor_id');
        $supervisors = [];
        if (count($supervisor_id) > 0) {
            foreach ($supervisor_id as $id) {
                array_push($supervisors, User::find($id));
            }
        }
        return view($this->clayout . ".index1", compact('zoom', 'address', 'zip', 'supervisors'));
    }

    public function addSite()
    {

        $validations = validation_value('site_create');

        $supervisors = $this->getSupervisors();
        return view($this->clayout . '.models.add.site_add', compact('validations', 'supervisors'));
    }

    public function editSite($id)
    {
        $site = Site::find($id);
        $validations = validation_value('site_create');
        return view($this->clayout . '.models.update', compact('site', 'validations'));
    }

    public function deleteSite($site_id)
    {
        return view($this->clayout . '.models.delete', compact('site_id'));
    }

    /**
     * @param $model
     * @return SiteRepo|null
     */
    private static function getInstance($model)
    {
        if (self::$repo == null) {
            self::$repo = new SiteRepo($model);
        }

        return self::$repo;
    }

    public function getAll(Request $request)
    {
        return self::getInstance('Fgp\Site')->selectDataTable($request);
    }
    public function getAllVolunteers(Request $request, $id)
    {
        return self::getInstance('Fgp\Site')->selectAllSitesVolunteer($request, $id);
    }

    public function viewSites($id)
    {
        $site = Site::find($id);
        return view('default.fgp.sites.models.viewSite', compact("site"));
    }

    public function exportData(Request $request, $type)
    {
        if (isset($_COOKIE['site_advanced']) || isset($_COOKIE['site_quick'])) {
            $advData = isset($_COOKIE['site_advanced']) ? json_decode($_COOKIE['site_advanced']) : [];
            $quickData = isset($_COOKIE['site_quick']) ? json_decode($_COOKIE['site_quick']) : [];
            $mergeData = array_merge($advData, $quickData);
        } else {
            $mergeData = [];
        }
        $data = self::getInstance('Fgp\Site')->getReportData($request);

        $fields = array('Site Code', 'Site Name', 'Address 1', 'Address 2', 'City', 'County', 'Phone', "Contact Person");
        $mapField = array('site_code', 'site_name', 'add1', 'add2', 'city', 'county', 'phone', 'contact_person');
        $data = cleaner($mapField, $data);
        
        $data['table'] = 'Report of Sites';
        if (count($data) > 0) {
            $export = $this->reportFactory($type, $fields, $data);
            $exporter = new \App\Lib\Exporter\Exporter($export);
            $filename = $exporter->export();
            return response()->download($filename)->deleteFileAfterSend(true);
        } {
            return 'No Data Available For Current Filter';
        }
    }

    /**
     * @param $type
     * @param $data
     * @return CSVExporter|JSONExporter|PDFExporter|TxtExporter
     * @throws \Exception
     */
    public function reportFactory($type, $fields, $data)
    {
        switch ($type) {
            case 'csv':
                return new CSVExporter($data, $fields, 'SiteReports');
                break;
            case 'json':
                return new JSONExporter($data);
                break;
            case 'txt':
                return new TxtExporter($data);
                break;
            case 'pdf':
                return new PDFExporter($data, $fields, 'print');
                break;
            default:
                throw new \Exception("Method Not Allowed " . $type);
                break;
        }
    }

    public function checkEmail(Request $request)
    {
        $e = Site::where('site_email', $request->email)->first();
        if (isset($e->id)) {
            return $e->id;
        } else {
            return 'not';
        }
    }

    public function getEmailInfo($id)
    {
        $site = Site::find($id);
        $site->address = Address::where('table_name', 'sites')->where('table_id', $site->id)->first();
        $site->contact = Contact::where('table_name', 'sites')->where('table_id', $site->id)->first();
        $site->person_first_name = $this->getValue($site->id, "contact_person_first_name")->value;
        $site->person_last_name = $this->getValue($site->id, "contact_person_last_name")->value;
        $site->person_email = $this->getValue($site->id, "contact_person_email")->value;
        //        $site->person_cell = $this->getValue($site->id,"contact_person_cell")->value;
        //        $site->alt_phone = $this->getValue($site->id,"person_alt_phone")->value;

        return view($this->clayout . '.models.info', compact('site'));
    }

    public function getValue($site_id, $code)
    {
        $data = SiteDetail::select('value')->where('site_id', $site_id)->where('code', $code)->first();
        return $data;
    }

    public function getLookup(Request $request)
    {
        if ($request->has('lookup') && $request->has('section')) {
            return Lookups::select('value as text', 'value as val')
                ->where('code', $request->lookup)
                ->where('section', $request->section)
                ->when($request->term, function ($query) use ($request) {
                    $query->where('value', 'like', '%' . $request->term . '%');
                })
                ->get();
        }
    }

    public function addVolunteerToSite(Site $site)
    {

        return view($this->clayout . '.models.add_volunteer', compact('site'));
    }

    /*
     * assigned volunteers to site
     * */
    public function vol_assign_modal($site_id)
    {

        $site = Site::select('id', 'site_name')->with(['address' => function ($add) {
            $add->select('table_id', 'add1', 'add2', 'county', 'city', 'state', 'zip_code');
        }])->where('id', $site_id)->first();
        return $this->view($this->clayout . '.models.vol_assign', compact('site_id', 'site'));
    }

    public function vol_list(Request $request, Site $site)
    {
        return (new VolunteerRepo('Fgp\Volunteer'))->siteVolList($request, $site);
    }

    public function vol_assign(Request $request, Site $site)
    {
        $vols = $request->input('ids', '[]');
        $vols = json_decode($vols);
        $bulk_data = array();
        foreach ($vols as $vol_id) {
            $bulk_data[$vol_id] = array(
                'date' => date('Y-m-d'),
                'userc_id' => $request->user()->id,
            );
        }
        $site->volunteers()->sync($bulk_data);
        return 'success';
    }

    public function getLocation()
    {
        $sites = Site::where('is_deleted', 0)->get();
        $address = [];
        foreach ($sites as $site) {
            // $data = ["site_name"=>$site["site_name"],"address"=>$site->address];
            $data = ["name" => $site->site_name, "address" => $site->address->add1 ?? ''];
            array_push($address, $data);
        }
        return $address;
    }

    public function getSiteValidation(SiteRequest $request)
    { }

    public function getAllSupervisors()
    {
        $supervisors = $this->getSupervisors();
        return view($this->clayout . '.models.get_supervisors', compact('supervisors'));
    }

    public function getSupervisors()
    {
        $supervisors = User::leftjoin('members', 'members.user_id', 'users.id')->select('users.id as id', \DB::raw("CONCAT(members.first_name,' ',members.last_name) as name"), 'users.email', 'users.id as id')
            ->where('users.role_id', 3)
            ->get();
        return $supervisors;
        // return User::where('role_id', 3)->get();
    }

    public function updatesiteWidget($id)
    {

        $site = Site::find($id);
        $validations = validation_value('site_create');
        // return view($this->clayout.'.models.add',compact('site','validations'));
        return view($this->clayout . '.models.update.site_update', compact('site', 'validations'));
    }

    //fetch supervisors for select2
    public function fetchSupervisors(Request $request)
    {

        $supervisors = User::leftjoin('members', 'members.user_id', 'users.id')->select('users.id as id', \DB::raw("CONCAT(members.first_name,' ',members.last_name) as text"))
            ->where('users.role_id', 3)
            ->when($request->term, function ($query) use ($request) {
                $query->where('users.name', 'like', '%' . $request->term . '%');
            })
            ->get();
        foreach ($supervisors as $supervisor) {
            $supervisor->text = ucfirst($supervisor->text);
        }
        return $supervisors;
    }

    public function getUser($id)
    {
        return User::find($id)->fullName();
    }

    public function checkSite($site_name)
    {
        if (!empty($site_name)) {
            # code...
            $site = Site::where('site_name', $site_name)->first();
            if ($site) {
                return response(["site" => $site->site_name], 200);
            } else {
                return;
            }
        }
    }

    public function checkCounty($countyName)
    {
        if (!empty($countyName)) {
            $county = County::where('county_name', $countyName)->first();
            if ($county == null) {
                return response(["county" => $countyName], 500);
            }
        }
    }

    public function getCounty()
    {
        return view($this->clayout . '.models.get_county');
    }
    public function fetchCounty()
    {
        return County::select('id', 'county_name')->where('is_deleted', 0)->get();
    }
}
