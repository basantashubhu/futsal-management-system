<?php

namespace App\Http\Controllers\Fgp\Sites;

use App\Http\Controllers\BaseController;
use App\Http\Requests\Fgp\SiteRequest;
use App\Models\Address;
use App\Models\Contact;
use App\Models\Fgp\Site;
use App\Repo\FGP\SiteRepo;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SiteStoreController extends BaseController
{

    private $table_name = 'sites';
    private static $repo = null;

    public static function getRepo($model)
    {
        self::$repo = new SiteRepo($model);
        return self::$repo;
    }

    public function storeSite(SiteRequest $request, Site $site = null)
    {

        DB::beginTransaction();
        try {
            $save_site = $this->saveSite($request, $site);

            $this->saveAddress($request, $save_site, $site);

            $this->saveContact($request, $save_site, $site);

//            $this->saveDetail($request,$save_site, $site);

            DB::commit();
        } catch (\Exception $e) {
            DB::rollback();
            return response(["message" => $e->getMessage()], 500);
        }

    }

    private function createLabelFromCode($code)
    {
        return ucfirst(str_replace('_', ' ', $code));
    }

    private function saveSite(Request $request, $site = null)
    {

        $site_info = $request->only([
            'site_name', 'site_code', 'site_type', 'cont_per_fname', 'cont_per_mname', 'cont_per_lname',
        ]);
        try {
            if ($site) {
                return self::getRepo($site)->saveUpdate($site_info);
            }
            return self::getRepo('Fgp\Site')->saveUpdate($site_info);
        } catch (\Exception $e) {
            return $this->response($e->getMessage(), 'error', 500);
        }
    }

    private function updateSite(Request $request, Site $site)
    {
        $site_info = $request->only([
            'site_name', 'site_type', 'cont_per_fname', 'cont_per_mname', 'cont_per_lname',
        ]);
        return self::getRepo($site)->saveUpdate($site_info);
    }

    private function saveAddress(Request $request, $created_site, $site)
    {

        $address_info = $request->only([
            'add1', 'add2', 'city', 'zip_code', 'county', 'region', 'district', 'state',
        ]);
        $address_info['table_name'] = $this->table_name;
        $address_info['table_id'] = $created_site->id;

        if ($site) {
            $addr = Address::where('table_name', $this->table_name)->where('table_id', $site->id)->first();
            return self::getRepo($addr)->saveUpdate($address_info);
        }
        return self::getRepo('Address')->saveUpdate($address_info);
    }

    private function saveContact(Request $request, $created_site, $site)
    {

        $contact_info = $request->only([
            'tel_phone', 'alt_phone', 'fax', 'email', 'cell_phone',
        ]);
        $contact_info['table_name'] = $this->table_name;
        $contact_info['table_id'] = $created_site->id;
        if ($site) {
            $contact = Contact::where('table_name', $this->table_name)->where('table_id', $site->id)->first();
            return self::getRepo($contact)->saveUpdate($contact_info);
        }
        return self::getRepo('Contact')->saveUpdate($contact_info);

    }

    public function deleteSite(Request $request)
    {
        $site = Site::find($request->id);
        $deleted = static::getRepo($site)->softDelete();
        if ($deleted):
            return $this->response('Site Deleted Successfully', 'view', '200');
        else:
            return $this->response('Failed to Delete Site', 'view', '500');
        endif;
    }

    public function storeFromWidget(Request $request, $site = null)
    {

        $data = $request->all();

        DB::beginTransaction();
        try {

            $save_site = $this->saveSite($request, $site);

            if (!$save_site instanceof Site) {
                throw new Exception('Can not save site.');
            }
            $this->saveAddress($request, $save_site, $site);

            $this->saveContact($request, $save_site, $site);

            if (array_key_exists("site_vol", $data)) {
                $this->assignVolunteerToSite($data["site_vol"], $save_site, $site);
            }

            if (array_key_exists("supervisors", $data)) {
                $this->assignSupervisorToSite($data["supervisors"], $save_site, $site);
            }

            DB::commit();

            return response(["message" => "Success", "status" => 200, 'site_id' =>  $save_site->id]);
        } catch (\Exception $e) {
            DB::rollback();
            return response(["message" => $e->getMessage()], 500);
        }

    }

    public function updateFromWidget(Request $request, Site $site)
    {
        $this->updateVoluntersToSite($request->input('site_vol', []), $site->id);
        return response(["message" => "Success", "status" => 200]);

    }

    public function updateSiteGenerals(SiteRequest $request, Site $site)
    {

        $site_info = $request->only([
            'site_name', 'site_type', 'cont_per_fname', 'cont_per_mname', 'cont_per_lname', 'site_code',
        ]);

        $address_info = $request->only([
            'add1', 'add2', 'city', 'zip_code', 'county', 'region', 'district', 'state',
        ]);
        $address_info['table_name'] = $this->table_name;
        $address_info['table_id'] = $site->id;

        $contact_info = $request->only([
            'tel_phone', 'alt_phone', 'fax', 'email', 'cell_phone',
        ]);
        $contact_info['table_name'] = $this->table_name;
        $contact_info['table_id'] = $site->id;

        DB::beginTransaction();
        try {
            self::getRepo($site)->saveUpdate($site_info);

            $addr = Address::where('table_name', $this->table_name)->where('table_id', $site->id)->first();
            self::getRepo($addr)->saveUpdate($address_info);

            $contact = Contact::where('table_name', $this->table_name)->where('table_id', $site->id)->first();
            if ($contact) {
                self::getRepo($contact)->saveUpdate($contact_info);
            }

            $this->updateSupervisorsToSite($request->input('supervisors', []), $site);

            DB::commit();
            return response(["message" => "Success", "status" => 200]);
        } catch (\Exception $e) {
            DB::rollback();
            return response(["message" => $e->getMessage()], 500);
        }
    }

    public function assignVolunteerToSite($data, $created_site, $site_id)
    {
        if ($site_id) {

        } else {
            $formattedData = [];
            foreach ($data as $datum) {
                $abc = [
                    'volunteer_id' => $datum,
                    'site_id' => $created_site->id,
                    'date' => now(),
                ];
                array_push($formattedData, $abc);
            }
            DB::table('volunteer_sites')->insert($formattedData);
        }

    }

    public function assignSupervisorTosite($data, $created_site, $site_id)
    {
        if ($site_id) {

        } else {
            $formattedData = [];
            foreach ($data as $datum) {
                $abc = [
                    'user_id' => $datum,
                    'site_id' => $created_site->id,
                ];
                array_push($formattedData, $abc);
            }
            DB::table('site_managers')->insert($formattedData);
        }

    }

    public function updateSupervisorsToSite($supervisor, Site $site)
    {
        $site->managingUser()->sync($supervisor);
    }

    public function updateVoluntersToSite($volunteers, $site_id)
    {
        $site = Site::find($site_id);
        $site->volunteers()->attach($volunteers);
    }
}
