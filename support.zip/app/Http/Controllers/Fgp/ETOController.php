<?php

namespace App\Http\Controllers\Fgp;

use App\Models\Fgp\PayPeriod;
use App\Models\Fgp\Site;
use App\Models\Fgp\Timesheet;
use App\Models\Fgp\Volunteer;
use Illuminate\Http\Request;
use App\Http\Controllers\BaseController;
use Illuminate\Support\Facades\DB;

class ETOController extends BaseController
{
    /**
     * calculates the eto related info for datatable
     * Request From : volunteer profile view | ETO Balance
     * @param Request   $request
     * @param Volunteer $volunteer
     * @return array
     */
    function getCalcEto(Request $request, Volunteer $volunteer)
    {
        $per_page = (int)$request->input('pagination', ['perpage' => 20])['perpage'];
        $page = (int)$request->input('pagination', ['page' => 1])['page'];
        $offset = ($page - 1) * $per_page;

        $data = $this->calcEto($volunteer);

        $result = [
            'meta' => [
                'page' => $page,
                'pages' => ceil(0 / $per_page),
                'perpage' => $per_page,
                'total' => 0,
                'sort' => $request->sort['sort'],
                'field' => $request->sort['field']
            ],
            'data' => $data
        ];
        return $result;
    }

    private function calcEto(Volunteer $volunteer)
    {
        $time_sheets =  Timesheet::from('timesheets as ts')->select([
            'ts.type', 'ts.period_id', 'ts.site_id',
            DB::raw('time_to_sec(ts.total_hrs) as total_sec'),
        ])->where('ts.volunteer_id', $volunteer->id)
            ->get()->map(function($time_sheet) {
                    $time_sheet->total_hrs = $time_sheet->total_sec / 3600;
                    unset($time_sheet->total_sec);
                    return $time_sheet;
            });

        $sites = Site::select('site_name', 'id')->whereIn('id', $time_sheets->pluck('site_id')->unique()->toArray())
            ->get();

        $stipend_period = PayPeriod::select([
            'id', 'period_no', 'start_date', 'end_date'
        ])->whereIn('id', $time_sheets->pluck('period_id')->unique()->toArray())
            ->get();

        $stipend_types = $time_sheets->pluck('type')->unique();

        foreach ($stipend_period as $period):
//            $stipend_sites = [];
            foreach ($sites as $key => $site):
                $ps_time_sheets = $time_sheets->filter(function($ts) use($period, $site) {
                    return $ts->period_id === $period->id && $ts->site_id === $site->id;
                });
                if (!$ps_time_sheets->count()) continue;
                foreach ($stipend_types as $type):
                    $period[$type] = $ps_time_sheets->where('type', $type)->sum('total_hrs');
                endforeach;
//                $site = $site->toArray();
//                unset($site['contact_person_email'], $site['contact_person_first_name'], $site['contact_person_last_name'], $site['site_contact']);
//                unset($site['person_alt_phone'], $site['person_cell']);
//                $stipend_sites[] = $site;
            endforeach;
//            $period->sites = collect($stipend_sites);
        endforeach;


        return $stipend_period;
    }
}
