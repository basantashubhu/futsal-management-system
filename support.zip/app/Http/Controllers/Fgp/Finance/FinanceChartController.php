<?php

namespace App\Http\Controllers\Fgp\Finance;

use App\Http\Controllers\BaseController;
use App\Models\Fgp\PayPeriod;
use App\Models\Fgp\StipendCalc;
use App\Models\Fgp\Timesheet;
use App\Models\Fgp\TimeSheetItem;
use Illuminate\Support\Facades\DB;

class FinanceChartController extends BaseController
{
    public function getChartTimeData($period_id)
    {
        $mainData['items'] = [];
        $data = &$mainData['items'];
        $stipendCalc = StipendCalc::with('stipendItemTypes')->where('period_unq_id', $period_id)->first();
        $chartColors = ['primary', 'success', 'danger', 'warning', 'accent'];
        $total = 0;
        $idx = 0;

        foreach ($stipendCalc->stipendItemTypes as $type):
            //$key => $title
            $time = (float) $type->total_hrs;
            $data[] = array('value' => $time, 'label' => ucwords($type->type_name), 'color' => $chartColors[$idx++]);
            $total += $time;
            if (count($chartColors) === $idx) {
                $idx = 0;
            }
        endforeach;

        $mainData['meta']['total'] = total_hrs($total);
        $mainData['meta']['volunteer'] = Timesheet::where('period_id', $period_id)->count(DB::raw('distinct volunteer_id'));
        $mainData['meta']['site'] = Timesheet::where('period_id', $period_id)->count(DB::raw('distinct site_id'));
        return $mainData;
    }
    public function getChartItemData($period_id)
    {
        $mainData['items'] = [];
        $data = &$mainData['items'];
        $items = ['Mileage Reimbursements' => 'Mileage', 'Food Service' => 'Food'];
        $total = 0;
        foreach ($items as $item => $label):
            $amt = TimeSheetItem::whereHas('time_sheet', function ($q) use ($period_id) {
                $q->where('period_id', $period_id);
            })->where('type', $item)->sum('amount');

            $data[] = array(
                'label' => $label, 'title' => $item,
                'value' => number_format($amt, 2, '.', ''),
            );
            $total += $amt;
        endforeach;
        $mainData['meta']['total'] = number_format($total, 2, '.', '');
        return $mainData;
    }

    public function reloadPartialChart($period)
    {
        $finance = StipendCalc::where('period_unq_id', $period)->first();
        $finance->stipend_period = $finance->payperiod;
        return view('default.fgp.dashboard.includes.partialsummary', compact('period', 'finance'));
    }
    public function reloadPartialChartItem($period)
    {
        $finance = StipendCalc::where('period_unq_id', $period)->first();
        $finance->stipend_period = $finance->payperiod;
        return view('default.fgp.dashboard.includes.partialItems', compact('period', 'finance'));
    }

    public function reloadFinanaceDetail($period)
    {
        $finance = StipendCalc::where('period_unq_id', $period)->first();
        if (isset($finance->id)) {
            $finance->stipend_period = PayPeriod::find($finance->period_unq_id);
        }
        return view('default.fgp.dashboard.includes.partialFinance', compact('period', 'finance'));
    }
}
