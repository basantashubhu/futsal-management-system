<?php

namespace App\Http\Controllers\Fgp\Finance;

use App\Events\HvsEvent;
use App\Events\ReorderHvs;
use App\Http\Controllers\BaseController;
use App\Http\Requests\Fgp\HighVolumeHeadersRequest;
use App\Models\Fgp\ApprovalFlow;
use App\Models\Fgp\HighVolumeHeaders;
use App\Models\Fgp\StipendCalc;
use App\Models\Fgp\StipendCalcItems;
use App\Models\Fgp\StipendCalcTypes;
use App\Models\Fgp\Timesheet;
use App\Models\Fgp\Volunteer;
use App\Models\User;
use App\Repo\FGP\FinanceRepo;
use App\Repo\FGP\HighVolumeHeadersRepo;
use App\Repo\FGP\PayPeriodRepo;
use App\Repo\TimeSheetRepo;
use Illuminate\Http\Request;

class HighVolumeSpreadSheetController extends BaseController
{
    private $clayout;
    private static $repo;

    public function __construct()
    {
        parent::__construct();
        $this->clayout = $this->layout . '.fgp.high_volume_spreadsheet';
    }

    public static function getRepo($model)
    {
	    self::$repo = new HighVolumeHeadersRepo($model);
	    return self::$repo;
    }
    
    public function highVolumeHeaders()
    {
        return view($this->clayout.'.headers.index');
    }

    public function getAll(Request $request)
    {
        $data = self::getRepo('Fgp\HighVolumeHeaders')->selectDataTable($request); 
        return $data;
    }

    public function addHeaders()
    {
        $validations = validation_value('high_volume_header_form');
        return view($this->clayout.'.headers.modals.add', compact('validations'));
    }

    public function storeHeaders(HighVolumeHeadersRequest $request)
    {

        $highVolumeHdr = HighVolumeHeaders::where('seq_num', $request->seq_num)->first();

        if($highVolumeHdr){

            $updateSeq['seq_num'] = $request->seq_num + 1;

            self::getRepo($highVolumeHdr)->saveUpdate($updateSeq);


        }

        $res = self::getRepo('Fgp\HighVolumeHeaders')->saveUpdate($request);
        
        event(new HvsEvent(!!$highVolumeHdr));        

        return $this->response("High Volume Headers is added Successfully", "view", 200);

    }
    public function editHeaders(HighVolumeHeaders $volume)
    {
        $validations = validation_value('high_volume_header_form');
        return view($this->clayout.'.headers.modals.edit', compact('volume', 'validations'));
    }

    public function updateHeaders(HighVolumeHeadersRequest $request, HighVolumeHeaders $volume)
    {
        $res = self::getRepo($volume)->saveUpdate($request);

        if ($res):
            return $this->response("High Volume Headers is updated", "view", 200);
        else:
            return $this->response("Cant update High Volume Headers", "view", 422);
        endif;
    }
        /**
     * @param HighVolumeHeaders $volume
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function delete(HighVolumeHeaders $volume)
    {
        return view($this->clayout . '.headers.modals.delete', compact('volume'));
    }

    /**
     * @param HighVolumeHeaders $volume
     * @return $this|\Illuminate\Http\JsonResponse
     */
    public function destroy(Request $request, HighVolumeHeaders $volume)
    {
        $res = self::getInstance($volume)->softDelete();

        if ($res)
            return $this->response("High volume Header deleted successFully", "view", 200);
        else
            return $this->response("Can't delete high volume header", 'view', 422);
    }
}
