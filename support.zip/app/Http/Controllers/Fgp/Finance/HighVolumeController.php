<?php
/**
 * @author Suman Thaapa -- Lead
 * @author Prabhat gurung
 * @author Basanta Tajpuriya
 * @author Rakesh Shrestha
 * @author Manish Buddhacharya
 * @author Lekh Raj Rai
 * @author Ascol Parajuli
 * @email NEPALNME@GMAIL.COM
 * @create date 2019-04-24 14:51:15
 * @modify date 2019-04-24 14:51:15
 * @desc [description]
 */

namespace App\Http\Controllers\Fgp\Finance;

use App\Http\Controllers\BaseController;
use App\Models\Fgp\HighVolumeHeaders;
use App\Models\ReportLog;
use App\Repo\FGP\HighVolumeReportsRepo;
use Illuminate\Http\Request;

class HighVolumeController extends BaseController
{
    private $clayout;
    private static $repo;
    const DS = DIRECTORY_SEPARATOR;
    public function __construct()
    {
        parent::__construct();
        $this->clayout = $this->layout . '.fgp.high_volume_spreadsheet.generate';
    }

    public function index()
    {
        return view($this->clayout . '.index');
    }

    public static function getRepo($model)
    {
        self::$repo = new HighVolumeReportsRepo($model);
        return self::$repo;
    }

    public function getAll(Request $request)
    {
        $data = self::getRepo('ReportLog')->selectDataTable($request);
        return $data;
    }

    public function downloadFile(ReportLog $report, Request $request)
    {
        $type = $request->type ?: false;
        $report->is_download = true;
        $report->save();
        $file = $report->file_name;
        $path = storage_path('reports' . self::DS . $file);
        if ($type === 'xlsx') {
            $file = preg_replace('/\.csv/', '.xlsx', $report->file_name);
            $path = storage_path("reports/$file");
        } elseif ($type === 'xlsm') {
            $file = preg_replace('/\.csv/', '.xlsm', $report->file_name);
            $path = storage_path("reports/$file");
        }

        // dd($report);
        if (file_exists($path)):
            $headers = [
                'Content-Description' => 'File Transfer',
                'Content-Disposition' => 'attachment; filename="' . $file . '"',
                'Content-Transfer-Encoding' => 'binary',
            ];
            return response()->download($path, $file, $headers);
        else:
            return $this->response("File not Found", "view", 404);
        endif;
    }

    public function delete($id)
    {
        return view($this->clayout . '.modal.deleteReport', compact('id'));
    }

    public function destroyReport(Request $request, $id)
    {
        try {
            $report = ReportLog::find($id);
            $report->is_deleted = true;
            $report->userd_id = auth()->id();
            $report->save();
            return $this->response('High Volume Report Deleted Successfully', 'view', 200);
        } catch (\Exception $e) {
            throw $e;

        }}

    public function sortHighVolume(Request $request)
    {
        $data = $request->data;
        $finalData = [];
        foreach ($data as $key => $datum) {

            $datum["seq_num"] = $key + 1;
            array_push($finalData, $datum);
        }

        $this->updateHighVolumeHeader($finalData);
    }

    private function updateHighVolumeHeader(array $finalData)
    {
        try {
            foreach ($finalData as $hvh) {

                $check = HighVolumeHeaders::where('id', $hvh['hvh_id'])->where('is_deleted', 0)->first();

                if ($check):

                    HighVolumeHeaders::where('id', $check->id)
                        ->update([
                            'seq_num' => $hvh['seq_num'],
                        ]);

                endif;
            }
            return response(["message" => "Success.", "view" => 200]);
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }
}
