<?php

namespace App\Http\Controllers\Fgp\Finance;

use App\Http\Controllers\BaseController;
use App\Jobs\GenerateHVS;
use App\Lib\Exporter\CSVExporter;
use App\Lib\Exporter\JSONExporter;
use App\Lib\Exporter\PDFExporter;
use App\Lib\Log\Log;
use App\Mail\Fgp\TimesheetPostMail;
use App\Models\Fgp\ApprovalFlow;
use App\Models\Fgp\HighVolumeHeaders;
use App\Models\Fgp\PayPeriod;
use App\Models\Fgp\Site;
use App\Models\Fgp\StipendCalc;
use App\Models\Fgp\StipendCalcTypes;
use App\Models\Fgp\StipendCalcVols;
use App\Models\Fgp\StipendItem;
use App\Models\Fgp\Timesheet;
use App\Models\Fgp\Volunteer;
use App\Models\ReportLog;
use App\Models\Settings\Lookups;
use App\Models\User;
use App\Repo\FGP\FinanceRepo;
use App\Repo\FGP\PayPeriodRepo;
use App\Repo\TimeSheetRepo;
use App\Traits\Xlxm;
use DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class FinanceController extends BaseController
{
    use Xlxm;

    private $clayout;
    private static $repo;

    public function __construct()
    {
        parent::__construct();
        $this->clayout = $this->layout . '.fgp.finance';
    }

    public static function getRepo($model)
    {

        self::$repo = new FinanceRepo($model);
        return self::$repo;
    }

    public function index(Request $request)
    {
        // 'vol_supervisors', 'data', 'stipend_periods', 'approval_flow', 'approval_flow1', 'data'
        return view($this->clayout . '.index', $this->stipend_periods($request));
    }

    private function stipend_periods(Request $request)
    {
        /*
         * formatted stipend period for new finance-time-sheet view
         * */
        $stipend_periods = (new PayPeriodRepo('Fgp\PayPeriod'))->getStipendPeriodsFinance($request, 'finance_time_sheet');

        $supervisor_id = Volunteer::select('vol_supervisor_id')->where('is_deleted', false)->distinct()->pluck('vol_supervisor_id')->toArray();
        $vol_supervisors = User::with('member')->find($supervisor_id);
        foreach ($stipend_periods as $key => $val) {
            $timesheet = Timesheet::where('period_id', $key)->first();
            $val->flow = $timesheet->approval_flow_id;
        }
        $approval_flow = ApprovalFlow::select('id', 'code', 'role')->where('is_deleted', false)->orderBy('seq_num', 'asc')->get();
        $approval_flow1 = ApprovalFlow::where('is_deleted', false)->orderBy('seq_num', 'asc')->get();

        return compact('vol_supervisors', 'stipend_periods', 'approval_flow', 'approval_flow1');
    }

    private function onlyTable(Request $request)
    {
        //        $data = $this->getTableData($request);
        //        dd($data);
        $id = $request->input('stipend_id');
        $timesheet = Timesheet::where('period_id', $id)->first();
        if ($timesheet->approval_flow_id != '' || $timesheet->approval_flow_id != null) {
            $flow = ApprovalFlow::find($timesheet->approval_flow_id);
            $seq = $timesheet->approval_flow_id;
        } else {
            $flow = ApprovalFlow::where('is_deleted', false)->orderby('seq_num', 'asc')->first();
            $seq = $flow->id;
        }
        $approval_flow = ApprovalFlow::where('is_deleted', false)->orderBy('seq_num', 'asc')->pluck('seq_num');
        $approval_flow1 = ApprovalFlow::where('is_deleted', false)->orderBy('seq_num', 'asc')->get();
        return compact('data', 'id', 'seq', 'approval_flow', 'approval_flow1', 'timesheet');
    }

    // table data
    private function getTableData(Request $request)
    {
        return (new TimeSheetRepo('Fgp\Timesheet'))
            ->selectFinanceDataTable($request);
    }

    public function getAll(Request $request, $type, $id = null)
    {
        if ($type == "period") {
            $data = self::getRepo('Fgp\StipendCalc')->selectDataTablePeriod($request);
            return $data;
        } elseif ($type == "sites") {
            $data = self::getRepo('Fgp\StipendCalc')->selectDataTableSites($request);
            return $data;
        } elseif ($type == "volunteer") {
            $data = self::getRepo('Fgp\StipendCalc')->selectDataTableVolunteer($request, $id);
            return $data;
        }
    }

    public function getView($view)
    {
        return view($this->clayout . '.includes.partial.' . $view);
    }

    /*================= volunteer view modals ==============*/
    public function viewVolunteer(Volunteer $volunteer, StipendCalcVols $stipend)
    {
        $types = StipendCalcTypes::select([
            'type_name as type', 'total_hrs',
        ])->where([
            'table_name' => 'volunteers', 'table_id' => $stipend->id,
            'stipend_calc_id' => $stipend->stipend_calc_id,
        ])->get();
        // dd($volunteer->id, $stipend->stipend_calc_id);
        $site = $stipend->site;
        $items = DB::table('timesheets')->where([
            'period_id' => $stipend->period_id, 'site_id' => $stipend->site_id,
            'volunteer_id' => $stipend->vol_id,
        ])->leftjoin('time_sheet_items as tsi', 'tsi.time_sheet_id', 'timesheets.id')
            ->select('tsi.type', DB::raw('sum(tsi.amount) as amount'))
            ->groupBy('tsi.type')
            ->get();
        $comments = DB::table('timesheets')->where([
            'period_id' => $stipend->period_id, 'site_id' => $stipend->site_id,
            'volunteer_id' => $stipend->vol_id,
        ])->whereRaw('comment != ""')->count();
        return view($this->clayout . '.volunteer.view', compact('volunteer', 'stipend', 'types', 'site', 'items', 'comments'));
    }

    //finance approve
    public function beforeAction(Request $request, $action, $num)
    {
        if ($action == "delete") {
            $title = "Are you sure to delete " . $num . " volunteer(s) ?";
        } else {
            $title = "Are you sure to approve " . $num . " volunteer(s) ?";
        }
        $showCheckbox = false;
        if($request->periods) {
            $periods = explode(',',$request->periods);
            $remainingVols = StipendCalcVols::whereIn('period_id', $periods)->whereNull('status')->count();
            $showCheckbox = $remainingVols == $num;
        }
        return view($this->clayout . '.includes.modals.beforeAction', compact('action', 'title', 'showCheckbox'));
    }

    public function chooseAction()
    {
        return view($this->clayout . '.includes.modals.chooseAction');
    }
    //direct approval   approval as period
    public function approveAllFinance(Request $request)
    {
        DB::beginTransaction();
        try {
            $ids = $request->id;
            foreach ($ids as $id) {
                $stipend_calc = StipendCalc::find($id);
                $this->runFinanceApproval($id, auth()->id());
            }
            DB::commit();
            return $this->response('Finance Approve Successfully', "view", 200);
        } catch (\Exception $e) {
            DB::rollBack();
            throw $e;
            return $this->response($e->getMessage(), "view", 500);
        }
    }

    //queue qpproval
    public function queueAllFinance(Request $request)
    {
        DB::beginTransaction();
        try {
            $ids = $request->id;
            // dd($ids);
            $success = [];
            $error = [];
            $datas = [];
            foreach ($ids as $id) {
                $stipend_calc = StipendCalc::find($id);
                $stipend_calc->is_queue = true;
                $stipend_calc->save();
                DB::Commit();
                GenerateHVS::dispatch($id, auth()->id());
            }
        } catch (\Exception $e) {
            DB::rollBack();
            throw $e;
            return $this->response($e->getMessage(), "view", 500);
        }
    }
    //approval as volunter
    public function approveAllFinanceVolunteer(Request $request)
    {
        // dd($request->all());
        DB::beginTransaction();
        try {

            $csvData = collect();
            $vol_ids = array_unique($request->ids);
            $period_ids = array_unique($request->period_id);

            $periods = PayPeriod::find($period_ids);
            $r = StipendCalcVols::whereIn('period_id', $period_ids)
                ->whereNull('status')
                ->whereIn('vol_id', $vol_ids)
                ->groupBy('vol_id')->get();

            foreach ($r as $stipends) {
                $data = $this->runFinanceApprovalVol($stipends, auth()->user());
                $csvData->push($data);
            }
            // dd($csvData);
            $periods->each(function ($period) use ($vol_ids) {
                $period->supervisors = Timesheet::with(['member' => function ($query) {
                    $query->selectRaw('concat(first_name, " ", last_name) as full_name, user_id');
                }])
                    ->where('period_id', $period->id)->whereIn('volunteer_id', $vol_ids)->get()
                    ->pluck('member')->pluck('full_name')->unique();
            });

            $csvData = $csvData->collapse();

            /* dd($csvData->map(function($st) {
            return array_filter($st);
            })); */
            $csvData = $csvData->toArray();
            $headers = HighVolumeHeaders::where('is_deleted', false)->orderBy('seq_num', 'asc')->get();

            $fields = [];
            $codes = [];
            $keys = [];
            foreach ($headers as $head) {

                array_push($fields, $head->label);
                array_push($codes, $head->code . '');
                $keys[$head->mapping_key] = $head->default_value; // changes
            }
            // dd($csvData);
            $filename = $this->generate('csv', $codes, $fields, $csvData, 'high_volume_spreadsheet');
            if ($filename) {
                $report = $this->storeReportLog('high_volume_spreadsheet', $filename, auth()->id(), null, $r);
                $xlsm = $this->generateXlsm($filename);
                if ($xlsm) {
                    $counties = Site::with('address')->whereIn('id', $r->pluck('site_id')->all())->get()
                        ->pluck('address.county')->unique();

                    $period_string = $periods->pluck('period_no')->implode(', Period #');
                    // $link = url("hvs/report/download/{$report->id}?type=xlsm");
                    $subject = "eStipend Posting for Period #$period_string";
                    Mail::to($request->user()->email)->send(new TimesheetPostMail([
                        'file' => $xlsm,
                        // 'link' => $link,
                        'user' => $request->user()->member,
                        'periods' => $periods,
                        'counties' => $counties,
                        'subject' => $subject,
                    ]));
                }
            }

            if($request->input('close_period') == '1') {

                foreach ($period_ids as $pp) {
                    $total = Timesheet::where('period_id', $pp)->count();
                    $posted = Timesheet::where('period_id', $pp)->where('status', 'posted')->count();
    
                    if ($total === $posted) {
                        PayPeriod::where('id', $pp)->update([
                            'pay_stat' => 'Posted', 'closed_date' => date('Y-m-d'),
                            'closed_time' => date('H:i:s'),
                        ]);
                    }
                }
            }
            DB::commit();
            return $this->response('Finance Approve Successfully', "view", 200);
        } catch (\Exception $e) {
            DB::rollBack();
            // dd($e);
            return $this->response($e->getMessage(), "view", 500);
        }
    }

    /**
     * @param $stipend
     * @param $user
     * @return array
     */
    private function runFinanceApprovalVol($stipend, $user)
    {

        $oldData = $stipend->__toString();
        /* $stipend->status = "Closed";
        $stipend->approved_by = $user->id;
        $stipend->approved_date = date('Y-m-d');
        $stipend->is_queue = false;
        $stipend->save(); */

        $approvedBy = User::find($stipend->approved_by);
        if (!is_null($approvedBy)) {
            $this->note($stipend, 'Stipend Period Approved by ' . ucfirst($approvedBy->member->first_name) . ' ' . ucfirst($approvedBy->member->last_name) . ' (' . ucfirst($approvedBy->role->name) . ')', 'note');
        } else {
            $this->note($stipend, 'Stipend Period Approved', 'note');
        }
        $newData = $stipend->__toString();
        self::getRepo($stipend)->audit($stipend->period_id, $oldData, $newData, $user->id);

        $filename = 'FiscalApprovalVolunteer' . date('Y-m-d');
        if(!defined('DS')) 
            define('DS', DIRECTORY_SEPARATOR);
        $full_path = env('APP_LOG_FILE_PATH', storage_path() . '\logs\FiscalApproval\success');
        $log_file = $full_path . DS . $filename . '.txt';
        if (file_exists($log_file)) {
            file_put_contents($log_file, "");
        }
        $period = PayPeriod::find($stipend->period_id);
        $message = 'High Volume SpreadSheet are Generated of Stipend Period ID ' . $period->period_no;
        $data = $this->prepareLogMessage($period->period_no, $message);
        $this->saveToLogMessage($data, $filename, ['FiscalApproval', 'success']);

        $data = $this->generateHighVolumeSpreadSheet($stipend, $user->id, $period, true);

        /*
        updating after getting all data
         */
        StipendCalcVols::where([
            'period_id' => $stipend->period_id,
            'vol_id' => $stipend->vol_id,
        ])->update([
            'status' => 'Closed',
            'approved_by' => $user->id,
            'approved_date' => date('Y-m-d'),
            'is_queue' => 0,
        ]);

        Timesheet::where([
            'period_id' => $stipend->period_id,
            'volunteer_id' => $stipend->vol_id,
            'next_approval' => 'Posted',
        ])->update(['co_no' => 2]);

        return $data;
    }
    //real approval process runs hear
    public function runFinanceApproval($id, $user_id)
    {
        $stipend = StipendCalc::find($id);
        $period = PayPeriod::find($stipend->period_unq_id);
        $period->closed_date = date('Y-m-d');
        $period->save();

        Timesheet::where("period_id", $stipend->period_unq_id)->update([
            'status' => 'Closed',
        ]);

        $oldData = $stipend->__toString();
        $stipend->status = "Approved";
        $stipend->approved_id = $user_id;
        $stipend->approved_date = date('Y-m-d');
        $stipend->is_queue = false;
        $stipend->save();
        $approvedBy = User::find($stipend->approved_id);
        if (!is_null($approvedBy)) {
            $this->note($stipend, 'Stipend Period Approved by ' . $approvedBy->name, 'note');
        } else {
            $this->note($stipend, 'Stipend Period Approved', 'note');
        }

        $newData = $stipend->__toString();
        self::getRepo($stipend)->audit($stipend->id, $oldData, $newData, $user_id);

        $filename = 'FiscalApproval' . date('Y-m-d');
        defined('DS') or define('DS', DIRECTORY_SEPARATOR);
        $full_path = env('APP_LOG_FILE_PATH', storage_path() . '\logs\FiscalApproval\success');
        $log_file = $full_path . DS . $filename . '.txt';
        if (file_exists($log_file)) {
            file_put_contents($log_file, "");
        }
        $message = 'High Volume SpreadSheet are Generated of Stipend Period ID ' . $period->period_no;
        $data = $this->prepareLogMessage($period->period_no, $message);
        $this->saveToLogMessage($data, $filename, ['FiscalApproval', 'success']);

        $this->generateHighVolumeSpreadSheet($stipend, $user_id, $period);
    }

    //generate of high volume SpreadSheet
    public function generateHighVolumeSpreadSheet($stipend, $user_id, $period, $volunteer = false)
    {

        $headers = HighVolumeHeaders::where('is_deleted', false)->orderBy('seq_num', 'asc')->get();
        $fields = [];
        $codes = [];
        $keys = [];
        foreach ($headers as $head) {
            array_push($fields, $head->label);
            array_push($codes, $head->code . '');
            $keys[$head->mapping_key] = $head->default_value; // changes
        }
        // dd($fields);
        if ($volunteer) {
            $datas = self::getRepo('Fgp\StipendCalc')->getDetailsForSpreadSheetVol($stipend);
        } else {
            $datas = self::getRepo('Fgp\StipendCalc')->getDetailsForSpreadSheet($stipend->id);
        }
        $c = array_unique($codes);
        $c = array_values($c);
        $d = [];

        $category_cd = siteSettingsValue('category_code');
        $stipendCodes = StipendItem::whereIn('item_code', ['stipend', 'stipends'])->first();

        $date_fm = "n/j/Y";
        if ($volunteer) {
            foreach ($datas as $k => $data) {
                $items = Lookups::where('code', 'CodeCategory')->where('is_deleted', false)->orderBy('sequence_num', 'asc')->get();
                $c = 2;
                foreach ($items as $k => $item) {
                    // $c = $k + 1;
                    if ($item->value == "Type") {
                        $data->item[$k] = [
                            'invoice_number' => $data->invoice_number . '-' . date('m/d', strtotime($data->start_date)) . '-' . date('m/d/Y', strtotime($data->end_date)),
                            'invoice_date' => date($date_fm, strtotime($data->invoice_date)),
                            'voucher_line_number' => $data->voucher_line_number,
                            'budget_reference' => $data->fiscal_year,
                            'merchandise_amt' => $data->merchandise_amt,
                            'gross_invoice_amount' => $data->gross_invoice_amount,
                            'goods_recv_dt' => date($date_fm, strtotime($data->goods_recv_dt)),
                            'description' => 'Stipends',
                            'voucher_line_number1' => $data->voucher_line_number,
                            'distribution_line' => $data->voucher_line_number,
                            'category_cd' => $category_cd,
                            'supplier_id' => str_pad($data->vendor_id, 10, '0', 0),
                            'supplier_location' => $data->vendor_loc,
                            'user_id' => auth()->user()->alt_id,
                            'accounting_date' => date($date_fm),
                            'fund_code' => $stipendCodes->fund_code,
                            'department' => $stipendCodes->department_code,
                            'operating_unit' => $stipendCodes->operating_unit,
                            'appropriation' => $stipendCodes->appropriation,
                            'account' => $stipendCodes->account_code,
                            'program_code' => $stipendCodes->program_code,
                            'school_code' => $stipendCodes->school_code,
                            'pc_business_unit' => $stipendCodes->business_unit,
                            'project' => "'" . $stipendCodes->project_code,
                            'activity' => $stipendCodes->item_header ?: $stipendCodes->item_code,
                        ];
                    } else {
                        $i = DB::table('timesheets')
                            ->leftJoin('time_sheet_items', 'time_sheet_items.time_sheet_id', 'timesheets.id')
                            ->leftJoin('stipend_items', 'stipend_items.id', 'time_sheet_items.stipend_item_id')
                            ->select(
                                'stipend_items.item_name',
                                'stipend_items.category as description',
                                'stipend_items.project_code as project',
                                'stipend_items.fund_code',
                                'stipend_items.department_code as department',
                                'stipend_items.account_code as account',
                                DB::raw('stipend_items.program_code'),
                                DB::raw('stipend_items.school_code'),
                                /*'stipend_items.business_unit',*/
                                'stipend_items.business_unit as pc_business_unit',
                                'stipend_items.year as budget_reference',
                                'stipend_items.item_code',
                                'stipend_items.item_name',
                                DB::raw('"" as statistic_amount'),
                                'stipend_items.operating_unit',
                                'stipend_items.appropriation',
                                'stipend_items.item_header as activity',
                                DB::raw('sum(stipend_items.unit_amount) as merchandise_amt'),
                                DB::raw('CONCAT("' . $c . '") as voucher_line_number'),
                                DB::raw('CONCAT("1") as distribution_line'),
                                DB::raw("'$category_cd' as category_cd"),
                                DB::raw('"" as remitting_address'),
                                DB::raw('"" as address_sequence_number')
                            )->where('timesheets.period_id', $stipend->period_id)
                            ->where('timesheets.co_no', 1)
                            ->where('timesheets.next_approval', 'Ready For HSV')
                            ->where('timesheets.volunteer_id', $stipend->vol_id)
                            ->where('stipend_items.category', $item->value)
                            ->groupBy('stipend_items.category')->first();
                        if (!is_null($i)) {
                            $c++;
                            $data->item[$k] = $i;
                        }
                    }
                }
            }
        }
        $cleanData = $this->highVolumeCsv($keys, $datas);
        if ($volunteer) {
            return $cleanData;
        } else {
            //            $filename = $this->generateXlsm($codes, $fields, $cleanData, 'high_volume_spreadsheet');
            $filename = $this->generate('csv', $codes, $fields, $cleanData, 'high_volume_spreadsheet');
            if ($filename) {
                $this->storeReportLog('high_volume_spreadsheet', $filename, $user_id, $period);
            }
        }
    }

    public function highVolumeCsv($fields, $datas)
    {
        $dataArr = [];
        foreach ($datas as $data) {
            if (isset($data->item) && is_array($data->item)) {
                foreach ($data->item as $k1 => $v1) {
                    $items = [];
                    foreach ($fields as $field => $default) {
                        $items[$field] = $default;
                        $getField = preg_replace('#[0-3]{1}$#', '', $field);

                        if (!array_key_exists($getField, $v1)) {
                            continue;
                        }

                        // only code 002 fields
                        if (in_array($getField, [
                            'project', 'fund_code', 'department', 'account', 'program_code', 'budget_reference',
                            'school_code', 'appropriation', 'operating_unit', 'pc_business_unit', 'activity',
                        ]) && !str_contains($field, '2')) {
                            continue;
                        }

                        if ($getField === 'description' && str_contains($field, '2')) {
                            continue;
                        }

                        if (is_array($v1)) {
                            $items[$field] = $v1[$getField];
                            /*
                         * this is commented due to non-redundancy of headers value
                         * if (!$items[$field]) {
                        for ($i = 0; $i < 4; $i++) {
                        if (array_key_exists($getField.$i, $items) && $items[$getField.$i]) {
                        $items[$field] = $items[$getField.$i];
                        }
                        }
                        }*/
                        } else {
                            $items[$field] = $v1->$getField;
                            /*
                         * this is commented due to non-redundancy of headers value
                         * if (!$items[$field]) {
                        for ($i = 0; $i < 4; $i++) {
                        if (array_key_exists($getField.$i, $items) && $items[$getField.$i]) {
                        $items[$field] = $items[$getField.$i];
                        }
                        }
                        }*/
                        }
                    }
                    // dd($items);
                    array_push($dataArr, $items);
                }
            }
        }
        //         dd($dataArr);
        return $dataArr;
    }
    /**
     * @param $report_name
     * @param $filename
     * @return ReportLog
     */
    public function storeReportLog($report_name, $filename, $user_id, $period = null, $r = null, $return = false)
    {
        $report = new ReportLog();
        // dd($r);
        if ($r != null) {
            $periods = [];
            $sites = [];
            $vols = [];
            foreach ($r as $t) {
                array_push($periods, $t->period_id);
                array_push($sites, $t->site_id);
                array_push($vols, $t->vol_id);
            }
            $periods = array_unique($periods);
            $sites = array_unique($sites);
            $vols = array_unique($vols);
            $report->period_id = implode(',', $periods);
            $report->site_id = implode(',', $sites);
            $report->vol_id = implode(',', $vols);
        }
        $report->report_type = 'Spreadsheet';
        $report->report_name = 'High Volume Report';
        $report->userc_id = $user_id;
        $report->file_name = $filename;
        if ($return) {
            $report->stipend_num = $period->period_no;
        }
        $report->save();
        return $report;
    }

    public function generate($format, $codes, $field, $data, $fileName, $mode = '')
    {
        //         dd($data);
        switch (strtolower($format)) {
            case 'csv':
                return CSVExporter::highVolumeSpreadSheet($codes, $field, $data, $fileName);
                break;
            case 'json':
                unset($data['request']);
                unset($data['table']);
                return JSONExporter::jsonExport($data, $fileName);
                break;
            case 'pdf':
                return PDFExporter::pdfExport($field, $data, $fileName, $mode);
                break;
            default:
                return false;
        }
    }

    public function prepareLogMessage($id, $message, $status = 'success')
    {
        $data = $message;
        return $data;
    }

    public function saveToLogMessage($data, $name = 'fiscal', $folder = [], $flag = 'a')
    {
        (new Log())->save($data, $name, $folder, $flag);
        return true;
    }

    public function queueUpdate($id)
    {
        $app = StipendCalc::find($id);
        return $app->is_queue;
    }
}
