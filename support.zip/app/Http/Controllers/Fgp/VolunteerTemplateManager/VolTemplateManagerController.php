<?php

namespace App\Http\Controllers\Fgp\VolunteerTemplateManager;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repo\FGP\TemplateManagerRepo;
use App\Models\User;
use App\Models\Fgp\Volunteer;

class VolTemplateManagerController extends Controller
{

    private const PATH = 'default.fgp.volunteer-template-manager.';
    private $repo;

    private function getPath(){
        return static::PATH;
    }

    public function __construct()
    {
        $this->repo = new TemplateManagerRepo;   
    }

    public function __invoke(){

        return view($this->getPath()."index",[

            'vol_supervisors' => $this->getSupervisors(),
            'categories' => $this->repo->getTemplateCategories()        
        ]);

    }

    public function getAllTemplates(Request $request){
        return $this->repo->selectDataTable($request);
    }

    private function getSupervisors(){
       return User::where('role_id', 3)->get();

    }

    public function transferTemplates(Request $request){
        return view($this->getPath().'modal.activateTemplate', [
            'volunteers' => $request->volsToTransfer
        ]);
    }

    public function activateTemplates(Request $request){

        Volunteer::whereIn('id', $request->volsToTransfer)
        ->with(['defaultTemplate', 'allTemplates' => function($query) use($request){
            $query->where('category_id', $request->category_id);
        }])        
        ->get()
        ->each(function($vol) use($request) {           

            if($temp = $vol->allTemplates->first()) {
                
                if($vol->defaultTemplate && $vol->defaultTemplate->category_id != $request->category_id) {

                    $vol->defaultTemplate->is_default = 0;
                    $vol->defaultTemplate->save();
                }

                $temp->is_default = 1;
                $temp->save();
            }
        });


    }

}
