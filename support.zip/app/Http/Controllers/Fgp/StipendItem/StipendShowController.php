<?php

namespace App\Http\Controllers\Fgp\StipendItem;

use App\Http\Controllers\BaseController;
use App\Models\Fgp\StipendItem;
use App\Models\Settings\Lookups;
use App\Repo\FGP\StipendItemRepo;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class StipendShowController extends BaseController
{
    private static $repo;
    public function __construct()
    {
        parent::__construct();
        $this->clayout = $this->layout . '.fgp.stipend_time_item';
    }
    public function __invoke(){
        return view($this->clayout.'.index');
    }
    public static function getRepo($model){
        self::$repo = new StipendItemRepo($model);
        return self::$repo;
    }
    public  function stipendItemType(Request $request){
        $data = self::getRepo('Fgp\StipendItem')->selectDataOnlyTypeCategory($request);
        return $data;
    }
    public function addTimeItem(){
        $id = 1;
        $validations = validation_value('stipend_item_create');
        return view($this->clayout.'.modal_new.item-time-add',compact('validations','id'));
    }

    public function editTimeItem($id){

        $validations = validation_value('stipend_item_create');
        $stipendItem = StipendItem::find($id);
        return view($this->clayout.'.modal_new.item-time-update',compact('validations','id','stipendItem'));
    }
    public function getLookup($category,$codeType) {

        return Lookups::select(\DB::raw('CONCAT(COALESCE(description,"")," - ",COALESCE(value,"")) as value'), 'value as id')
            ->where('code',$codeType)
            ->where('section','FinanceCode')
            ->where('type',$category)
            ->where('is_deleted',0)
            ->get();
    }

    public function getLookupSearch($category,$codeType,$data) {

        return Lookups::select(\DB::raw('CONCAT(COALESCE(description,"")," - ",COALESCE(value,"")) as value'), 'value as id')
            ->where('code',$codeType)
            ->where('section','FinanceCode')
            ->where('type',$category)
            ->when($data, function($query) use($data){
                $query->where('value', 'like', '%'. $data .'%')
                    ->orWhere('description','like','%'. $data .'%');
            })
            ->where('code',$codeType)
            ->where('section','FinanceCode')
            ->where('type',$category)
            ->where('is_deleted',0)
            ->get();
    }

    public function checkCode($category,$codeType,$value) {
        $data = Lookups::where('code',$codeType)
            ->where('section','FinanceCode')
            ->where('type',$category)
            ->where('value',$value)
            ->where('is_deleted',0)
            ->first();
        if ($data) return response(["msg"=>"Success"],200);
        else return response(["msg"=>"This code not available, Do you want to continue?"],422);
    }

    public function confirm() {
        return view($this->clayout.'.modal_new.modal-confirm');
    }

    public function getCategory() {
        $category = Lookups::select('type as value','id as id')
            ->where('section','FinanceCode')
            ->where('type','!=','Type')
            ->groupBy('type')
            ->get();
        return $category;
    }

    public function addExpenseItem() {
        $id = 1;
        $validations = validation_value('stipend_item_create');
        return view($this->clayout.'.modal_new.item-expense-add',compact('validations','id'));
    }

    public function editExpenseItem($id) {
        $stipendItem = StipendItem::find($id);
        $validations = validation_value('stipend_item_create');
        return view($this->clayout.'.modal_new.item-expense-update',compact('stipendItem','validations'));
    }

}
