<?php

namespace App\Http\Controllers\Fgp\StipendItem;

use App\Http\Controllers\BaseController;
use App\Http\Requests\Fgp\StipendItemRequest;
use App\Models\Fgp\StipendItem;
use App\Models\Settings\Lookups;
use App\Repo\FGP\StipendItemRepo;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class StipendItemStoreController extends BaseController
{

    private static $repo = null;
    protected $code;
    protected $category;
    public static function getRepo($model)
    {
        self::$repo = new StipendItemRepo($model);
        return self::$repo;
    }

    private function createCodeFromLabel($label)
    {
        return array_reduce(explode(' ', $label), function ($acc, $ite) {

            return $acc ? $acc . "_" . strtolower($ite) : strtolower($ite);
        }, '');
    }

    private function getMissingInActionFields(): \Illuminate\Support\Collection
    {

        return collect(['project_code', 'fund_code', 'department_code', 'account_code', 'program_code', 'business_unit', 'operating_unit', 'appropriation', 'school_code']);
    }

    //store and update
    public function storeItem(StipendItemRequest $request, StipendItem $stipendItem = null)
    {

        $stipendItemInfo = $request->only([
            'item_name', 'year', 'item_header', 'description', 'unit_amount', 'max_amount', 'category', 'project_code',
            'fund_code', 'department_code', 'account_code', 'program_code', 'business_unit', 'is_active', 'is_eto', 'is_fsy', 'extended_sick_level',
            'field_type', 'operating_unit', 'appropriation', 'school_code'
        ]);
        $mia = $this->getMissingInActionFields();

        /** set atleast null to the missing fields */
        $mia->each(function ($clearAbles) use ($request, &$stipendItemInfo) {

            $stipendItemInfo[$clearAbles] = $request->$clearAbles;
        })->all();

        $required_codes = $request->only([
            'project_code', 'fund_code', 'department_code', 'account_code', 'program_code', 'business_unit'
        ]);

        if ($stipendItemInfo) {

            $this->checkLookup($request->category, $required_codes);

            if ($request->is_active == "on") :
                $stipendItemInfo['is_active'] = 1;
            else :
                $stipendItemInfo['is_active'] = 0;
            endif;

            if (!$request->item_header)
                $stipendItemInfo['item_header'] = ''; //$this->createCodeFromLabel($request->item_name);

            if ($request->is_eto == "on") :
                $stipendItemInfo['is_eto'] = 1;
            else :
                $stipendItemInfo['is_eto'] = 0;
            endif;

            if ($request->is_fsy == "on") :
                $stipendItemInfo['is_fsy'] = 1;
            else :
                $stipendItemInfo['is_fsy'] = 0;
            endif;

            if ($request->extended_sick_level == "on") :
                $stipendItemInfo['extended_sick_level'] = 1;
            else :
                $stipendItemInfo['extended_sick_level'] = 0;
            endif;

            //change item_name into item_code
            $item_code = str_replace(" ", "_", $stipendItemInfo["item_name"]);
            $stipendItemInfo['item_code'] = $item_code;


            if ($stipendItem) {
                $update = self::getRepo($stipendItem)->saveUpdate($stipendItemInfo);
                if ($update) :
                    return $this->response('Successfully Stipend Item Updated', 'view', '200');
                else :
                    return $this->response('Failed to Update', 'view', '500');
                endif;
            } else {

                $checkItemCode = StipendItem::where('item_code', $stipendItemInfo['item_code'])->first();
                if (!$checkItemCode) {
                    $save = self::getRepo('Fgp\StipendItem')->saveUpdate($stipendItemInfo);
                    if ($save) :
                        return $this->response('Successfully Created', 'view', '200');
                    else :
                        return $this->response('Failed to create', 'view', '500');
                    endif;
                } else {
                    return $this->response('Item Code Already Exists', 'view', '500');
                }
            }
        }
    }

    private function checkLookup($category, $codes)
    {
        foreach ($codes as $key => $code) {
            if ($code !== null) {
                $check = Lookups::where('value', $code)->where('type', $category)->first();
                if (!$check) {
                    if ($key == "project_code") {
                        $this->code = "Project";
                    } else if ($key == "department_code") {
                        $this->code = "Department";
                    } else if ($key == "fund_code") {
                        $this->code = "Fund";
                    } else if ($key == "account_code") {
                        $this->code = "Account";
                    } else if ($key == "program_code") {
                        $this->code = "Program";
                    } else if ($key == "business_unit") {
                        $this->code = "Business";
                    }
                    //                    Lookups::create([
                    //                        'code'=>$this->code,
                    //                        'value'=>$code,
                    //                        'type'   => $category,
                    //                        'section'    => 'FinanceCode',
                    //                        'userc_id'   => Auth::user()->id,
                    //                   ]);

                }
            }
        }
    }

    public function updateItem(Request $request, StipendItem $stipendItem)
    {

        $update =  self::getRepo($stipendItem)->saveUpdate($request->all());
        if ($update) :
            return $this->response('Successfully Stipend Item Updated', 'view', '200');
        else :
            return $this->response('Failed to Update', 'view', '500');
        endif;
    }

    public function deleteItem(Request $request)
    {
        $deleted = StipendItem::find($request->id)
            ->update([
                'is_deleted' => 1,
                'useru_id' => $request->userd_id
            ]);
        if ($deleted) :
            return $this->response('Item Deleted Successfully', 'view', '200');
        else :
            return $this->response('Failed to Delete Item', 'view', '500');
        endif;
    }

    private function validateFinanceCode(Request $request)
    {

        $this->validate($request, [

            "description" => "required|string",
            "value" => "required|string"

        ], [

            "description.required" => "The name field is required",
            "value.required" => "The Finance Code field is required",

        ]);
    }

    /**
     * Update Stipend Item code exisitng on lookups table
     * @param  Request $request [description]
     * @param  Lookups $lookup  [description]
     * @return Lookups $lookup          
     */
    public function updateStipendItemCode(Request $request, Lookups $lookup): Lookups
    {

        $this->validateFinanceCode($request);

        $lookup->update($request->all());

        return $lookup;
    }

    /**
     * Add Stipend Item code exisitng on lookups table
     * @param  Request $request [description]
     * @param  Lookups $lookup  [description]
     * @return Lookups $lookup          
     */
    public function addStipendItemCode(Request $request): Lookups
    {

        $this->validateFinanceCode($request);

        $lookup = new Lookups;

        $lookup->create($request->all());

        return $lookup;
    }

    public function deleteStipendCode(Lookups $lookup)
    {


        $lookup->update(['is_deleted' => 1]);

        return response(["Stipend Code Deleted"], 200);
    }
}
