<?php

namespace App\Http\Controllers\Fgp\StipendItem;

use App\Http\Controllers\BaseController;
use App\Lib\Exporter\CSVExporter;
use App\Models\Fgp\StipendItem;
use App\Models\Settings\Lookups;
use App\Repo\FGP\StipendItemRepo;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class StipendTimeItemShowController extends BaseController
{
    private static $repo;
    public function __construct()
    {
        parent::__construct();
        $this->clayout = $this->layout . '.fgp.stipend_time_item';
    }
    public function __invoke(){
        return view($this->clayout.'.index');
    }
    public static function getRepo($model){
        self::$repo = new StipendItemRepo($model);
        return self::$repo;
    }


    public  function stipendItemType(Request $request){
        $data = self::getRepo('Fgp\StipendItem')->selectDataOnlyTypeCategory($request);
        return $data;
    }


    public function addTimeItem(){
        $id = 1;
        $validations = validation_value('stipend_item_create');
        // return view($this->clayout.'.modals.add',compact('validations','id'));
       return view($this->clayout.'.modals.stipend-time-item-add',compact('validations','id'));
    }


    public function editTimeItem($id){
        $stipendItem = StipendItem::find($id);
        $validations = validation_value('stipend_item_create');
        // return view($this->clayout.'.modals.update1',compact('stipendItem','validations'));
        // return view($this->clayout.'.modals.update',compact('stipendItem','validations'));
        return view($this->clayout.'.modals.stipend-time-item-update',compact('stipendItem','validations'));
    }

    public function deleteTimeItem($id){
        return $this->view($this->clayout.'.modals.delete',compact('id'));
    }

    public function exportStipendTimeItem(Request $request,$type) {

        $data = StipendItem::select('item_name','item_code','unit_amount','max_amount','category','project_code',
            'fund_code','department_code','account_code','program_code','business_unit','operating_unit','appropriation','school_code',
            'year')
            ->where('category','Type')->where('is_deleted',0)->get();


        $fields = array('Year', 'Activity', 'Activity Code', 'Project Code', 'Fund Code', 'Department Code',

                        'Account Code','Program Code','Business Unit','Operating Unit','Appropriation','School Code','Unit Amount', 'Max. Amount');

        $mapField = array('year','item_name','item_code','project_code','fund_code','department_code',

                        'account_code','program_code','business_unit','operating_unit','appropriation','school_code','unit_amount','max_amount');

        $data = cleaner($mapField, $data);

        $data['table'] = "Stipend Time Items";
        $data['request'] = ["Search"    =>  "All"];


        if(count($data) > 0){
            $export = $this->reportFactory($type, $fields, $data);

            $exporter = new \App\Lib\Exporter\Exporter($export);

            $filename   = $exporter->export();

            return response()->download($filename)->deleteFileAfterSend(true);
        }{
            return " No data available at the moment";
        }

    }
    /**
     * @param $type
     * @param $data
     * @return CSVExporter|JSONExporter|PDFExporter|TxtExporter
     * @throws \Exception
     */
    public function reportFactory($type, $fields, $data)
    {
        switch ($type) {
            case 'csv':
                return new CSVExporter($data, $fields, 'StipendTimeItems');
                break;
            case 'json':
                return new JSONExporter($data);
                break;
            case 'txt':
                return new TxtExporter($data);
                break;
            case 'pdf':
                return new PDFExporter($data, $fields, 'print');
                break;
            default:
                throw new \Exception("Method Not Allowed " . $type);
                break;
        }
    }

    public function financeCodeLookup(Request $request, $category, $codeType) {
        // dd($category,$codeType);
        // if ($request->has('lookup') && $request->has('section'))

        return Lookups::select('description as text', 'value as val')
            ->where('code',$codeType)
            ->where('section','FinanceCode')
            ->where('type',$category)
            ->when($request->term, function($query) use($request){
                $query->where('value', 'like', '%'. $request->term .'%');
            })
            ->where('is_deleted',0)
            ->get();
    }

    public function stipendItemCategory(Request $request){
         return Lookups::select('value as text', 'value as val')
            ->where('code','CodeCategory')
            ->where('section','FinanceCode')
            ->when($request->term, function($query) use($request){
                $query->where('value', 'like', '%'. $request->term .'%');
            })
            ->where('value','!=','Type')
            ->get();
    }

}
