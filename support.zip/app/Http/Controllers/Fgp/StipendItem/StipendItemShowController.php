<?php

namespace App\Http\Controllers\Fgp\StipendItem;

use App\Http\Controllers\BaseController;
use App\Lib\Exporter\CSVExporter;
use App\Lib\Importer\CsvImporter;
use App\Models\Fgp\StipendItem;
use App\Models\Settings\Lookups;
use App\Repo\Fgp\StipendItemRepo;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
use App\Lib\Filter\Fgp\StipendItemFilter;

class StipendItemShowController extends BaseController
{
    private $myquery;
    private $abc;
    private static $repo;
    private $subClayout;
    public function __construct()
    {
        parent::__construct();
        $this->clayout = $this->layout . '.fgp.stipend-items';
        $this->subClayout = $this->layout . '.fgp.stipend_time_item';
    }
    public static function getRepo($model){
        self::$repo = new StipendItemRepo($model);
        return self::$repo;
    }
    public function __invoke(){
        return view($this->clayout.'.index');
    }

    public function addItem(){
        $id = 1;
        $validations = validation_value('stipend_item_create');
        return view($this->clayout.'.modals.stipend-item-add',compact('validations','id'));
    }


    public function editItem($id){
        $stipendItem = StipendItem::find($id);
        $validations = validation_value('stipend_item_create');
        return view($this->clayout.'.modals.stipend-item-edit',compact('stipendItem','validations'));
        // return view($this->subClayout.'.modals.stipend-time-item-update',compact('stipendItem','validations'));
    }

    public function deleteItem($id){
        return $this->view($this->clayout.'.modals.delete',compact('id'));
    }


    public  function stipendItemAll(Request $request){
        $data = self::getRepo('Fgp\StipendItem')->selectDataTable($request);
        return $data;
    }

    public function fetchLookup1($lookup,$category,$query = null){
        if ($lookup === "CodeCategoryAll"){
            $data = Lookups::select('value', 'id')
                ->where('code','CodeCategory')
                ->when($query, function($query1) use($query){
                    $query1->where('value', 'like', '%'. $this->myquery .'%');
                })
                ->get();
            return $data;
        }
        else if ($lookup === 'CodeCategory'){
            $data = Lookups::select('value', 'id')
                ->where('code',$lookup)
                ->when($query, function($query1) use($query){
                    $query1->where('value', 'like', '%'. $this->myquery .'%');
                })
                ->get();

            $finalData = [];
            foreach ($data as $datum){
                if ($datum->value != "Type"):
                    array_push($finalData,['value'=>$datum->value, 'id'=>$datum->id]);
                endif;
            }
            return $finalData;
        }
        else{
            if($query){
                return Lookups::select('description as value', 'value as id')
                    ->where('code',$lookup)
                    ->where('type',$category)
                    ->when($query,function($qry, $query){
                        $qry->where('value', 'like', $query .'%');
                    })
                    ->get();
            }else{
                return Lookups::select('description as value', 'value as id')
                    ->where('code',$lookup)
                    ->where('type',$category)
                    ->get();
            }
        }
    }



    public function getCategoryName($id) {
        return Lookups::select('value')->where('id',$id)->where('code','CodeCategory')->first();
    }
    public function fetchAmount($id)
    {
        $lookup = Lookups::find($id);
        $item = StipendItem::where('lookup_id', $id)->first();
        if(is_null($item)){
            return ;
        }else{
            return ['id'=> $item->id, 'amt'=>$item->unit_amount];
        }
    }


    /*------------- open sub modals ----------*/


    public function subModalProject($category,$id){

        $data = Lookups::where('code','Project')->where('section','FinanceCode')->where('type',$category)->where('is_deleted', 0)->get();
        return view($this->subClayout.'.modals.sub.project',compact('data','id','category'));
    }

    public function subModalBusiness($category,$id){

        $data = Lookups::where('code','Business')->where('section','FinanceCode')->where('type',$category)->where('is_deleted', 0)->get();
        return view($this->subClayout.'.modals.sub.business',compact('data','id','category'));
    }

    public function subModalFund($category,$id){
        $data = Lookups::where('code','Fund')->where('section','FinanceCode')->where('type',$category)->where('is_deleted', 0)->get();
        return view($this->subClayout.'.modals.sub.fund',compact('data','id','category'));
    }

    public function subModalAccount($category,$id){
        $data = Lookups::where('code','Account')->where('section','FinanceCode')->where('type',$category)->where('is_deleted', 0)->get();
        return view($this->subClayout.'.modals.sub.account',compact('data','id','category'));
    }

    public function subModalDepartment($category,$id){
        $data = Lookups::where('code','Department')->where('section','FinanceCode')->where('type',$category)->where('is_deleted', 0)->get();
        return view($this->subClayout.'.modals.sub.department',compact('data','id','category'));
    }

    public function subModalProgram($category,$id){
        $data = Lookups::where('code','Program')->where('section','FinanceCode')->where('type',$category)->where('is_deleted', 0)->get();
        return view($this->subClayout.'.modals.sub.program',compact('data','id','category'));
    }

    private function createLabelFromCode($code){

        $codeArray = array_reduce(explode('_', $code), function($acc, $ite){

            return $acc . " " . ucfirst($ite);

        }, '');

        return $codeArray;

    }

    public function financeSubModal($category,$code, $id){
        $label = $this->createLabelFromCode($code);
        $data = Lookups::where('code',$code)
        ->where('section','FinanceCode')
        ->where('type',$category)
        ->where('is_deleted', 0)
        ->get();
        return view($this->subClayout.'.modals.sub.financeModal',compact('data','id','category', 'label', 'code'));
    }

    public function financeAdd(Request $request){
        $category = $request->category;
        $code = $request->code;
        return view($this->subClayout.'.modals.sub.finance_code.add',compact('code','category'));
    }

    public function checkFinanceCode($code) {
        if ($code){
            $check = Lookups::where('value',$code)->where('is_deleted',0)->first();
            if (!$check){
                return response()->json(['message'=> 'Doesn\'t exists'],500);
            }else{
                return response()->json(['message'=> 'exists'],200);
            }
        }
    }



    public function checkStipendCategory($code) {
        if ($code){
            $check = Lookups::where('value',$code)
                ->where('code','codeCategory')
                ->where('is_deleted',0)->first();
            if (!$check){
                return response()->json(['message'=> 'Doesn\'t exists'],500);
            }else{
                return response()->json(['message'=> 'exists'],200);
            }
        }
    }

    

    public function getTableDataRefresh($category,$code){
          $data = Lookups::where('code',$code)->where('section','FinanceCode')->where('type',$category)->where('is_deleted', 0)->get();
          return $data;
    }


    public function exportStipendItem(Request $request, $type) {
         $data = StipendItem::select('item_name','item_code','unit_amount','max_amount','category','project_code',
            'fund_code','department_code','account_code','program_code','business_unit','operating_unit','appropriation','school_code',
            'year')
            ->where('category','!=','Type')->where('is_deleted',0)->get();

        $fields = array('Fiscal Year','Activity', 'Activity Code', 'Project Code','Fund Code', 
            'Department Code','Account Code','Program Code','Business Unit','Operating Unit','Appropriation','School Code','Unit Amount', 'Max. Amount');

        $mapField = array('year','item_name','item_code','project_code','fund_code',
           'department_code','account_code','program_code','business_unit','operating_unit','appropriation','school_code','unit_amount','max_amount');

        $data = cleaner($mapField, $data);

        $data['table'] = "Stipend Items";
        $data['request'] = ["Search"    =>  "All"];


        if(count($data) > 0){
            $export = $this->reportFactory($type, $fields, $data);

            $exporter = new \App\Lib\Exporter\Exporter($export);

            $filename   = $exporter->export();

            return response()->download($filename)->deleteFileAfterSend(true);
        }{
            return " No data available at the moment";
        }

    }
    /**
     * @param $type
     * @param $data
     * @return CSVExporter|JSONExporter|PDFExporter|TxtExporter
     * @throws \Exception
     */
    public function reportFactory($type, $fields, $data)
    {
        switch ($type) {
            case 'csv':
                return new CSVExporter($data, $fields, 'StipendItems');
                break;
            case 'json':
                return new JSONExporter($data);
                break;
            case 'txt':
                return new TxtExporter($data);
                break;
            case 'pdf':
                return new PDFExporter($data, $fields, 'print');
                break;
            default:
                throw new \Exception("Method Not Allowed " . $type);
                break;
        }
    }





    /*------------------- lookups ----------*/
    public function getCategory(Request $request){
        if ($request->has('lookup') && $request->has('section'))
        return Lookups::select('value as text', 'value as val')
            ->where('code',$request->lookup)
            ->where('section',$request->section)
            ->when($request->term, function($query) use($request){
                $query->where('value', 'like', '%'. $request->term .'%');
            })
            ->get();
    }

    /* items Edit */

    public function editStipendItem(Lookups $lookup){

        return view($this->subClayout.'.modals.sub.finance_code.edit', [
            'stipendItem' => $lookup
        ]);

    }


}
