<?php

namespace App\Http\Controllers\Fgp\Floater;

use App\Http\Controllers\Controller;
use App\Models\Fgp\Site;

class FloaterShowController extends Controller
{
    private const layout = 'default.fgp.floater.';

    public function create($period, $site)
    {
        return view(self::layout . 'modals.create', compact('period', 'site'));
    }

    public function loadFloater(Site $site)
    {
        return $site->floaters()->select('vol_id', 'first_name', 'middle_name', 'last_name')->get();
    }
}
