<?php

namespace App\Http\Controllers\Fgp\Floater;

use App\Fgp\Floater;
use App\Http\Controllers\Controller;
use App\Models\Fgp\Timesheet;
use Exception;
use Illuminate\Http\Request;

class FloaterAddUpdateController extends Controller
{
    public function addFloaters(Request $request)
    {
        $vol_ids = is_array($request->vol_ids) ? array_unique($request->vol_ids) : [];
        $site_id = $request->site_id;
        $period_id = $request->period_id;

        $data = [];
        $errors = [];
        foreach ($vol_ids as $vol_id):
            $tsExists = Timesheet::where([
                'volunteer_id' => $vol_id,
                'period_id' => $period_id,
                // 'site_id' => $site_id,
            ])->count();

            if ($tsExists > 0) {
                $errors[] = [$vol_id];
            }

            $data[] = [
                'vol_id' => $vol_id,
                'site_id' => $site_id,
                'period_id' => $period_id,
                'created_at' => date('Y-m-d'),
                'updated_at' => date('Y-m-d'),
                'userc_id' => $request->user()->id,
            ];
        endforeach;
        try {
            throw_if(count($errors), new Exception('Volunteer is already in the same period.'));
            $floaters = Floater::insert($data);
            return response(['message' => 'Floaters added successfully', 'data' => $floaters]);
        } catch (Exception $e) {
            return response(['message' => $e->getMessage()], 422);
        }
    }
}
