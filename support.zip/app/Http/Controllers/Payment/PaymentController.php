<?php

namespace App\Http\Controllers\Payment;

use App\Http\Controllers\Application\ProcessController;
use App\Lib\Capture\ScreenCapture;
use App\Lib\Email\EmailSender;
use App\Lib\Notification\Notification;
use App\Models\Application;
use App\Models\Budget;
use App\Models\Invoice;
use App\Models\InvoiceBatch;
use App\Models\Ledger;
use App\Models\Settings\Lookups;
use App\Repo\BudgetRepo;
use Illuminate\Http\Request;
use App\Http\Controllers\BaseController;
use App\Http\Requests\PaymentRequest;
use App\Repo\PaymentRepo;
use App\Models\Payment;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Lib\File\FileUploader;

use App\Lib\Exporter\CSVExporter;
use App\Lib\Exporter\JSONExporter;
use App\Lib\Exporter\PDFExporter;
use App\Lib\Exporter\TxtExporter;

class PaymentController extends BaseController
{
    private static $repo = null;
    private $clayout = "";

    public function __construct()
    {
        parent::__construct();
        $this->clayout = $this->layout . '.pages.payment.';
    }

    /**
     * @param $model
     * @return PaymentRepo|null
     */
    private static function getInstance($model)
    {
        self::$repo = new PaymentRepo($model);
        return self::$repo;
    }

    public function index()
    {
        $status = Lookups::where('code', 'payment_status')->where('is_deleted', false)->get();
        $payMethod = Lookups::where('code', 'payment_method')->where('is_deleted', false)->get();
        return view($this->clayout . 'index', compact('status', 'payMethod'));
    }

    public function getAll(Request $request)
    {
        $data = self::getInstance('Payment')->selectDataTable($request);
        return $data;
    }


    public function export(Request $request, $type)
    {
        $data = self::getInstance('Payment')->exportData($request);
        $fields = array('Invoice Number', 'Transaction Date', 'Transaction Type', 'Payment Method', 'Transaction Status', 'Amount');
        $mapField = array('invoice_id', 'trans_date', 'trans_type', 'payment_method', 'trans_status', 'trans_amount');
        $data = cleaner($mapField, $data);
        $data['request'] = ['Application ID' => $request->applicationID];
        $data['table'] = 'Showing Results of Payment Table';
        if (count($data) > 0) {
            $export = $this->reportFactory($type, $data);
            $exporter = new \App\Lib\Exporter\Exporter($export);
            $filename = $exporter->export();
            return response()->download($filename)->deleteFileAfterSend(true);
        }
        return 'No Data Available For Current Filter';
    }

    /**
     * Create A object for print
     * @param $type
     * @param $data
     * @return CSVExporter|JSONExporter|PDFExporter|TxtExporter
     * @throws \Exception
     */
    public function reportFactory($type, $data)
    {
        switch ($type) {
            case 'csv':
                return new CSVExporter($data, array_keys((array)$data[0]), 'PaymentReports');
                break;
            case 'json':
                return new JSONExporter($data);
                break;
            case 'txt':
                return new TxtExporter($data);
                break;
            case 'pdf':
                return new PDFExporter($data, array_keys((array)$data[0]), 'applicationpdf');
                break;
            default:
                throw new \Exception("Method Not Allowed " . $type);
                break;
        }
    }

    public function edit(Request $request,Payment $payment)
    {
        $source='application';
        if($request->has('source'))
            $source='Payment';
        $id = $payment->table_id;
        return view($this->clayout . 'modal.edit', compact('payment', 'id','source'));
    }

    /**
     * @param Request $request
     * @param Application $application
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function addCopay(Request $request, Application $application)
    {
        $invoice = '';
        $pet = '';
        if ($request->has('inv_id'))
            $invoice = Invoice::find($request->inv_id);

        $source = 'application';
        if ($request->has('source'))
            $source = $request->source;

        if ($request->has('pet'))
            $pet = $request->pet;

        $type = $request->type;

        $payment=$application->payment()->sum('trans_amount');

        return view($this->clayout . 'modal.payment', compact('type', 'application', 'invoice', 'source', 'pet','payment'));
    }

    /**
     * @param PaymentRequest $request
     * @return $this|PaymentController|\Illuminate\Http\JsonResponse
     */
    public function store(PaymentRequest $request)
    {
        DB::beginTransaction();
        try {

            if ($request->trans_type == 'revenue')
                $data = $request->only('table_id', 'ref_no', 'trans_amount', 'trans_type', 'invoice_id', 'trans_date', 'payment_method', 'trans_des', 'cheque_number', 'cheque_name', 'cheque_exp_date', 'cheque_date');
            else {

                if ($this->checkBalance($request->trans_amount))
                    $data = $request->only('table_id', 'inv_id', 'trans_amount', 'trans_type', 'invoice_id', 'trans_date', 'payment_method', 'trans_des', 'cheque_number', 'cheque_name', 'cheque_exp_date', 'cheque_date');
                else
                    return $this->response('Insufficient Balance', 'view', 500);
            }


            $data['table_name'] = 'applications';
            if ($request->payment_method == 'Cash')
                $data['trans_status'] = 'Pending';
            if ($request->payment_method == 'Cash' && $request->trans_type == 'revenue')
                $data['trans_status'] = 'Deposited';
            elseif ($request->payment_method == 'Cheque')
                $data['trans_status'] = 'Chequed';
            elseif ($request->payment_method == 'Card')
                $data['trans_status'] = 'Deposited';
            else
                $data['trans_status']='Paid';
            $data['trans_date'] = date('Y-m-d');
            $data['cheque_exp_date'] = array_key_exists('cheque_exp_date', $data) ? date('Y-m-d', strtotime($data['cheque_exp_date'])) : null;
            $data['cheque_date'] = array_key_exists('cheque_date', $data) ? date('Y-m-d', strtotime($data['cheque_date'])) : null;


            $res = self::getInstance('Payment')->saveUpdate($data);
            $repo = self::getInstance('Payment');

            if ($request->hasFile('photoIdProof')) {
                $fileName = $this->uploadAttachment($request->file());
                $file = $repo->storeUploadedFilePath($fileName, $res);
            }

            if ($res) {
                $application = Application::find($request->table_id);
                $provider = $application->providers();


                if ($request->trans_type == 'revenue') {
                    if (auth()->user()->role_id == 1 || auth()->user()->role->name == 'admin') {
                        $fundData['particulars'] = 'Copay Received';
                        $fundData['table_name'] = $application->getTable();
                        $fundData['table_id'] = $application->id;
                        $fundData['ref_type'] = 'application';
                        $fundData['ref_no'] = $application->alt_id;
                        $fundData['type'] = $application->client->org_id ? 'NP' : 'IE';
                        $fundData['dr_amount'] = $request->trans_amount;
                        $fundData['budget_date'] = date('Y-m-d');
                        $this->payment($fundData);
                    } else {
                        $led = new \App\Lib\Ledger('payment', $res->id, $provider->id, $request->trans_amount, $request->invoice_id, 'voucher', 'dr');
                        $led->store();
                    }
                    return $this->copayProcess($request);
                } else {

                    $led = new \App\Lib\Ledger('payment', $res->id, $provider->id, $request->trans_amount, $request->invoice_id, 'voucher', 'dr');
                    $led->store();

                    $fundData['particulars'] = 'Payment To Provider';
                    $fundData['table_name'] = $provider->getTable();
                    $fundData['table_id'] = $provider->id;
                    $fundData['ref_type'] = 'voucher';
                    $fundData['ref_no'] = $request->invoice_id;
                    $fundData['type'] = $application->client->org_id ? 'NP' : 'IE';
                    $fundData['cr_amount'] = $request->trans_amount;
                    $fundData['budget_date'] = date('Y-m-d');
                    $this->payment($fundData);
                    return $this->invoiceProcess($request);
                }
            } else
                throw new \Exception('Can\'t make payment');

        } catch (\Exception $e) {
            dd($e);
            DB::rollBack();
            return $this->response('Can\'t make payment', 'view', 500);
        }
    }

    public function payment($data)
    {
        $repo = new BudgetRepo('Budget');
        $res = $repo->saveUpdate($data);
        if ($res)
            return $this->response('Fund Added Successfully', 'view', 200);
        else
            return $this->response('Failed To Add Fund', 'view', 500);

    }

    public function checkBalance($amount)
    {
        $dr_balance = Budget::sum('dr_amount');
        $cr_balance = Budget::sum('cr_amount');
        $balance = $dr_balance - $cr_balance;

        return $balance > $amount;
    }

    /**
     * @param Request $request
     * @param Payment $payment
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function view(Request $request, Payment $payment)
    {
        if($request->has('app_id'))
            $application = Application::find($request->app_id);
        else
            $application = Application::find($payment->table_id);

        $provider=$application->providers();

        $client = $application->client;
        if($payment->trans_type == 'revenue'):
            $logo = dashboard_logo('dashboard_logo');
            $type = 'Citizen';
        else:
            $logo = getLogo('organization', $application->provider_id);
            $type = $provider->type;
        endif;
        return view($this->clayout . '.modal.view', compact('application', 'payment', 'client', 'logo', 'provider', 'type'));
    }

    /**
     * @param Request $request
     * @param Payment $payment
     * @return $this
     */
    function download(Request $request, Payment $payment)
    {
        $application = Application::find($request->app_id);
        $client = $application->client;

        $view = view($this->clayout . 'download.paymentDownload', compact('application', 'payment', 'client'));

        $screenCapture = new ScreenCapture();

        $path = $screenCapture->load($view);

        $filename = md5(uniqid()) . ".pdf";
        $headers = [
            'Content-Description' => 'File Transfer',
            'Content-Disposition' => 'attachment; filename="' . $filename . '"',
            'Content-Transfer-Encoding' => 'binary',
            'Content-Type' => 'application/pdf'
        ];
        return response()->download($path, $filename, $headers)->deleteFileAfterSend(true);
    }

    /**
     * @param $file
     * @return array
     */
    public function uploadAttachment($file)
    {
        $fname = FileUploader::upload($file['photoIdProof']);
        return $fname;
    }

    /**
     * @param PaymentRequest $request
     * @param Payment $payment
     * @return $this|\Illuminate\Http\JsonResponse
     */
    public function update(PaymentRequest $request, Payment $payment)
    {
        DB::beginTransaction();
        try {
            $res = self::getInstance($payment)->saveUpdate($request);
            if ($res) {
                DB::commit();
                return $this->response('Payment Made successfully', 'view', 200);
            } else
                throw new \Exception('Can\'t make payment');

        } catch (\Exception $e) {
            DB::rollBack();
            return $this->response('Can\'t make payment', 'view', 500);
        }
    }

    /**
     * @param $type
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function addFieldType($type)
    {
        if ($type == 'Credit Card'):
            return view($this->clayout . '.modal.paymentByCard');
        elseif ($type == 'Check'):
            return view($this->clayout . '.modal.paymentByCheque');
        endif;
    }

    /**
     * @param $request
     * @return $this|\Illuminate\Http\JsonResponse
     */
    public function copayProcess($request)
    {
        $application = Application::find($request->table_id);
        //change Process status
        $process = new ProcessController();
        $process->changeProcessStatus($application, 'Copay Received');

        $mailData['id'] = $application->id;
        $mailData['amount'] = $request->amount;

        $mailer = new EmailSender();
        $mailer->sendEmail('copayReceived', $application->getMailAddress(), $mailData, 'Copay Received Email Notification');

        DB::commit();
        return $this->response('Payment Made successfully', 'view', 200);
    }

    /**
     * @param $request
     * @return $this|\Illuminate\Http\JsonResponse
     */
    public function invoiceProcess($request)
    {
        $application = Application::find($request->table_id);

        $mailData['id'] = $application->id;
        $mailData['amount'] = $request->amount;
        $mailData['inv_number'] = Invoice::find($request->inv_id)->invoice_number;

        $mailer = new EmailSender();
        $mailer->sendEmail('paymentProcess', $application->getMailAddress(), $mailData, 'Payment Processed Email Notification');
        DB::commit();
        return $this->response('Payment Made successfully', 'view', 200);
    }

    /**
     * @param Request $request
     * @param Application $application
     * @return array
     */
    public function getPaymentApplication(Request $request, Application $application)
    {
        return self::getInstance('Payment')->selectPaymentTable($request, $application->id);
    }

    /**
     * @param Request $request
     * @param Payment $payment
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function changeStatusView(Request $request, Payment $payment)
    {
        if ($request->has('source'))
            $source = $request->source;
        else
            $source = 'application';

        $applicationid = $request->app_id;
        $application = Application::find($applicationid);
        $status = Lookups::where('code', 'payment_status')->get();
        return view($this->clayout . '.modal.changeStatus', compact('application', 'payment', 'source', 'status'));
    }

    /**
     * @param Request $request
     * @param Payment $payment
     * @return $this|\Illuminate\Http\JsonResponse
     */
    public function changeStatus(Request $request, Payment $payment)
    {
        DB::beginTransaction();
        try {
            $oldrecord = $payment->__toString();
            $status = $request->status;
            $payment->trans_status = $status;
            $payment->useru_id = Auth::id();
            $payment->save();
            $newRecord = $payment->__toString();
            self::getInstance($payment)->audit($payment->id, $oldrecord, $newRecord, auth()->check() ? auth()->id() : 0);

            if (strtolower($payment->trans_type) == 'expenses') {
                $application = Application::find($request->app_id);
                if (getSiteSettings('partial_mode') && getSiteSettings('partial_mode') == 'true') {
                    $process = new ProcessController();
                    $process->changeProcessStatus($application, 'Payment Made');
                }
                else{
                    $this->paymentProcess($application, $payment);
                }
            } elseif (strtolower($payment->trans_type) == 'revenue') {
                $application = Application::find($request->app_id);
                if (getSiteSettings('partial_mode') && getSiteSettings('partial_mode') == 'true') {
                    $process = new ProcessController();
                    $process->changeProcessStatus($application, 'Payment Made');
                }
                else{
                    $process = new ProcessController();
                    $process->changeProcessStatus($application, 'Copay Deposited to Bank');
                }
            }
            DB::commit();

            if ($request->has('source'))
                $source = $request->source;
            else
                $source = 'application';

            return $this->response('Status Change Successfully', $source, 200);
        } catch (\Exception $e) {
            DB::rollBack();
            return $this->response('Failed to change Status', 'view', 500);
        }
    }

    /**
     * @param $application
     * @param $payment
     */
    private function paymentProcess($application, $payment)
    {

        $process = new ProcessController();
        $mailer = new EmailSender();
        $status = $payment->trans_status;
        if ($status == 'Deposited') {
            $mailData['id'] = $application->id;
            $mailData['status'] = $status;
            $mailData['inv_number'] = $payment->inv_id;
            $mailData['amount'] = $payment->amount;

            $process->changeProcessStatus($application, 'Payment Deposited to Bank Account');
            $mailer->sendEmail('paymentDeposited', $application->getMailAddress(), $mailData, 'Payment Deposited Email Notification');
            $application->status = 'Closed';
            $application->save();
        } elseif ($status == 'Chequed') {
            $process->changeProcessStatus($application, 'Payment Cheque Sent by Mail');
            $application->status = 'Closed';
            $application->save();
        }
        if (getSiteSettings('application_status_change') && getSiteSettings('application_status_change') == 'True') {
            Notification::applicationStatusChanged($application, $application->status);
        }

    }

    public function massPay(Request $request)
    {
        if ($this->checkBalance($request->trans_amount)) {
            DB::beginTransaction();
            try {
                $pid = 0;
                $invoices = explode(',', $request->inv_id);
                $datas = $request->only('table_id', 'inv_id', 'invoice_id',
                    'payment_method', 'trans_des', 'cheque_number', 'cheque_name', 'cheque_exp_date', 'cheque_date');
                $batchIds=null;
                $batchNo=[];
                if($request->has('batchId'))
                {
                    $batchIds=$request->batchId;
                    $batches=explode(',',$request->batchId);
                    foreach ($batches as $b)
                    {
                        $batch=InvoiceBatch::find($b);
                        $batch->status='Paid';
                        $batch->save();
                        array_push($batchNo,$batch->batch_no);
                    }
                }

                foreach ($invoices as $invoice) {
                    $invoice = Invoice::find($invoice);
                    if (!$invoice->payment) {
                        $pid = $invoice->invoiceItems->first()->provider_id;
                        $provider = $invoice->invoiceItems->first()->provider;
                        $data = array();
                        $data = $datas;
                        $data['trans_amount'] = $invoice->invoice_total;
                        $data['trans_type'] = 'expenses';
                        $data['inv_id'] = $invoice->id;
                        $data['invoice_id'] = $request->voucher_number;
                        $data['trans_date'] = date('Y-m-d', strtotime($request->trans_date));
                        if($request->ready_for_voucher == '1'){
                            $data['trans_status'] = 'Ready for AP Voucher';
                        }else{
                            $data['trans_status'] = 'Ready for AP Voucher';
                        }
                        $this->storeAll($request, $data);
                        $invoice->invoice_status = 'Paid';
                        $invoice->save();

                        //generateFundData
                        $fundData['particulars'] = 'Payment To Provider';
                        $fundData['table_name'] = $provider->getTable();
                        $fundData['table_id'] = $provider->id;
                        $fundData['ref_type'] = count($batchNo)>0?'Batch Invoice':'Voucher';
                        $fundData['ref_no'] = count($batchNo)>0?implode(',',$batchNo):$request->voucher_number;
                        $fundData['type'] = $invoice->client->org_id ? 'NP' : 'IE';
                        $fundData['cr_amount'] = $invoice->invoice_total;
                        $fundData['budget_date'] = date('Y-m-d');
                        $this->payment($fundData);
                    }
//                else{
//                    throw new \Exception('Payment Already Made');
//                }
                }


                $led = new \App\Lib\Ledger('applications', $request->table_id, $pid, $request->trans_amount, $request->inv_id, 'invoice', 'dr',$batchIds);
                $led->store();

                DB::commit();
                return $this->response('Payment made Successfully', 'view', 200);
            } catch (\Exception $e) {
                DB::rollBack();
                return $this->response($e->getMessage(), 'view', 500);
            }
        } else {
            return $this->response('Insufficient Balance', 'view', 500);
        }
    }

    public function checkIfPartial($invoiceIds,$givenAmt)
    {
        $amount=0;
        foreach ($invoiceIds as $id)
        {
            $invoice=Invoice::find($id);
            $amount+=$invoice->invoice_total;
        }

        return $amount==$givenAmt;
    }

    /**
     * @param Request $request
     * @param $data
     * @return PaymentController|\Illuminate\Http\JsonResponse|string
     * @throws \Exception
     */
    public function storeAll(Request $request, $data)
    {

        $data['table_name'] = 'applications';
        // $data['trans_status'] = 'Pending';
        if ($res = self::getInstance('Payment')->saveUpdate($data)) {
            return 'done';
        }

        if ($res) {
            if ($request->trans_type == 'revenue')
                return $this->copayProcess($request);
            else
                return $this->invoiceProcess($request);
        } else
            throw new \Exception('Can\'t make payment');
    }

    /**
     * View for refund
     */
    public function refundView(Payment $payment)
    {
        return view($this->clayout . '.modal.refund', compact('payment'));
    }


    public function refund(Request $request, Payment $payment)
    {
        $request->validate([
            'ref_no' => 'required',
            'amount' => 'required|numeric',
        ]);

        $application = Application::find($payment->table_id);
        $fundData['particulars'] = 'Copay Refund';
        $fundData['table_name'] = $payment->table_name;
        $fundData['table_id'] = $payment->table_id;
        $fundData['ref_type'] = 'Voucher';
        $fundData['ref_no'] = $request->ref_no;
        $fundData['type'] = $application->client->org_id ? 'NP' : 'IE';
        $fundData['cr_amount'] = $request->amount;
        $fundData['budget_date'] = date('Y-m-d');
        $this->payment($fundData);

        $payment->trans_status = 'Refunded';
        $payment->save();

        return $this->response('Amount Refunded Successfully', 'view', 200);

    }


    public function importCopay($appId, $amount)
    {
        $data['table_name'] = 'applications';
        $data['table_id'] = $appId;
        $data['invoice_id'] = 1234;
        $data['trans_date'] = date('Y-m-d');
        $data['trans_type'] = 'revenue';
        $data['payment_method'] = 'cash';
        $data['trans_des'] = 'Import From Importer';
        $data['trans_status'] = 'Deposited';
        $data['trans_amount'] = $amount;
        $res = self::getInstance('Payment')->saveUpdate($data);
        if ($res) {
            return true;
        } else {
            return false;
        }

    }
}
