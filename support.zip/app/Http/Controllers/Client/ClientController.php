<?php
/**
 * DEVELOPERS
 * ----------------------------------------------
 * SUMAN  THAPA - LEAD  (NEPALNME@GMAIL.COM)
 * ----------------------------------------------
 * - BASANTA TAJPURIYA
 * - RAKESH SHRESTHA
 * - LEKH RAJ RAI 
 * -----------------------------------------------
 * Created On: 08/02/2019
 *
 * THIS INTELLECTUAL PROPERTY IS COPYRIGHT Ⓒ 2019
 * ZEUSLOGIC, INC. ALL RIGHT RESERVED
 */

namespace App\Http\Controllers\Client;

use App\Http\Controllers\BaseController;
use App\Http\Requests\ClientRequest;
use App\Lib\Email\EmailSender;
use App\Lib\Notification\Notification;
use App\Models\Client;
use App\Models\Role;
use App\Models\User;
use App\Models\Member;
use App\Models\Contact;
use App\Models\UserSettings;
use App\Repo\AddressRepo;
use App\Repo\ClientRepo;
use App\Repo\ContactRepo;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Crypt;

use App\Lib\Exporter\CSVExporter;
use App\Lib\Exporter\JSONExporter;
use App\Lib\Exporter\PDFExporter;
use App\Lib\Exporter\TxtExporter;

class ClientController extends BaseController
{
    /**
     * @var null
     */
    private static $repo = null;
    /**
     * @var string
     */
    private $clayout = '';
    /**
     * @var EmailSender
     */
    private $mail;

    /**
     * ClientController constructor.
     */
    public function __construct()
    {
        parent::__construct();
        $this->clayout = $this->layout . '.pages.client.';
        $this->mail = new EmailSender();
    }

    /**
     * @param $model
     * @return ClientRepo|null
     */
    private static function getInstance($model)
    {
        self::$repo = new ClientRepo($model);
        return self::$repo;
    }

    /**
     *
     */
    public function index()
    {
        return view($this->layout . '.pages.client.index');
    }

    /**
     * @param ClientRequest $request
     * @param bool $returnapplication
     * @return $this|bool|\Illuminate\Http\JsonResponse|mixed
     * @throws \Exception
     */
    public function store(ClientRequest $request, $returnapplication = false)
    {
        $clients = $request->all();
        if (array_key_exists('role_name', $clients)):
            $role = $clients['role_name'];
            unset($clients['role_name']);
        else:
            $role = 'client';
        endif;
        DB::beginTransaction();
        try {

            if (array_key_exists('personal_email', $clients)) {
                $client = self::getInstance('Client')->findByEmail($clients['personal_email']);
            } else {
                $client = false;
            }
            if (!$client) {
                if ($request->has('personal_email')) {
                    $user = $this->createUser($request->personal_email, $role);

                    $clients['user_id'] = $user->id;
                } else {
                    $user = $this->createUser($request->company_email, $role);
                    $clients['user_id'] = $user->id;
                }
            }

            $clientMdl=$client?$client:'client';

            $dob = date('Y-m-d', strtotime($request->dob));
            $clients['dob'] = $dob;

            $contactField = ['phone', 'cell_phone', 'alt_phone', 'phone_type', 'personal_email', 'company_email', 'url'];
            $addressField = ['add1', 'add2', 'zip', 'city', 'state', 'county'];

            //seprate data of client contact and address
            $data = $this->getClientField($clients, $contactField, $addressField);

            if (array_key_exists('mname', $data['data'])) {
                $mname = $data['data']['mname'];
                if (!is_null($mname) && strlen($mname) == 1) {
                    $mname = $mname . '.';
                }
                $data['data']['mname'] = $mname;
            }
            //getData
            $client = self::getInstance($clientMdl)->saveUpdate($data['data']);


            //add contact
            (new ContactRepo())->updateContact($data['contact'], $client);

            //addAddress
            (new AddressRepo())->updateAddress($data['address'], $client);

            DB::commit();
            if (!$client->is_imported)
                if (getSiteSettings('new_client_registered') && getSiteSettings('new_client_registered') == 'True') {
                    Notification::ClientCreationNotification($client);
                }
            if ($returnapplication) {
                return $client;
            }

            return $this->response("Client Added SuccessFully", "view", 200);
        } catch (\Exception $e) {
            DB::rollBack();
            throw  $e;
            return $this->response("Unable to add CLient", 'view', 422);
        }
    }

    //get user details for organization
    private function getUserDetails($id)
    {
        if ($client = Client::where('id', $id)->first()):
            if ($user = $client->user) {
                $password = random_string(10);
                $user->password = bcrypt($password);
                $user->save();
                $data['username'] = $user->name;
                $data['password'] = $password;
                return $data;
            } else {

                return false;
            }
        else:
            return false;
        endif;

    }

    /**
     * @param $email
     * @param $role
     * check if user exist
     */
    public function createUser($email, $role)
    {
        $user = self::getInstance('User')->checkUser($email);
        if (!$user) {
            $password = random_string();
            $user = User::create([
                'name' => $email,
                'email' => $email,
                'role_id' => $this->getRole($role),
                'password' => bcrypt($password)
            ]);
            $data = [
                'id' => $user->id,
                'username' => $user->email,
                'password' => $password
            ];
            if (getSiteSettings('EmailQueue-Clients') == 'true') {
                $this->sendLoginCredentials($user->email, $data);
            }
        }
        return $user;

    }

    protected function sendLoginCredentials($email, $data)
    {

        $this->mail->sendEmail('userCreated', $email, $data, '', '', 'users');
    }

    /**
     * @param $data
     * @param $contactField
     * @param $addressField
     * @return array
     */
    public function getClientField($data, $contactField, $addressField)
    {
        $contact = array();
        $address = array();
        foreach ($contactField as $f) {
            if (isset($data[$f]) && !is_null($data[$f])):
                $contact[$f] = $data[$f];
            endif;
            unset($data[$f]);
        }

        foreach ($addressField as $f) {
            if (isset($data[$f]) && !is_null($data[$f])):
                $address[$f] = $data[$f];
            endif;
            unset($data[$f]);
        }
        return ['data' => $data, 'contact' => $contact, 'address' => $address];

    }

    /**
     * @param $clientData
     * @return ClientController|bool|\Illuminate\Http\JsonResponse|\Illuminate\Support\MessageBag|mixed|string
     */
    public function storeClient($clientData)
    {
        $count = 0;
        $vets = array();
        foreach ($clientData as $key => $value) {
            if (is_array($value))
                $removedElementArr = $this->removeNullValue($value);
            for ($i = 0; $i < count($removedElementArr); $i++) {
                if (!(array_key_exists($i, $vets)))
                    $vets[$i] = array();
                $vets[$i][$key] = $removedElementArr[$i];
            }
        }
        foreach ($vets as $p) {
            $p['org_id'] = $clientData['org_id'];
            $p['add1'] = $clientData['add1'];
            if (array_key_exists('add2', $clientData))
                $p['add2'] = $clientData['add2'];
            $p['zip'] = $clientData['zip'];
            $p['city'] = $clientData['city'];
            $p['state'] = $clientData['state'];
            $p['role_name'] = 'vet';

            $validation = $this->checkValidation($p);

            if ($validation == 'true') {
                $client = $this->store(new ClientRequest($p), true);
            } else {
                return $validation;
            }
        }
    }

    public function checkValidation($p)
    {
        $request = new Request($p);
        $request->setMethod('POST');

        $validator = Validator::make($request->all(), validation_value('client_form'));

        if ($validator->fails()) {
            return $validator->errors();
        } else {
            return "true";
        }
    }


    public function removeNullValue($data)
    {
        return array_values(array_filter($data, function ($value) {
            return $value !== null;
        }));
    }

    /**
     * @param Request $request
     * @param Client $client
     * @return $this|\Illuminate\Http\JsonResponse
     * @throws \Exception
     */
    public function update(Request $request, $id)
    {
        // $clients = $request->all();

        DB::beginTransaction();
        try {
            $clients = $request->only('first_name', 'middle_name', 'last_name');
            $contact = $request->only('cell_phone', 'email');
            $address = $request->only('add1', 'zip_code', 'city', 'state');

            // $dob = date('Y-m-d', strtotime($request->dob));
            // $clients['dob'] = $dob;
            //seprate data of client contact and address
            // $data = $this->getClientField($clients, $contactField, $addressField);
            //getData
            $client = Member::where('user_id', $id)->first();
            // dd($clients);
            $client = self::getInstance($client)->saveUpdate($clients);

            //add contact
            // dd($client, $data['contact'], $data['address'], $data['data']);
            (new ContactRepo())->updateContact($contact, $client);

            //addAddress
            (new AddressRepo())->updateAddress($address, $client);

            $this->saveCounties($id, $request->input('default_counties', []));

            DB::commit();
            return $this->response("Member Updated SuccessFully", "view", 200);
        } catch (\Exception $e) {
            DB::rollback();
            throw $e;
            return $this->response("Can't Update Client", 'view', 422);
        }
    }


    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function create()
    {
        return view($this->layout . '.pages.client.modal.add');
    }

    /**
     * @param $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function editClient(Request $request, $id)
    {
        if($request->has('for'))
            $for = $request->for;
        $client = self::getInstance('Client')->findById($id);
        return view($this->layout . '.pages.client.modal.edit', compact('client', 'for'));

    }

    /**
     * @param Request $request
     * @return array
     */
    public function getAll(Request $request)
    {
        $data = self::getInstance('Client')->selectDataTable($request);
        return $data;
    }

    /**
     * @param $email
     * @return bool|string
     */
    public function getClient($email)
    {
        if ($client = self::getInstance('Contact')->findByEmail($email)) {
            return $client;
        }
        return 'false';
        // return view($this->layout . '.pages.client.modal.edit', compact('client'));
    }

    /**
     * @param Client $client
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function delete(Request $request, Client $client)
    {
        if ($type = $request->type):
            $type = 'Veteranarian';
            return view($this->clayout . 'modal.delete', compact('client', 'type'));
        else:
            $type = 'CLient';
            return view($this->clayout . 'modal.delete', compact('client', 'type'));
        endif;
    }

    /**
     * @param Client $client
     * @return $this|\Illuminate\Http\JsonResponse
     */
    public function destroy(Client $client)
    {
        $client->is_deleted = true;
        $client->save();
        if ($client)
            return $this->response("Client deleted successFully", "view", 200);
        else
            return $this->response("Can't delete client", 'view', 422);
    }


    /**
     * @param Client $client
     * @return mixed
     */
    public function getPets(Client $client)
    {
        $pets = $client->pets;
        return $pets;
    }

    /**
     * Clients
     */
    public function getClients()
    {
        $clients = self::getInstance('Client')->select();
        return $this->responseLookup($clients, ["fname", "mname", "lname"]);
    }

    protected function getRole($role)
    {
        return Role::where('name', $role)->first()->id;
    }

    public function emailCheck(Request $request)
    {
        $email = $request->email;
        $contact = Contact::where('personal_email', $email)->first();
        $user = User::where('email', $email)->first();

        if ($user->count() > 0 || $contact->count() > 0):
            return $user->client;
        else:
            return 'false';
        endif;
    }

    public function clientInfo(Client $client)
    {
        return view('default.pages.client.modal.clientInfo', compact('client'));
    }

    public function storeimportClient($clientData)
    {
        $clientData['role_name'] = 'client';
        $validation = $this->checkValidation($clientData);

        if ($validation == 'true') {
            $vet = $this->store(new ClientRequest($clientData), true);
            return $vet;
        } else {
            return $validation;
        }
    }


    public function storeApi(Request $request, $returnapplication = false)
    {

        $clients = $request->all();
        if (array_key_exists('role_name', $clients)):
            $role = $clients['role_name'];
            unset($clients['role_name']);
        else:
            $role = 'client';
        endif;
        DB::beginTransaction();
        try {

            if (!$client = self::getInstance('Client')->findByEmail($clients['personal_email'])) {
                if ($request->has('personal_email')) {
                    $password = random_string();
                    $user = User::create([
                        'name' => $clients['personal_email'],
                        'email' => $clients['personal_email'],
                        'role_id' => $this->getRole($role),
                        'password' => bcrypt($password)
                    ]);
                    $clients['user_id'] = $user->id;
                }
                $dob = date('Y-m-d', strtotime($request->dob));
                $clients['dob'] = $dob;

                $contactField = ['phone', 'cell_phone', 'alt_phone', 'personal_email', 'company_email', 'url'];
                $addressField = ['add1', 'add2', 'zip', 'city', 'state', 'county'];

                //seprate data of client contact and address
                $data = $this->getClientField($clients, $contactField, $addressField);

                //getData
                $client = self::getInstance('Client')->saveUpdate($data['data']);
                //add contact
                (new ContactRepo())->storeContact($data['contact'], $client);

                //addAddress
                (new AddressRepo())->storeAddress($data['address'], $client);

            }
            DB::commit();
            if (getSiteSettings('new_client_registered') && getSiteSettings('new_client_registered') == 'True') {
                Notification::ClientCreationNotification($client);
            }
            if ($returnapplication) {
                return $client;
            }
            return $this->response("Client Added SuccessFully", "view", 200);
        } catch (\Exception $e) {
            DB::rollBack();
            throw $e;
            return $this->response("Unable to add CLient", 'view', 422);
        }
    }

    public function getLookup($value = null)
    {
        return DB::table('clients')
            ->join('users', 'clients.user_id', 'users.id')
            ->join('roles', 'roles.id', 'users.role_id')
            ->select('clients.id',
                DB::raw('CONCAT(clients.fname," ",COALESCE(clients.mname,"")," ",clients.lname) AS value')
            )
            ->where(function ($query) use ($value) {
                $query->orWhere('fname', 'like', $value . '%')
                    ->orWhere('lname', 'like', $value . '%')
                    ->orWhere('mname', 'like', $value . '%');
            })
            ->whereNull('org_id')->where('roles.name', 'client')->get();
    }

    public function exporter(Request $request, $type)
    {
        $data = self::getInstance('Client')->exportData($request);
        $fields = array('Name', 'Mobile Phone', 'Email', 'Address', 'City', 'Zip', 'State', 'DOB');
        $mapField = array('full_name', 'cell_phone', 'personal_email', 'add1', 'city', 'zip_code', 'state', 'dob');
        $data = cleaner($mapField, $data);
        $data['request'] = ['Name' => $request->clientName, 'Mobile Phone' => $request->cellPhone, 'Email' => $request->email, 'Zip' => $request->zipCode, 'City' => $request->city, 'DOB' => $request->dob];
        $data['table'] = 'Showing Results of Citizens Table';
        if (count($data) > 0) {
            $export = $this->reportFactory($type, $data);
            $exporter = new \App\Lib\Exporter\Exporter($export);
            $filename = $exporter->export();
            return response()->download($filename)->deleteFileAfterSend(true);
        }
        return 'No Data Available For Current Filter';
    }

    /**
     * Create A object for print
     * @param $type
     * @param $data
     * @return CSVExporter|JSONExporter|PDFExporter|TxtExporter
     * @throws \Exception
     */
    public function reportFactory($type, $data)
    {
        switch ($type) {
            case 'csv':
                return new CSVExporter($data, array_keys((array)$data[0]), 'PaymentReports');
                break;
            case 'json':
                return new JSONExporter($data);
                break;
            case 'txt':
                return new TxtExporter($data);
                break;
            case 'pdf':
                return new PDFExporter($data, array_keys((array)$data[0]), 'applicationpdf');
                break;
            default:
                throw new \Exception("Method Not Allowed " . $type);
                break;
        }
    }

    private function saveCounties($id, array $counties)
    {
        $user = User::find($id);
        $user->settings()->where('type', 'default_counties')->delete();
        foreach ($counties as $county) {
            $user->settings()->save(new UserSettings([
                'type' => 'default_counties',
                'value' => $county,
                'user_id' => $id
            ]));
        }
    }
}
