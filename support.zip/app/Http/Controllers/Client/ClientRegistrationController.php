<?php

namespace App\Http\Controllers\Client;

use App\Http\Requests\ClientRequest;
use App\Mail\Email\EmailConfirmation;
use App\Models\Client;
use App\Models\User;
use App\Repo\ClientRepo;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Mail;

class ClientRegistrationController extends Controller
{
    private static $repo = null;

    /**
     * @param $model
     * @return ClientRepo|null
     */
    private static function getInstance($model)
    {
        if (self::$repo == null)
            self::$repo = new ClientRepo($model);
        return self::$repo;
    }

    public function register(Request $request)
    {
        /*$request->validate([
            'personal_email' => 'email',
            'ssn' => 'required',
            'password'=>'required|confirmed',
            'name'=>'required'
        ]);*/
        $tokens = new \App\Lib\Generators\EmailConfirmToken();
        if ($tokens->checkToken($request->personal_email, $request->email_token)) {
            $user = User::create([
                'name' => $request->personal_email,
                'email' => $request->personal_email,
                'role_id' => 3,
                'password' => bcrypt($request->password)
            ]);
            $names = explode(' ', $request->name);
            if (count($names) == 3) {
                $fname = $names[0];
                $mname = $names[1];
                $lname = $names[2];
            } else {
                $fname = $names[0];
                $lname = isset($names[1]) ? $names[1] : 'default';
            }
            $clients = array(
                'fname' => isset($fname) ? $fname : 'fname',
                'mname' => isset($mname) ? $mname : null,
                'lname' => isset($lname) ? $lname : 'lname',
                'user_id' => $user->id
            );
            $contactField = ['personal_email'];
            $data = $this->getClientField($clients, $contactField);
            $client = self::getInstance('Client')->saveUpdate($data['data']);
            if ($client) {
                return array(
                    'status' => 'success',
                    'message' => 'Registration Completed Successfully'
                );
            } else {
                return array(
                    'status' => 'error',
                    'message' => 'Registration not completed Successfully'
                );
            }
        } else
            return array(
                'status' => 'error',
                'message' => 'Registration not completed Successfully'
            );


    }

    /**
     * @param $data
     * @param $contactField
     * @param $addressField
     * @return array
     */
    public function getClientField($data, $contactField)
    {
        $contact = array();
        foreach ($contactField as $f) {
            if (isset($data[$f]) && !is_null($data[$f])):
                $contact[$f] = $data[$f];
            endif;
            unset($data[$f]);
        }

        return ['data' => $data, 'contact' => $contact];

    }

    public function sendEmail(Request $request)
    {
        $email = $request->email;
        Mail::to($email)->send(new EmailConfirmation($email));
    }

    public function confirmEmail($token)
    {
        $tokens = new \App\Lib\Generators\EmailConfirmToken();
        if ($email = $tokens->checkTokenEmail($token))
            return view('auth.createcredential', compact('email', 'token'));
        else
            return redirect('/error');
    }
}
