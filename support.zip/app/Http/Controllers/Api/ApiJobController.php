<?php

namespace App\Http\Controllers\Api;



use App\Http\Controllers\BaseController;
use App\Jobs\RunImporter;
use App\Lib\File\FileUploader;
use App\Lib\Importer\ClientImporter;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;
use PDO;
use App\Lib\Importer\CsvImporter;
use Carbon\Carbon;
use App\Models\Fgp\Volunteer; 


class ApiJobController extends BaseController
{
    

    public function  vol(){

        $fullpath = storage_path('uploads/csv/vol.csv');

		//	return $fullpath;

       // return Volunteer::get()->toArray();
      //  $data = fgetcsv(file($fullpath));

        $csv = array_map('str_getcsv', file($fullpath));

		//return $csv;
	
        $i=0;
        $a = array(0,1,2);
        
        foreach ($csv  as $k=>$v){
            if(!in_array($i, $a)){

				
               // return $v[13]; 
                $vol= Volunteer::where('alt_id',$v[0])->get(); 

               if(isset($vol[0])):
            DB::statement('SET FOREIGN_KEY_CHECKS=0;');    
                $inv= DB:: table('volunteers_supervisors')->insert([
                        'volunteer_id'=>$vol[0]->id, 'supervisor_id' =>$v[13], 'is_active'=>1
                    ]
                    );


		endif;
            }
	
            $i++;
        }



    }
   

}
