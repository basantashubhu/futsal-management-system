<?php
/**
 * DEVELOPERS
 * ----------------------------------------------
 * SUMAN  THAPA - LEAD  (NEPALNME@GMAIL.COM)
 * ----------------------------------------------
 * - RUNA SIDDHI BAJRACHARYA
 * - RABIN BHANDARI
 * - SHIVA THAPA
 * - PRABHAT GURUNG
 * - KIRAN CHAULAGAIN
 * -----------------------------------------------
 * Created On: 5/6/2018
 *
 * THIS INTELLECTUAL PROPERTY IS COPYRIGHT Ⓒ 2018
 * ZEUSLOGIC, INC. ALL RIGHT RESERVED
 */

namespace App\Http\Controllers\Api;


use App\Http\Controllers\BaseController;
use App\Models\ClientToken;
use App\Models\User;
use App\Repo\PassportExtendedRepo\ClientRepository;
use Illuminate\Http\Request;
use Laravel\Passport\Client;

class CLientApiController extends BaseController
{
    protected $clayout, $clients;


    private static $repo = null;

    public function __construct(ClientRepository $clients)
    {
        parent::__construct();
        $this->clayout = $this->layout . '.pages.settings.api.';
        $this->clients = $clients;


    }

    /**
     * @param $model
     * @return ClientRepository|null
     */
    private static function getInstance()
    {
        self::$repo = new ClientRepository();
        return self::$repo;
    }


    public function index()
    {
        return view($this->clayout . 'index');
    }

    /**
     * @param Request $request
     * @return mixed
     */
    public function getAll(Request $request)
    {
        $data = self::getInstance()->selectDataTable($request);
        return $data;
    }


    public function create()
    {
        $users = User::all();
        return view($this->clayout . 'modal.add', compact('users'));
    }

    public function store(Request $request)
    {

        try {
            $request->validate([
                'name' => 'required',
                'redirect' => 'required',
                'user' => 'required',
            ]);
            $this->clients->createPersonalAccessClient($request->user, $request->name, $request->redirect);
            return $this->response("Personal Access Token Generated Successfully", "view", 200);
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function edit($id)
    {
        $users = User::all();
        $client = ClientToken::find($id);
        return view($this->clayout . 'modal.edit', compact('client', 'users'));

    }

    public function update(Request $request, $id)
    {
        try {
            $client = $this->clients->find($id);
            $client->name = $request->name;
            $client->redirect = $request->redirect;
            $client->save();
            return $this->response("Personal Access Token update Successfully", "view", 200);
        } catch (\Exception $e) {
            throw $e;
            return $this->response("Personal Access Token couldnot be updated", "view", 200);
        }
    }

    public function remove(ClientToken $client)
    {
        return view($this->clayout . 'modal.delete', compact('client'));
    }


    public function revoke(Client $client)
    {
        try {
            $this->clients->delete($client);
            return $this->response("Personal Access Token Revoked Successfully", "view", 200);
        } catch (\Exception $e) {
            return $this->response("Personal Access Token Could Not be Revoked", "error", 500);
        }
    }


}