<?php

namespace App\Http\Controllers\Api;

use App\Exceptions\ValidationError;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\Application\ProcessController;
use App\Http\Controllers\Client\ClientController;
use App\Http\Controllers\Pet\PetController;
use App\Http\Requests\ClientRequest;
use App\Lib\BaseException\BaseResponse;
use App\Lib\Log\Log;
use App\Lib\Notification\Notification;
use App\Models\Application;
use App\Models\Client;
use App\Models\CommunicationPrefrence;
use App\Repo\ApplicationRepo;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\MessageBag;

class ApiApplicationController extends Controller
{
    /**
     * @var null
     */
    private static $repo = null;

    /**
     * @var ProcessController
     */
    private $process;


    /**
     * ApiApplicationController constructor.
     */
    public function __construct()
    {
        $this->process = new ProcessController();
    }

    /**
     * @param $model
     * @return ApplicationRepo|null
     */
    private static function getInstance($model)
    {
        self::$repo = new ApplicationRepo($model);
        return self::$repo;
    }

    /**
     * @param Request $request
     * @return mixed
     * @throws \Exception
     */
    public function store(Request $request)
    {
        $data=$request->all();
		$data2=$data;
		$data=$this->mapData($data[0]);
        $req=new Request($data);
        //setting filename1 and filename2 false in initial
        $filename1 = false;
        $filename2 = false;

        //checking if file is present or not for filename1
        if(isset($data2[0]['photo_id'])){
            $this->saveToLogText($data2[0]['photo_id'], "url1");
            $filename1 =  $data2[0]['photo_id'];
        }
        //checking if file is present or not for filename2
        if(isset($data2[0]['ap_bl'])){
            $this->saveToLogText($data2[0]['ap_bl'], "url2");
            $filename2 =  $data2[0]['ap_bl'];
        }

        //getting file from pushFile
        if($filename1){
            $file = $this->pushFile($filename1, $filename2);
            $this->saveToLogText(print_r($file), "url3");
        }


        try {
            $this->saveToLog($req->all());

            //$app = $this->storeApp($request);

            $app=$this->storeAppByApi($req);

            if(!empty($file)){
                $repo = self::getInstance('application');
                $repo->storeUploadedFilePath($file, $app, 'No Title');
            }



            return BaseResponse::response('Application Inserted Successfully', 'success', ['application_id' => $app->id]);
        } catch (\Exception $e) {
            throw $e;
            return BaseResponse::response($e->getmessage(), 'error');
        }
    }

    /**
     * Convert the data in suitable format
     *
     * @param $data
     * @return array
     */
    public function mapData($data)
    {

        $newData=array();
        $newData['client']=array();
        $nameField=explode(' ',$data['full_name']);


        //taking Client Data
        $newData['client']['fname']=$nameField[0];
        $newData['client']['lname']=$nameField[count($nameField)-1];
        if(count($nameField)>=3)
            $newData['client']['mname']=$nameField[1];

        $newData['client']['dob']=$data['dob'];
        $newData['client']['ssn']=$data['ssn'];
        $newData['client']['add1']=$data['add1'];
        $newData['client']['city']=$data['city'];
        $newData['client']['zip']=$data['zip'];
        $newData['client']['cell_phone']=$data['phone'];
        $newData['client']['alt_phone']=$data['alt_phone'];

        if(!array_key_exists('email',$data))
            $newData['client']['personal_email']='fake__'.get_fake_email();
        else
            $newData['client']['personal_email']=$data['email'];

        if(!array_key_exists('state',$data))
            $newData['client']['state']=get_fake_state();
        else
            $newData['client']['state']=$data['state'];

        //taking pet details
        $newData['pets']=$this->petDataMap($data['animal']);

        //taking application Data
        $stateData=$this->getStateData($data['state_elig']);
        foreach ($stateData as $key=>$value)
            $newData['application'][$key]=$value;

        //taking Application Data
        $federalData=$this->getFederalData($data['federal_elig']);
        foreach ($federalData as $key=>$value)
            $newData['application'][$key]=$value;
        $newData['application']['hear_about_us']=$data['camp'];
        $newData['application']['is_prev_applied']=$data['camp'];

        return $newData;
    }

    /**
     *
     */
    public function getFederalData($data)
	    {
        $federalData=[];
        $federalData['is_ssd']=0;
        $federalData['is_ssi']=0;
        $federalData['is_vad']=0;

		if(empty($data)){
			return $federalData;
		}


		if(is_string($data)){
		 $data = "fe ".$data;
		if(strpos($data,'Supplemental Security'))
            {
                $federalData['is_ssi']=1;
            }
            elseif(strpos($data,'Social Security'))
            {
                $federalData['is_ssd']=1;
            }
            elseif(strpos($data,'Veterans Administration Disability'))
            {
                $federalData['is_vad']=1;
            }

		}
		else
			{
			 foreach ($data as $d)
				{
					$d = "fed ".$d;

					if(strpos($d,'Supplemental Security'))
					{
						$federalData['is_ssi']=1;
					}
					elseif(strpos($d,'Social Security'))
					{
						$federalData['is_ssd']=1;
					}
					elseif(strpos($d,'Veterans Administration Disability'))
					{
						$federalData['is_vad']=1;
					}
				}

			}

        return $federalData;
    }


    /**
     * Get State Data
     *
     * @param $data
     * @return array
     */
    public function getStateData($data)
    {
        $stateData=[];
        $stateData['is_tanf']=0;
        $stateData['is_medicaid']=0;
        $stateData['is_general_assistance']=0;
        $stateData['is_food_stamp']=0;
        $stateData['is_wic']=0;

		if(empty($data)){
			return $stateData;
		}

		if(is_string($data)){

			 $data = "state ". $data;
			 if(strpos($data,'Temporary Assistance to Needy Families'))
           {
               $stateData['is_tanf']=1;
               $stateData['is_medicaid']=1;
               $stateData['is_general_assistance']=1;
               $stateData['is_food_stamp']=1;
           }
           elseif(strpos($data,'Women, Infants and Children'))
           {
               $stateData['is_wic']=1;
           }


		} else
		{
			 foreach ($data as $d)

			   {
				   $d = "state". $d;
				   if(strpos($d,'Temporary Assistance to Needy Families'))
				   {
					   $stateData['is_tanf']=1;
					   $stateData['is_medicaid']=1;
					   $stateData['is_general_assistance']=1;
					   $stateData['is_food_stamp']=1;
				   }
				   elseif(strpos($d,'Women, Infants and Children'))
					   {
						   $stateData['is_wic']=1;
					   }
				}
		}



       return $stateData;
    }
    /**
     * Get Pet Data
     *
     * @param $data
     * @return array
     */
    public function petDataMap($data)
    {
        $petData=array();
        foreach ($data as $d)
        {
			if($d['name'] !=null || $d['name'] !=""){
				$pet['pet_name']=$d['name'];
				$pet['sex']=$d['sex'];
				$pet['species']=$d['type'];
				$pet['age_of_pet']=$d['age'];
				$pet['age_type']='Yearly';
				$pet['breed']=$d['bread'];
				$pet['weight']=10;
				$pet['color']='black';
				$pet['where_obtained']=$d['obtain_animal'][0];

				array_push($petData,$pet);
			}

        }
        return $petData;
    }

    /**
     * Create a instance of request via given array
     * @param array $array
     * @return Request
     */
    protected function makeRequestObject(Array $array)
    {
        $request = new Request($array);
        $request->setMethod('POST');
        return $request;
    }

    /**
     *All the operations required by the app
     * @param Request $request
     * @return mixed
     * @throws \Exception
     */
    protected function storeApp(Request $request)
    {
        DB::beginTransaction();
        try {
            //Retrieves the client information
            $clientData = new ClientRequest($request->only('client')['client']);
            $this->validateClient($clientData);
            //triggering client Controller to handel client Information
            $client = (new ClientController())->store($clientData, true);

            //checks if the response was instance of Client
            if (!($client instanceof Client))
                throw new \Exception('Error');

            //gets the lastest application
            if ($oldapp = Application::latest()->first()) {
                //retrieves the laste saved alternative id if available if not gets it from site settings
                $alt_id = isset($oldapp->alt_id) ? $oldapp->alt_id : getSiteSettings('application_alt_id');
            } else {
                //sets a default alternative id
                $alt_id = 1000;
                if ($id = getSiteSettings('application_alt_id')) {
                    $alt_id = $id;
                }
            }

            //getting Application Related Data
            $applicationData = $request->only('application')['application'];

            //sets the key of client
            $applicationData['client_id'] = $client->id;

            $applicationData['alt_id'] = ++$alt_id;

            $applicationData['source'] = 'FF';

            $applicationData['application_date'] = date('Y-m-d');

            $this->validateApplication($this->makeRequestObject($applicationData));
            $repo = self::getInstance('application');
            //saves the application information retrieved from api
            $application = $repo->saveUpdate($applicationData);




            //Retrieves only pet information
            $pets = $request->only('pets')['pets'];

            //Saves all the pet information
            foreach ($pets as $pet) {
                //set the client of the new pet
                $pet['client_id'] = $client->id;
                $this->validatePet($this->makeRequestObject($pet));
                //store the pet information
                $pet = (new PetController())->ApiStore($pet, $application);

                //checks the response if error
                if ($pet instanceof MessageBag)
                    array_push($testpet, $pet);
                elseif ($pet instanceof \Exception)
                    throw new \Exception($pet);
            }

            //store Progress
            (new ProcessController())->store($application);
            $this->process->changeProcessStatus($application, 'Application Received');
            $this->process->changeProcessStatus($application, 'Application Received By Web');

            //commits all the information
            DB::commit();

            //sends the notification
            Notification::newApplicationCreation($application);
            return $application;
        } catch (\Exception $e) {
            DB::rollBack();
            throw  $e;
        }

    }

    protected function storeAppByApi(Request $request)
    {
        DB::beginTransaction();
        try {
            //Retrieves the client information
            $clientData = new ClientRequest($request->only('client')['client']);
         //   $this->validateClient($clientData);
            //triggering client Controller to handel client Information
            $client = (new ClientController())->store($clientData, true);

            //checks if the response was instance of Client
            if (!($client instanceof Client))
                throw new \Exception('Error');

            //gets the lastest application
            if ($oldapp = Application::latest()->first()) {
                //retrieves the laste saved alternative id if available if not gets it from site settings
                $alt_id = isset($oldapp->alt_id) ? $oldapp->alt_id : getSiteSettings('application_alt_id');
            } else {
                //sets a default alternative id
                $alt_id = 1000;
                if ($id = getSiteSettings('application_alt_id')) {
                    $alt_id = $id;
                }
            }

            //getting Application Related Data
            $applicationData = $request->only('application')['application'];

            //sets the key of client
            $applicationData['client_id'] = $client->id;

            $applicationData['alt_id'] = ++$alt_id;

            $applicationData['source'] = 'FF';

            $applicationData['application_date'] = date('Y-m-d');

            $this->validateApplication($this->makeRequestObject($applicationData));
            $repo = self::getInstance('application');
            //saves the application information retrieved from api
            $application = $repo->saveUpdate($applicationData);


            //Retrieves only pet information
            $pets = $request->only('pets')['pets'];

            //Saves all the pet information
            foreach ($pets as $pet) {
                //set the client of the new pet
                $pet['client_id'] = $client->id;
                $this->validatePet($this->makeRequestObject($pet));
                //store the pet information
                $pet = (new PetController())->ApiStore($pet, $application);

                //checks the response if error
                if ($pet instanceof MessageBag)
                    array_push($testpet, $pet);
                elseif ($pet instanceof \Exception)
                    throw new \Exception($pet);
            }

            //store Progress
            (new ProcessController())->store($application);
            $this->process->changeProcessStatus($application, 'Application Received by Web');
            $this->process->changeProcessStatus($application, 'Application Received');

            //commits all the information
            DB::commit();

            //sends the notification
            Notification::newApplicationCreation($application);
            return $application;
        } catch (\Exception $e) {
            DB::rollBack();
            throw  $e;
        }

    }

    public function getFile($url)
    {
        $content = file_get_contents($url);

        $filename = "";
        $f = explode('/', $url);
        foreach($f as $file):
            $filename = "ff".time().$file;
        endforeach;

        $filename1 = storage_path('uploads'.DIRECTORY_SEPARATOR.$filename);

        file_put_contents($filename1, $content);
        return $filename;
    }

    public function pushFile($file_url1, $file_url2 = false)
    {
        $file = [];
	        array_push($file, $this->getFile($file_url1));

        if($file_url2){
            array_push($file, $this->getFile($file_url2));
        }

        return $file;
    }

    protected function validateClient(Request $clients)
    {
        $fields = ['fname', 'lname', 'add1', 'city', 'state', 'zip', 'cell_phone', 'personal_email','ssn'];
        $validator = Validator::make($clients->all(), validation_value('client_form'), $this->clientValidateMessage());
        if ($validator->fails()) {
            $code = 101;
            $errors = $validator->errors();
            foreach ($fields as $index => $field) {
                if ($errors->has($field)) {
                    $code = $code + $index;
                    break;
                }
            }
            throw  new ValidationError($validator->errors()->all()[0], $code);
        }

    }

    protected function validateApplication(Request $application)
    {
        $validator = Validator::make($application->all(), [
            'client_id' => 'required'
        ]);
        if ($validator->fails()) {

            throw  new ValidationError('In Application: ' . $validator->errors()->all()[0], 150);
        }
    }

    protected function validatePet(Request $pet)
    {

        $fields = ['pet_name', 'sex', 'age_type', 'age_of_pet', 'weight', 'species', 'color', 'breed'];
        $validator = Validator::make($pet->all(), [
            'pet_name' => 'required',
            'sex' => 'required',
            'age_type' => 'required',
            'age_of_pet' => 'required',
            'weight' => 'required|min:1',
            'species' => 'required',
            'color' => 'required',
            'breed' => 'required',
            'client_id' => 'required'
        ]);
        if ($validator->fails()) {
            $code = 151;
            $errors = $validator->errors();
            foreach ($fields as $index => $field) {
                if ($errors->has($field)) {
                    $code = $code + $index;
                    break;
                }
            }
            throw  new ValidationError('In Pet: ' . $validator->errors()->all()[0], $code);
        }
    }

    /**
     * Retreive all the information about Application
     * @param Request $request
     * @return mixed
     */
    public function allApplications(Request $request)
    {

        $data = self::getInstance('Application')->apiResponse($request);
        return $data;
    }

    /**
     * Saves to log for a given log
     * @param $data
     * @return bool
     */
    public function saveToLog($data)
    {
        (new Log())->save(json_encode($data), 'ApplicationLog' . rand(0, 1000), []);
        return true;
    }

    public function saveToLogText($data, $filename)
    {
        (new Log())->save($data, $filename . rand(0, 1000), []);
        return true;
    }


    protected function clientValidateMessage()
    {
        return [
            'fname.required' => 'Client first name is required',
            'lname.required' => 'Client last name is required',
            'lname.string' => 'Client last name must be String',
            'fname.string' => 'Client first name must be String',
            'add1.required' => 'Primary address is required',
            'add1.string' => 'Primary address must be String',
            'city.required' => 'City name is required',
            'city.string' => 'City name must be String',
            'state.required' => 'State Name is required',
            'state.string' => 'State Name must be String',
            'zip.required' => 'Zip Code is required',
            'zip.numeric' => 'Zip Code must be Numbers',
            'cell_phone.required' => 'Phone number is required',
            'cell_phone.numeric' => 'Phone number must be Numbers',
            'personal_email.required' => 'Client personal_email  is required',
            'personal_email.email' => 'Client personal_email must be valid',
        ];
    }

}
