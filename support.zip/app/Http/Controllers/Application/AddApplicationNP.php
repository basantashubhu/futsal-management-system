<?php

namespace App\Http\Controllers\Application;

use App\Http\Controllers\BaseController;
use App\Http\Controllers\Pet\PetController;
use App\Http\Requests\ApplicationNpRequest;
use App\Lib\Email\EmailSender;
use App\Lib\File\FileUploader;
use App\Lib\Notification\Notification;
use App\Models\Organization;
use App\Repo\ApplicationRepo;

use Illuminate\Contracts\Support\MessageBag;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Pet;
use App\Models\Treatment;
use App\Models\Settings\Lookups;

class AddApplicationNP extends BaseController
{
     /**
     * @var null
     */
    private static $repo = null;
    private $process;
    private $mail;

     /**
     * ApplicationController constructor.
     */
    public function __construct()
    {
        parent::__construct();
        $this->process = new ProcessController();
        $this->mail = new EmailSender();
    }

     /**
     * @param $model
     * @return ApplicationRepo|null
     */
    private static function getInstance($model)
    {
        if (self::$repo == null)
            self::$repo = new ApplicationRepo($model);
        return self::$repo;
    }

    public function index()
    {
    	$pets = Pet::where('is_deleted', false)->get();
        $states = Lookups::where('code', 'state')->where('is_deleted', false)->get();
        $federals = Lookups::where('code', 'federal')->where('is_deleted', false)->get();


        $nonProfit = Organization::where('type', 'Non Profit')
            ->where('is_deleted', false)
            ->where('is_approved', 1)
            ->get();


        $providers = Organization::where('type', 'Service Provider')
            ->where('is_deleted', false)
            ->where('is_approved', 1)
            ->get();
        $treatments = Treatment::where('is_must', true)->get();
        return view($this->layout . '.pages.application.addPages.addNP.index', compact('pets', 'states', 'federals', 'providers', 'for', 'nonProfit', 'treatments'));
    }

    public function store(Request $request)
    {
        DB::beginTransaction();
        try {
            $treatments = $request->treatment_id;
            $org = Organization::find($request->nonProfit_id);
            if(auth()->user()->role->id == 1):
                $client = $org->contactPerson;
            else:
                $client = auth()->user()->client;
            endif;
            //getting Application Related Data
            $applicationData = $request->only('is_tanf', 'is_medicaid', 'is_general_assistance', 'is_food_stamp', 'is_wic', 'is_ssi', 'is_ssd', 'is_vad', 'client_id', 'provider_id', 'is_prev_applied', 'hear_about_us');
            $applicationData['client_id'] = $client->id;
            $applicationData['provider_id'] = $request->nonProfit_id;
            $applicationData['application_date'] = date('Y-m-d');

            $repo = self::getInstance('application');
            $application = $repo->saveUpdate($applicationData);
            //Upload attachment
            $fileName = $this->uploadAttachment($request->file());
            $fileTitle = [];
            if ($request->has('extraFiles')) {
                foreach ($request->extraFiles as $title)
                    array_push($fileTitle, $title);
            }
            $repo->storeUploadedFilePath($fileName, $application, $fileTitle);

            //Pet Store
            $petData = $request->only('pet_name', 'sex', 'age_type', 'age_of_pet', 'weight', 'species', 'color', 'breed', 'unique_traits', 'where_obtained');
            $petData['client_id'] = $client->id;
            $petData['provider_id'] = $request->nonProfit_id;
            $petData['vet_id'] = $request->vet_id;
            $pet=(new PetController())->storePet($petData, $application, $treatments);

            if($pet instanceof MessageBag)
                return response(['message'=>'the given data was invalid','errors'=>$pet],422);
            elseif($pet instanceof \Exception)
                throw new \Exception($pet);


            //store Progress
            (new ProcessController())->storeNP($application);
            $this->process->changeProcessStatus($application, 'Application Received by Web');
            $this->process->changeProcessStatus($application, 'Application Received');
            if ($request->has('nonProfit_id') && $request->nonProfit_id != '' && $request->nonProfit_id != null)
                $this->process->changeProcessStatus($application, 'Choose Service Provider');
            if ($request->has('vet_id') && $request->vet_id != '' && $request->vet_id != null)
                $this->process->changeProcessStatus($application, 'Choose Veterinarian');;
            DB::commit();

            Notification::newApplicationCreation($application);
            return $this->response("Application added successfully", ['app_id'=>$application->id], 200);
        } catch (\Exception $e) {
            dd($e);
            DB::rollBack();
            return $this->response("Application Can't submitted", 'view', 422);
        }

    }

    public function uploadAttachment($file)
    {
        $fileName = array();

        if (array_key_exists('addinationalPhotos', $file)) {
            foreach ($file['addinationalPhotos'] as $f) {
                $fname = FileUploader::upload($f);
                array_push($fileName, $fname);
            }
        }
        return $fileName;
    }

    public function getNonProfit(Request $request)
    {
        $nonProfit = Organization::where('type', 'Non Profit')
            ->where('is_deleted', false)
            ->where('is_approved', 1)
            ->where('cname', 'like', "%$request->cname%")
            ->get();
        return view($this->layout . '.pages.application.modal.loadNP', compact('nonProfit'));
    }

    public function addNewPetPageForm($id=1)
    {
        $treatments = Treatment::where('is_must', true)->get();
        return view('default.pages.application.templates.addNewPetPageForm', compact('treatments', 'id'));
    }
}
