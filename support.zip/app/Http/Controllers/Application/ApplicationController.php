<?php

/**
 * DEVELOPERS
 * ----------------------------------------------
 * SUMAN  THAPA - LEAD  (NEPALNME@GMAIL.COM)
 * ----------------------------------------------
 * - PRABHAT GURUNG
 * - BASANTA TAJPURIYA
 * - RAKESH SHRESTHA
 * - MANISH BUDDHACHARYA
 * - LEKH RAJ RAI
 * - ASCOL PARAJULI
 * -----------------------------------------------
 * Created On: 3/10/2018
 *
 * THIS INTELLECTUAL PROPERTY IS COPYRIGHT Ⓒ 2019
 *  SHUBHU TECH PVT LTD , NEPAL. ALL RIGHT RESERVED
 */


namespace App\Http\Controllers\Application;

use App\Http\Controllers\BaseController;
use App\Http\Controllers\Client\ClientController;

use App\Http\Controllers\Communication\CommunicationPrefController;
use App\Http\Controllers\Invoice\InvoiceController;

use App\Http\Controllers\Payment\PaymentController;
use App\Http\Controllers\Pet\PetController;
use App\Http\Requests\ApplicationRequest;
use App\Http\Requests\ClientRequest;
use App\Lib\Capture\ScreenCapture;
use App\Lib\Email\EmailSender;
use App\Lib\Exporter\CSVExporter;
use App\Lib\Exporter\JSONExporter;
use App\Lib\Exporter\PDFExporter;
use App\Lib\Exporter\TxtExporter;
use App\Lib\File\FileUploader;
use App\Lib\Filter\OrganizationFilter\OrganizationFilter;
use App\Lib\Log\Log;
use App\Lib\Notification\Notification;

use App\Lib\Template\TemplateMerge;
use App\Mail\CustomCopayReminder;
use App\Models\Application;
use App\Models\ApplicationPet;
use App\Models\ApplicationPetTreatments;
use App\Models\Client;
use App\Models\EmailTemplate;
use App\Models\File;
use App\Models\InvoiceItem;
use App\Models\Organization;
use App\Models\Pet;
use App\Models\Treatment;
use App\Repo\ApplicationRepo;
use App\Repo\OrganizationRepo;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Settings\Lookups;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\MessageBag;
use App\Models\Rate;
use App\Models\RatePlan;
use App\Models\SiteSettings;

/**
 * Class ApplicationController
 * @package App\Http\Controllers\Application
 */
class ApplicationController extends BaseController
{
    /**
     * @var null
     */
    private static $repo = null;
    private $process;
    private $mail;
    private $responseMsg = 'Processing...';

    /**
     * ApplicationController constructor.
     */
    public function __construct()
    {
        parent::__construct();
        $this->process = new ProcessController();
        $this->mail = new EmailSender();
        ini_set('max_execution_time', 800);
    }

    /**
     * @param $model
     * @return ApplicationRepo|null
     */
    private static function getInstance($model)
    {
        self::$repo = new ApplicationRepo($model);
        return self::$repo;
    }


    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function index()
    {
        $providers = Organization::where('is_deleted', false)->orderBy('cname', 'asc')->get();
        $status = Lookups::where('code', 'application_status')->where('is_deleted', false)->get();
        $app_citizen_href = siteSettingsValue('application_citizen_add_mode');
        $app_np_href = siteSettingsValue('application_np_add_mode');
        return view($this->layout . '.pages.application.index', compact('status', 'app_np_href', 'app_citizen_href', 'providers'));
    }

    public function getReportData(Request $request, $type)
    {
        $data = self::getInstance('Application')->getReportData($request);
        $fields = array('Date', 'Status', 'Copay', 'Total Pets', 'Client Name', 'Phone', 'Email', 'Provider Name');
        $mapField = array('date', 'status', 'copay', 'no_of_pet', 'owner_name', 'cell_phone', 'personal_email', 'service_provider');
        $data = cleaner($mapField, $data);
        $status = $request->status ? $request->status : $request->statusSingle;
        $data['request'] = ['Application ID' => $request->applicationID, 'Status' => $status, 'Date Range' => $request->dateRange, 'SSN' => $request->ssn, 'Copay' => $request->copay, 'Client Name' => $request->clientName, 'Phone Number' => $request->cellPhone, 'Email Address' => $request->email, 'City' => $request->city, 'Zip' => $request->zipCode];
        $data['table'] = 'Showing Results of Applications Table';
        if (count($data) > 0) {
            $export = $this->reportFactory($type, $fields, $data);
            $exporter = new \App\Lib\Exporter\Exporter($export);
            $filename = $exporter->export();
            return response()->download($filename)->deleteFileAfterSend(true);
        }
        return 'No Data Available For Current Filter';
    }

    public function delete(Application $application)
    {
        return view($this->layout . '.pages.application.modal.delete', compact('application'));
    }


    public function destroy(Application $application)
    {
        DB::beginTransaction();
        $res = false;
        $res = self::getInstance($application)->softDelete();
        $application->status = 'Deleted';
        $application->save();

        $appPet = ApplicationPet::where('application_id', $application->id)->get();

        foreach ($appPet as $apt) {
            $res = self::getInstance($apt)->softDelete();
        }

        if ($res) {
            DB::commit();
            return $this->response("Application deleted successFully", "view", 200);
        } else {
            DB::rollBack();
            return $this->response("Can't delete Application", 'view', 422);
        }

    }

    /**
     * @param $type
     * @param $data
     * @return CSVExporter|JSONExporter|PDFExporter|TxtExporter
     * @throws \Exception
     */
    public function reportFactory($type, $fields, $data)
    {
        switch ($type) {
            case 'csv':
                return new CSVExporter($data, $fields, 'ApplicationReports');
                break;
            case 'json':
                return new JSONExporter($data);
                break;
            case 'txt':
                return new TxtExporter($data);
                break;
            case 'pdf':
                return new PDFExporter($data, $fields, 'applicationpdf');
                break;
            default:
                throw new \Exception("Method Not Allowed " . $type);
                break;
        }
    }

    public function getChartData()
    {
        $data = array();
        $required = ['New', 'Approved', 'Review', 'Denial', 'Closed', 'total'];
        foreach ($required as $r) {
            $newarray = array();
            if (auth()->user()->role->name == 'serviceProvider' || auth()->user()->role->name == 'non_profit'):
                if ($r == 'total') {

                    $new = Application::count();
                } else {
                    $org = auth()->user()->client->org_id;
                    $new = count(DB::table('applications')
                        ->join('application_pet as ap', 'ap.application_id', 'applications.id')
                        ->where('ap.provider_id', 2)
                        ->where('applications.status', $r)
                        ->groupBy('applications.id')->get());
                }
            else:
                $new = Application::where('status', $r)->count();
                if ($r == 'total')
                    $new = Application::count();

            endif;
            $newarray['label'] = $r;
            $newarray['value'] = $new;
            array_push($data, $newarray);
        }
        return $data;
    }

    /**
     * @param null $for
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function create($for = null)
    {
        $pets = Pet::where('is_deleted', false)->get();
        $states = Lookups::where('code', 'state')->where('is_deleted', false)->get();
        $federals = Lookups::where('code', 'federal')->where('is_deleted', false)->get();


        $nonProfit = Organization::where('type', 'Non Profit')
            ->where('is_deleted', false)
            ->where('is_approved', 1)
            ->get();


        $providers = Organization::where('is_deleted', false)
            ->where('is_approved', 1)
            ->get();

        if (!is_null($for)) {
            return view($this->layout . '.pages.application.modal.add', compact('pets', 'states', 'federals', 'providers', 'for', 'nonProfit'));
        } else {
            return view($this->layout . '.pages.application.modal.add', compact('pets', 'states', 'federals', 'providers'));
        }
    }

    /**
     * Get Copay Reminder
     */
    public function getCopayConfirm($id)
    {
        $template = false;
        if ($template = EmailTemplate::where('temp_name', 'Copay Reminder')->first()) {
            $template = $template->temp_html;
        }
        $application = Application::find($id);
        return view($this->layout . '.pages.application.applicationdetails.include.leftSection.copayReminder', compact('template', 'application'));
    }

    public function sendCopayReminder(Request $request)
    {
        $data = [
            'amount' => $request->copayAmount
        ];

        $to = $request->to ? $request->to : 'kkchaulagain@gmail.com';
        Mail::to($to)->send(new CustomCopayReminder($this->tempMerge($request->template, $data), $request->subject));
        return $this->response("Copay Reminder Sent Successfully to $to", 'view', 200);

    }


    public function tempMerge($template, $data)
    {
        return TemplateMerge::makeTempTemplate($template, $data);
    }

    /**
     * @param Application $application
     * @param Pet $pet
     * @return $this|\Illuminate\Contracts\View\Factory|\Illuminate\Http\JsonResponse|\Illuminate\View\View
     */
    public function showTreatment(Request $request, Application $application, Pet $pet)
    {

        if ($application->status != 'Denial') {
            if ($request->has('from')):
                $from = 'pets';
            else:
                $from = 'applications';
            endif;
            $client = $application->client;
            $apt = ApplicationPetTreatments::where('application_id', $application->id)->where('pet_id', $pet->id)->first();
            $serviceProvider = false;
            if ($apt)
                $serviceProvider = true;
            else
                $serviceProvider = false;

            $treatments = Treatment::where('is_deleted', 0)->get();
            $providers = $application->applicationPet->where('pet_id', $pet->id)->first()->serviceProvider;

            if ($providers != null):
                $organization = Organization::find($providers->id);
                if ($apt)
                    $vet = Client::find($apt->vet_id);
                else
                    $vet = null;
            endif;

            $app_pet_treatment = self::getInstance($application)->getTreatmentDetails($application->id, $pet->id);
            if (getSiteSettings('partial_mode') && getSiteSettings('partial_mode') == 'true') {

                $pets = $application->pets;
                foreach ($pets as $p):
                    $p->treatments = ApplicationPetTreatments::where('application_id', $application->id)->where('pet_id', $p->id)->where('is_deleted', false)->get();
                    $cert = ApplicationPet::where('application_id', $application->id)->where('pet_id', $p->id)->first();
                    $p->cert_number = $cert->cert_number;
                    foreach ($p->treatments as $t):
                        $treat = Treatment::find($t->treatment_id);
                        if (isset($treat->id)):
                            $t->treatment_id = $treat->id;
                            $t->treatment_name = $treat->treatment_name;
                            $t->treatment_type = $treat->treatment_type;
                            $p->notPerformed = 'true';
                            $rate = Rate::where('treatment_id', $treat->id)->first();
                            if (isset($rate->id))
                                $t->cost = $rate->cost;
                        endif;
                        $veterinarian = Client::find($t->vet_id);
                        if (isset($veterinarian->fname)):
                            $p->vet = $veterinarian->title . ' ' . $veterinarian->fname . ' ' . $veterinarian->lname;
                        endif;
                    endforeach;
                endforeach;
                return view($this->layout . '.pages.application.PartialView.include.treatment.addTreatment',
                    compact('treatments', 'pet', 'client', 'application', 'app_pet_treatment', 'pets', 'treatmentList', 'from'));
            } else {
                return view($this->layout . '.pages.application.applicationDetails.include.treatment.addTreatment',
                    compact('vet', 'treatments', 'pet', 'client', 'application', 'app_pet_treatment', 'treatmentList', 'providers', 'serviceProvider', 'from'));
            }
        } else {
            return $this->response('Can\'t Add Treatment', 'view', 422);
        }

    }

    public function showInvoice(Application $application, Pet $pet)
    {
        $client = $application->client;
        $apt = ApplicationPetTreatments::where('application_id', $application->id)->where('pet_id', $pet->id)->first();
        $serviceProvider = false;
        if ($apt)
            $serviceProvider = true;
        else
            $serviceProvider = false;

        $treatments = Treatment::where('is_deleted', 0)->get();
        $providers = $application->applicationPet->where('pet_id', $pet->id)->first()->serviceProvider;

        if ($providers != null):
            $organization = Organization::find($providers->id);
            if ($apt)
                $vet = Client::find($apt->vet_id);
            else
                $vet = null;
        endif;

        $app_pet_treatment = self::getInstance($application)->getTreatmentDetails($application->id, $pet->id);


        $pet->treatments = ApplicationPetTreatments::where('application_id', $application->id)->where('pet_id', $pet->id)->where('is_deleted', false)->get();
        $cert = ApplicationPet::where('application_id', $application->id)->where('pet_id', $pet->id)->first();
        foreach ($pet->treatments as $t):
            $treat = Treatment::find($t->treatment_id);
            $veterinarian = Client::find($t->vet_id);
            if (isset($veterinarian->fname)):
                $pet->vet = $veterinarian->title . ' ' . $veterinarian->fname . ' ' . $veterinarian->lname;
            endif;
        endforeach;
        $rates = RatePlan::all();
        return view($this->layout . '.pages.application.PartialView.include.treatment.newTreatment',
            compact('treatments', 'pet', 'client', 'application', 'app_pet_treatment', 'pet', 'treatmentList', 'rates', 'serviceProvider', 'providers', 'vet'));
    }

    public function generateAppInvoice(Request $request, Application $application)
    {
        if ($request->has('from')):
            $from = 'pets';
        else:
            $from = 'applications';
        endif;
        $client = $application->client;

        $pets = $application->pets;
        foreach ($pets as $p):
            $p->treatments = ApplicationPetTreatments::where('application_id', $application->id)->where('pet_id', $p->id)->where('is_deleted', false)->get();
            $cert = ApplicationPet::where('application_id', $application->id)->where('pet_id', $p->id)->first();
            $p->cert_number = $cert->cert_number;
            foreach ($p->treatments as $t):
                $treat = Treatment::find($t->treatment_id);
                if (isset($treat->id)):
                    $t->treatment_id = $treat->id;
                    $t->treatment_name = $treat->treatment_name;
                    $t->treatment_type = $treat->treatment_type;
                    $p->notPerformed = 'true';
                    $rate = Rate::where('treatment_id', $treat->id)->first();
                    $t->cost = $rate->cost;
                endif;
                $veterinarian = Client::find($t->vet_id);
                if (isset($veterinarian->fname)):
                    $p->vet = $veterinarian->title . ' ' . $veterinarian->fname . ' ' . $veterinarian->lname;
                endif;
            endforeach;
        endforeach;
        return view($this->layout . '.pages.application.PartialView.include.treatment.addTreatment',
            compact('client', 'application', 'pets', 'from'));
    }

    public function showDenial(Application $application)
    {
        $reasons = SiteSettings::where('code', 'denial_reason')->where('is_deleted', false)->get();
        return view($this->layout . '.pages.application.modal.denialReason', compact('application', 'reasons'));
    }

    public function showProvider(Request $request, Application $application)
    {
        $data_send = array();

        $pet_ids = $request->data;
        if ($pet_ids):
            $pet_ids = explode(',', $pet_ids);
            $pets = array();
            foreach ($pet_ids as $pet):
                $data = Pet::find($pet);
                array_push($pets, $data);
            endforeach;
        endif;

        $vetAssign = ApplicationPetTreatments::where('application_id', $application->id)->first();
        $client = $application->client;

        if ($application->provider != null && isset($application->provider)):
            $providers = $application->provider;
            $data_send['providers'] = $providers;
            if ($vetAssign)
                $providers['vet_id'] = $vetAssign->vet_id;
            else
                $providers['vet_id'] = 0;

            if (isset($providers)):
                $organization = Organization::find($providers->id);
                $vet = $organization->vet;
            endif;
        endif;
        if (getSiteSettings('partial_mode') && getSiteSettings('partial_mode') == 'true') {
            return view($this->layout . '.pages.application.partialView.include.treatment.assignServiceProvider',
                compact('application', 'client', 'vet', 'providers', 'pets'));
        } else {
            return view($this->layout . '.pages.application.applicationDetails.include.treatment.assignServiceProvider',
                compact('application', 'client', 'vet', 'providers', 'pets'));
        }
    }


    /**
     * @param ApplicationRequest $request
     * @return $this|\Illuminate\Http\JsonResponse
     * @throws \Exception
     */
    public function store(ApplicationRequest $request)
    {
        DB::beginTransaction();
        try {
            $clientData = new ClientRequest($request->only('title', 'fname', 'mname', 'lname', 'dob', 'add1', 'add2', 'zip', 'state', 'city', 'cell_phone', 'phone_type', 'alt_phone', 'personal_email'));

            //triggering client Controller to handel client Information
            $client = (new ClientController())->store($clientData, true);


            if (!($client instanceof Client))
                throw new \Exception('Error');
            if ($oldapp = Application::latest()->first()) {
                $alt_id = isset($oldapp->alt_id) ? $oldapp->alt_id : getSiteSettings('application_alt_id');
            } else {
                $alt_id = 1000;
                if ($id = getSiteSettings('application_alt_id')) {
                    $alt_id = $id;
                }
            }

            //getting Application Related Data
            if (getSiteSettings('partial_mode') && getSiteSettings('partial_mode') != 'true'):
                $applicationData = $request->only('is_tanf', 'is_medicaid', 'is_general_assistance', 'is_food_stamp', 'is_wic', 'is_ssi', 'is_ssd', 'is_vad', 'client_id', 'provider_id', 'is_prev_applied', 'hear_about_us');
            else:
                $applicationData = $request->only('is_tanf', 'is_medicaid', 'is_general_assistance', 'is_food_stamp', 'is_wic', 'is_ssi', 'is_ssd', 'is_vad', 'client_id', 'is_prev_applied', 'hear_about_us');
            endif;
            $applicationData['client_id'] = $client->id;
            $applicationData['alt_id'] = ++$alt_id;
            $applicationData['source'] = 'Manual';

            $applicationData['application_date'] = date('Y-m-d');

            $repo = self::getInstance('application');
            $application = $repo->saveUpdate($applicationData);

            //store Communication Preference
            $commPref = $request->only('is_email', 'is_mail', 'is_phone', 'is_sms');
            (new CommunicationPrefController())->store($commPref, $application);

            //Upload attachment
            $fileName = $this->uploadAttachment($request->file());
            $fileTitle = [];
            if ($request->has('photoIdProofTitle'))
                array_push($fileTitle, $request->photoIdProofTitle);

            if ($request->has('anualProofTitle'))
                array_push($fileTitle, $request->anualProofTitle);

            if ($request->has('extraFiles')) {
                foreach ($request->extraFiles as $title)
                    array_push($fileTitle, $title);
            }
            $repo->storeUploadedFilePath($fileName, $application, $fileTitle);

            //Pet Store
            $petData = $request->only('pet_name', 'sex', 'age_type', 'age_of_pet', 'weight', 'species', 'color', 'breed', 'unique_traits', 'where_obtained');
            $petData['client_id'] = $client->id;
            $petData['provider_id'] = $request->provider_id;
            $petData['vet_id'] = $request->vet_id;
            $petData['inv_edit_breed'] = $request->breed;
            $petData['inv_edit_sex'] = $request->sex;
            $petData['inv_edit_age_of_pet'] = $request->age_of_pet;
            $petData['inv_edit_age_type'] = $request->age_type;
            $petData['inv_edit_weight'] = $request->weight;
            $pet = (new PetController())->storePet($petData, $application);

            if ($pet instanceof MessageBag)
                return response(['message' => 'the given data was invalid', 'errors' => $pet], 422);
            elseif ($pet instanceof \Exception)
                throw new \Exception($pet);

            $this->note($application, 'Application Created', 'note');

            //store Progress
            (new ProcessController())->store($application);
            $this->process->changeProcessStatus($application, 'Application Received by Web');
            $this->process->changeProcessStatus($application, 'Application Received');
            if ($request->has('provider_id') && $request->provider_id != '' && $request->provider_id != null)
                $this->process->changeProcessStatus($application, 'Choose Service Provider');
            if ($request->has('vet_id') && $request->vet_id != '' && $request->vet_id != null)
                $this->process->changeProcessStatus($application, 'Choose Veterinarian');;
            DB::commit();
            if (getSiteSettings('new_application') && getSiteSettings('new_application') == 'True') {
                Notification::newApplicationCreation($application);
            }
            return $this->response("Application added Successfully", ['app_id' => $application->id], 200);
        } catch (\Exception $e) {
            DB::rollBack();
            throw  $e;
            return $this->response("Application Can't submitted", 'view', 422);
        }

    }


    public function getApplicationValidation(ApplicationRequest $request)
    {
    }

    public function getPetValidation(Request $request)
    {
        $valid = array();
        $data = $request->only('pet_name', 'species', 'sex', 'age_of_pet', 'weight', 'color', 'breed');
        foreach ($data as $key => $value):
            foreach ($value as $k => $v) {
                if ($v == ""):
                    $valid[$key . '_multi'] = 'required';
                endif;
            }
        endforeach;
        $valid = ['errors' => $valid];
        return response($valid, 422);
    }

    /***
     * @param $file
     * @return array
     * @throws \Exception
     */
    public function uploadAttachment($file)
    {
        $fileName = array();

        if (array_key_exists('photoIdProof', $file)):
            $fname = FileUploader::upload($file['photoIdProof']);
            array_push($fileName, $fname);
        endif;

        if (array_key_exists('anualProof', $file)):
            $fname = FileUploader::upload($file['anualProof']);
            array_push($fileName, $fname);
        endif;
        if (array_key_exists('addinationalPhotos', $file)) {
            foreach ($file['addinationalPhotos'] as $f) {
                $fname = FileUploader::upload($f);
                array_push($fileName, $fname);
            }
        }
        return $fileName;
    }


    /**
     * @param Request $request
     * @return mixed
     */
    public function getAll(Request $request)
    {
        // dd($request->all());
        $data = self::getInstance('Application')->selectDataTable($request);
        return $data;
    }

    public function getAll1(Request $request)
    {
        // dd($request->all());
        $data = self::getInstance('Application')->selectDataTable1($request);
        return $data;
    }

    public function updateAgency(Request $request, Application $application)
    {
        $oldData = $application->__toString();
        if ($request->agency == 'remove') {
            $application->verified_agency_id = NULL;
        } else {
            $application->verified_agency_id = $request->agency;
        }
        $application->save();
        $newData = $application->__toString();
        self::getInstance($application)->audit($application->id, $oldData, $newData, auth()->check() ? auth()->id() : 0);
        if ($request->agency == 'remove') {
            return $this->response("Agency is Removed Successfully.", "view", 200);
        } else {
            return $this->response("Agency Changed to " . $request->agency, "view", 200);
        }
    }

    /**
     * @param Application $application
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function changeStatus(Application $application)
    {
        $status = Lookups::where('code', 'application_status')->where('value', '!=', 'Approved')->where('value', '!=', 'Denial')->where('is_deleted', false)->get();
        return view($this->layout . '.pages.application.modal.change', compact('application', 'status'));
    }

    /**
     * @param Request $request
     * @param Application $application
     * @return $this|\Illuminate\Http\JsonResponse
     * @throws \Exception
     */
    public function StatusChange(Request $request, Application $application)
    {
        DB::beginTransaction();
        try {
            $prevStatus = $application->status;
            $data['status'] = $request->status;
            $data['comments'] = $request->comments;
            $data['approved_by'] = auth()->id();
            $data['approved_date'] = Carbon::now();
            $client = self::getInstance($application)->saveUpdate($data);
            $step = $this->process->trackProcess($application->id);

            //check if status changed to review
            if ($request->status == 'Review') {
                $this->reviewProcess($application);
            }
            DB::commit();
            if (getSiteSettings('application_status_change') && getSiteSettings('application_status_change') == 'True') {
                Notification::applicationStatusChanged($application);
            }
            $this->note($application, 'Status Change', 'Task', 'Application', 'Application Status Change To ' . $request->status);
            return $this->response("Status updated to " . $request->status, "view", 200);
        } catch (\Exception $e) {
            DB::rollBack();
            return $this->response("Can't Update Status", 'view', 422);
        }

    }

    public function approval(Request $request, Application $application)
    {
        DB::beginTransaction();
        try {
            if ($application->status !== 'Approved') {
                $oldData = $application->__toString();
                $application->status = 'Approved';
                $application->is_provider_view = true;
                $application->approved_by = auth()->id();
                $application->approved_date = Carbon::now();

                $application->signature = $request->signature;
                $application->signature_holder = $request->signature_holder;
                $application->save();

                $this->note($application, 'Application Approved', 'note');

                $newData = $application->__toString();
                self::getInstance($application)->audit($application->id, $oldData, $newData, auth()->check() ? auth()->id() : 0);
                $this->approvedProcess($application);
            }
            if (getSiteSettings('application_approval') && getSiteSettings('application_approval') == 'True') {
                Notification::applicationApproved($application);
            }
            DB::commit();
            return $this->response("Application Approved" . $request->status, "view", 200);
        } catch (\Exception $e) {
            DB::rollBack();
            throw $e;
            return $this->response($e->getMessage() . $request->status, "view", 500);
        }

    }

    public function disapprove(Request $request, Application $application)
    {
        $request->validate([
            'denial_reason' => 'required'
        ]);
        DB::beginTransaction();
        try {
            if ($application->status !== 'Denial') {

                $oldData = $application->__toString();
                $application->status = 'Denial';
                $application->approved_by = auth()->id();
                $application->approved_date = Carbon::now();

                $application->signature = $request->signature;
                $application->signature_holder = $request->signature_holder;
                $application->save();

                $this->note($application, 'Application DisApproved', 'note');
                $newData = $application->__toString();
                self::getInstance($application)->audit($application->id, $oldData, $newData, auth()->check() ? auth()->id() : 0);
                $this->note($application, $request->denial_reason, 'application_denial');
                $denialReasonDetail = EmailTemplate::where('temp_code', $request->denial_reason)->where('is_deleted', false)->first();
                $this->denialProcess($application, $denialReasonDetail->temp_html);
            }
            if (getSiteSettings('application_denial') && getSiteSettings('application_denial') == 'True') {
                Notification::applicationDenied($application);
            }
            DB::commit();
            return $this->response("Application Denial" . $request->status, "view", 200);
        } catch (\Exception $e) {
            DB::rollBack();
            throw $e;
            return $this->response($e->getMessage(), "view", 500);

        }

    }

    /**
     * @param Application $application
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function select(Application $application)
    {
        if (getSiteSettings('partial_mode') && getSiteSettings('partial_mode') == 'true') {
            $view = $this->partialView($application);
        } else {
            $view = $this->fullView($application);
        }
        return $view;
    }


    /**
     * @param Application $application
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    protected function partialView(Application $application)
    {
        // $this->checkStatus($application);

        $client = $application->client;
        $files = $application->files();
        $notes = $application->notes();

        $process = $application->getProcess();
        $step = $this->process->trackProcess($application->id);

        //dd($step);

        $copayStatus = $application->copayStatus();

        $signatureMode = getSiteSettings('signature_mode') == 'on';

        if (!isset($signatureMode)):
            $signatureMode = false;
        endif;

        $invoiceItem = $application->invoiceItem->first();

        $verifyAgency = Lookups::where('code', 'verified_agency')->get();
        if (!is_null($invoiceItem)) {
            $invoiceStatus = $invoiceItem->invoice->invoice_status;
            $invoice = $invoiceItem->invoice;
        } else {
            $invoiceStatus = "Approved";
            $invoice = '';
        }

        $providers = $application->providers();
        $vets = null;
        if ($providers != null) {
            $vets = $providers->vet;
        }

        $comments = ApplicationCommentController::getAllComment($application->id);
        $c = auth()->user()->client;
        // dd($c);

        return view($this->layout . '.pages.application.PartialView.applicationDetail',
            compact('application', 'client', 'providers', 'vets',
                'files', 'notes', 'process', 'step', 'copayStatus', 'invoiceStatus', 'signatureMode', 'invoice', 'c', 'verifyAgency', 'comments'));
    }

    /**
     * @param Application $application
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    protected function fullView(Application $application)
    {
        // $this->checkStatus($application);

        $client = $application->client;
        $files = $application->files();
        $notes = $application->notes();

        $process = $application->getProcess();
        $step = $this->process->trackProcess($application->id);

        //dd($step);

        $copayStatus = $application->copayStatus();

        $signatureMode = getSiteSettings('signature_mode') == 'on';

        if (!isset($signatureMode)):
            $signatureMode = false;
        endif;

        $invoiceItem = $application->invoiceItem->first();

        $verifyAgency = Lookups::where('code', 'verified_agency')->get();
        if (!is_null($invoiceItem)) {
            $invoiceStatus = $invoiceItem->invoice->invoice_status;
            $invoice = $invoiceItem->invoice;
        } else {
            $invoiceStatus = "Approved";
            $invoice = '';
        }

        $providers = $application->providers();
        $vets = null;
        if ($providers != null) {
            $vets = $providers->vet;
        }

        $comments = ApplicationCommentController::getAllComment($application->id);
        $c = auth()->user()->client;
        // dd($c);

        return view($this->layout . '.pages.application.applicationdetails.applicationDetail',
            compact('application', 'client', 'providers', 'vets',
                'files', 'notes', 'process', 'step', 'copayStatus', 'invoiceStatus', 'signatureMode', 'invoice', 'c', 'verifyAgency', 'comments'));
    }

    public function checkStatus($application)
    {
        if ($application->status == 'New') {
            $application->status = 'Review';
            $application->save();
            $this->reviewProcess($application);
        }

        if ($application->status == 'Partial Invoiced') {
            $appCount = ApplicationPetTreatments::where('application_id', $application->id)->count();
            $invCount = InvoiceItem::where('application_id', $application->id)->count();
            if ($invCount >= $appCount) {
                $application->status = 'Invoiced';
                $application->save();
            }

        }
    }

    public function getSignatureModal($id)
    {
        return view($this->layout . '.pages.application.applicationdetails.include.leftSection.sign_modal');
    }

    /**
     * @param Application $application
     * @return mixed
     */
    public function getPets(Application $application)
    {
        return $application->pets;
    }


    /**
     * Upload File
     */
    public function uploadFile(Application $application)
    {
        if (getSiteSettings('partial_mode') && getSiteSettings('partial_mode') == 'true') {
//            $fileTitle = 'Invoice';
            $fileTitle = 'File Name';
        } else {
            $fileTitle = 'File Name';
        }
        return view($this->layout . '.pages.application.modal.uploadFile', compact('application', 'fileTitle'));
    }

    /**
     * Store File
     */
    public function storeFile(Request $request, Application $application)
    {
        try {
            $file = array();
            $fileName = $this->uploadAttachmentSingle($request->file());
            $repo = self::getInstance('Application');
            array_push($file, $fileName);
            $fileTitle = $request->anualProofTitle;
            $res = $repo->storeUploadedFilePath($file, $application, $fileTitle);
            if (getSiteSettings('partial_mode') && getSiteSettings('partial_mode') == 'true') {
                if ($fileTitle == 'invoice' || $fileTitle == 'Invoice'):
                    $this->process->changeProcessStatus($application, 'Service Provider Invoice Received');
                endif;
            }
            return $this->response("File Uploaded Successfully.", $fileName, 200);
        } catch (\Exception $e) {
            return $this->response("File Couldn't be Uploaded", "view", 500);
        }

    }

    public function uploadAttachmentSingle($file)
    {
        $fname = FileUploader::upload($file['photoIdProof']);
        return $fname;
    }

    public function searchOrg(Request $request)
    {
        $zip = new OrganizationFilter();

        if ($request->cname && !is_null($request->cname)) {
            $orgs = $zip->filterbyName($request->cname);
        } else if ($request->has('zip_code') && !is_null($request->zip_code)) {
            $orgs = $zip->filterbyZip($request->zip_code);
        } else {
            $orgs = Organization::where([
                ['is_deleted', 0],
                ['is_approved', 1],
                ['type', '!=', 'Rescue']
            ])->orderBy('cname', 'asc')->get();
        }
        foreach ($orgs as $org) {
            $org->no_of_vets = count($org->vet);
        }
        return $orgs;
    }

    public function searchRescue(Request $request)
    {
        return Organization::where('cname', 'LIKE', '%' . $request->cname . '%')
            ->with('address', 'contact')
            ->where([['is_deleted', false]])
            ->where('type', '=', 'Rescue')
            ->get();
    }

    /**
     * @param Request $request
     * @param $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function getPetByApplication(Request $request, $id)
    {
        $data = self::getInstance('application')->getPet($request, $id);
        return response()->json($data);
    }

    public function reviewProcess($application)
    {
        $data['id'] = $application->id;
        $this->process->changeProcessStatus($application, 'Status Changed to Review');
        if (email_app_review__mode()) {
            if ($application->commPref() && $application->commPref()->is_email) {
                $this->mail->sendEmail('appChangeToReview', $application->getMailAddress(), $data, 'Status Email Notification');
            }
        }
        if (getSiteSettings('application_review') && getSiteSettings('application_review') == 'True') {
            Notification::applicationReviewed($application);
        }
    }

    /**
     * return step of approval process
     * @return \Illuminate\Http\JsonResponse
     */
    public function returnProcess()
    {

        return response()->json(['process' => $this->responseMsg], 200);
    }

    /**
     * @param $application
     */
    public function approvedProcess($application, $generateletter = true)
    {
        $this->process->changeProcessStatus($application, 'Approved');
        if ($generateletter) {
            //approval Letter Generation
            $client = $application->client;

            if ($client->org_id)
                $cname = $client->organization->cname;
            else
                $cname = $client->fname . ' ' . $client->mname . ' ' . $client->lname;

            if ($client->address->zip_code)
                $city = $client->address->city . ', ' . $client->address->state . ' ' . $client->address->zip_code;
            else
                $city = $client->address->zip->city . ', ' . $client->address->zip->state . ' ' . $client->address->zip->zip_code;

            $date = date('m/d/Y', strtotime($application->approved_date));
            $data = [['title' => $client->title, 'client_name' => $cname, 'lname' => $client->lname, 'add1' => $client->address->add1, 'add2' => $client->address->add2, 'city' => $city, 'date' => $date]];
            $this->generateLetter($data, 'Approved letter', $application, 'application_approval');
            $this->process->changeProcessStatus($application, 'Approval Letter Generated');
            $this->note($application, 'Approval Letter Generated');
            $this->responseMsg = 'Approval Letter Generated';

//            if (!$application->client->org_id):
//                //Service Provider List
//                $this->generateServiceProviderList($client, $application);
//                $this->note($application, 'Service Provider List Letter Generated');
//            endif;

            //surgery Certificate Generated
            $data = self::getInstance($application)->getDetailsForSurgery();


            if (!getSiteSettings('partial_view') && getSiteSettings('partial_view') != 'true'):
                if ($application->client->org_id)
                    $letterName = 'Surgery Certificates';
                else
                    $letterName = 'Surgery Certificates IE';
                //generate single certificate
                foreach ($data as $d):
                    $cert_number = $this->generateCertificateNumber();

                    $pet_id = str_replace('PT', '', $d->pet_id);
                    //update Cert in DB
                    $appPet = ApplicationPet::where('application_id', $application->id)->where('pet_id', $pet_id)->first();

                    $appPet->cert_number = $cert_number;
                    $appPet->save();

                    //
                    $appData[0] = $d;
                    $d->cert_number = $cert_number;
                    $path = $this->generateFile($appData, $letterName, 'true');
                    self::getInstance($application)->storeUploadedFilePath([$path], Pet::find($pet_id), 'Surgery Certificate_' . $d->pet_name, 'application_pet_surgery', 'Certificate');
                endforeach;
            endif;
            //generate merge certificate
            $data = self::getInstance($application)->getDetailsForSurgery();
            $this->generateLetter($data, $letterName, $application, 'application_approval', true);
            $this->process->changeProcessStatus($application, 'Surgery Certificate Generated');
            $this->note($application, 'Surgery Certificate Generated');
            $this->responseMsg = 'Surgery Certificate Generated';

            //Copay  reminder letter
            if ($application->client->org_id == null) {

                $data = [];
                $data = [['amount' => 20, 'id' => $application->id]];
                if (getSiteSettings('copay_reminder') && getSiteSettings('copay_reminder') == 'True'):
                    $this->generateLetter($data, 'Copay Reminder', $application, 'application_approval');
                    $this->process->changeProcessStatus($application, 'Copay Reminder Letter');
                    $this->note($application, 'Copay Reminder Letter');
                    $this->responseMsg = 'Copay Reminder Letter Generated';
                endif;
            }
            if (email_app_approved__mode()):
                if ($application->commPref() && $application->commPref()->is_email) {
                    //retrieve all generated Attachment and send to Applicant

                    $data = [];
                    $data['client_name'] = $cname;
                    $data['id'] = $application->id;
                    $file = self::getInstance($application)->getFile('application_approval');
                    $this->mail->sendEmail('appApproved', $application->getMailAddress(), $data, 'Approval Letter Email Notice to Applicant & Attach Certificate', $file);
                    $this->note($application, 'Approval Letter Email Notice to Applicant & Attach Certificate');
                    $this->responseMsg = 'Approval Letter Email Notice to Applicant & Attach Certificate';
                }
            endif;

            //Send Certificate To Service Provider
//            $data = [];
//            $data['id'] = $application->id;
//            $file = self::getInstance($application)->getFile('application_approval', 'certificate');
//            $this->mail->sendEmail('spSurgeryCert', $application->getMailAddress(), $data, 'Certificate Email Sent to Service Provider', $file);
//            $this->note($application, 'Certificate Email Sent to Service Provider');
//            $this->responseMsg = 'Certificate Email Sent to Service Provider';
        }
    }

    /**
     * Generate Certificate Number For application
     */
    public function generateCertificateNumber()
    {
        $appPet = ApplicationPet::whereNotNull('cert_number')->orderBy('cert_number', 'ASC')->get()->last();
        if (!is_null($appPet)) {
            $appPet = $appPet->cert_number;
            $cert = str_replace("CERT-", "", $appPet);
            $cert++;
            $appPet = "CERT-" . str_pad($cert, 5, '0', STR_PAD_LEFT);
            return $appPet;
        } else {
            $cert = 1;
            $appPet = "CERT-" . str_pad($cert, 5, '0', STR_PAD_LEFT);
            return $appPet;
        }
    }

    /**
     * @param $application
     */
    public function denialProcess($application, $reason)
    {
        $client = $application->client;
        if ($client->org_id)
            $cname = $client->organization->cname;
        else
            $cname = $client->fname . ' ' . $client->mname . ' ' . $client->lname;

        if ($client->address->zip_code)
            $city = $client->address->city . ', ' . $client->address->state . ' ' . $client->address->zip_code;
        else
            $city = $client->address->zip->city . ', ' . $client->address->zip->state . ' ' . $client->address->zip->zip_code;

        $this->process->changeProcessStatus($application, 'Denial');
        //Denial Letter EmailNotification
        $data = [['title' => $client->title, 'client_name'=> $cname,  'lname' => $client->lname, 'date'=> date('M d, Y'), 'content' => $reason, 'add1' => $client->address->add1, 'add2' => $client->address->add2, 'city' => $city]];

        $this->generateLetter($data, 'Denial letter', $application, 'application_denial');
        $this->process->changeProcessStatus($application, 'Denial Letter Generated');
        $this->note($application, 'Denial Letter Generated');

        if ($application->commPref() && $application->commPref()->is_email) {
            //retrieve all generated Attachment and send to Applicant
            $data = [];
            $data['id'] = $application->id;
            $file = self::getInstance($application)->getFile('application_denial');
            $this->mail->sendEmail('appDenial', $application->getMailAddress(), $data, 'Denial Letter Email Notification', $file);
            $this->note($application, 'Denial Letter Email Notification');

        }
    }

    /**
     * @param $data
     * @param $letterName
     * @param $model
     * @param $documentSegment
     * @param bool $isCert
     */
    protected function generateLetter($data, $letterName, $model, $documentSegment, $isCert = false)
    {
        $path = $this->generateFile($data, $letterName);
        $type = $isCert ? 'certificate' : 'letter';
        if (strtolower($letterName) == 'approved letter')
            $letterName = 'Approval Letter';
        elseif ($letterName == 'Surgery Certificates IE')
            $letterName = 'Surgery Certificate - IE';
        self::getInstance($model)->storeUploadedFilePath([$path], $model, $letterName, $documentSegment, $type);
    }

    /**
     * @param Application $application
     * @return $this|\Illuminate\Http\JsonResponse
     * @throws \Exception
     */
    public function generateInvoice(Application $application)
    {
//        $invoice = new InvoiceController();
//        DB::beginTransaction();
//        try {
//            $invoice->store($application);
//            $this->process->changeProcessStatus($application, 'Service Provider Invoice Received');
//            $application->status = 'Invoiced';
//            $application->save();
//            DB::commit();
//            return $this->response('Invoice generated successfully', 'view', 200);
//        } catch (\Exception $e) {
//            DB::rollBack();
//            return $this->response('Something went wrong while generating Invoice', 'view', 422);
//        }
        foreach ($application->pets as $pet) {
            $this->generateInvoiceByPet($application, $pet, true);
        }
        return $this->response('Invoice generated successfully', 'view', 200);
    }

    /*
     * Invoice By individual pet
     */
    public function generateInvoiceByPet(Application $application, Pet $pet, $multi = false)
    {
        $invoice = new InvoiceController();
        DB::beginTransaction();
        try {
            $invoice->storeByPet($application, $pet);
            DB::commit();
            return $this->response('Invoice generated successfully', 'view', 200);
        } catch (\Exception $e) {
            DB::rollBack();
            if ($multi) {
                return true;
            } else {
                return $this->response($e->getMessage(), 'view', 422);
            }

        }
    }

    /**
     * Response File
     */
    public function responseFile($applicationId, $fileId)
    {
        $application = Application::where("id", $applicationId)->where("is_deleted", false)->first();

        if (!is_null($application)) {
            $file = $application->files($fileId)->first();
            if ($file->count()) {
                if (file_exists(storage_path('uploads/' . $file->file_name))) {
                    if (($file->fileInfo("extension") != "jpg" || $file->fileInfo("extension") != "jpeg" || $file->fileInfo("extension") != "png")) {
                        return response()->file(storage_path('uploads/' . $file->file_name));
                    } else {
                        return response()->file(storage_path('uploads/' . $file->file_name));
                    }
                } else {
                    return back();
                }
            }
        }
        return "false";
    }

    /*
     * Copay Reminder Email Notification sender
     * @param Application $application
     */
    public function sendCopayEmail(Application $application)
    {
        $data['amount'] = 20;
        $data['id'] = $application->id;
        $res = $this->mail->sendEmail('copayReminder', $application->getMailAddress(), $data);
        if ($res) {
            $this->note($application, 'Copay Email Reminder Send');
            $this->response('Copay Reminder Send Successfully', 'view', 200);
        } else {
            $this->note($application, 'Failed to send Copay Email Reminder');
            $this->response('Failed to send Copay Reminder', 'view', 422);
        }
    }

    private function getProvider($provider)
    {
        if ($provider = Organization::where('lic_no', $provider)->first()) {
            return $provider->id;
        }
        return null;
    }

    private function getVet($lic)
    {
        if ($client = Client::where('vet_lic', $lic)->first()) {
            return $client->id;
        }
        return false;
    }

    public function storeImports(Array $datas, $flag)
    {
        DB::beginTransaction();
        try {
            $client = $this->getClient($datas['client_id']);

            $provider = $this->getProvider($datas['provider_name']);

            $treatments = $this->createTreatmentArray($datas);

            $vet = $this->getVet($datas['vet']);

            if (array_key_exists('is_secondary_app', $datas) && $app = Application::find($datas['is_secondary_app'])) {
                $app = Application::find($datas['is_secondary_app']);
            } else {
                $fields = ['application_date', 'alt_id', 'is_tanf', 'is_general_assistance', 'is_food_stamp', 'is_medicaid', 'is_wic', 'is_ssi',
                    'is_ssd', 'approved_date', 'provider_id', 'client_id'
                ];
                $datas['provider_id'] = $this->getProvider($datas['provider_name']);
                $datas['client_id'] = $client->id;

                $number = preg_replace("/[^0-9\.]/", '', $datas['alt_id']);
                $datas['alt_id'] = str_pad($number, 5, "0", STR_PAD_LEFT);
                $app = new Application;
                foreach ($fields as $field) {
                    if ($field == 'application_date') {
                        $app->application_date = date('Y-m-d', strtotime($datas['application_date']));
                    } else {
                        $app->$field = $datas[$field];
                    }
                }
//                $app->created_at = $app->application_date
                $app->save();

            }


            $petfields = [
                'pet_name', 'type_of_Pet', 'age_type', 'age_of_pet', 'weight', 'where_obtained', 'comments', 'color'
            ];
            $pets = $this->getRequiredPetField($petfields, $datas, $client->id);
            $pet = new PetController;
            $pets = $pet->importPet($pets, $app, $provider, $vet, $treatments);
            //store Progress
            (new ProcessController())->store($app);
            $this->process->changeProcessStatus($app, 'Application Received');
            $this->process->changeProcessStatus($app, 'Application Received by Web');
            $this->note($app, 'Application Created', 'Import');

            $this->process->changeProcessStatus($app, 'Status Changed to Review');
            $this->note($app, 'Application Status Changed From New TO Review', 'Import');

            $this->process->changeProcessStatus($app, 'Choose Service Provider');
            $this->note($app, 'Service Provider Assign To Application');
            if ($vet) {
                $this->process->changeProcessStatus($app, 'Choose Veterinarian');
            }
            if ($treatments) {
                $this->process->changeProcessStatus($app, 'Choose Treatment Plan');
            }
            if (array_key_exists('approved_date', $datas) && $datas['approved_date'] != '') {
                $this->approvedProcess($app, false);
                $app->approved_by = auth()->id();
                $app->approved_date = date('Y-m-d', strtotime($datas['approved_date']));
                $app->is_provider_view = true;
            }
            $app->save();
            if (array_key_exists('is_copay_paid', $datas) && $datas['is_copay_paid'] == 'TRUE' && array_key_exists('copay_amt', $datas)) {
                $copay = (new PaymentController())->importCopay($app->id, $datas['copay_amt']);
                $this->process->changeProcessStatus($app, 'Copay Received');
                $this->note($app, 'Copay Received for Application', 'Import');
            }
            if (array_key_exists('funded_amount', $datas)) {
                $this->generateImportInvoice($app, $datas['funded_amount']);
                $this->note($app, 'Invoice generated for Application', 'Import');
                $app->status = 'Closed';

            }
            $app->save();

//            Notification::applicationStatusChanged($app,$app->status);
            $message = 'Application Inserted succesfully' . PHP_EOL . json_encode($datas);
            $data = $this->prepareLog($datas['alt_id'], $message);
            $this->saveToLog($data, 'Application' . date('Y-m-d'), ['importer', 'success']);

            $logData = json_encode(['id' => $app->alt_id, 'type' => 'Sucess', "message" => "Application Saved SuccessFully"], JSON_PRETTY_PRINT) . '|';
            $this->saveToLog($logData, 'ApplicationImportMonitor', ['importer'], $flag);
            DB::commit();
            return true;

        } catch (\Exception $e) {
            DB::rollBack();
            $message = json_encode($e) . PHP_EOL . json_encode($datas);
            $data = $this->prepareLog($datas['alt_id'], $message, 'error');
            $this->saveToLog($data, 'Application ' . date('Y-m-d'), ['importer', 'error']);

            $logData = json_encode(['type' => 'Error', "message" => "Failed To save Application"], JSON_PRETTY_PRINT) . '|';
            $this->saveToLog($logData, 'ApplicationImportMonitor' . date('Y-m-d'), ['importer'], $flag);

            return $this->response("Application Can't submitted", 'view', 422);

        }

    }

    protected function prepareLog($id, $message, $status = 'success')
    {

        $data = "Application no : $id " . PHP_EOL .
            "---------------------------------------------" . PHP_EOL .
            $message . PHP_EOL .
            "**********************************************" . PHP_EOL .
            "Status = $status" . PHP_EOL .
            "----------------------------------------------" . PHP_EOL;
        return $data;
    }

    public function saveToLog($data, $name = 'applicationname', $folder = [], $flag = 'a')
    {
        (new Log())->save($data, $name, $folder, $flag);
        return true;
    }

    protected function createTreatmentArray(Array $datas)
    {
        $treatments = [];
        if (array_key_exists('is_rabbies_vaccination', $datas) && $datas['is_rabbies_vaccination'] == 'TRUE') {
            $t = Treatment::where('treatment_name', 'Rabbies')->first();
            array_push($treatments, $t->id);
        }
        if (array_key_exists('is_sterilization', $datas) && $datas['is_sterilization'] == 'TRUE') {
            $t = Treatment::where('treatment_name', 'surgery')->first();
            array_push($treatments, $t->id);
        }
        if (count($treatments) > 0) {
            return $treatments;
        }
        return false;

    }

    public function getClient($id)
    {
        if ($client = Client::where('alt_id', $id)->first()) {
            return $client;
        }
        return Client::first();
    }

    public function generateImportInvoice(Application $application, $amount)
    {
        $invoice = new InvoiceController();
        $invoice->importStore($application, $amount);
        $this->process->changeProcessStatus($application, 'Service Provider Invoice Received');
        $this->process->changeProcessStatus($application, 'Invoice Approved');
        $application->status = 'Closed';
        $application->source = 'CSV';
        $application->save();
        return $this->response('Invoice generated successfully', 'view', 200);

    }

    protected function getRequiredField(Array $field, Array $client)
    {
        $d = array();
        foreach ($client as $key => $value) {
            if (in_array($key, $field)) {
                $d[$key] = $value;
            }
        }
        $d['personal_email'] = $d['lname'] . random_string() . '@' . $d['lname'] . '.com';
        $d['state'] = 'De';
        $d['cell_phone'] = '9841080357';
        return $d;
    }

    /**
     * @param Application $application
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function editEligibility(Application $application)
    {
        $states = Lookups::where('code', 'state')->where('is_deleted', false)->get();
        $federals = Lookups::where('code', 'federal')->where('is_deleted', false)->get();
        return view($this->layout . '.pages.application.applicationdetails.include.leftSection.editEligibility', compact('application', 'states', 'federals'));
    }

    /**
     * @param Request $request
     * @param Application $application
     * @return $this|\Illuminate\Http\JsonResponse
     */
    public function updateEligibility(Request $request, Application $application)
    {
        //check if request contain the
        $data = $request->all();
        $eligibility = ['is_tanf', 'is_food_stamp', 'is_medicaid', 'is_general_assistance', 'is_wic', 'is_ssi', 'is_vad', 'is_ssd'];
        foreach ($eligibility as $e):
            if (!array_key_exists($e, $data))
                $data[$e] = 0;
        endforeach;

        $res = self::getInstance($application)->saveUpdate($data);
        if ($res)
            return $this->response('Eligibility Update Successfully', 'view', 200);
        else
            return $this->response('Failed to update Eligibility', 'view', 422);
    }

    protected function getRequiredPetField(Array $field, Array $client, $clientid)
    {
        $d = array();
        foreach ($client as $key => $value) {
            if (in_array($key, $field)) {
                if ($key == 'type_of_Pet') {
                    $details = explode(' ', $value);
                    if (array_key_exists(1, $details))
                        $d['species'] = $details[1];
                    if (array_key_exists(0, $details))
                        $d['sex'] = $details[0];
                }
                $d[$key] = $value;
            }
        }
        $d['client_id'] = $clientid;
        return $d;
    }

//for adding new pet in application form
    public function addNewPetForm($id = 1)
    {
        $treatments = Treatment::where('is_must', true)->get();
        return view('default.pages.application.templates.addNewPetForm', compact('treatments', 'id'));
    }

    //for adding new pet in application form
    public function addNewPetTreatmentForm($id = 1)
    {
        $treatments = Treatment::where('is_must', true)->get();
        return view('default.pages.application.templates.addNewPetTreatmentForm', compact('treatments', 'id'));
    }

    //service queue
    public function serviceQueue(Application $application)
    {
        $pets = $application->pets;
        foreach ($pets as $p):
            $p->treatments = ApplicationPetTreatments::where('application_id', $application->id)->where('pet_id', $p->id)->where('treatment_date', '=', Null)->get();
            foreach ($p->treatments as $t):
                $treatment = Treatment::find($t->treatment_id);
                $t->treatment_id = $treatment->id;
                $t->treatment_name = $treatment->treatment_name;
                $t->treatment_type = $treatment->treatment_type;
                $p->notPerformed = 'true';
            endforeach;

            $client = Client::find($application->client_id);
            $p->owner_name = $client->fname . ' ' . $client->mname . ' ' . $client->lname;
        endforeach;
        return view('default.pages.application.servicePerform.index', compact('pets', 'application'));
    }

    public function checkPetTreatment(Application $application)
    {
        $result = array();
        $pets = $application->pets;
        foreach ($pets as $pet):
            $data = ApplicationPetTreatments::where('application_id', $application->id)->where('pet_id', $pet->id)->get();
            foreach ($data as $d):
                if ($d->treatment_date):
                    $treatment = 'true';
                    array_push($result, $treatment);
                else:
                    $treatment = 'false';
                    array_push($result, $treatment);
                endif;
            endforeach;
        endforeach;
        if (in_array("false", $result)):
            return 'false';
        else:
            return 'true';
        endif;
    }

    public function checkSingleTreatment(Application $application, Pet $pet, Treatment $treatment)
    {

        $data = ApplicationPetTreatments::where('application_id', $application->id)->where('pet_id', $pet->id)->where('treatment_id', $treatment->id)->first();
        $treatment = 'false';
        if ($data->treatment_date):
            $treatment = 'true';
        endif;
        return $treatment;
    }

    /**
     * generate service Provide list
     *
     * @param Client $client
     * @param $application
     */
    public function generateServiceProviderList(Client $client, $application)
    {
        $providers = \App\Models\ProviderList::all();
        $view = view('default.print.providerList', compact('providers'));

        $screenCapture = new ScreenCapture();
        $path = $screenCapture->load($view);

        //replace full path with absolute
        $abPath = storage_path('uploads' . DIRECTORY_SEPARATOR);
        $path = str_replace($abPath, '', $path);

        self::getInstance($application)->storeUploadedFilePath([$path], $application, 'Service Provider List', 'application_approval', 'letter');
    }

    public function regenerate(Application $application)
    {
        DB::beginTransaction();
        try{
            $surgery = File::where('table', 'applications')
                ->where('table_id', $application->id)
                ->where('document_title', 'Surgery Certificate - IE')
                ->first();

            $approval = File::where('table', 'applications')
                ->where('table_id', $application->id)
                ->where('document_title', 'Approval Letter')
                ->first();
            $client = $application->client;

            if ($client->org_id)
                $cname = $client->organization->cname;
            else
                $cname = $client->fname . ' ' . $client->mname . ' ' . $client->lname;

            if ($client->address->zip_code)
                $city = $client->address->city . ', ' . $client->address->state . ' ' . $client->address->zip_code;
            else
                $city = $client->address->zip->city . ', ' . $client->address->zip->state . ' ' . $client->address->zip->zip_code;

            $date = date('m/d/Y', strtotime($application->approved_date));
            $data = [['title' => $client->title, 'client_name' => $cname, 'lname' => $client->lname, 'add1' => $client->address->add1, 'add2' => $client->address->add2, 'city' => $city, 'date' => $date]];
            $path = $this->generateFile($data, 'Approved letter');
            $approval->file_name = $path;
            $approval->save();
            $this->note($application, 'Approval Letter ReGenerated');


            //Generating Surgery Certificate
            $data = self::getInstance($application)->getDetailsForSurgery();
            if ($application->client->org_id)
                $letterName = 'Surgery Certificates';
            else
                $letterName = 'Surgery Certificates IE';

            foreach ($data as $d) {
                $pet_id = str_replace('PT', '', $d->pet_id);
                //update Cert in DB
                $appPet = ApplicationPet::where('application_id', $application->id)->where('pet_id', $pet_id)->first();

                $appData[0] = $d;

                $petFile = File::where('table', 'pets')
                    ->where('table_id', $pet_id)
                    ->first();

                $path = $this->generateFile($appData, $letterName, 'true');
                $petFile->file_name = $path;
                $petFile->save();
            }
            $path = $this->generateFile($data, $letterName);
            $this->note($application, 'Surgery Certificate Regenerated');
            $surgery->file_name = $path;
            $surgery->save();
            DB::commit();
            return $this->response("Application File Regenerated" , "view", 200);
        }catch (\Exception $e)
        {
            DB::rollBack();
            throw $e;
            return $this->response($e->getMessage() , "view", 500);
        }

    }

    public function regenerateApp(Application $application)
    {
        return view('default.pages.application.modal.regenerateApp', compact('application'));
    }

    public function editSurvey(Application $application)
    {
        return view('default.pages.application.modal.editSurvey', compact('application'));
    }

    public function updateSurvey(Request $request, Application $application)
    {
        DB::beginTransaction();
        try{
            $application->is_prev_applied = $request->is_prev_applied;
            $application->hear_about_us = $request->hear_about_us;
            $application->save();
            DB::commit();
            return $this->response("Application Survey Updated Successfully" , "view", 200);
        }
        catch (\Exception $e)
        {
            DB::rollBack();
            throw $e;
            return $this->response($e->getMessage() , "view", 500);
        }
    }
}

