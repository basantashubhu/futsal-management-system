<?php
/**
 * DEVELOPERS
 * ----------------------------------------------
 * SUMAN  THAPA - LEAD  (NEPALNME@GMAIL.COM)
 * ----------------------------------------------
 * - RUNA SIDDHI BAJRACHARYA
 * - RABIN BHANDARI
 * - SHIVA THAPA
 * - PRABHAT GURUNG
 * - KIRAN CHAULAGAIN
 * -----------------------------------------------
 * Created On: 4/12/2018
 *
 * THIS INTELLECTUAL PROPERTY IS COPYRIGHT Ⓒ 2018
 * ZEUSLOGIC, INC. ALL RIGHT RESERVED
 */

namespace App\Http\Controllers\Application;


use App\Http\Controllers\BaseController;
use App\Models\Application;
use App\Models\ApplicationPet;
use App\Models\ApplicationPetTreatments;
use App\Models\Client;
use App\Models\Organization;
use App\Models\Pet;
use App\Models\RatePlan;
use App\Models\RateType;
use App\Models\Rate;
use App\Repo\ApplicationRepo;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Treatment;

class ApplicationTreatmentController extends BaseController
{
    protected $process;
    private $clayout;

    public function __construct()
    {
        parent::__construct();
        $this->clayout = $this->layout . '/pages/application/applicationdetails/include/treatment/';
        $this->process = new ProcessController();
    }

    public function store(Request $request, Application $application)
    {
        DB::beginTransaction();
        try {
            if (getSiteSettings('partial_mode') && getSiteSettings('partial_mode') == 'true') {
                //   Assign Provider
                $pet = $request->pet;
                //assign Pet With Treatment
                $appPet = ApplicationPet::where('application_id', $application->id)->where('pet_id', $pet)->first();
                if ($request->has('provider_id') && $request->provider_id != null) {
                    $appPet->provider_id = $request->provider_id;
                    $appPet->save();

                    $data = array(
                        'application_id' => $application->id,
                        'pet_id' => $pet,
                        'vet_id' => $request->vet_id,
                        'created_at' => date('Y-m-d H:i:s')
                    );
                }
                $apt = ApplicationPetTreatments::where('application_id', $application->id)->where('pet_id', $pet)->first();
                if(isset($apt->id)):
                ApplicationPetTreatments::where('application_id', $application->id)->where('pet_id', $pet)->update($data);
                else:
                ApplicationPetTreatments::insert($data);
                endif;
                $this->changeProcess($application);
                DB::commit();
                // return $this->returnRow($application);
                $template = $this->returnRow($application);
                return $template;
                return $this->response('Service Provider Updated', ['template' => $template], 200);
            }
            else{
                //   Assign Provider
                $pets = $request->only('pets');
                //assign Pet With Treatment
                $treatArr = [];
                foreach ($request->pets as $pet):
                    $appPet = ApplicationPet::where('application_id', $application->id)->where('pet_id', $pet)->first();
                    if ($request->has('provider_id') && $request->provider_id != null) {
                        $appPet->provider_id = $request->provider_id;
                        $appPet->save();

                        $data = array(
                            'application_id' => $application->id,
                            'pet_id' => $pet,
                            'vet_id' => $request->vet_id,
                            'created_at' => date('Y-m-d H:i:s')
                        );
                        array_push($treatArr, $data);
                    }
                endforeach;
                if (count($treatArr) > 0)
                    ApplicationPetTreatments::insert($treatArr);
            $this->changeProcess($application);
            DB::commit();
            return $this->returnPartial($application, $request->pets[0]);
            }
        } catch (\Exception $e) {
            DB::rollBack();
            throw $e;
            return $this->response('Service Provider Can\'t Assigned', 'view', 422);
        }
    }

    private function returnRow($application)
    {
        $pets = $application->pets;
        foreach ($pets as $p):
            $p->treatments = ApplicationPetTreatments::where('application_id', $application->id)->where('pet_id', $p->id)->get();
            $cert = ApplicationPet::where('application_id', $application->id)->where('pet_id', $p->id)->first();
            $p->cert_number = $cert->cert_number;
            foreach ($p->treatments as $t):
                $treat = Treatment::find($t->treatment_id);
                if(isset($treat)):
                $t->treatment_id = $treat->id;
                $t->treatment_name = $treat->treatment_name;
                $t->treatment_type = $treat->treatment_type;
                $p->notPerformed = 'true';
                $rate = Rate::where('treatment_id', $treat->id)->first();
                $t->cost = $rate->cost;
                endif;
                $veterinarian = Client::find($t->vet_id);
                if(isset($veterinarian->fname)):
                    $p->vet = $veterinarian->title.' '.$veterinarian->fname.' '.$veterinarian->lname;
                endif;
            endforeach;
        endforeach;
        return view($this->layout . '.pages.application.partialView.include.treatment.partial.partialView',
            compact('pets', 'application'));
    }
    private function returnPartial($application, $pet)
    {
        $pet = Pet::findOrFail($pet);
        $apt = ApplicationPetTreatments::where('application_id', $application->id)->where('pet_id', $pet->id)->first();
        $serviceProvider = false;
        if ($apt)
            $serviceProvider = true;
        else
            $serviceProvider = false;

        $providers = $application->applicationPet->where('pet_id', $pet->id)->first()->serviceProvider;

        if ($providers != null):
            $organization = Organization::find($providers->id);
            if ($apt)
                $vet = Client::find($apt->vet_id);
            else
                $vet = null;
        endif;

        return view($this->layout . '.pages.application.applicationDetails.include.treatment.partial.serviceProvider',
            compact('vet', 'providers', 'serviceProvider', 'application', 'pet'));
    }

    public function storeImport(Application $application)
    {
//        DB::beginTransaction();
        try {
            $vetid = $application->vets->first()->id;
            foreach ($application->pets as $pet):
                $treatArr = [];
                $appPet = ApplicationPet::where('application_id', $application->id)->where('pet_id', $pet->id)->first();
                $data = array(
                    'application_id' => $application->id,
                    'pet_id' => $pet->id,
                    'vet_id' => $vetid,
                    'created_at' => date('Y-m-d H:i:s')
                );
                array_push($treatArr, $data);
            endforeach;
            ApplicationPetTreatments::insert($treatArr);

            $this->changeProcess($application);
//            DB::commit();
            return true;
        } catch (\Exception $e) {
//            DB::rollBack();
            return $this->response('Treatment Plan Can\'t Added ', 'view', 422);
        }
    }

    public function changeProcess($application)
    {
        $totalPets = $application->pets->count();
        $treatmentPet = ApplicationPetTreatments::where('application_id', $application->id)->groupBy('application_id', 'pet_id')->get()->count();
        if ($totalPets == $treatmentPet):
            $this->process->changeProcessStatus($application, 'Choose Service Provider');
            $this->process->changeProcessStatus($application, 'Choose Veterinarian');;
        endif;

    }

    public function getCustomTreatmentPlan(Pet $pet)
    {
        $rateType = $this->getRateType($pet);
        $ratePlan = RatePlan::where([
            ['is_active', 1],
            ['is_deleted', 0]
        ])->first();
        return view($this->clayout . 'addCustomTreatment', compact('pet', 'rateType', 'ratePlan'));
    }

    public function listCustomPlan(Pet $pet)
    {
        return view($this->clayout . 'listCustomPlan', compact('pet'));
    }

    public function getRateType($pet)
    {
        $weight = $pet->weight;
        $sex = strtolower($pet->sex);
        $species = strtolower($pet->species);

        $rateQuery = RateType::where('is_deleted', 0)->where('name', 'like', "$sex%")->where('name', 'like', "%$species%");

        if ($species == 'dog' && $weight > 50)
            $rateQuery = $rateQuery->where('rate_metrics', '>50');
        elseif ($species == 'dog' && $weight <= 50)
            $rateQuery = $rateQuery->where('rate_metrics', '<=50');

        $rateType = $rateQuery->first();
        return $rateType;
    }

    public function storeTreatment(Request $request, Application $application)
    {
        $petId = $request->pet_id;
        $treatments = $request->treatment;
        if (count($treatments) <= 0)
            return $this->response('Please select treatment first', 'view', 422);
        DB::beginTransaction();
        try {
            $prevApt = ApplicationPetTreatments::where([
                ['application_id', $application->id],
            ])->first();

            $treatArr = [];

            $aptInv = ApplicationPetTreatments::where([
                ['application_id', $application->id],
                ['pet_id', $petId],
            ])->first();

            ApplicationPetTreatments::where([
                ['application_id', $application->id],
                ['pet_id', $petId],
            ])->delete();

            foreach ($treatments as $treatment):
                $data = array(
                    'application_id' => $application->id,
                    'pet_id' => $petId,
                    'vet_id' => $prevApt->vet_id,
                    'treatment_id' => $treatment,
                    'created_at' => date('Y-m-d H:i:s')
                );

                array_push($treatArr, $data);
            endforeach;
            ApplicationPetTreatments::insert($treatArr);

            $this->changeTreatmentProcess($application);
            DB::commit();
            return $this->response('Treatment Plan Added Successfully', 'view', 200);
        } catch (\Exception $e) {
            DB::rollBack();
            return $this->response($e->getMessage(), 'view', 422);
        }

    }

    public function changeTreatmentProcess($application)
    {
        $totalPets = $application->pets->count();
        $treatmentPet = ApplicationPetTreatments::whereNotNull('treatment_id')->where('application_id', $application->id)->groupBy('application_id', 'pet_id')->get()->count();
        if ($totalPets == $treatmentPet):
            $this->process->changeProcessStatus($application, 'Choose Treatment Plan');
        endif;
    }

    public function getApplicationTreatment(Request $request, Application $application)
    {
        $repo = new ApplicationRepo($application);
        return $repo->getApplicationTreatment($request, $application->id);
    }

    public function storeAppTreatmentMonthly(Application $application, Pet $pet, $treatmentId, $amt, $treatmentDate=null)
    {

        $provider = $application->providers($pet->id);

        $prevApt=ApplicationPetTreatments::where('application_id',$application->id)
            ->where('pet_id',$pet->id)
            ->whereNotNull('vet_id')->first();

        $apt=ApplicationPetTreatments::where('application_id',$application->id)
            ->where('pet_id',$pet->id)
            ->whereNull('treatment_id')->first();

        if($apt)
        {
            $apt->vet_id=($provider->vet->first())?$provider->vet->first()->id:1;
            $apt->treatment_id=$treatmentId;
            $apt->treatment_date=is_null($treatmentDate)?date('Y-m-d'):$treatmentDate;
            $apt->treatment_period_start=is_null($treatmentDate)?date('Y-m-d'):$treatmentDate;
            $apt->treatment_status='Completed';
            $apt->billed_amt=$amt[0];
            $apt->approved_amt=isset($amt[1])?$amt[1]:$amt[0];
            $apt->save();
        }
        else
        {
            $apt=new ApplicationPetTreatments();
            $apt->application_id=$application->id;
            $apt->pet_id=$pet->id;
            $apt->vet_id=($prevApt)?$prevApt->vet_id:(($provider->vet->first())?$provider->vet->first()->id:1);
            $apt->treatment_id=$treatmentId;
            $apt->treatment_date=is_null($treatmentDate)?date('Y-m-d'):$treatmentDate;
            $apt->treatment_period_start=is_null($treatmentDate)?date('Y-m-d'):$treatmentDate;
            $apt->treatment_status='Completed';
            $apt->billed_amt=$amt[0];
            $apt->approved_amt=isset($amt[1])?$amt[1]:$amt[0];;
            $apt->save();
        }
    }

}