<?php

namespace App\Http\Controllers\Application;

use App\Http\Controllers\BaseController;
use App\Http\Controllers\Client\ClientController;

use App\Http\Controllers\Communication\CommunicationPrefController;
use App\Http\Controllers\Invoice\InvoiceController;

use App\Http\Controllers\Pet\PetController;
use App\Http\Controllers\Settings\RateController;
use App\Http\Requests\ApplicationRequest;
use App\Http\Requests\ClientRequest;
use App\Lib\Email\EmailSender;
use App\Lib\File\FileUploader;
use App\Lib\Filter\OrganizationFilter\OrganizationFilter;
use App\Lib\Notification\Notification;

use App\Models\Application;
use App\Models\ApplicationPetTreatments;
use App\Models\Client;
use App\Models\Organization;
use App\Models\Pet;
use App\Models\File;
use App\Models\Treatment;
use App\Repo\ApplicationRepo;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Settings\Lookups;
use Illuminate\Support\MessageBag;

class AddApplicationCitizen extends BaseController
{
	private static $repo = null;
	private $process;
    public function __construct()
    {
    	parent::__construct();
    	$this->process = new ProcessController();
    }
        /**
     * @param $model
     * @return ApplicationRepo|null
     */
    private static function getInstance($model)
    {
        self::$repo = new ApplicationRepo($model);
        return self::$repo;
    }

    public function index($for = null)
    {
    	$pets = Pet::where('is_deleted', false)->get();
        $states = Lookups::where('code', 'state')->where('is_deleted', false)->get();
        $federals = Lookups::where('code', 'federal')->where('is_deleted', false)->get();

        $nonProfit = Organization::where('type', 'Non Profit')
            ->where('is_deleted', false)
            ->where('is_approved', 1)
            ->get();

        $providers = Organization::where('type', 'Service Provider')
            ->where('is_deleted', false)
            ->where('is_approved', 1)
            ->get();

        if (!is_null($for)) {
            return view($this->layout . '.pages.application.addPages.addCitizen.index', compact('pets', 'states', 'federals', 'providers', 'for', 'nonProfit'));
        } else {
            return view($this->layout . '.pages.application.addPages.addCitizen.index', compact('pets', 'states', 'federals', 'providers'));
        }
    }

        /**
     * @param ApplicationRequest $request
     * @return $this|\Illuminate\Http\JsonResponse
     * @throws \Exception
     */
    public function store(ApplicationRequest $request)
    {
        DB::beginTransaction();
        try {
            $clientData = new ClientRequest($request->only('title', 'fname', 'mname', 'lname', 'dob', 'add1', 'add2', 'zip', 'state', 'city', 'cell_phone', 'alt_phone', 'personal_email'));

            //triggering client Controller to handel client Information
            $client = (new ClientController())->store($clientData, true);

            if (!($client instanceof Client))
                throw new \Exception('Error');
            if ($oldapp = Application::latest()->first()) {
                $alt_id = isset($oldapp->alt_id) ? $oldapp->alt_id : getSiteSettings('application_alt_id');
            } else {
                $alt_id = 1000;
                if ($id = getSiteSettings('application_alt_id')) {
                    $alt_id = $id;
                }
            }

            //getting Application Related Data
            $applicationData = $request->only('is_tanf', 'is_medicaid', 'is_general_assistance', 'is_food_stamp', 'is_wic', 'is_ssi', 'is_ssd', 'is_vad', 'client_id', 'provider_id');
            $applicationData['client_id'] = $client->id;
            $applicationData['alt_id'] = ++$alt_id;

            $applicationData['application_date'] = date('Y-m-d');

            $repo = self::getInstance('application');
            $application = $repo->saveUpdate($applicationData);

            //store Communication Preference
            $commPref = $request->only('is_email', 'is_mail', 'is_phone', 'is_sms');
            (new CommunicationPrefController())->store($commPref, $application);

            //Upload attachment
            $fileName = $this->uploadAttachment($request->file());
            $fileTitle = [];
            if ($request->has('photoIdProofTitle'))
                array_push($fileTitle, $request->photoIdProofTitle);

            if ($request->has('anualProofTitle'))
                array_push($fileTitle, $request->anualProofTitle);

            if ($request->has('extraFiles')) {
                foreach ($request->extraFiles as $title)
                    array_push($fileTitle, $title);
            }
            $repo->storeUploadedFilePath($fileName, $application, $fileTitle);

            //Pet Store
            $petData = $request->only('pet_name', 'sex', 'age_type', 'age_of_pet', 'weight', 'species', 'color', 'breed', 'unique_traits', 'where_obtained');
            $petData['client_id'] = $client->id;
            $petData['provider_id'] = $request->provider_id;
            $petData['vet_id'] = $request->vet_id;
            $pet = (new PetController())->storePet($petData, $application);

            if ($pet instanceof MessageBag)
                return response(['message' => 'the given data was invalid', 'errors' => $pet], 422);
            elseif ($pet instanceof \Exception)
                throw new \Exception($pet);

            //store Progress
            (new ProcessController())->store($application);
            $this->process->changeProcessStatus($application, 'Application Received by Web');
            $this->process->changeProcessStatus($application, 'Application Received');
            if($request->has('provider_id') && $request->provider_id!='' && $request->provider_id!=null)
                $this->process->changeProcessStatus($application, 'Choose Service Provider');
            if($request->has('vet_id') && $request->vet_id!='' && $request->vet_id!=null)
                $this->process->changeProcessStatus($application, 'Choose Veterinarian');;
            DB::commit();

            Notification::newApplicationCreation($application);

            return $this->response("Application added successfully", ['app_id'=>$application->id], 200);
        } catch (\Exception $e) {
            DB::rollBack();
            return $this->response("Application Can't submitted", 'view', 422);
        }
    }

        /***
     * @param $file
     * @return array
     * @throws \Exception
     */
    public function uploadAttachment($file)
    {
        $fileName = array();

        if (array_key_exists('photoIdProof', $file)):
            $fname = FileUploader::upload($file['photoIdProof']);
            array_push($fileName, $fname);
        endif;

        if (array_key_exists('anualProof', $file)):
            $fname = FileUploader::upload($file['anualProof']);
            array_push($fileName, $fname);
        endif;
        if (array_key_exists('addinationalPhotos', $file)) {
            foreach ($file['addinationalPhotos'] as $f) {
                $fname = FileUploader::upload($f);
                array_push($fileName, $fname);
            }
        }
        return $fileName;
    }
}
