<?php
/**
 * DEVELOPERS
 * ----------------------------------------------
 * SUMAN  THAPA - LEAD  (NEPALNME@GMAIL.COM)
 * ----------------------------------------------
 * - RUNA SIDDHI BAJRACHARYA
 * - RABIN BHANDARI
 * - SHIVA THAPA
 * - PRABHAT GURUNG
 * - KIRAN CHAULAGAIN
 * -----------------------------------------------
 * Created On: 5/24/2018
 *
 * THIS INTELLECTUAL PROPERTY IS COPYRIGHT Ⓒ 2018
 * ZEUSLOGIC, INC. ALL RIGHT RESERVED
 */

namespace App\Http\Controllers\Application;


use App\Http\Controllers\BaseController;
use App\Models\Application;
use App\Repo\ApplicationCommentRepo;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class ApplicationCommentController extends BaseController
{
    private static $repo;
    private $clayout;

    public function __construct()
    {
        parent::__construct();
        $this->clayout=$this->layout.'.pages.application.applicationdetails.include.rightSection.';
    }

    public static function getInstance($model)
    {
        self::$repo=new ApplicationCommentRepo($model);
        return self::$repo;
    }

    public function store(Request $request,Application $application)
    {
        $data=$request->all();
        $data['table_id']=$application->id;
        $data['table_name']=$application->getTable();
        $data['comment_by']=auth()->user()->client->id;
        $data['userc_id']=auth()->id();
        $res=self::getInstance('ApplicationComment')->saveUpdate($data);
        if($res)
            return $this->response("Comment Added", 'test', 200);
        else
            return $this->response("Failed to Add Comment", 'test', 500);
    }

    public function getComment(Application $application)
    {
        $comments=self::getAllComment($application->id);
        return view($this->clayout.'commentList',compact('comments'));
    }

    public static function getAllComment($id)
    {

        $query=DB::table('application_comment')
            ->join('clients','clients.id','application_comment.comment_by')
            ->join('clients as c','c.id','application_comment.comment_to')
            ->select('application_comment.*',
                DB::raw('CONCAT(clients.fname," ",COALESCE(clients.mname,"")," ",clients.lname) AS comment_by_name'),
                DB::raw('CONCAT(c.fname," ",COALESCE(c.mname,"")," ",c.lname) AS comment_to_name')
            )->where([
                ['table_id',$id],
                ['table_name','applications'],
            ]);

        if(Auth::user()->role_id !=1 && Auth::user()->role->name != 'admin')
            $query=$query->where('comment_to',Auth::id());

        $query=$query->get();
        return $query;

    }
}
