<?php
/**
 * DEVELOPERS
 * ----------------------------------------------
 * SUMAN  THAPA - LEAD  (NEPALNME@GMAIL.COM)
 * ----------------------------------------------
 * - RUNA SIDDHI BAJRACHARYA
 * - RABIN BHANDARI
 * - SHIVA THAPA
 * - PRABHAT GURUNG
 * - KIRAN CHAULAGAIN
 * -----------------------------------------------
 * Created On: 4/11/2018
 *
 * THIS INTELLECTUAL PROPERTY IS COPYRIGHT Ⓒ 2018
 * ZEUSLOGIC, INC. ALL RIGHT RESERVED
 */

namespace App\Http\Controllers\Application;


use App\Http\Controllers\BaseController;
use App\Models\Application;
use App\Models\ApplicationProcess;
use Illuminate\Support\Facades\DB;

class ProcessController extends BaseController
{

    public function store(Application $application)
    {
        if (getSiteSettings('partial_mode') && getSiteSettings('partial_mode') == 'true') {
            $file = config('partialProcess');
        } else {

            $file = config('process');
        }
        $data = array();
        foreach ($file as $process) {
            $process['application_id'] = $application->id;
            if (!array_key_exists('step_type', $process))
                $process['step_type'] = null;
            $process['created_at'] = date('Y-m-d H:i:s');
            array_push($data, $process);
        }
        ApplicationProcess::insert($data);
    }

    public function storeNP(Application $application)
    {
        if (getSiteSettings('partial_mode') && getSiteSettings('partial_mode') == 'true') {
            $file = config('partialProcess');
        } else {
            $file = config('npProcess');
        }
        $data = array();
        foreach ($file as $process) {
            $process['application_id'] = $application->id;
            if (!array_key_exists('step_type', $process))
                $process['step_type'] = null;
            $process['created_at'] = date('Y-m-d H:i:s');
            array_push($data, $process);
        }
        ApplicationProcess::insert($data);
    }


    public function changeProcessStatus($application, $process)
    {
        $process = ApplicationProcess::where('progress_name', $process)->where('application_id', $application->id)->first();
        if ($process):
            $process->status = 1;
            $process->progress_date = date('Y-m-d');
            $process->save();
        endif;
    }

    public function trackProcess($id)
    {
        $data = DB::table('application_progress')
            ->select(DB::raw('count(step) as finished_step'), 'step')
            ->where([
                ['application_id', $id],
                ['status', 1],
            ])
            ->groupBy('step')
            ->orderBy('step', 'desc')
            ->limit(1)
            ->get();
        return $data[0];
    }

}