<?php

namespace App\Http\Controllers\Application;

use App\Http\Controllers\BaseController;
use App\Http\Controllers\Pet\PetController;
use App\Http\Requests\ApplicationNpRequest;
use App\Lib\Email\EmailSender;
use App\Lib\File\FileUploader;
use App\Lib\Notification\Notification;
use App\Models\Application;
use App\Models\Organization;
use App\Repo\ApplicationRepo;
use Illuminate\Support\Facades\Validator;
use Illuminate\Contracts\Support\MessageBag;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Requests\PetRequest;
use App\Models\Pet;
use App\Models\ApplicationPetTreatments;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Application\ApplicationTreatmentController;

class ApplicationNpController extends BaseController
{
    /**
     * @var null
     */
    private static $repo = null;
    private $process;
    private $mail;

    /**
     * ApplicationController constructor.
     */
    public function __construct()
    {
        parent::__construct();
        $this->process = new ProcessController();
        $this->mail = new EmailSender();
    }

    /**
     * @param $model
     * @return ApplicationRepo|null
     */
    private static function getInstance($model)
    {
        // if (self::$repo == null)
        self::$repo = new ApplicationRepo($model);
        return self::$repo;
    }

    public function store(Request $request)
    {

        DB::beginTransaction();
        try {
            // dd($request->all());

            $treatments = $request->treatment_id;
            $org = Organization::find($request->nonProfit_id);
            if (auth()->user()->role->id == 1 || auth()->user()->role->name == 'admin'):
                $client = $org->contactPerson;
            else:
                $client = auth()->user()->client;
            endif;

            if ($oldapp = Application::latest()->first()) {
                $alt_id = isset($oldapp->alt_id) ? $oldapp->alt_id : getSiteSettings('application_alt_id');
            } else {
                $alt_id = 1000;
                if ($id = getSiteSettings('application_alt_id')) {
                    $alt_id = $id;
                }
            }

            //getting Application Related Data
            $applicationData = $request->only('is_tanf', 'is_medicaid', 'is_general_assistance', 'is_food_stamp', 'is_wic', 'is_ssi', 'is_ssd', 'is_vad', 'client_id', 'provider_id', 'is_prev_applied', 'hear_about_us');
            $applicationData['client_id'] = $client->id;
            $applicationData['provider_id'] = $request->nonProfit_id;
            $applicationData['application_date'] = date('Y-m-d');
            $applicationData['alt_id'] = ++$alt_id;

            $repo = self::getInstance('application');
            $application = $repo->saveUpdate($applicationData);
            //Upload attachment
            $fileName = $this->uploadAttachment($request->file());
            $fileTitle = [];
            if ($request->has('photoIdProofTitle'))
                array_push($fileTitle, $request->photoIdProofTitle);

            if ($request->has('anualProofTitle'))
                array_push($fileTitle, $request->anualProofTitle);

            if ($request->has('extraFiles')) {
                foreach ($request->extraFiles as $title)
                    array_push($fileTitle, $title);
            }
            $repo->storeUploadedFilePath($fileName, $application, $fileTitle);

            //Pet Store
            $petData = $request->only('pet_name', 'sex', 'age_type', 'age_of_pet', 'weight', 'species', 'color', 'breed', 'unique_traits', 'where_obtained');
            $petData['client_id'] = $client->id;
            $petData['provider_id'] = $request->nonProfit_id;
            $petData['vet_id'] = $request->vet_id;
            $pet = $this->storePet($petData, $application, $treatments);

            if ($pet instanceof MessageBag)
                return response(['message' => 'the given data was invalid', 'errors' => $pet], 422);
            elseif ($pet instanceof \Exception)
                throw new \Exception($pet);

            //store Progress
            (new ProcessController())->storeNP($application);
            $this->process->changeProcessStatus($application, 'Application Received by Web');
            $this->process->changeProcessStatus($application, 'Application Received');

            if ($request->has('nonProfit_id') && $request->nonProfit_id != '' && $request->nonProfit_id != null)
                $this->process->changeProcessStatus($application, 'Choose Service Provider');
            if ($request->has('vet_id') && $request->vet_id != '' && $request->vet_id != null)
                $this->process->changeProcessStatus($application, 'Choose Veterinarian');;
            DB::commit();

            Notification::newApplicationCreation($application);
            (new ApplicationTreatmentController())->changeTreatmentProcess($application);
            return $this->response("Application added Successfully", ['app_id' => $application->id], 200);
        } catch (\Exception $e) {
            DB::rollBack();
            throw $e;
            return $this->response("Application Can't submitted", 'error', 422);
        }

    }

    /**
     * @param $petData
     * @param $application
     * @return \Exception
     */
    public function storePet($petData, $application, $treatments)
    {
        if (auth()->user()->role_id == 4):
            $provider = auth()->user()->organization()->id;
        else:
            $provider = $petData['provider_id'];
        endif;

        $vetId = null;
        if (array_key_exists('vet_id', $petData)) {
            $vetId = $petData['vet_id'];
            unset($petData['vet_id']);
        }

        unset($petData['provider_id']);

        $count = 0;
        $pets = array();
        foreach ($petData as $key => $value) {
            if (is_array($value))
                $removedElementArr = $this->removeNullValue($value);
            for ($i = 0; $i < count($removedElementArr); $i++) {
                if (!(array_key_exists($i, $pets)))
                    $pets[$i] = array();
                $pets[$i][$key] = $removedElementArr[$i];
            }
        }

        try {
            if (count($pets) == 0)
                return $this->checkValidation($pets);

            $ct = 0;
            foreach ($pets as $p) {
                $p['client_id'] = $petData['client_id'];

                $validation = $this->checkValidation($p);

                if ($validation == 'true') {
                    $pet = $this->np_store(new PetRequest($p), true);
                    if ($pet) {
                        $application->pets()->attach($pet->id, ['provider_id' => $provider, 'created_at' => date('Y-m-d H:i:s')]);

                        if (!is_null($vetId)) {
                            if ($treatments[$ct]):
                                foreach ($treatments[$ct] as $treatment):
                                    ApplicationPetTreatments::insert([
                                        'application_id' => $application->id,
                                        'treatment_id' => $treatment,
                                        'pet_id' => $pet->id,
                                        'vet_id' => $vetId,
                                        'userc_id' => Auth::id(),
                                        'created_at' => date('Y-m-d H:i:s')
                                    ]);
                                endforeach;
                            else:
                                ApplicationPetTreatments::insert([
                                    'application_id' => $application->id,
                                    'pet_id' => $pet->id,
                                    'vet_id' => $vetId,
                                    'userc_id' => Auth::id(),
                                    'created_at' => date('Y-m-d H:i:s')
                                ]);
                            endif;
                        }

                    } else
                        throw new \Exception("something went wrong");
                } else {
                    return $validation;
                }
                $ct++;
            }
        } catch (\Exception $e) {
            return $e;
        }
    }

    public function np_store(PetRequest $request, $returnapplication = false)
    {
        //getting Pet Related Data
        $pet = $this->checkIfExist($request);
        if (!$pet) {
            $petdata = $request->all();
            $petdata['alt_id'] = $this->getAltId();
            $pet = self::getInstance('Pet')->saveUpdate($petdata);
        }
        if ($returnapplication) {
            return $pet;
        }
        if ($pet) {
            return $this->response("Pet Added SuccessFully", "view", 200);
        } else {
            return $this->response("Can't Add Pet", 'view', 422);
        }
    }

    private function checkIfExist($request)
    {
        $pet = Pet::where('client_id', $request->client_id)
            ->where('pet_name', $request->pet_name)
            ->where('species', $request->species)
            ->where('sex', $request->sex)
            ->where('breed', $request->breed)
            ->first();
        return $pet;
    }

    public function checkValidation($p)
    {
        $petRequest = new Request($p);
        $petRequest->setMethod('POST');

        $validator = Validator::make($petRequest->all(), validation_value('pet_form'));

        if ($validator->fails()) {
            return $validator->errors();
        } else {
            return "true";
        }
    }

    public function removeNullValue($data)
    {
        return array_values(array_filter($data, function ($value) {
            return $value !== null;
        }));
    }

    private function getAltId()
    {
        if ($oldapp = Pet::latest()->first()) {
            $alt_id = isset($oldapp->alt_id) ? $oldapp->alt_id : getSiteSettings('pet_alt_id');
        } else if ($id = getSiteSettings('pet_alt_id')) {
            $alt_id = $id;
        } else {
            $alt_id = 2000;
        }
        return ++$alt_id;
    }

    public function uploadAttachment($file)
    {
        $fileName = array();

        if (array_key_exists('photoIdProof', $file)):
            $fname = FileUploader::upload($file['photoIdProof']);
            array_push($fileName, $fname);
        endif;

        if (array_key_exists('anualProof', $file)):
            $fname = FileUploader::upload($file['anualProof']);
            array_push($fileName, $fname);
        endif;
        if (array_key_exists('addinationalPhotos', $file)) {
            foreach ($file['addinationalPhotos'] as $f) {
                $fname = FileUploader::upload($f);
                array_push($fileName, $fname);
            }
        }
        return $fileName;
    }

    public function getNonProfit(Request $request)
    {
        $nonProfit = Organization::where('type', 'Non Profit')
            ->where('is_deleted', false)
            ->where('is_approved', 1)
            ->where('cname', 'like', "%$request->cname%")
            ->get();
        return view($this->layout . '.pages.application.modal.loadNP', compact('nonProfit'));
    }
}
