<?php

namespace App\Http\Controllers\Organization;

use App\Models\OrganizationProcess;

use App\Http\Controllers\BaseController;
use App\Models\Organization;
use DB;

class OrganizationProcessController extends BaseController
{
    public function store(Organization $organization)
    {
        $file = config('organizationProcess');
        $data = array();
        foreach ($file as $process) {
            $process['organization_id'] = $organization->id;
            if (!array_key_exists('step_type', $process))
                $process['step_type'] = null;
            $process['created_at'] = date('Y-m-d H:i:s');
            array_push($data, $process);
        }
        OrganizationProcess::insert($data);
    }

    public function changeProcessStatus($organization, $process)
    {
        $process = OrganizationProcess::where('progress_name', $process)->where('organization_id', $organization->id)->first();
        if ($process):
            $process->status = 1;
            $process->progress_date = date('Y-m-d');
            $process->save();
        endif;
    }

    public function trackProcess($id)
    {
        $data = DB::table('organization_processes')
            ->select(DB::raw('count(step) as finished_step'), 'step')
            ->where([
                ['organization_id', $id],
                ['status', 1],
            ])
            ->groupBy('step')
            ->orderBy('step', 'desc')
            ->limit(1)
            ->get();
        return $data[0];
    }
}
