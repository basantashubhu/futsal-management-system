<?php
/**
 * DEVELOPERS
 * ----------------------------------------------
 * SUMAN  THAPA - LEAD  (NEPALNME@GMAIL.COM)
 * ----------------------------------------------
 * - BASANTA TAJPURIYA
 * - RAKESH SHRESTHA
 * - LEKH RAJ RAI 
 * -----------------------------------------------
 * Created On: 08/02/2019
 *
 * THIS INTELLECTUAL PROPERTY IS COPYRIGHT Ⓒ 2019
 * ZEUSLOGIC, INC. ALL RIGHT RESERVED
 */

namespace App\Http\Controllers\Organization;


use App\Http\Controllers\BaseController;
use App\Http\Requests\OrganizationRequest;
use App\Lib\Exporter\CSVExporter;
use App\Lib\Exporter\JSONExporter;
use App\Lib\Exporter\PDFExporter;
use App\Lib\Exporter\TxtExporter;
use App\Models\Organization;
use App\Repo\AddressRepo;
use App\Repo\ContactRepo;
use App\Repo\OrganizationRepo;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Client;
use App\Models\Role;
use App\Http\Controllers\Client\ClientController;
use App\Http\Requests\ClientRequest;
use App\Lib\File\FileUploader;
use App\Models\Terms;
use App\Models\RatePlan;
use App\Models\Options;
use App\Models\Settings\Lookups;
use App\Lib\Email\EmailSender;
use Illuminate\Support\MessageBag;
use App\Models\Contact;
use App\Models\EmailTemplate;
use App\Models\User;

class OrganizationController extends BaseController
{
    private static $repo = null;
    private $clayout = "";
    private $process;
    private $mail;

    public function __construct()
    {
        parent::__construct();
        $this->clayout = $this->layout . '.pages.organization.';
        $this->process = new OrganizationProcessController();
        $this->mail = new EmailSender('Organization');
    }

    /**
     * @param $model
     * @return OrganizationRepo|null
     */
    private static function getInstance($model)
    {
        self::$repo = new OrganizationRepo($model);
        return self::$repo;
    }

    //get all organization
    public function getOrganizations()
    {
        $organizations = self::getInstance('Organization')->select();
        return $this->responseLookup($organizations, ["cname"]);
    }

    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function index()
    {
        $addMode = siteSettingsValue('provider_add_mode');
        $status = Lookups::where('code', 'application_status')->where('is_deleted', false)->get();
        return view($this->layout . '.pages.np.dashboard.index', compact('status', 'addMode'));
    }

    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function addNpPage()
    {
        $addMode = siteSettingsValue('provider_add_mode');
        $status = Lookups::where('code', 'application_status')->where('is_deleted', false)->get();
        $PrimaryPlans = RatePlan::where('is_deleted', false)->where('is_active', true)->where('is_custom', false)->first();
        $term = EmailTemplate::where("temp_type", 'Terms')->where('is_deleted', false)->where('is_active', true)->first();
        $options = Lookups::where('code', 'np_terms')->where('is_deleted', false)->get();
        return view($this->layout . '.pages.np.addFormPage.index', compact('status', 'addMode', 'PrimaryPlans', 'term', 'options'));
    }

    public function getOrganizationValidation(OrganizationRequest $request)
    {
    }

    public function getVetValidation(Request $request)
    {
        $valid = array();
        $data = $request->only('fname', 'lname', 'personal_email', 'cell_phone', 'vet_lic');
        foreach ($data as $key => $value):
            foreach ($value as $k => $v) {
                if ($v == ""):
                    $valid[$key . '_multi'] = 'required';
                endif;
            }
        endforeach;
        $valid = ['errors' => $valid];
        return response($valid, 422);
    }

    public function addNewVet($id = 1)
    {
        return view($this->layout . '.pages.np.aggreement.modal.includes.new_vet', compact('id'));
    }

    public function getType($choice)
    {
        $type = '';
        switch ($choice):
            case 'NP':
                $type = "Non Profit";
                break;
            case 'SP':
                $type = "Service Provider";
                break;
            default:
                $type = 'Organization';
        endswitch;
        return $type;
    }

    /**
     * Create Form
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function create(Request $request)
    {
        $title = $this->getType($request->type);
        return view($this->clayout . 'modal.add', compact('title'));
    }

    /**
     * @param Organization $organization
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function edit(Organization $organization)
    {
        return view($this->clayout . 'modal.edit', compact('organization'));
    }


    public function addClient($organizationId)
    {
        return view($this->layout . '.pages.client.modal.add', compact('organizationId'));
    }

    /**
     * @param Request $request
     * @return mixed
     */
    public function getAll(Request $request)
    {
        $data = self::getInstance('Organization')->selectDataTable($request);
        return $data;
    }

    /**
     * @param OrganizationRequest $request
     * @return $this|\Illuminate\Http\JsonResponse
     */
    public function store(OrganizationRequest $request)
    {


        $organizations = $request->all();

        DB::beginTransaction();
        try {

            $contactField = ['phone', 'cell_phone', 'alt_phone', 'fax', 'personal_email', 'company_email', 'url'];
            $addressField = ['add1', 'add2', 'zip', 'city', 'state', 'county'];

            //seprate data of client contact and address
            $data = $this->getOrganizationField($organizations, $contactField, $addressField);

            //getData
            $organization = self::getInstance('Organization')->saveUpdate($data['data']);

            //add contact
            (new ContactRepo())->storeContact($data['contact'], $organization);

            //addAddress
            (new AddressRepo())->storeAddress($data['address'], $organization);

            DB::commit();

            return $this->response("Organization Added SuccessFully", "view", 200);
        } catch (\Exception $e) {
            DB::rollBack();
            return $this->response("Can't Add Organization", 'view', 422);
        }
    }

    /**
     * @param $data
     * @param $contactField
     * @param $addressField
     * @return array
     */
    public function getOrganizationField($data, $contactField, $addressField)
    {
        $contact = array();
        $address = array();
        foreach ($contactField as $f) {
            if (isset($data[$f]) && !is_null($data[$f])):
                $contact[$f] = $data[$f];
            endif;
            unset($data[$f]);
        }

        foreach ($addressField as $f) {
            if (isset($data[$f]) && !is_null($data[$f])):
                $address[$f] = $data[$f];
            endif;
            unset($data[$f]);
        }
        return ['data' => $data, 'contact' => $contact, 'address' => $address];

    }

    /*
     *
     */
    public function update(OrganizationRequest $request, Organization $organization)
    {
        $organizations = $request->all();

        DB::beginTransaction();
        try {

            $contactField = ['phone', 'cell_phone', 'alt_phone', 'fax', 'personal_email', 'company_email', 'url'];
            $addressField = ['add1', 'add2', 'zip', 'city', 'state', 'county'];

            //seprate data of client contact and address
            $data = $this->getOrganizationField($organizations, $contactField, $addressField);

            //getData
            $organization = self::getInstance($organization)->saveUpdate($data['data']);

            //add contact
            (new ContactRepo())->updateContact($data['contact'], $organization);

            //addAddress
            (new AddressRepo())->updateAddress($data['address'], $organization);

            DB::commit();

            return $this->response("Organization Updated SuccessFully", "view", 200);
        } catch (\Exception $e) {
            DB::rollBack();
            return $this->response("Can't Update Organization", 'view', 422);
        }
    }


    public function delete(Organization $organization)
    {
        return view($this->clayout . 'modal.delete', compact('organization'));
    }


    public function destroy(Organization $organization)
    {
        DB::beginTransaction();
        $res = false;
        $res = self::getInstance($organization)->softDelete();

        $allOrgPerson = Client::where('org_id', $organization->id)->get();

        foreach ($allOrgPerson as $clients) {
            $res = self::getInstance($clients)->softDelete();
            $user = $clients->user;
            if ($user)
                self::getInstance($user)->softDelete();
        }

        if ($res) {
            DB::commit();
            return $this->response("Organization deleted successFully", "view", 200);
        } else {
            DB::rollBack();
            return $this->response("Can't delete organization", 'view', 422);
        }

    }

    public function provider()
    {
        return view('default.pages.provider.index');
    }

    public function RatePlans(Organization $organization)
    {
        return view($this->clayout . 'modal.changerateplan', compact('organization'));
    }

    public function ChangeRatePlans(Request $request, Organization $organization)
    {
        if ($request->has('active')) {
            $organization->plan_id = $request->active;
            $organization->save();
            if ($organization)
                return $this->response("Rate Plan changed succesfully", $organization->plan_id, 200);
            else
                return $this->response("Rate Plan could not be changed", 'view', 422);
        }
        return $this->response("Please Select a Rate Plan First", 'view', 422);
    }


    public function single(Organization $organization)
    {
        if ($organization->is_approved == 0) {
            $organization->is_approved = 2;
            $organization->save();
            $this->process->changeProcessStatus($organization, 'status Changed to Review');
            $data['id'] = $organization->id;
            $this->mail->sendEmail('orgStatusReview', $organization->getMailAddress(), $data, 'Email Notification to Applicant', '', 'organization');
        }
        $representative = Client::where('org_id', $organization->id)->first();
        if ($organization->agreement):
            $options = Options::where('table', 'terms')->where('table_id', $organization->agreement->id)->get();
        endif;
        if ($organization->type == 'Non Profit'):
            $value = 'np_terms';
        else:
            $value = 'sp_terms';
        endif;
        $process = $organization->getProcess();
        $step = $this->process->trackProcess($organization->id);
        $comments=OrganizationCommentController::getAllComment($organization->id);
        $terms = Lookups::where('code', $value)->where('is_deleted', false)->get();
        return view($this->clayout . 'single.single_page', compact('organization', 'step', 'representative', 'options', 'terms', 'process','comments'));
    }

    public function getRepresentetive(Organization $organization)
    {
        $representative = Client::where('org_id', $organization->id)->first();
        return view($this->clayout . 'single.section.representative', compact('organization', 'representative'));
    }

    public function getAllVet(Request $request, Organization $organization)
    {
        $data = self::getInstance('Organization')->getVetByOrg($request, $organization->id);
        return $data;
    }

    public function approval(Organization $organization)
    {
        return view($this->clayout . 'modal.approval', compact('organization'));
    }

    public function disApproval(Organization $organization)
    {
        return view($this->clayout . 'modal.disapproval', compact('organization'));
    }

    public function approvedOrg(Request $request, Organization $organization)
    {
        DB::beginTransaction();
        try {
            $oldData = $organization->__toString();
            $organization->is_approved = true;
            $organization->approved_by = auth()->id();
            $organization->save();

            $newData = $organization->__toString();
            self::getInstance($organization)->audit($organization->id, $oldData, $newData, auth()->check() ? auth()->id() : 0);

            //Approval Process
            $this->approvalProcess($organization);

            DB::commit();
            return $this->response("Organization approved successFully", $organization->is_approved, 200);
        } catch (\Exception $e) {
            DB::rollBack();
            throw $e;
            return $this->response("Can't approved organization", 'view', 500);
        }

    }

    public function makeActive($from, Organization $organization)
    {
        return view($this->clayout . 'modal.makeActive', compact('organization', 'from'));
    }

    public function activeOrg(Request $request, Organization $organization)
    {

        $oldData = $organization->__toString();
        if($organization->is_active):
            $organization->is_active = false;
        else:
            $organization->is_active = true;
        endif;
        $organization->save();
        $newData = $organization->__toString();
        self::getInstance($organization)->audit($organization->id, $oldData, $newData, auth()->check() ? auth()->id() : 0);

        if ($organization)
            return $this->response("Organization Activation Status Change", $organization->id, 200);
        else
            return $this->response("Failed To Disapproved Application", 'view', 422);
    }

    public function disApprovedOrg(Request $request, Organization $organization)
    {

        $oldData = $organization->__toString();
        $organization->is_approved = 3;
        $organization->approved_by = auth()->id();
        $organization->comments = $request->comment;
        $organization->save();
        $newData = $organization->__toString();
        self::getInstance($organization)->audit($organization->id, $oldData, $newData, auth()->check() ? auth()->id() : 0);
        //Approval Process
        $this->disApprovalProcess($organization);

        if ($organization)
            return $this->response("Organization Application disapproved", $organization->is_approved, 200);
        else
            return $this->response("Failed To Disapproved Application", 'view', 422);
    }

    public function denailReason(Organization $organization)
    {
        return view($this->clayout . 'modal.denailReason', compact('organization'));
    }

    private function approvalProcess($organization, $file = true)
    {
        $this->process->changeProcessStatus($organization, 'Approval');
        if ($file):
            $details = $this->getUserDetails($organization->id);
            if ($details) {
                $data = [[
                    'id' => $organization->id,
                    'user_name' => $details['username'],
                    'password' => $details['password'],
                    'name' => $organization->cname
                ]];
            } else {
                $data = [['id' => $organization->id]];
            }
            //$data = [['id' => $organization->id,'']];
            $this->generateLetter($data, 'Organization Approval Letter', $organization, 'organization_disapproval');
            $this->process->changeProcessStatus($organization, 'Approval Letter Generated');
            $this->note($organization, 'Organization Approved letter Generated', 'Organization');
            //send mail to applicant

            $data = [];

            // $details = $this->getUserDetails($organization->id);
            if ($details) {
                $data = [
                    'id' => $organization->id,
                    'user_name' => $details['username'],
                    'password' => $details['password'],
                    'name'=>$organization->cname
                ];
            } else {
                $data = ['id' => $organization->id];
            }
            $this->mail->sendEmail('orgApproved', $organization->getMailAddress(), $data, 'Approval Letter Email Notice to Applicant', '', 'organization');
            $this->note($organization, 'Approval Letter Email Notice to Applicant');
        endif;
    }

    //get user details for organization
    private function getUserDetails($id)
    {
        if ($client = Client::where('org_id', $id)->first()):
            if ($user = $client->user) {
                $password = random_string(10);
                $user->password = bcrypt($password);
                $user->save();
                $data['username'] = $user->name;
                $data['password'] = $password;
                return $data;
            } else {

                return false;
            }
        else:
            return false;
        endif;

    }

    private function disApprovalProcess($organization)
    {
        $this->process->changeProcessStatus($organization, 'Denial');
        $data = [['id' => $organization->id]];
        $this->generateLetter($data, 'Organization Denial Letter', $organization, 'organization_approval');
        $this->process->changeProcessStatus($organization, 'Denial Letter Generated');
        $this->note($organization, 'Denial Letter Generated', 'Organization');

        //send mail to applicant
        $data = [];
        $data = [['id' => $organization->id]];
        $this->mail->sendEmail('orgDisApproved', $organization->getMailAddress(), $data, 'Denial Letter Email Notification', '', 'organization');
        $this->note($organization, 'Denial Letter Email Notification');
    }

    protected function generateLetter($data, $letterName, $model, $documentSegment, $isCert = false)
    {
        $path = $this->generateFile($data, $letterName);
        $type = $isCert ? 'certificate' : 'letter';
        self::getInstance($model)->storeUploadedFilePath([$path], $model, $letterName, $documentSegment, $type);
    }

    /**
     * @param Request $request
     * @return $this|\Illuminate\Http\JsonResponse
     * @throws \Exception
     */
    public function insertData(Request $request, $returnimporter = false, $approved = false)
    {
        DB::beginTransaction();
        try {
            $rate_plan = RatePlan::where('is_active', true)->where('is_custom', 0)->first();
            $type = '';
            switch ($request->type):
                case 'NP':
                    $type = "Non Profit";
                    break;
                case 'SP':
                    $type = "Service Provider";
                    break;
                default:
                    $type = 'Service Provider';
            endswitch;
            $organizations = $request->only('cname', 'lic_no', 'is_sp','invoice_code', 'phone', 'company_email', 'fax', 'add1', 'add2', 'zip', 'city', 'state', 'external_id');

            $organizations['type'] = $type;
            $organizations['agreement_status'] = false;
            $organizations['is_approved'] = $approved;
            $organizations['plan_id'] = $request->has('plan_id')?$request->plan_id:$rate_plan->id;
            $contactField = ['phone', 'company_email', 'fax'];
            $addressField = ['add1', 'add2', 'zip', 'state', 'city'];

            //separate data of organization contact and address
            $data = $this->getOrganizationField($organizations, $contactField, $addressField);

            //getData
            $organization = self::getInstance('Organization')->saveUpdate($data['data']);

            //add contact
            (new ContactRepo())->storeContact($data['contact'], $organization);
            //add address
            (new AddressRepo())->storeAddress($data['address'], $organization);

            if ($request->exists('org_fname')):
                $clientData = $request->only('org_title', 'org_fname', 'org_mname', 'org_lname', 'phone', 'company_email', 'add1', 'add2', 'zip', 'city', 'state');
                $client['title'] = $clientData['org_title'];
                $client['fname'] = $clientData['org_fname'];
                $client['mname'] = $clientData['org_mname'];
                $client['lname'] = $clientData['org_lname'];
                $client['phone'] = $clientData['phone'];
                $client['company_email'] = $clientData['company_email'];
                $client['add1'] = $clientData['add1'];
                $client['add2'] = $clientData['add2'];
                $client['zip'] = $clientData['zip'];
                $client['city'] = $clientData['city'];
                $client['state'] = $clientData['state'];
                $client['org_id'] = $organization->id;

                if ($request->type == 'NP')
                    $client['role_name'] = 'non_profit';
                elseif ($request->type == 'SP')
                    $client['role_name'] = 'serviceProvider';

                $c = new ClientRequest($client);
                $clientStore = (new ClientController())->store($c, true);
                if (!$clientStore instanceof Client)
                    throw new \Exception("Error");
            endif;


            $repo = self::getInstance('Organization');

            //Upload attachment
            $fileName = $this->uploadAttachment($request->file());
            $fileTitle = [$request->photoIdProofTitle, $request->anualProofTitle];
            if ($request->has('extraFiles')) {
                foreach ($request->extraFiles as $title)
                    array_push($fileTitle, $title);
            }
            $repo->storeUploadedFilePath($fileName, $organization, $fileTitle);

            if ($request->exists('terms_title')):
                $terms = $request->only('code', 'terms_title', 'terms_type', 'instruction', 'description', 'client_signature', 'client_signed_by');
                $term = new Terms;
                $term->table = 'organization';
                $term->table_id = $organization->id;
                $term->code = $terms['code'];
                $term->terms_type = $terms['terms_type'];
                $term->terms_title = $terms['terms_title'];
                $term->description = $terms['description'];
                $term->instruction = $terms['instruction'];
                $term->client_signature = $terms['client_signature'];
                $term->client_signed_by = $terms['client_signed_by'];
                $term->client_signed_title = $terms['client_signed_by'];
                $term->client_signature_date = date('Y-m-d');
                $term->save();
            else:

            endif;
            $demos = Lookups::where('code', 'np_terms')->get();
            foreach ($demos as $demo):
                $options = $request->only($demo->value);


                foreach ($options as $key => $value):
                    $option = new Options;
                    $option->table = 'terms';
                    $option->table_id = $term->id;
                    $option->field_name = $key;
                    $option->is_checked = $value;

                    $description = $request->only($key . '_description');
                    foreach ($description as $k => $v) {
                        $option->description = $v;
                    }
                    $option->save();
                endforeach;
            endforeach;
            $this->process->store($organization);
            $this->process->changeProcessStatus($organization, 'Application Received');
            if ($organization->is_approved) {
                $this->process->changeProcessStatus($organization, 'status Changed to Review');
                $this->approvalProcess($organization, false);
            }
            DB::commit();

            if ($returnimporter) {
                return $organization;
            }

            return $this->response("Organization is added succesfully", ['org_id' => $organization->id], "200");
        } catch (\Exception $e) {
            DB::rollBack();
            throw $e;
            return $this->response("Organization can't be added", "view", "422");
        }
    }

    /**
     * @param $file
     * @return array
     */
    public function uploadAttachment($file)
    {
        $fileName = array();
        if (array_key_exists('photoIdProof', $file)) {
            $fname = FileUploader::upload($file['photoIdProof']);
            array_push($fileName, $fname);
        }
        if (array_key_exists('addinationalPhotos', $file)) {
            foreach ($file['addinationalPhotos'] as $f) {
                $fname = FileUploader::upload($f);
                array_push($fileName, $fname);
            }
        }
        return $fileName;
    }

    /**
     * @param $array
     * @param $index
     * @return array
     */
    protected function seperateArray($array, $index)
    {
        $pet = array();
        foreach ($array as $key => $value) {
            $pet[$key] = $value[$index];
        }
        return $pet;
    }

    protected function getRole($role)
    {
        return Role::first()->id;
    }

    public function approveNP()
    {
        return view('default.pages.sandbox.np.modal.approval');
    }

    public function disApproveNP()
    {
        return view('default.pages.sandbox.np.modal.disapprove');
    }

    public function np_edit(Organization $organization)
    {
        return view('default.pages.organization.modal.edit', compact('organization'));
    }

    public function addRates()
    {
        return view('default.pages.sandbox.np.modal.addRates');
    }

    public function rate_view()
    {
        return view('default.pages.sandbox.np.modal.rate_view');
    }

    public function rate_edit()
    {
        return view('default.pages.sandbox.np.modal.rate_edit');
    }


    public function searchVet(Request $request)
    {
        $organization = Organization::find($request->provider_id);
        return $organization->vet;
    }

    /**
     * Service Provider
     */
    public function addSp()
    {
        return view('default.pages.sp.application.add');
    }

    //for chart data
    public function getChartData()
    {
        $data = array();
        $required = ['Service Provider', 'Non Profit', 'Rescue'];
        foreach ($required as $r) {
            $newarray = array();
            $new = Organization::where('type', $r);
            $newarray['label'] = $r;
            $newarray['value'] = $new->count();
            array_push($data, $newarray);
        }
        return $data;
    }

    public function emailCheck(Request $request)
    {
        $email = $request->email;
        if ($user = User::where('email', $email)->first()):
            return $user->client->organization;
        else:
            return 'false';
        endif;
    }

    public function orgInfo(Organization $organization)
    {
        return view('default.pages.np.aggreement.modal.includes.orgInfo', compact('organization'));
    }

    public function GetExports(Request $request, $type)
    {
        if($request->singleStatus == '0'):
            $status = 'Pending';
        elseif($request->singleStatus == '1'):
            $status = 'Approved';
        elseif($request->singleStatus == '2'):
            $status = 'Review';
        elseif($request->singleStatus == '3'):
            $status = 'Denial';
        else:
            $status = 'All';
        endif;
        $data = self::getInstance('Organization')->getExportData($request);
        $fields = array('Provider Name', 'Type', 'License Number', 'Email Address', 'Phone Number', 'Address', 'City', 'State', 'Zip');
        $mapField = array('cname', 'type', 'lic_no', 'company_email', 'phone', 'add1', 'city', 'state', 'zip_code');
        $data = cleaner($mapField, $data);
        $data['request'] = ['Provider Name' => $request->name, 'Status' => $status, 'Phone Number' => $request->ownerphone, 'City' => $request->city, 'Zip' => $request->zipCode];
        $data['table'] = 'Showing Results of Providers Table';
        if (count($data) > 0) {
            $export = $this->reportFactory($type, $fields, $data);
            $exporter = new \App\Lib\Exporter\Exporter($export);
            $filename = $exporter->export();
            return response()->download($filename)->deleteFileAfterSend(true);
        }
        return 'No Data Available For Current Filter';
    }


    /**
     * Create A object for print
     * @param $type
     * @param $data
     * @return CSVExporter|JSONExporter|PDFExporter|TxtExporter
     * @throws \Exception
     */
    public function reportFactory($type, $fields, $data)
    {
        switch ($type) {
            case 'csv':
                return new CSVExporter($data, array_keys((array)$data[0]), 'OrganizationReports');
                break;
            case 'json':
                return new JSONExporter($data);
                break;
            case 'txt':
                return new TxtExporter($data);
                break;
            case 'pdf':
                return new PDFExporter($data, $fields, 'applicationpdf');
                break;
            default:
                throw new \Exception("Method Not Allowed " . $type);
                break;
        }
    }

    /*
        Upload File
    */
    public function uploadFile(Organization $organization)
    {
        $types = Lookups::where('code', 'document_type')->get();
        return view($this->layout . '.pages.organization.modal.uploadFile', compact('organization', 'types'));
    }

    /*
    Store file
    */

    public function storeFile(Request $request, Organization $organization)
    {
        try {
            $file = array();
            $fileName = $this->uploadAttachmentSingle($request->file());
            $repo = self::getInstance('Organization');
            array_push($file, $fileName);
            $fileTitle = $request->anualProofTitle;
            $res = $repo->storeUploadedFilePath($file, $organization, $fileTitle, 'upload', $request->document_type);
            return $this->response("File Uploaded SuccessFully", $fileName, 200);
        } catch (\Exception $e) {
            return $this->response("File couldnt be uploaded", "view", 500);
        }
    }

    /**
     * @param $file
     * @return string
     */
    public function uploadAttachmentSingle($file)
    {
        $fname = FileUploader::upload($file['photoIdProof']);
        return $fname;
    }
    public function getOrgAll()
    {
        $orgs = self::getInstance('Organization')->select();
        return $this->responseLookup($orgs, ["cname"]);
    }

}