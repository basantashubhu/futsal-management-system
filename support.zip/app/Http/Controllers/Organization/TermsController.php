<?php

namespace App\Http\Controllers\Organization;

use Illuminate\Http\Request;
use App\Http\Controllers\BaseController;
use App\Repo\TermsRepo;
use App\Http\Requests\AgreementRequest;
use App\Models\EmailTemplate;
use App\Models\Terms;
use App\Models\Organization;
use App\Models\Contact;
use App\Models\Address;

class TermsController extends BaseController
{
	private static $repo = null;
	private $clayout = "";

	public function __construct()
	{
		parent::__construct();
		$this->clayout = $this->layout . '.pages.terms';
	}
	public function getInstance($model)
	{
		if(self::$repo == null)
			self::$repo = new TermsRepo($model);
		return self::$repo;
	}
	public function create()
	{
		$temp = EmailTemplate::where('temp_type', 'Terms')->where('is_deleted', false)->first();
		return view($this->clayout.'.index', compact('temp'));
	}
	public function store(Request $request)
	{
		$org = new Organization;
		$orgs = $request->only('organization-data')['organization-data'][0];
		foreach ($orgs as $key => $value) {
			$org->$key = $value;
		}
		$org->type = "Non Profit";
		$org->agreement_status = false;
		$org->is_approved = false;
		$org->userid = auth()->id();
		$org->save();

		$contact = new Contact;
		$contact->org_id = $org->id;
		$contacts = $request->only('organization-data-contact')['organization-data-contact'][0];
		foreach($contacts as $key=>$val){
			$contact->$key = $value;
		}
		$contact->save();

		$address = new address;
		$address->org_id = $org->id;
		$address->zip_id = '1';
		$addresss = $request->only('organization-data-address')['organization-data-address'][0];
		foreach($addresss as $key=>$val){
			$address->$key = $value;
		}
		$address->save();

		$terms = new Terms;
		$terms['table'] = 'organization';
		$terms['table_id'] = $org->id;
		$terms['terms_type'] = 'Agreement';
		$terms['terms_title'] = 'Agreement';
		$data = $request->only('terms-data');
			foreach ($data as $d){
				foreach($d as $k){
					foreach($k as $key=>$val){
						$terms->$key = $val;
					}
				}
			}
		$terms->save();

		if($terms):
			return $this->response("Terms Added", "view", 200);
		else:
			return $this->response("Cant Add Terms", "view", 422);
		endif;
	}
	public function selectTerm($id)
	{
		$term = Terms::find($id);
		$org = Organization::where('id', $term->table_id)->first();
		return view($this->clayout.'.modal.org_terms', compact('term', 'org'));
	}
	public function updateTerms(Request $request, $id)
	{
		$term = Terms::find($id);
		$term->signed_by = $request->signed_by;
		$term->signed_title = $request->signed_title;
		$term->signature = $request->signature;
		$term->signature_date = $request->signature_date;
		$term->save();
		if($terms):
			return $this->response("Terms Update", "view", 200);
		else:
			return $this->response("Cant update Terms", "view", 422);
		endif;

	}
}
