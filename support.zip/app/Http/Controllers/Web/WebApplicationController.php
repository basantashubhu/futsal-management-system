<?php

namespace App\Http\Controllers\Web;

use App\Exceptions\ValidationError;
use App\Http\Controllers\Application\ProcessController;
use App\Http\Controllers\Client\ClientController;
use App\Http\Controllers\Pet\PetController;
use App\Http\Requests\ClientRequest;
use App\Http\Requests\PetRequest;
use App\Lib\File\FileUploader;
use App\Models\Application;
use App\Repo\ApplicationRepo;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Validator;

class WebApplicationController extends Controller
{

    private static $repo = null;
    private $process;

    /**
     * ApplicationController constructor.
     */
    public function __construct()
    {
        $this->process = new ProcessController();
    }

    public function index()
    {
        return view('web.pages.application');
    }

    public function store(Request $request)
    {
//        dd($request->all());

        DB::beginTransaction();
        try {
            $error = false;
            $client = $this->storeClient($request);
            $app = $this->makeApplication($request, $client);
            DB::commit();
            session()->flash('ApplicationSent', 'Application  Submitted Successfully');
            return view('web.pages.application', compact('error'));

        } catch (\Exception $e) {
            DB::rollBack();
            throw $e;
            $error = $e;
            session()->flash('ApplicationFailed', 'Failed to submit Applications');
            return view('web.pages.application', compact('error'));
        }
    }


    /**
     * @param $model
     * @return ApplicationRepo|null
     */
    private static function getInstance($model)
    {
        self::$repo = new ApplicationRepo($model);
        return self::$repo;
    }

    protected function storeClient(Request $request)
    {
        $clientData = $request->only('legalName', 'dob', 'add1', 'add2', 'zip', 'state', 'city', 'cell_phone', 'phone_type', 'alt_phone', 'personal_email');

//        $this->validateClient($this->makeRequestObject($clientData));
        $cdata = array_merge($clientData, $this->seperateNames($request->legalName));
        unset($cdata['legalName']);
        $clientData = new ClientRequest($cdata);

        //triggering client Controller to handel client Information
        $client = (new ClientController())->store($clientData, true);
        return $client;
    }


    protected function makeApplication(Request $request, $client)
    {
        if ($oldapp = Application::latest()->first()) {
            $alt_id = isset($oldapp->alt_id) ? $oldapp->alt_id : getSiteSettings('application_alt_id');
        } else {
            $alt_id = 1000;
            if ($id = getSiteSettings('application_alt_id')) {
                $alt_id = $id;
            }
        }
        //getting Application Related Data
        $applicationData = $request->only('is_tanf', 'is_medicaid', 'is_general_assistance', 'is_food_stamp', 'is_wic', 'is_ssi', 'is_ssd', 'is_vad', 'client_id', 'provider_id');
        $applicationData['client_id'] = $client->id;
        $applicationData['alt_id'] = ++$alt_id;
        $applicationData['source'] = 'WebSite';

        $applicationData['application_date'] = date('Y-m-d');

        $repo = self::getInstance('application');
        $application = $repo->saveUpdate($applicationData);

        //Upload attachment
        $fileName = $this->uploadAttachment($request->file());
        $fileTitle = [];
        if ($request->has('photoIdProofTitle'))
            array_push($fileTitle, $request->photoIdProofTitle);

        if ($request->has('anualProofTitle'))
            array_push($fileTitle, $request->anualProofTitle);

        if ($request->has('extraFiles')) {
            foreach ($request->extraFiles as $title)
                array_push($fileTitle, $title);
        }
        $repo->storeUploadedFilePath($fileName, $application, $fileTitle);

        $this->insertPets($request, $client, $application);

        //store Progress
        (new ProcessController())->store($application);
        $this->process->changeProcessStatus($application, 'Application Received by Web');
        $this->process->changeProcessStatus($application, 'Application Received');
        return $application;
    }

    protected function seperateNames($name)
    {
        $namearray = [];
        $names = explode(' ', $name);
        if (count($names) == 3) {
            $namearray['fname'] = $names[0];
            $namearray['mname'] = $names[1];
            $namearray['lname'] = $names[2];
        } else if (count($names) == 2) {
            $namearray['fname'] = $names[0];
            $namearray['mname'] = '';
            $namearray['lname'] = $names[1];
        } else {
            $namearray['fname'] = $names[0];
            $namearray['mname'] = '';
            $namearray['lname'] = '';
        }
        return $namearray;
    }

    protected function makeRequestObject(Array $array)
    {
        $request = new Request($array);
        $request->setMethod('POST');
        return $request;
    }


    /***
     * @param $file
     * @return array
     * @throws \Exception
     */
    public function uploadAttachment($file)
    {
        $fileName = array();

        if (array_key_exists('photoIdProof', $file)):
            $fname = FileUploader::upload($file['photoIdProof']);
            array_push($fileName, $fname);
        endif;

        if (array_key_exists('anualProof', $file)):
            $fname = FileUploader::upload($file['anualProof']);
            array_push($fileName, $fname);
        endif;
        if (array_key_exists('addinationalPhotos', $file)) {
            foreach ($file['addinationalPhotos'] as $f) {
                $fname = FileUploader::upload($f);
                array_push($fileName, $fname);
            }
        }
        return $fileName;
    }


    protected function insertPets(Request $request, $client, $application)
    {
        //Pet Store
        for ($count = 1; $count < 3; $count++):
            $petData = $this->getPet($request, $count);
            if ($petData) {
                $petData['client_id'] = $client->id;
                $petData['weight'] = siteSettingsValue('default_pet_weight') ? siteSettingsValue('default_pet_weight') : 12;
                $pet = (new PetController())->store(new PetRequest($petData), true);
                if ($pet)
                    $application->pets()->attach($pet->id);
            }

        endfor;

    }

    public function getPet(Request $request, $i)
    {
        if ($request->has('pet_name') && $request->has('sex')) {
            $pet = [];
            $fields = ['pet_name', 'sex', 'age_type', 'age_of_pet', 'weight', 'species', 'color', 'breed', 'unique_traits', 'where_obtained'];
            foreach ($fields as $field):
                $name = $field . $i;
                $pet[$field] = $request->$name;
            endforeach;
            return $pet;
        } else {
            return false;
        }

    }

    protected function validateClient(Request $clients)
    {
        $fields = ['fname', 'lname', 'add1', 'city', 'state', 'zip', 'cell_phone', 'personal_email', 'ssn'];
        $validator = \Validator::make($clients->all(), validation_value('client_form'), $this->clientValidateMessage());
        if ($validator->fails()) {
            $code = 101;
            $errors = $validator->errors();
            foreach ($fields as $index => $field) {
                if ($errors->has($field)) {
                    $code = $code + $index;
                    break;
                }
            }
            throw  new \Exception($validator->errors()->all()[0], $code);
        }

    }

    protected function clientValidateMessage()
    {
        return [
            'fname.required' => 'Client first name is required',
            'lname.required' => 'Client last name is required',
            'lname.string' => 'Client last name must be String',
            'fname.string' => 'Client first name must be String',
            'add1.required' => 'Primary address is required',
            'add1.string' => 'Primary address must be String',
            'city.required' => 'City name is required',
            'city.string' => 'City name must be String',
            'state.required' => 'State Name is required',
            'state.string' => 'State Name must be String',
            'zip.required' => 'Zip Code is required',
            'zip.numeric' => 'Zip Code must be Numbers',
            'cell_phone.required' => 'Phone number is required',
            'cell_phone.numeric' => 'Phone number must be Numbers',
            'personal_email.required' => 'Client personal_email  is required',
            'personal_email.email' => 'Client personal_email must be valid',
        ];
    }
}
