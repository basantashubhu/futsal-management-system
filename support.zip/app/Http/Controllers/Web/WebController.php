<?php

namespace App\Http\Controllers\Web;

use App\Models\Settings\ZipCode;
use Illuminate\Http\Request;
use App\Http\Controllers\BaseController;
use Illuminate\Support\Facades\DB;


class WebController extends BaseController
{

    public function index()
    {
        return view('web.master');
    }

    public function home()
    {
        return view('web.pages.index');
    }

    public function application()
    {
        return view('web.pages.application');
    }

    public function about()
    {
        return view('web.pages.about');
    }

    public function partners()
    {
        $zips = ZipCode::pluck('zip_code');
        $providers = DB::table('organization')
            ->join('address', 'address.org_id', 'organization.id')
            ->join('zip_codes', 'address.zip_id', 'zip_codes.id')
            ->join('contacts', 'contacts.org_id', 'organization.id')
            ->select('cname', 'address.add1 as add1', 'zip_codes.state as state', 'zip_codes.city as city', 'zip_codes.zip_code as zip', 'contacts.phone as phone')
            ->offset(0)
            ->limit(10)
            ->get();
        return view('web.pages.partners', compact('zips','providers'));
    }

    public function getPatners(Request $request, $zip)
    {
        $offset = $request->offset?$request->offset:0;
        $limit = $request->limit?$request->limit:10;
        $providers = DB::table('organization')
            ->join('address', 'address.org_id', 'organization.id')
            ->join('zip_codes', 'address.zip_id', 'zip_codes.id')
            ->join('contacts', 'contacts.org_id', 'organization.id')
            ->where('zip_codes.zip_code', $zip)
            ->select('cname', 'address.add1 as add1', 'zip_codes.state as state', 'zip_codes.city as city', 'zip_codes.zip_code as zip', 'contacts.phone as phone')
            ->offset($offset)
            ->limit($limit)
            ->get();
        return view('web.pages.partials.partner', compact('providers'));
    }
}
