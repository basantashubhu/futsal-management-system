<?php
/**
 * DEVELOPERS
 * ----------------------------------------------
 * SUMAN  THAPA - LEAD  (NEPALNME@GMAIL.COM)
 * ----------------------------------------------
 * - BASANTA TAJPURIYA
 * - RAKESH SHRESTHA
 * - LEKH RAJ RAI 
 * -----------------------------------------------
 * Created On: 08/02/2019
 *
 * THIS INTELLECTUAL PROPERTY IS COPYRIGHT Ⓒ 2019
 * ZEUSLOGIC, INC. ALL RIGHT RESERVED
 */

namespace App\Http\Controllers\NonProfit;


use App\Http\Controllers\BaseController;
use App\Http\Requests\OrganizationRequest;
use App\Models\Organization;
use App\Repo\AddressRepo;
use App\Repo\ContactRepo;
use App\Repo\OrganizationRepo;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Contact;
use App\Models\Address;
use App\Models\Settings\ZipCode;
use App\Models\Client;
use App\Models\User;
use App\Models\Role;
use App\Models\RatePlan;
use App\Models\EmailTemplate;
use App\Models\Settings\Lookups;

class NonProfitController extends BaseController
{
    private static $repo = null;
    private $clayout = "";

    public function __construct()
    {
        parent::__construct();
        $this->clayout = $this->layout . '.pages.np.';
    }

    public function addNp(Request $request)
    {
        $type = $request->type;
        $title = $request->type;
        $plans = RatePlan::where('is_deleted', false)->where('is_custom', 0)->get();
        $PrimaryPlans = RatePlan::where('is_deleted', false)->where('is_active', true)->where('is_custom', false)->first();
        $term = EmailTemplate::where("temp_type", 'Terms')->where('is_deleted', false)->where('is_active', true)->first();
        $options = Lookups::where('code', 'np_terms')->where('is_deleted', false)->get();
        return view($this->clayout. 'aggreement.modal.add', compact('PrimaryPlans', 'plans', 'term', 'title', 'options', 'type'));
    }

}