<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class EmailTemplateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return validation_value('email_template_form');
    }
    public function messages()
    {
        return [
            'section.required'=>'Section is required',
            'temp_type.required'=>'Template Type is required',
            'temp_name.required'=>'Template Name is required',
            'temp_html.required'=>'Template Html is required'
        ];
    }
}
