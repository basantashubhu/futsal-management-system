<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Fgp\Timesheet\TimesheetApprovalController;

class TimesheetApprovalSingle implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    protected $periods;
    protected $sites;
    protected $volunteers;
    protected $user;
    public function __construct($periods, $sites, $volunteers, $user)
    {
        $this->periods = $periods;
        $this->sites = $sites;
        $this->volunteers = $volunteers;
        $this->user = $user;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $approval = new TimesheetApprovalController();
        $approval->approveSingle($this->periods, $this->sites, $this->volunteers, $this->user);
    }

    public function send()
    {
        Log::info("Request Cycle with Queues Begins");
        $this->dispatch()->delay(now()->addMinutes(1));
        Log::info("Request Cycle with Queues Ends");
    }
}
