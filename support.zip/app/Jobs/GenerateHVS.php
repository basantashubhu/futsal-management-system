<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use  App\Http\Controllers\Fgp\Finance\FinanceController;
use Illuminate\Support\Facades\Log;

class GenerateHVS implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    protected $id;
    protected $user_id;
    public function __construct($id, $user_id)
    {
        $this->id = $id;
        $this->user_id = $user_id;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $app=new FinanceController();
        $app->runFinanceApproval($this->id, $this->user_id);
    }

    public function send()
    {
        Log::info("Request Cycle with Queues Begins");
        $this->dispatch()->delay(now()->addMinutes(1));
        Log::info("Request Cycle with Queues Ends");
    }
}
