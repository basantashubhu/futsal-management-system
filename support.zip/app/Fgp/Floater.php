<?php

namespace App\Fgp;

use Illuminate\Database\Eloquent\Model;

class Floater extends Model
{
    protected $table = 'floaters';
    protected $guarded = [];
}
