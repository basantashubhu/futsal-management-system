<?php
/**
 * DEVELOPERS
 * ----------------------------------------------
 * SUMAN  THAPA - LEAD  (NEPALNME@GMAIL.COM)
 * ----------------------------------------------
 * - BASANTA TAJPURIYA
 * - RAKESH SHRESTHA
 * - LEKH RAJ RAI 
 * -----------------------------------------------
 * Created On: 08/02/2019
 *
 * THIS INTELLECTUAL PROPERTY IS COPYRIGHT Ⓒ 2019
 * ZEUSLOGIC, INC. ALL RIGHT RESERVED
 */

namespace App\Repo;


use App\Lib\Filter\PaymentFIlter\PaymentFilter;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PaymentRepo extends BaseRepo
{
    public function storeUploadedFilePath($fileName, $res)
    {
        $data = array(
            'table' => 'payment',
            'table_id' => $res->id,
            'document_segment' => 'copay',
            'document_type' => 'copay',
            'document_title' => 'copay',
            'file_name' => $fileName,
            'created_at' => date('Y-m-d H:i:s')
        );

        return \App\File::insert($data);

    }

    public function selectPaymentTable(Request $request, $id)
    {
        $perpage = $request->pagination['perpage'];
        $offset = ($request->pagination['page'] - 1) * $perpage;

        $result = DB::table('payment')
            ->join('applications', function ($join) {
                $join->on('payment.table_id', '=', 'applications.id');
                $join->on('payment.table_name', '=', DB::raw('"applications"'));
            })
            ->leftJoin('invoice_header as invoice', 'invoice.id', 'payment.inv_id')
            ->select('payment.*', 'applications.id as application_number', 'applications.alt_id as alt_id', 'invoice.invoice_number')
            ->where('table_id', $id)
            ->where('payment.is_deleted', false);

        $totalResult = count($result->get());

        if (isset($request->sort['field']))
            $result = $result->orderBy($request->sort['field'], $request->sort['sort']);
        if (!is_null($perpage))
            $result = $result->limit($perpage)->offset($offset);

        $result = $result->get();


        $data = [
            'meta' => [
                'page' => (int)$request->pagination['page'],
                'pages' => ceil($totalResult / $perpage),
                'perpage' => (int)$perpage,
                'total' => (int)$totalResult,
                'sort' => $request->sort['sort'],
                'field' => $request->sort['field']
            ],
            'data' => $result
        ];
        return $data;
    }

    public function selectDataTable(Request $request)
    {
        $perpage = $request->pagination['perpage'];
        $offset = ($request->pagination['page'] - 1) * $perpage;
        $role = auth()->user()->role;

        $result = DB::table('payment')
                ->join('applications', function ($join) {
                $join->on('payment.table_id', '=', 'applications.id');
                $join->on('payment.table_name', '=', DB::raw('"applications"'));
            })
            ->leftJoin('invoice_line_item as item','payment.inv_id','item.inv_id')
            ->leftJoin('organization','item.provider_id','organization.id')
            ->select('payment.*', 'applications.id as application_number', 'applications.alt_id as alt_id','organization.cname',

            DB::raw('(select batch_no from invoice_batch where invoice_ids in (payment.inv_id)) as batch_id'),
            DB::raw('(select invoice_number from invoice_header where id in (payment.inv_id)) as invoice_no')
            )
            ->groupBy('payment.id');

        /*----Applying filter--------*/
        $filter=new PaymentFilter($request);

        if(isset($_COOKIE['payment']) || isset($_COOKIE['payment_quick']))
        {
            $advData=isset($_COOKIE['payment'])?json_decode($_COOKIE['payment']):[];
            $openData=isset($_COOKIE['payment_quick'])?json_decode($_COOKIE['payment_quick']):[];
            $mergeData=array_merge($advData,$openData);
            $result=$filter->getQueryCookie($result,$mergeData);
            // dd($mergeData);
        }else{
            $r = $request->all();
            if(!array_key_exists('query', $r) || (array_key_exists('query', $r) && $r['query']==null))
            {
                $start = date("Y-01-01");
                $end = date("Y-12-31");
                $result = $result->whereBetween('trans_date', [$start, $end])->whereIn('trans_status', ["Ready for AP Voucher"]);
            }   
        }

        $result=$filter->getQuery($result);
        /*----------end Filter---------*/

        if ($role->name == 'serviceProvider' || $role->name == 'non_profit') {
            $client = auth()->user()->client;
            if ($client !== null)
                $result = $result->where(function($query) use ($client){
                    $query->where('ap.provider_id', $client->org_id)->orWhere('applications.client_id', $client->id);
                });
            else {
                throw new \Exception('Not registered in system');
            }
        }

        $result = DB::table(DB::raw("({$result->toSql()}) as a"))
            ->select('a.*',  DB::raw('sum(trans_amount) as amt'))
            ->mergeBindings($result)->groupBy('invoice_id');
        $totalResult = count($result->get());

        if (isset($request->sort['field']))
            $result = $result->orderBy($request->sort['field'], $request->sort['sort']);
        if (!is_null($perpage))
            $result = $result->limit($perpage)->offset($offset);

        $result=$result->get();

        $data = [
            'meta' => [
                'page' => (int)$request->pagination['page'],
                'pages' => ceil($totalResult / $perpage),
                'perpage' => (int)$perpage,
                'total' => (int)$totalResult,
                'sort' => $request->sort['sort'],
                'field' => $request->sort['field']
            ],
            'data' => $result
        ];
        return $data;
    }
    public function exportData(Request $request)
    {
        $perpage = $request->pagination['perpage'];
        $offset = ($request->pagination['page'] - 1) * $perpage;
        $result = DB::table('payment')
            ->join('applications', function ($join) {
                $join->on('payment.table_id', '=', 'applications.id');
                $join->on('payment.table_name', '=', DB::raw('"applications"'));
            })
            ->leftJoin('invoice_line_item as item','payment.inv_id','item.inv_id')
            ->leftJoin('organization','item.provider_id','organization.id')
            ->select('payment.*', 'applications.id as application_number', 'applications.alt_id as app_alt_id','organization.cname',
            DB::raw('(select batch_no from invoice_batch where invoice_ids in (payment.inv_id)) as batch_id'),
            DB::raw('(select invoice_number from invoice_header where id in (payment.inv_id)) as invoice_no'))
            ->groupBy('payment.id');
        /*----Applying filter--------*/
        $filter=new PaymentFilter($request);
        $result=$filter->getQueryNormal($result);
        /*----------end Filter---------*/
        $result = DB::table(DB::raw("({$result->toSql()}) as a"))
        ->select('a.*',  DB::raw('sum(trans_amount) as amt'))
        ->mergeBindings($result)->groupBy('invoice_id');
        $totalResult = count($result->get());

        if (isset($request->sort['field']))
            $result = $result->orderBy($request->sort['field'], $request->sort['sort']);
        if (!is_null($perpage))
            $result = $result->limit($perpage)->offset($offset);

        $result=$result->get();
        return $result;
    }
}