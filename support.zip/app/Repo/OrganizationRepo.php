<?php
/**
 * DEVELOPERS
 * ----------------------------------------------
 * SUMAN  THAPA - LEAD  (NEPALNME@GMAIL.COM)
 * ----------------------------------------------
 * - BASANTA TAJPURIYA
 * - RAKESH SHRESTHA
 * - LEKH RAJ RAI 
 * -----------------------------------------------
 * Created On: 08/02/2019
 *
 * THIS INTELLECTUAL PROPERTY IS COPYRIGHT Ⓒ 2019
 * ZEUSLOGIC, INC. ALL RIGHT RESERVED
 */

namespace App\Repo;


use App\Lib\Filter\OrganizationFilter\OrgFilter;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Organization;

class OrganizationRepo extends BaseRepo
{
    private function organizationQuery()
    {
        return DB::table('organization')
            ->join('users', 'users.id', 'organization.approved_by')
            ->leftjoin('address', 'address.org_id', 'organization.id')
            ->leftJoin('zip_codes', 'address.zip_id', 'zip_codes.id')
            ->leftJoin('contacts', 'contacts.org_id', 'organization.id');
        /*->join('terms', function ($join) {
            $join->on('terms.table_id', '=', 'organization.id');
            $join->on('terms.table', '=', DB::raw('"organization"'));
        });*/
    }

    public function selectDataTable(Request $request)
    {
        if ($request->has('singleStatus') && $request->has('status')) {
            $request->status = '';
        }
        $perpage = $request->pagination['perpage'];
        $offset = ($request->pagination['page'] - 1) * $perpage;
//        dd($perpage);

        $ext_Query='SELECT COUNT(clients.id) FROM organization as org INNER JOIN clients ON clients.org_id=org.id WHERE clients.org_id=orgId AND is_vet=1';
        $result = $this->organizationQuery()
            ->select('organization.*', 'organization.id as orgId', 'address.add1', 'address.add2',
                DB::raw('COALESCE(address.zip_code,zip_codes.zip_code) as zip_code'),
                DB::raw('COALESCE(address.city,zip_codes.city) as city'),
                DB::raw('COALESCE(address.state,zip_codes.state) as state'),
                'users.name as approver',
                'zip_codes.county',
                'contacts.phone', 'contacts.cell_phone', 'contacts.company_email',
                DB::raw("($ext_Query) as no_of_vets")
            )
            ->where('organization.is_deleted', 0);

        /* apply filter */
        $filter = new OrgFilter($request);

        if(isset($_COOKIE['service_provider']) || isset($_COOKIE['service_provider_quick']))
        {
            $advData=isset($_COOKIE['service_provider'])?json_decode($_COOKIE['service_provider']):[];
            $openData=isset($_COOKIE['service_provider_quick'])?json_decode($_COOKIE['service_provider_quick']):[];
            $mergeData=array_merge($advData,$openData);
            $result=$filter->getQueryCookie($result,$mergeData);
        }
        // $result = $filter->getQuery($result);
        $result = $filter->getQuery($result);
        // dd($result->get());

        $requestData=$request->all();
        if ((array_key_exists('query', $requestData) && $requestData['query'] == null) || !array_key_exists('query', $requestData))
        {
            $result = $result->whereIn('organization.is_approved', [null,2]);
        }

        $totalResult = count($result->get());
        if (isset($request->sort['field']))
            $result = $result->orderBy($request->sort['field'], $request->sort['sort']);
        if (!is_null($perpage))
            $result = $result->limit($perpage)->offset($offset);

        $result = $result->groupBy('organization.id')->get();

        $data = [
            'meta' => [
                'page' => (int)$request->pagination['page'],
                'pages' => ceil($totalResult / $perpage),
                'perpage' => (int)$perpage,
                'total' => (int)$totalResult,
                'sort' => $request->sort['sort'],
                'field' => $request->sort['field']
            ],
            'data' => $result
        ];
        return $data;
    }


    public function getExportData(Request $request)
    {
        $result = $this->organizationQuery()
            ->select('organization.*', 'address.add1', 'address.add2', 'zip_codes.zip_code', 'zip_codes.city', 'zip_codes.state', 'users.name as approver',
                'zip_codes.county', 'contacts.phone', 'contacts.cell_phone', 'contacts.company_email')
            ->where('organization.is_deleted', 0)->latest();

        /* apply filter */
        // dd($request->all());
        $filter = new OrgFilter($request);
        $result = $filter->getQueryNormal($result);
        return $result->get();
    }

    public function findById($id)
    {
        if ($org = Organization::find($id)) {
            return $org->with('address', 'contact')->first();
        } else {
            return false;
        }
    }

    public function storeUploadedFilePath($fileName, $organization, $fileTitle, $document_segment = "", $document_type = "")
    {
        $fileData = array();
        $count = 0;
        $time = getSiteSettings('application_file_expiry_time');
        foreach ($fileName as $file) {
            $data = array(
                'table' => $organization->getTable(),
                'table_id' => $organization->id,
                'document_segment' => $document_segment != "" ? $document_segment : 'upload',
                'document_type' => $document_type != "" ? $document_type : 'file',
                'document_title' => is_array($fileTitle) ? (isset($fileTitle[$count]) ? $fileTitle[$count] : "title") : $fileTitle,
                'file_name' => $file,
                'expiry_date' => date('Y-m-d', strtotime('+' . $time)),
                'created_at' => date('Y-m-d H:i:s')
            );
            array_push($fileData, $data);
            $count++;
        }
        \App\File::insert($fileData);
    }


    public function getVetByOrg(Request $request, $orgId)
    {
        $perpage = $request->pagination['perpage'];
        $offset = ($request->pagination['page'] - 1) * $perpage;

        $result = DB::table('clients')
            ->leftJoin('address', 'address.client_id', 'clients.id')
            ->leftJoin('zip_codes', 'address.zip_id', 'zip_codes.id')
            ->leftJoin('contacts', 'contacts.client_id', 'clients.id')
            ->select('clients.*', 'clients.id as vetId','clients.is_imported as imported', 'address.add1', 'address.add2',
                DB::raw('COALESCE(address.zip_code,zip_codes.zip_code) as zip_code'),
                DB::raw('COALESCE(address.city,zip_codes.city) as city'),
                DB::raw('COALESCE(address.state,zip_codes.state) as state'),
                DB::raw('COALESCE(address.county,zip_codes.county) as county'),
                'contacts.phone', 'contacts.cell_phone', 'contacts.personal_email', 'contacts.company_email',
                DB::raw('CONCAT(clients.fname," ",COALESCE(clients.mname,"")," ",clients.lname) AS client_name'))
            ->where([
                ['clients.org_id', $orgId],
                ['clients.is_vet', 1],
                ['clients.is_deleted', false],
            ]);

        $totalResult = count($result->get());


        if (isset($request->sort['field']))
            $query = $result->orderBy($request->sort['field'], $request->sort['sort']);
        if (!is_null($perpage))
            $result = $result->limit($perpage)->offset($offset);

        $result = $result->get();

        $data = [
            'meta' => [
                'page' => (int)$request->pagination['page'],
                'pages' => ceil($totalResult / $perpage),
                'perpage' => (int)$perpage,
                'total' => (int)$totalResult,
                'sort' => $request->sort['sort'],
                'field' => $request->sort['field']
            ],
            'data' => $result
        ];
        return $data;
    }


    /**
     * @param $field
     * @param $type
     * @return $this
     */
    public function getByZipOrCounty($field,$type)
    {
        $query = DB::table('organization')
            ->join('address', 'address.org_id', 'organization.id')
            ->join('zip_codes', 'address.zip_id', 'zip_codes.id')
            ->join('contacts', 'contacts.org_id', 'organization.id')
            ->select('organization.cname','contacts.company_email','contacts.phone',
                'address.add1','address.add2','zip_codes.zip_code','zip_codes.city','zip_codes.county','zip_codes.state')->where('organization.is_deleted',0);

        $query=$query->orderBy('county','asc')->get();

        return $query;
    }

    public function selectApprovedOrg(Request $request)
    {
        $perpage = $request->pagination['perpage'];
        $offset = ($request->pagination['page'] - 1) * $perpage;

        $selectChecked=<<<SQL
(SELECT provider FROM `providers_list_report` WHERE provider LIKE CONCAT(cname,'%') OR providers_list_report.phone=contacts.phone)
SQL;

        $result = $this->model
            ->join('address', 'address.org_id', 'organization.id')
            ->join('contacts', 'contacts.org_id', 'organization.id')
            ->select('organization.*',
                'address.add1','address.add2','address.zip_code','address.city','address.county','address.state',
                DB::raw($selectChecked.' as checked')
            )
            ->where('organization.is_deleted', 0)->where('is_approved',1);

        if($request->has('provider'))
        {
            $result=$result->where('cname','like','%'.$request->provider.'%');
        }
        $totalResult = count($result->get());

        if (isset($request->sort['field']))
            $result = $result->orderBy($request->sort['field'], $request->sort['sort']);
        if (!is_null($perpage))
            $result = $result->limit($perpage)->offset($offset);

        $result=$result->get();


        $data = [
            'meta' => [
                'page' => (int)$request->pagination['page'],
                'pages' => ceil($totalResult / $perpage),
                'perpage' => (int)$perpage,
                'total' => (int)$totalResult,
                'sort' => $request->sort['sort'],
                'field' => $request->sort['field']
            ],
            'data' => $result
        ];
        return $data;
    }
}