<?php
/**
 * DEVELOPERS
 * ----------------------------------------------
 * SUMAN  THAPA - LEAD  (NEPALNME@GMAIL.COM)
 * ----------------------------------------------
 * - RUNA SIDDHI BAJRACHARYA
 * - RABIN BHANDARI
 * - SHIVA THAPA
 * - PRABHAT GURUNG
 * - KIRAN CHAULAGAIN
 * -----------------------------------------------
 * Created On: 3/20/2018
 *
 * THIS INTELLECTUAL PROPERTY IS COPYRIGHT Ⓒ 2018
 * ZEUSLOGIC, INC. ALL RIGHT RESERVED
 */

namespace App\Repo;


use App\Lib\Filter\PetFilter\PetFilter;
use App\Models\Pet;
use App\Models\ApplicationPet;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PetRepo extends BaseRepo
{
    public function selectDataTable(Request $request)
    {
        $perpage = $request->pagination['perpage'];
        $offset = ($request->pagination['page'] - 1) * $perpage;

        $result = Pet::where('is_deleted', 0);

        $totalResult = count($result->get());

        $result = $result->orderBy($request->sort['field'], $request->sort['sort'])
            ->limit($perpage)->offset($offset)->with('client')->get();


        $data = [
            'meta' => [
                'page' => (int)$request->pagination['page'],
                'pages' => ceil($totalResult / $perpage),
                'perpage' => (int)$perpage,
                'total' => (int)$totalResult,
                'sort' => $request->sort['sort'],
                'field' => $request->sort['field']
            ],
            'data' => $result
        ];
        return $data;
    }


    public function reponseNpPetDataTable(Request $request, $id)
    {
        $perpage = $request->pagination['perpage'];
        $offset = ($request->pagination['page'] - 1) * $perpage;

        $result = Pet::where('is_deleted', 0)->where('client_id', 30);

        $totalResult = count($result->get());

        if (isset($request->sort['sort'])) {
            $result = $result->orderBy($request->sort['field'], $request->sort['sort'])
                ->limit($perpage)->offset($offset)->with('client')->get();
        } else {
            $result = $result->limit($perpage)->offset($offset)->with('client')->get();
        }


        $data = [
            'meta' => [
                'page' => (int)$request->pagination['page'],
                'pages' => ceil($totalResult / $perpage),
                'perpage' => (int)$perpage,
                'total' => (int)$totalResult,
                'sort' => $request->sort['sort'],
                'field' => $request->sort['field']
            ],
            'data' => $result
        ];
        return $data;
    }

    public function exportPet(Request $request)
    {
        // dd($request->all());
        $sortField = $request->sort_field;
        if($sortField == ''){
            $sortField = 'alt_id';
        }
        $sortvalue = $request->sort_value;
        if($sortvalue == ''){
            $sortvalue = 'desc';
        }
        $role = auth()->user()->role;

        $query = $this->appPetQuery()->select('pets.*', 'pets.status as pet_status', 'applications.id as app_id', 'appPet.cert_number',DB::raw('CONCAT(vet.fname," ",COALESCE(vet.mname,"")," ",vet.lname) AS vet_name'), 'applications.application_date',
            DB::raw('CONCAT("PR",LPAD(pets.alt_id,5,0)) as pet_id'),
             DB::raw('CONCAT("CERT-",LPAD(pets.alt_id,5,0)) as cert_id'),
            DB::raw('CONCAT("IE",LPAD(applications.alt_id,5,0)) as app_alt_id'),
            DB::raw('CONCAT(clients.fname," ",COALESCE(clients.mname,"")," ",clients.lname) AS owner_name'),
            DB::raw('CONCAT(UCASE(LEFT(species, 1)),SUBSTRING(species, 2)) as species'),
            'applications.status as app_status', 'applications.application_date',
            'organization.cname as service_provider', 'contacts.cell_phone','contacts.personal_email',
            'organization.type',
            DB::raw('sum(item.amount_total) as max_contingent')
        )->where([
            ['applications.is_deleted', 0],
            ['pets.is_deleted', 0],
            ['clients.is_deleted', 0]
        ]);

        // if ($role->id == 4 || $role->id == 3 || $role->id == 7) {
        //     $client = auth()->user()->client;
        //     if ($client !== null)
        //         $query = $query->where('appPet.provider_id', $client->org_id)->where(function ($query) {
        //             $query->where('applications.status', 'Approved')->orWhere('applications.is_provider_view', 1);
        //         });
        // }

        // if ($request->has('source') && $role->id == 1 || $role->name == 'admin') {
        //     $query = $query->where('applications.status', '!=', 'Approved')->where('is_provider_view', 0);
        // }

        // if ($request->has('vetId')) {
        //     $query = $query->where('vet.id', $request->vetId);
        // }

        $filter = new PetFilter($request);
        // $query = $filter->getQuery($query);
        $query = $filter->getQueryNormal($query);

        $result = $query->groupBy('applications.id', 'pets.id')->orderBy($sortField, $sortvalue)->get();

        return $result;
    }


    /**
     * @return \Illuminate\Database\Query\Builder
     */
    private function appPetQuery()
    {
        return DB::table('applications')
            ->leftJoin('application_pet as appPet', 'appPet.application_id', 'applications.id')
            ->leftJoin('pets', 'pets.id', 'appPet.pet_id')
            ->leftJoin('clients', 'clients.id', 'pets.client_id')
            ->leftJoin('address', 'address.client_id', 'clients.id')
            ->leftJoin('zip_codes', 'address.zip_id', 'zip_codes.id')
            ->leftJoin('contacts', 'contacts.client_id', 'clients.id')
            ->leftJoin('organization', 'appPet.provider_id', 'organization.id')
            ->leftJoin('invoice_line_item as item', 'item.application_id', 'applications.id')
            ->leftJoin('app_pet_treatment as apt', 'apt.pet_id', 'pets.id')
            ->leftJoin('clients as vet', 'apt.vet_id', 'vet.id')
            ->leftJoin('files', function ($join) {
                $join->on('files.table_id', '=', 'applications.id');
                $join->on('files.table', '=', DB::raw('"applications"'));
            });
    }

    public function appPetRegistration(Request $request)
    {
        $perpage = $request->pagination['perpage'] == 0 ? 20 : $request->pagination['perpage'];
        $offset = ($request->pagination['page'] - 1) * $perpage;
        $role = auth()->user()->role;

        $query = $this->appPetQuery()->select('pets.*', 'applications.id as app_id', 'applications.alt_id as app_alt_id',
            DB::raw('CONCAT(clients.fname," ",COALESCE(clients.mname,"")," ",clients.lname) AS owner_name'),
            DB::raw('CONCAT(vet.fname," ",COALESCE(vet.mname,"")," ",vet.lname) AS vet_name'),
            'vet.vet_lic as vet_lic_num',
            'applications.application_date',
            'applications.status as app_status',
            'organization.cname as service_provider',
            'organization.type',
            'files.id as file_id',
            'cert_number',
            DB::raw('sum(item.amount_total) as max_contingent')
        )->where([
            ['applications.is_deleted', 0],
            ['clients.is_deleted', 0]
        ]);

        if ($role->id == 4 || $role->id == 3 || $role->id == 7) {
            $client = auth()->user()->client;
            if ($client !== null)
                $query = $query->where('appPet.provider_id', $client->org_id)->where(function ($query) {
                    $query->where('pets.status', 'Approved')->orWhere('applications.is_provider_view', 1);
                });
        }

        $filter = new PetFilter($request);
        // dd($request->all());
        $r = $request->all(); 
        if(isset($_COOKIE['pet_registration']) || isset($_COOKIE['pet_registration_quick']))
        {
            $advData=isset($_COOKIE['pet_registration'])?json_decode($_COOKIE['pet_registration']):[];
            $openData=isset($_COOKIE['pet_registration_quick'])?json_decode($_COOKIE['pet_registration_quick']):[];
            $mergeData=array_merge($advData,$openData);
            $query=$filter->getQueryCookie($query,$mergeData);
        }
        else
        {
            if(!array_key_exists('query', $r) || (array_key_exists('query', $r) && $r['query']==null))
            {
                $start = date("Y-m-d", strtotime("first day of -2 month"));
                $end = date("Y-m-d", strtotime('last day of this month'));
                $query = $query->whereIn('applications.status', ['New', 'Review', 'Pending', 'Approved'])->whereBetween('applications.application_date', [$start, $end]);
            }else{
                if(array_key_exists('query', $r) && $r['query'] != null && array_key_exists('statusDate', $r['query'])){
                    $query = $filter->getQuery($query);
                }
            }
        }
        
        // $query = $filter->getQuery($query);
        $query = $filter->getQueryNormal($query);

        $totalResult = count($query->groupBy('applications.id', 'pets.id')->get());

        if (isset($request->sort['field']))
            $query = $query->orderBy($request->sort['field'], $request->sort['sort']);
        if (!is_null($perpage))
            $query = $query->limit($perpage)->offset($offset);


        $result = $query->groupBy('applications.id', 'pets.id')->get();

        $data = [
            'meta' => [
                'page' => (int)$request->pagination['page'],
                'pages' => ceil($totalResult / $perpage),
                'perpage' => (int)$perpage,
                'total' => (int)$totalResult,
                'sort' => $request->sort['sort'],
                'field' => $request->sort['field']
            ],
            'data' => $result
        ];
        return $data;
    }
    public function dashboardPetAll(Request $request)
    {
        $perpage = $request->pagination['perpage'] == 0 ? 20 : $request->pagination['perpage'];
        $offset = ($request->pagination['page'] - 1) * $perpage;
        $role = auth()->user()->role;

        $query = $this->appPetQuery()->select('pets.*', 'applications.id as app_id', 'applications.alt_id as app_alt_id',
            DB::raw('CONCAT(clients.fname," ",COALESCE(clients.mname,"")," ",clients.lname) AS owner_name'),
            DB::raw('CONCAT(vet.fname," ",COALESCE(vet.mname,"")," ",vet.lname) AS vet_name'),
            'vet.vet_lic as vet_lic_num',
            'applications.application_date', 'applications.status as app_status',
            'organization.cname as service_provider',
            'organization.type',
            'files.id as file_id',
            'cert_number',
            DB::raw('sum(item.amount_total) as max_contingent')
        )->where([
            ['applications.is_deleted', 0],
            ['clients.is_deleted', 0]
        ]);

        if ($role->id == 4 || $role->id == 3 || $role->id == 7) {
            $client = auth()->user()->client;
            if ($client !== null)
                $query = $query->where('appPet.provider_id', $client->org_id)->where(function ($query) {
                    $query->where('pets.status', 'Approved')->orWhere('applications.is_provider_view', 1);
                });
        }

        $filter = new PetFilter($request);
        // dd($request->all());
        $r = $request->all(); 
        if(isset($_COOKIE['pet_registration']) || isset($_COOKIE['pet_registration_quick']))
        {
            $advData=isset($_COOKIE['pet_registration'])?json_decode($_COOKIE['pet_registration']):[];
            $openData=isset($_COOKIE['pet_registration_quick'])?json_decode($_COOKIE['pet_registration_quick']):[];
            $mergeData=array_merge($advData,$openData);
            $query=$filter->getQueryCookie($query,$mergeData);
        }
        else
        {
            if(!array_key_exists('query', $r) || (array_key_exists('query', $r) && $r['query']==null))
            {
                $start = date("Y-m-d", strtotime("first day of this month"));
                $end = date("Y-m-d", strtotime('last day of this month'));
                $query = $query->whereIn('applications.status', ['New'])->whereBetween('applications.application_date', [$start, $end]);
            }else{
                if(array_key_exists('query', $r) && $r['query'] != null && array_key_exists('statusDate', $r['query'])){
                    $query = $filter->getQuery($query);
                }
            }
        }
        
        
        // $query = $filter->getQuery($query);
        $query = $filter->getQueryNormal($query);

        $totalResult = count($query->groupBy('applications.id', 'pets.id')->get());

        if (isset($request->sort['field']))
            $query = $query->orderBy($request->sort['field'], $request->sort['sort']);
        if (!is_null($perpage))
            $query = $query->limit($perpage)->offset($offset);


        $result = $query->groupBy('applications.id', 'pets.id')->get();

        $data = [
            'meta' => [
                'page' => (int)$request->pagination['page'],
                'pages' => ceil($totalResult / $perpage),
                'perpage' => (int)$perpage,
                'total' => (int)$totalResult,
                'sort' => $request->sort['sort'],
                'field' => $request->sort['field']
            ],
            'data' => $result
        ];
        return $data;
    }

    /**
     * @return \Illuminate\Database\Query\Builder
     */

    public function selectPetTable(Request $request,$provider=null)
    {

        $perpage = $request->pagination['perpage'] == 0 ? 20 : $request->pagination['perpage'];
        $offset = ($request->pagination['page'] - 1) * $perpage;

        $query = DB::table('application_pet as appPet')
                    ->join('applications', 'applications.id', '=', 'appPet.application_id')
                    ->join('pets', 'pets.id', '=', 'appPet.pet_id')
                    ->join('clients', 'clients.id', '=', 'pets.client_id')
                    ->select('pets.*', 'appPet.cert_number', 'applications.alt_id as app_alt_id', 'applications.id as app_id',
                    DB::raw('CONCAT(clients.fname," ",COALESCE(clients.mname,"")," ",clients.lname) AS owner_name')
                );


        $filter = new PetFilter($request);
        $query = $filter->getQuery($query);
        // $query = $filter->getQueryNormal($query);
        if(!is_null($provider))
            $query = $query->where('appPet.provider_id', $provider);
        else
            $query = $query->where('appPet.provider_id', NULL);
        
        $query = $query->where('applications.status', 'Approved');

        $totalResult = count($query->get());

        if (isset($request->sort['field']))
            $query = $query->orderBy($request->sort['field'], $request->sort['sort']);
        if (!is_null($perpage))
            $query = $query->limit($perpage)->offset($offset);


        $result = $query->get();

        $data = [
            'meta' => [
                'page' => (int)$request->pagination['page'],
                'pages' => ceil($totalResult / $perpage),
                'perpage' => (int)$perpage,
                'total' => (int)$totalResult,
                'sort' => $request->sort['sort'],
                'field' => $request->sort['field']
            ],
            'data' => $result
        ];
        return $data;
    }

    public function dataTable(Request $request)
    {
        $offset = $request->start;
        $length = $request->length;

        $externalQuery = "SELECT GROUP_CONCAT(treatment_name) FROM treatments JOIN app_pet_treatment AS apt1 ON apt1.treatment_id=treatments.id WHERE apt1.application_id=applications.id AND apt1.pet_id=pets.id GROUP BY application_id";
        $query = DB::table('applications')
            ->join('application_pet as appPet', 'appPet.application_id', 'applications.id')
            ->join('pets', 'pets.id', 'appPet.pet_id')
            ->join('clients', 'clients.id', 'pets.client_id')
            ->join('address', 'address.client_id', 'clients.id')
            ->join('zip_codes', 'address.zip_id', 'zip_codes.id')
            ->join('contacts', 'contacts.client_id', 'clients.id')
            ->leftJoin('invoice_line_item as item', 'item.application_id', 'applications.id')
            ->leftJoin('app_pet_treatment as apt', 'apt.pet_id', 'pets.id')
            ->leftJoin('clients as vet', 'vet.id', 'apt.vet_id')
            ->join('treatments', 'treatments.id', 'apt.treatment_id')
            ->select('pets.*', 'applications.id as app_id', 'appPet.cert_number', 'item.inv_id',
                DB::raw('CONCAT(vet.fname," ",COALESCE(vet.mname, "")," ",vet.lname) AS vet_name'),
                DB::raw('CONCAT(clients.fname," ",COALESCE(clients.mname, "")," ",clients.lname) AS owner_name'),
                DB::raw("($externalQuery) as treatment_name"),
                'applications.status')
            ->where([
                ['appPet.provider_id', auth()->user()->organization()->id],
                ['applications.is_deleted', 0],
                ['pets.is_deleted', 0],
                ['clients.is_deleted', 0]
            ])
            ->where(function ($query) {
                $query->where('applications.status', 'Approved')->orWhere('applications.is_provider_view', 1);
            });
        $filter = new PetFilter($request);
        $result = $filter->getQuery($query);

        $totalResult = count($result->get());

        $data = [
            "draw" => $request->draw,
            "recordsTotal" => (int)$totalResult,
            "recordsFiltered" => count($result),
            "data" => $result
        ];

        return $data;
    }

    public function petExpiration(Request $request)
    {
        $d = date('Y-m-d');
        $query = $this->appPetQuery()->select('pets.pet_name', 'pets.breed', 'pets.id as pet_id','applications.id as app_id', 'applications.alt_id',
            DB::raw('CONCAT(clients.fname," ",COALESCE(clients.mname,"")," ",clients.lname) AS owner_name'),
            DB::raw('CONCAT(vet.fname," ",COALESCE(vet.mname,"")," ",vet.lname) AS vet_name'),
            'applications.status',
            'organization.cname as service_provider',
            'organization.type',
            // DB::raw('sum(item.amount_total) as max_contingent'),
            // DB::raw('Case when files.expiry_date >= '.$d.' then "Not Expire" else "Expired" end as file_status'),
            'files.expiry_date',
            'applications.application_date'
        )->where([
            ['applications.is_deleted', 0],
            ['pets.is_deleted', 0],
            ['clients.is_deleted', 0]
        ])->where(function ($query) {
            $query->whereIn('applications.status', ['Approved', 'Partial Invoiced', 'Invoiced', 'Denial', 'Closed'])->where('applications.is_provider_view', 1);
        });

        $filter = new PetFilter($request);
        $query = $filter->getQuery($query);
        $query = $filter->getQueryNormal($query);
        $result = $query->groupBy('applications.id', 'pets.id')->get();
        return $result;
    }
}