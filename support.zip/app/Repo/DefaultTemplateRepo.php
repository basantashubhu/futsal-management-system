<?php
/**
 * DEVELOPERS
 * ----------------------------------------------
 * SUMAN  THAPA - LEAD  (NEPALNME@GMAIL.COM)
 * ----------------------------------------------
 * - BASANTA TAJPURIYA
 * - RAKESH SHRESTHA
 * - LEKH RAJ RAI 
 * -----------------------------------------------
 * Created On: 08/02/2019
 *
 * THIS INTELLECTUAL PROPERTY IS COPYRIGHT Ⓒ 2019
 * ZEUSLOGIC, INC. ALL RIGHT RESERVED
 */

namespace App\Repo;

use App\Lib\Filter\DefaultTemplateFilter\DefaultTemplateFilter;
use App\Models\Fgp\Volunteer;
use http\Env\Response;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DefaultTemplateRepo extends BaseRepo
{
    protected function joins()
    {
//        return DB::table('default_templates');
        return DB::table('templates')
        ->leftJoin('volunteers', function ($join) {
            $join->on('templates.table_name', DB::raw('"volunteers"'));
            $join->on('templates.table_id', 'volunteers.id');
        });
    }

    /*-------------------- for m datatable--------*/
    public function selectDataTable(Request $request)
    {
        $perpage = $request->pagination['perpage'];
        $offset = ($request->pagination['page'] - 1) * $perpage;
        $result = $this->joins()
            ->select(\DB::raw("CONCAT(volunteers.first_name,' ',COALESCE(volunteers.middle_name,''),' ',volunteers.last_name) as vol_name"),
                'templates.template_name','templates.is_default','templates.id as tempId','volunteers.id as volId')
            ->where('templates.is_deleted', 0);

        $filter = new DefaultTemplateFilter($request);

        $result = $filter->getQuery($result);

        $totalResult = count($result->get());

        if (isset($request->sort['field']))
            $result = $result->orderBy($request->sort['field'], $request->sort['sort']);
        if (!is_null($perpage))
            $result = $result->limit($perpage)->offset($offset);

        $result = $result->get();

        $data = [
            'meta' => [
                'page' => (int)$request->pagination['page'],
                'pages' => ceil($totalResult / $perpage),
                'perpage' => (int)$perpage,
                'total' => (int)$totalResult,
                'sort' => $request->sort['sort'],
                'field' => $request->sort['field']
            ],
            'data' => $result
        ];
        return $data;
    }


    public function selectVolDefaultTemplate(Request $request,$vol_id) {

        $perpage = $request->pagination['perpage'];
        $offset = ($request->pagination['page'] - 1) * $perpage;
        $result = $this->joins()
            ->select(\DB::raw("CONCAT(volunteers.first_name,' ',COALESCE(volunteers.middle_name,''),' ',volunteers.last_name) as vol_name"),
                'templates.template_name','templates.is_default','templates.id as tempId','volunteers.id as volId')
            ->where('templates.is_deleted', 0)
            ->where('table_id',$vol_id);

        $filter = new DefaultTemplateFilter($request);

        $result = $filter->getQuery($result);

        $totalResult = count($result->get());

        if (isset($request->sort['field']))
            $result = $result->orderBy($request->sort['field'], $request->sort['sort']);
        if (!is_null($perpage))
            $result = $result->limit($perpage)->offset($offset);

        $result = $result->get();

        $data = [
            'meta' => [
                'page' => (int)$request->pagination['page'],
                'pages' => ceil($totalResult / $perpage),
                'perpage' => (int)$perpage,
                'total' => (int)$totalResult,
                'sort' => $request->sort['sort'],
                'field' => $request->sort['field']
            ],
            'data' => $result
        ];
        return $data;
    }


}