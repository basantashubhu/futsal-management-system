<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CommunicationPrefrence extends Model
{
    protected $table = 'comm__prefs';

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
