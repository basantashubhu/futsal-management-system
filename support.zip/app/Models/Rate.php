<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Rate extends Model
{
    public function provider()
    {
        return $this->belongsTo(Organization::class, 'provider_id');
    }
    public function rate_type()
    {
    	return $this->belongsTo(RateType::class, 'rate_type_id');
    }
    public function treatment()
    {
    	return $this->belongsTo(Treatment::class, 'treatment_id');
    }
}
