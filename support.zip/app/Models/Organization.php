<?php
/**
 * DEVELOPERS
 * ----------------------------------------------
 * SUMAN  THAPA - LEAD  (NEPALNME@GMAIL.COM)
 * ----------------------------------------------
 * - BASANTA TAJPURIYA
 * - RAKESH SHRESTHA
 * - LEKH RAJ RAI 
 * -----------------------------------------------
 * Created On: 08/02/2019
 *
 * THIS INTELLECTUAL PROPERTY IS COPYRIGHT Ⓒ 2019
 * ZEUSLOGIC, INC. ALL RIGHT RESERVED
 */

namespace App\Models;


use Illuminate\Database\Eloquent\Model;
use App\File;

class Organization extends Model
{
    protected $table = 'accounts';

    public function contact()
    {
        return $this->hasOne(Contact::class, 'org_id');
    }

    public function contactPerson()
    {
        return $this->hasOne(Client::class, 'org_id');
    }

    public function address()
    {
        return $this->hasOne(Address::class, 'org_id')->with('zip');
    }

    public function agreement()
    {
        return $this->hasOne(Terms::class, 'table_id');
    }

    public function invoiceBatch()
    {
        return $this->hasOne(InvoiceBatch::class, 'provider_id');
    }

    public function files($id = null)
    {
        if ($id) {
            $this->files = File::where('table', $this->getTable())->where('table_id', $this->id)->where("id", $id)->get();
        } else {
            $this->files = File::where('table', $this->getTable())->where('table_id', $this->id)->get();
        }
        return $this->files;
    }

    public function vet()
    {
        return $this->hasMany(Client::class, 'org_id')->with('address', 'contact')->where('is_vet', 1)->orderBy('fname', 'asc');
    }

    public function process()
    {
        return $this->hasMany(OrganizationProcess::class, 'organization_id');
    }

    public function getProcess()
    {
        return OrganizationProcess::select('step', 'step_name', 'step_type',
            \DB::raw('GROUP_CONCAT(CONCAT(progress_name," - ",COALESCE(progress_date,""))) as item,
            GROUP_CONCAT(STATUS) as status,GROUP_CONCAT(IFNULL(step_type,"Null")) as type'))
            ->where('organization_id', $this->id)->groupBy('step', 'step_name')->get();
    }

    public function ratePlan()
    {
        return $this->hasOne(RatePlan::class, 'id', 'plan_id');
    }

    public function getMailAddress()
    {
        if ($this->contactPerson) {
            $personal = $this->contactPerson->contact->personal_email;

            $company = $this->contactPerson->contact->company_email;

            if (!is_null($personal))
                return $personal;
            elseif (!is_null($company))
                return $company;
        } else
            return 'demo@zeuslogic.com';

    }

}