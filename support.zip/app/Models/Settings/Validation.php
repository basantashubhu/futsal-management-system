<?php

namespace App\Models\Settings;

use Illuminate\Database\Eloquent\Model;

class Validation extends Model
{
    //
}
