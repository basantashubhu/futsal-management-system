<?php
/**
 * DEVELOPERS
 * ----------------------------------------------
 * SUMAN  THAPA - LEAD  (NEPALNME@GMAIL.COM)
 * ----------------------------------------------
 * - RUNA SIDDHI BAJRACHARYA
 * - RABIN BHANDARI
 * - SHIVA THAPA
 * - PRABHAT GURUNG
 * - KIRAN CHAULAGAIN
 * -----------------------------------------------
 * Created On: 5/25/2018
 *
 * THIS INTELLECTUAL PROPERTY IS COPYRIGHT Ⓒ 2018
 * ZEUSLOGIC, INC. ALL RIGHT RESERVED
 */

namespace App\Models;


use Illuminate\Database\Eloquent\Model;

class Budget extends Model
{
    protected $table='budget';

    public function checkBalance()
    {
        $dr_balance=$this->sum('dr_amount');
        $cr_balance=$this->sum('cr_amount');
        $balance=$dr_balance-$cr_balance;
        return $balance;
    }

    public static function checkExistingBalance()
    {
        $dr_balance=self::sum('dr_amount');
        $cr_balance=self::sum('cr_amount');
        $balance=$dr_balance-$cr_balance;
        return $balance;
    }
}