<?php

namespace App\Models;

use App\File;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Application extends Model
{

    public function client()
    {
        return $this->belongsTo(Client::class);
    }

    public function pets($petIDs = '')
    {
        if ($petIDs == '')
            return $this->belongsToMany(Pet::class);
        else
            return $this->belongsToMany(Pet::class)->whereIn('pet_id', $petIDs)->get();
    }

    public function provider()
    {
        return $this->belongsTo(Organization::class, 'provider_id');
    }

    public function process()
    {
        return $this->hasMany(ApplicationProcess::class, 'application_id');
    }

    public function getProcess()
    {
        return ApplicationProcess::select('step', 'step_name', 'step_type',
            \DB::raw('GROUP_CONCAT(CONCAT(progress_name," - ",COALESCE(DATE_FORMAT(progress_date, "%m/%d/%Y"),""))) as item,
            GROUP_CONCAT(STATUS) as status,GROUP_CONCAT(IFNULL(step_type,"Null")) as type'))
            ->where('application_id', $this->id)->groupBy('step', 'step_name')->get();

    }

    public function files($id = null)
    {
        if ($id) {
            $this->files = File::where('table', 'applications')->where('table_id', $this->id)->where("id", $id)->get();
        } else {
            $this->files = File::where('table', 'applications')->where('table_id', $this->id)->get();
        }
        return $this->files;
    }

    public function notes()
    {
        return Note::where('table_name', 'applications')->where('table_id', $this->id)->get();
    }

    public function providers($petId=null)
    {
        $providers=Organization::leftJoin('application_pet', 'application_pet.provider_id', 'organization.id')
            ->select('organization.*')
            ->where('application_id', $this->id);
        if($petId!=null)
            $providers->where('pet_id',$petId);

        return $providers->groupBy('provider_id')->first();
    }

    public function invoiceItem()
    {
        return $this->hasMany(InvoiceItem::class, 'application_id');
    }

    public function applicationPet()
    {
        return $this->hasMany(ApplicationPet::class, 'application_id')->with('serviceProvider');
    }

    public function getMailAddress()
    {
        if ($this->client->contact) {
            if ($personal = $this->client->contact->personal_email)
                return $personal;
            elseif ($company = $this->client->contact->company_email)
                return $company;
        }

        return 'demo@zeuslogic.com';

    }

    public function copayStatus()
    {
        $data = Payment::where([
            ['table_name', 'applications'],
            ['table_id', $this->id],
            ['trans_type', 'revenue']
        ])->sum('trans_amount');

        return $data != null && $data == $this->pets->count() * getSiteSettings('copay_amount');
    }

    public function copayStatusPet($pet)
    {
        $data = Payment::where([
            ['table_name', 'applications'],
            ['table_id', $this->id],
            ['trans_type', 'revenue'],
            ['ref_no', $pet]
        ])->sum('trans_amount');

        return $data != null;
    }

    public function copayPaidAmount()
    {
        return Payment::where([
            ['table_name', 'applications'],
            ['table_id', $this->id],
            ['trans_type', 'revenue']
        ])->sum('trans_amount');
    }

    public function copay()
    {
        return Payment::where([
            ['table_name', 'applications'],
            ['table_id', $this->id],
            ['trans_type', 'revenue'],
        ])->first();
    }

    public function copayPet($pet)
    {
        return Payment::where([
            ['table_name', 'applications'],
            ['table_id', $this->id],
            ['trans_type', 'revenue'],
            ['ref_no', $pet]
        ])->first();
    }

    public function payment()
    {
        return Payment::where([
            ['table_name', 'applications'],
            ['table_id', $this->id],
            ['trans_type', 'expenses'],
        ])->get();
    }

    public function commPref()
    {
        return CommunicationPrefrence::where([
            ['table', $this->getTable()],
            ['table_id', $this->id]
        ])->first();
    }

    public function vet()
    {
        if ($vets = DB::table('app_pet_treatment')->where('application_id', $this->id)->first()) {

            if ($client = Client::find($vets->vet_id)) {
                return $client;
            }
        }
        return false;
    }

    public function appPetTreatment($petID)
    {
        $treats = DB::table('app_pet_treatment')->where('application_id', $this->id)->where('pet_id', $petID)->get();
        foreach($treats as $treatment):
            $treatment->t = DB::table('treatments')->find($treatment->treatment_id);
        endforeach;
        return $treats;
    }
}
