<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RatePlan extends Model
{
    protected $table = 'rate_plan';

    public function rates()
    {
    	return $this->hasMany(Rate::class, 'plan_id');
    }
}
