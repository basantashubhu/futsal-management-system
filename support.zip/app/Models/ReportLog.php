<?php
/**
 * DEVELOPERS
 * ----------------------------------------------
 * SUMAN  THAPA - LEAD  (NEPALNME@GMAIL.COM)
 * ----------------------------------------------
 * - RUNA SIDDHI BAJRACHARYA
 * - RABIN BHANDARI
 * - SHIVA THAPA
 * - PRABHAT GURUNG
 * - KIRAN CHAULAGAIN
 * -----------------------------------------------
 * Created On: 3/29/2018
 *
 * THIS INTELLECTUAL PROPERTY IS COPYRIGHT Ⓒ 2018
 * ZEUSLOGIC, INC. ALL RIGHT RESERVED
 */

namespace App\Models;


use App\Models\Fgp\Site;
use App\Models\Fgp\Volunteer;
use Illuminate\Database\Eloquent\Model;

class ReportLog extends Model
{
    protected $table='report_logs';

    protected $appends = ['total_vols', 'total_sites'];

    public function getTotalVolsAttribute() {
        return Volunteer::whereIn('id', explode(',', $this->vol_id))->count();
    }

    public function getTotalSitesAttribute() {
        return Site::whereIn('id', explode(',', $this->site_id))->count();
    }
}