<?php

namespace App\Models\Fgp;

use Illuminate\Database\Eloquent\Model;

class VolunteerSites extends Model
{
    public function sites(){
    	return $this->belongsTo(Site::class, 'site_id', 'id');
  
    }

    
    	
}
