<?php

namespace App\Models\Fgp;

use App\Models\Address;
use App\Models\Contact;
use Illuminate\Database\Eloquent\Model;

class Organization extends Model
{
    protected $fillable = ['is_deleted'];

    public function contact(){
        return Contact::where('table_name', 'organizations')->where('table_id', $this->id)->where('is_deleted', 0)->first();
    }

    public function address(){
        return $this->hasOne(Address::class, 'table_id', 'id')->where('table_name', 'organizations')->first();
    }
}
