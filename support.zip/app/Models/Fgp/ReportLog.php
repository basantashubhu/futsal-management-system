<?php
/**
 * @author Suman Thaapa -- Lead 
 * @author Prabhat gurung 
 * @author Basanta Tajpuriya 
 * @author Rakesh Shrestha 
 * @author Manish Buddhacharya 
 * @author Lekh Raj Rai 
 * @author Ascol Parajuli
 * @email NEPALNME@GMAIL.COM
 * @create date 2019-04-01 20:41:42
 * @modify date 2019-04-01 20:41:42
 * @desc [description]
 */


namespace App\Models\Fgp;

use Illuminate\Database\Eloquent\Model;

class ReportLog extends Model
{
    protected $table='report_logs';
}
