<?php

namespace App\Models\Fgp;

use Illuminate\Database\Eloquent\Model;

class VolunteerDeactive extends Model
{
    protected $table = "volunteer_deactivates";

    protected $guarded = [];
}
