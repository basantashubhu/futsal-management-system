<?php

namespace App\Models\Fgp;

use Illuminate\Database\Eloquent\Model;

class SiteDetail extends Model
{
    protected $table = "site_details";
    protected $fillable = [
    	'contact_person','person_email','person_cell','person_alt_phone'
    ];
}
