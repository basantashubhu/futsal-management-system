<?php

namespace App\Models\Fgp;

use Illuminate\Database\Eloquent\Model;

class TemplateComponent extends Model
{
    protected $guarded = [];

    public function items()
    {
        return $this->hasMany(TemplateItems::class)->whereHas('stipendItem', function ($stipendItem) {
            $stipendItem->where('is_deleted', 0);
        });
    }

    public function noConstraintItems(){
        return $this->hasMany(TemplateItems::class);
    }

    public function site()
    {
        return $this->belongsTo(Site::class);
    }

    public function timeType()
    {
        return $this->belongsTo(StipendItem::class, 'time_type');
    }

}
