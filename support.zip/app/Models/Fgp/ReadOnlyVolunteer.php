<?php

namespace App\Models\Fgp;

class ReadOnlyVolunteer extends Volunteer
{
    protected $table = 'volunteers';
    protected $fillable = [];
    protected $guarded = ['*'];
    protected $appends = [];

    /**
     * Modifying default attribute accessor to get direct access to the detail
     * ReadOnly
     *
     * @param string $key
     * @return mixed
     */
    public function __get($key)
    {
        if (!$value = parent::__get($key)) {
            $value = $this->details->firstWhere('code', $key)->value ?? null;
        }
        return $value;
    }

    /**
     * format tele phone to US standard format
     *
     * @param string $tel_phone
     * @return string actual tele phone in US standard format
     */
    public function getTelPhoneAttribute($tel_phone)
    {
        $tel_phone = preg_replace('/[^\d]/', '', $tel_phone);
        return format_cell($tel_phone);
    }

    /**
     * format cell phone to US standard format
     *
     * @param string $tel_phone
     * @return string actual cell phone in US standard format
     */
    public function getCellPhoneAttribute($cell_phone)
    {
        $cell_phone = preg_replace('/[^\d]/', '', $cell_phone);
        return format_cell($cell_phone);
    }
}
