<?php

namespace App\Models\Fgp;

use App\Models\Fgp\StipendCalc;
use Illuminate\Database\Eloquent\Model;

class PayPeriod extends Model
{
    protected $fillable = [
        'period_no', 'fiscal_year','start_date','end_date','closed_date','closed_time','userc_id','pay_code', 'pay_stat'
    ];

    public $collection = [];
    public $children_collect = [];
    protected $appends = ['collect', 'childrens'];

    public function getCollectAttribute() {
        return $this->collection;
    }

    public function setCollectAttribute($ts) {
        array_push($this->collection, $ts);
        return $this;
    }

    public function getChildrensAttribute() {
        return $this->children_collect;
    }

    
    // has many timesheets
    public function timesheets() {
        return $this->hasMany(Timesheet::class, 'period_id', 'id');
    }

    // approvals
    public function approval() {
        return $this->hasMany(ApprovalTable::class, 'period_id', 'id')
            ->when(!is_super_admin(), function($approvals) {
                $approvals->where('next_approval', auth()->id());
            });
    }

    public function approvalWithFlow(){
        return $this->hasMany(ApprovalTable::class, 'period_id', 'id')->orderBy('created_at');
    }

    public function accessibleSites() {
        $sites = auth()->user()->managerSites()->where('user_id', auth()->id())->get();
        return $this->hasMany(Timesheet::class, 'period_id', 'id')
            ->whereIn('site_id', $sites)->select('site_id');
    }

    public function sites()
    {
        return $this->belongsToMany(Site::class, 'timesheets', 'period_id', 'site_id')
            ->groupBy('sites.id');
    }

    public function volunteers()
    {
        return $this->belongsToMany(Volunteer::class, 'timesheets', 'period_id', 'volunteer_id')
            ->groupBy('volunteers.id');
    }

    public function stipendCalcs()
    {
        return $this->hasMany(StipendCalc::class, 'period_unq_id');
    }
}
