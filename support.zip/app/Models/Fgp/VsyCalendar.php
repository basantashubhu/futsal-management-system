<?php

namespace App\Models\Fgp;

use Illuminate\Database\Eloquent\Model;

class VsyCalendar extends Model
{
    //
}
