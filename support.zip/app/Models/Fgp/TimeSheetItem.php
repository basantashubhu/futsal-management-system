<?php

namespace App\Models\Fgp;

use App\Models\Settings\Lookups;
use Illuminate\Database\Eloquent\Model;

class TimeSheetItem extends Model
{
    protected $table = 'time_sheet_items';

    protected $guarded = [];

    public function time_sheet()
    {
        return $this->belongsTo(Timesheet::class, 'time_sheet_id');
    }

    public function stipendItem(){
    	return $this->belongsTo(StipendItem::class, 'stipend_item_id');
    }

    public function lookups(){
    	return $this->belongsTo(Lookups::class, 'stipend_lookup_id');
    }

    public function getTypeAttribute($value){
    	return $this->lookups->value ?? $value;
    }

    public function getValueAttribute($value){
    	return $this->stipendItem->item_name ?? $value;
    }

}
