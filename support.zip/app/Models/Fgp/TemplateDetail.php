<?php

namespace App\Models\Fgp;

use Illuminate\Database\Eloquent\Model;

class TemplateDetail extends Model
{

    public function template()
    {
        return $this->belongsTo(Template::class);
    }

    public function items()
    {
        return $this->hasMany(TemplateItems::class)->where('is_deleted', 0);
    }
}
