<?php

namespace App\Models\Fgp;

use App\Container\RoleContainer;
use App\Models\Address;
use App\Models\Contact;
use App\Models\Fgp\SiteDetail;
use App\Models\Fgp\Volunteer;
use App\Models\User;
use App\Traits\AssignedVolunteerTrait;
use Illuminate\Database\Eloquent\Model;

class Site extends Model
{
    use AssignedVolunteerTrait;

    protected $table = 'sites';

    protected $fillable = [
        'site_name', 'site_type', 'audit_key', 'cont_per_fname', 'cont_per_mname', 'cont_per_lname', 'fax',
    ];
    protected $appends = ['contact_person_first_name', 'contact_person_last_name', 'contact_person_email', 'person_cell', 'person_alt_phone', 'site_contact'];

    public function getContactPersonFirstNameAttribute()
    {
        return $this->siteDetails('contact_person_first_name');
    }
    public function getContactPersonLastNameAttribute()
    {
        return $this->siteDetails('contact_person_last_name');
    }

    public function getContactPersonEmailAttribute()
    {
        return $this->siteDetails('contact_person_email');
    }

    public function getPersonCellAttribute()
    {
        return $this->siteDetails('contact_person_cell');
    }

    public function getPersonAltPhoneAttribute()
    {
        return $this->siteDetails('person_alt_phone');
    }

    public function contact()
    {
        return Contact::where('table_name', 'sites')->where('table_id', $this->id)->where('is_deleted', 0)->first();
    }

    public function getSiteContactAttribute()
    {
        return $this->contact() ?: ['email' => 'Not assigned'];
    }

    /*
     * ADDRESS CAN BELONG TO MANY OTHER TABLE
     * ADDRESS BELONGS TO USERS
     * ADDRESS BELONGS TO VOLUNTEERS
     * MORPH SPECIFIES WHICH TABLE SHOULD USER FOR ADDRESS
     * */
    public function address()
    {
        return $this->morphOne(Address::class, 'table', 'table_name', 'table_id', 'id');
    }

    public function contacts()
    {
        return $this->morphOne(Contact::class, 'table', 'table_name', 'table_id', 'id');
    }

    public function details($site_id)
    {
        return $this->hasMany(SiteDetail::class)->where('site_id', $site_id)->get();
    }

    public function siteDetails($code)
    {
        // $details = $this->hasOne(SiteDetail::class, 'site_id')->where('label', $label);
        $details = SiteDetail::where('site_id', $this->id)->where('code', $code)->first();
        if (!is_null($details)) {
            return $details->value;
        }
        return null;
    }

    public function managingUser()
    {
        return $this->belongsToMany(User::class, 'site_managers');
    }

    public function volunteers()
    {
        return $this->belongsToMany(Volunteer::class, 'volunteer_sites')
            ->where('volunteers.is_deleted', 0)
            ->orderBy('volunteers.first_name');
    }

    public function users()
    {
        return $this->belongsToMany(User::class, 'site_managers');
    }

    public function timesheets()
    {
        return $this->hasMany(Timesheet::class, 'site_id');
    }

    /* Accessibility */
    public function relatedVolunteers($period = false, $requester = false)
    {

        // $requester = func_get_arg(1) ?? false;

        $vols = Timesheet::select('volunteer_id')->distinct()->with('volunteer')
            ->where('site_id', $this->id)
            ->whereHas('volunteer', function ($vs) {
                $vs->where('is_active', 1);
            })
            ->when($period, function ($q, $id) {
                $q->where('period_id', $id);
            })

            ->get()->map(function ($ts) {
            $ts->volunteer->tsExists = $this->id;
            return $ts->volunteer;
        });

        $floaters = $this->floaters()->select(['volunteers.*'])
            ->selectRaw('(select distinct site_id from timesheets where period_id = floaters.period_id and site_id = floaters.site_id and volunteer_id = floaters.vol_id) as tsExists')
            ->selectRaw('"true" as is_floater')
            ->when($period, function ($query, $id) {
                $query->where('period_id', $id);
            })
            ->where('site_id', $this->id)
            ->get();

        $vols = $vols->merge($floaters);

        if ($requester) {
            return $vols;
        }

        $query = $this->volunteers()->select('volunteers.*')
            ->where('volunteers.is_active', 1)
        // ->when($requester == "finance", function($q) use ($period){
        //     $q->whereHas('timesheets', function($query) use($period){
        //         $query->where('period_id', $period);
        //     });
        // })
            ->selectRaw('(
                    select group_concat(distinct ts.site_id separator ",")
                    from timesheets ts
                    where ts.volunteer_id = volunteers.id
                    ' . ($period ? 'AND ts.period_id = ?' : '') . '
                ) as tsExists', [$period]);

        $roleContainer = app(RoleContainer::class);

        if ($roleContainer->hasRole(["superAdmin", "admin", "fiscal"])) {

            return $query->get()->merge($vols);

        }

        $rptmgr = auth()->user()->getReportingMgr();

        return $query

            ->whereHas('supervisors', function ($sup) use ($rptmgr) {
                $sup->whereIn('volunteers_supervisors.supervisor_id', $rptmgr);
            })
            ->get()->merge($vols);
    }

    public function floaters()
    {
        return $this->belongsToMany(Volunteer::class, 'floaters', 'site_id', 'vol_id');
    }
}
