<?php

namespace App\Models\Fgp;

use Illuminate\Database\Eloquent\Model;

class Payroll extends Model
{
    //
}
