<?php

namespace App\Models\Fgp;

use Illuminate\Database\Eloquent\Model;

class TemplateItems extends Model
{
    protected $guarded = [];

    public function stipendItem(){
        return $this->belongsTo(StipendItem::class);
    }
}
