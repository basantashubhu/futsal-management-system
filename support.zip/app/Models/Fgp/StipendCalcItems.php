<?php

namespace App\Models\Fgp;

use Illuminate\Database\Eloquent\Model;

class StipendCalcItems extends Model
{
    //
}
