<?php

namespace App\Models\Fgp;

use Illuminate\Database\Eloquent\Model;

class TimesheetFile extends Model
{
    public function site(){
    	return $this->belongsTo(Site::class);
    }
}
