<?php

namespace App\Models\Fgp;

use Illuminate\Database\Eloquent\Model;

class VolunteerDetail extends Model
{
    protected $table = 'volunteer_details';
    protected $fillable = ['volunteer_id', 'label', 'code', 'value'];
}
