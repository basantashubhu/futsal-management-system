<?php

namespace App\Models\Fgp;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;

class ApprovalTable extends Model
{
    protected $table = 'apprvl';
    protected $fillable = ['period_id', 'site_id', 'vol_id', 'user_approved_id', 'next_approval'];

    public function approver() 
    {
    	return $this->belongsTo(User::class, 'user_approved_id', 'id');
    }

}
