<?php

namespace App\Models\Fgp;

use Illuminate\Database\Eloquent\Model;

class StipendCalcVols extends Model
{
    protected $table = 'stipend_calc_vols';

    public function stipendCalcTypes()
    {
        return $this->hasMany(StipendCalcTypes::class, 'table_id', 'id')
            ->where('stipend_calc_id', $this->stipend_calc_id)->where('table_name', 'volunteers');
    }

    public function stipendCalc()
    {
        return $this->belongsTo(StipendCalc::class, 'stipend_calc_id');
    }

    public function site()
    {
        return $this->belongsTo(Site::class, 'site_id');
    }

    public function period()
    {
        return $this->belongsTo(PayPeriod::class, 'period_id');
    }

    public function volunteer()
    {
        return $this->belongsTo(Volunteer::class, 'vol_id');
    }
}
