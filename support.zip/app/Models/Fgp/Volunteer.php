<?php

namespace App\Models\Fgp;

use App\Models\Address;
use App\Models\Contact;
use App\Models\Fgp\VolunteerDetail;
use App\Models\Member;
use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\Relation;
use Illuminate\Support\Facades\Crypt;

class Volunteer extends Model
{
    protected $fillable = [
        'alt_id', 'vol_ssn', 'salutation', 'vol_title', 'first_name', 'vol_supervisor_id', 'middle_name', 'last_name', 'vol_active', 'hired_date', 'vol_status',
    ];
    public $edit_modal_excludes = ['emergency_contact', 'emergency_contact_tel'];
    protected $appends = ['volunteer_contact', 'def_template', 'vendor_id', 'physical_exam_date', 'stipend_rate'];

    /**
     * volunteer's user
     */

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }

    public function profilePicture()
    {
        return $this->morphOne(\App\File::class, 'table', 'table', 'table_id')->where("document_type", "profile");
    }

    public function documents()
    {
        return $this->morphMany(\App\File::class, 'table', 'table', 'table_id')->where("document_type", "file");
    }

    public function files()
    {
        return $this->morphMany(\App\File::class, 'table', 'table', 'table_id');
    }

    public function setVolSsnAttribute($ssn)
    {
        /*
         * width custom key
         * $encrypter = new Encrypter(config('app.custom_key'));
        $this->attributes['vol_ssn'] = $encrypter->encrypt($ssn);*/
        $this->attributes['vol_ssn'] = Crypt::encryptString($ssn);
    }

    public function setAltIdAttribute($alt_id)
    {
        $this->attributes['alt_id'] = str_pad($alt_id, 6, 0, STR_PAD_LEFT);
    }

    public function getDefTemplateAttribute()
    {
        return $this->defaultTemplate ?: null;
    }

    public function getVolSsnAttribute($value)
    {
        $ssn = null;
        try {
            $ssn = Crypt::decryptString($value);
            /*
         * with custom key
         * $encrypter = new Encrypter(config('app.custom_key'));
        $ssn = $encrypter->decrypt($value);*/
        } catch (\Exception $e) {
            $ssn = null;
        }
        return $ssn;
        // return Crypt::decryptString($value);
    }

    public function contact()
    {
        return Contact::where('table_name', 'volunteers')->where('table_id', $this->id)->where('is_deleted', 0)->first();
    }

    // polymorphic relation with contacts
    public static function boot()
    {
        parent::boot();
        Relation::morphMap([
            'volunteers' => self::class,
        ]);
    }

    public function contacts()
    {
        return $this->morphOne(Contact::class, 'table', 'table_name', 'table_id');
    }

    public function getVolunteerContactAttribute()
    {
        return $this->contact() ?: ['cell_phone' => 'Not assigned', 'email' => 'Not assigned'];
    }

    /*
    out dated
     */
    public function address()
    {
        return Address::where('table_name', 'volunteers')->where('table_id', $this->id)->where('is_deleted', 0)->first();
    }
    /*
     * ADDRESS CAN BELONG TO MANY OTHER TABLE
     * ADDRESS BELONGS TO USERS
     * ADDRESS BELONGS TO VOLUNTEERS
     * MORPH SPECIFIES WHICH TABLE SHOULD USER FOR ADDRESS
     * */
    public function addresses()
    {
        return $this->morphOne(Address::class, 'table', 'table_name', 'table_id', 'id');
    }

    public function assignedSites()
    {
        return $this->hasMany(VolunteerSites::class, 'volunteer_id', 'id')->where('is_deleted', 0);
    }

    public function assignedSupervisor()
    {
        return $this->belongsTo(User::class, 'vol_supervisor_id');
    }

    public function details()
    {
        return $this->hasMany(VolunteerDetail::class, 'volunteer_id');
    }

    public function fetchFromDetails($code)
    {
        $detail = $this->details->where('code', $code)->first();
        return $detail ? $detail->value : null;
    }

    public function getVendorIdAttribute()
    {
        $hasVendorIdAttr = $this->details->where('code', 'vendor_id')->first();

        return $hasVendorIdAttr ? $hasVendorIdAttr->value : null;
    }

    public function getPhysicalExamDateAttribute()
    {
        $hasDetails = $this->details->where('code', 'physical_exam_date')->first();

        return $hasDetails ? $hasDetails->value : null;
    }

    public function getStipendRateAttribute()
    {
        $hasDetails = $this->details->where('code', 'stipend_rate')->first();

        return $hasDetails ? $hasDetails->value : null;
    }

    public function templates()
    {
        return $this->hasMany(Template::class);
    }

    public function emergencyContact()
    {
        /* There can only be one emergency contact */
        return $this->hasOne(VolunteerDetail::class)->where('code', 'emergency_contact');
    }

    public function emergencyContacts()
    {
        return $this->hasMany(EmergencyContact::class)->where('is_deleted', 0);
    }

    public function emergencyContactTel()
    {
        /* There can only be one emergency contact tel */
        return $this->hasOne(VolunteerDetail::class)->where('code', 'emergency_contact_tel');
    }

    public function name($mname = false)
    {
        $name = [$this->first_name, $this->last_name];
        return $mname === false ? join(' ', $name) : join(" $this->middle_name ", $name);
    }

    public function supervisors()
    {
        return $this->belongsToMany(User::class, 'volunteers_supervisors', 'volunteer_id', 'supervisor_id');
    }

    public function supervisorsWithName()
    {
        return $this->belongsToMany(Member::class, 'volunteers_supervisors', 'volunteer_id', 'supervisor_id', 'id', 'user_id');
    }

    public function allTemplates()
    {
        return $this->morphMany(Template::class, 'table', 'table_name', 'table_id')->where('is_deleted', 0);
    }

    public function defaultTemplate()
    {
        return $this->morphOne(Template::class, 'table', 'table_name', 'table_id')->where([
            'is_default' => 1,
            'is_active' => 1,
            'is_deleted' => 0,
        ]);
    }

    public function stipend()
    {
        return Timesheet::select('site_id', 'period_id')->distinct()->where('volunteer_id', $this->id)
            ->with('pay_period', 'site', 'site.address')
            ->get();
    }

    public function sites()
    {
        return $this->belongsToMany(Site::class, 'volunteer_sites', 'volunteer_id', 'site_id')->withPivot('is_default');
    }

    public function readOnlySites()
    {
        return $this->belongsToMany(ReadOnlySite::class, 'volunteer_sites', 'volunteer_id', 'site_id')->withPivot('is_default');
    }

    public function defaultSite()
    {
        return $this->sites()->where('is_default', 1)->first();
    }

    public function total_hrs($p_id, $site_id = false)
    {
        $tss = Timesheet::selectRaw('(sum(time_to_sec(total_hrs)) / 3600) as total_hrs')->where([
            'period_id' => $p_id, 'volunteer_id' => $this->id,
        ])->when($site_id, function ($q, $id) {
            $q->where('site_id', $id);
        })->first();
        return total_hrs($tss->total_hrs);
    }

    private function getEtoItems()
    {
        return StipendItem::where('is_eto', 1)->get()->pluck('id');

    }

    public function etoBalance($p_id, $site_id = false)
    {
        $etoItems = $this->getEtoItems();
        $ts = Timesheet::selectRaw('((SUM(time_to_sec(total_hrs)) / 3600)) as etoBalance')
            ->where([
                'period_id' => $p_id, 'volunteer_id' => $this->id,
            ])
            ->whereIn('type_label', $etoItems)
            ->when($site_id, function ($q, $id) {
                $q->where('site_id', $id);
            })->first();

        return total_hrs($ts->etoBalance);

    }

    // public function totalEtoBalance(){

    //     $etoItems = $this->getEtoItems();

    //     return Timesheet::selectRaw('((SUM(time_to_sec(total_hrs)) / 3600)) as etoBalance')
    //     ->where('volunteer_id', $this->id)
    //     ->whereIn('type_label', $etoItems)
    //     ->get();
    // }

    public function volunteerDeactive()
    {
        return $this->hasOne(volunteerDeactive::class);
    }

    public function timesheets()
    {
        return $this->hasMany(Timesheet::class);
    }

}
