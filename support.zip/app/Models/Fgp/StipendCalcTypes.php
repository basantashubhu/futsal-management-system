<?php

namespace App\Models\Fgp;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\Relation;

class StipendCalcTypes extends Model
{
    protected $table = 'stipend_calc_types';


}
