<?php

namespace App\Models\Fgp;

use Illuminate\Database\Eloquent\Model;

class StipendCalc extends Model
{
    protected $table = 'stipend_calcs';

    public function stipendCalcSites()
    {
        return $this->hasMany(StipendCalcSites::class, 'stipend_calc_id', 'id');
    }
    public function stipendCalcVols()
    {
        return $this->hasMany(stipendCalcVols::class, 'stipend_calc_id', 'id');
    }

    public function payperiod()
    {
        return $this->belongsTo(PayPeriod::class, 'period_unq_id', 'id');
    }

    public function stipendItemTypes()
    {
        return $this->hasMany(StipendCalcTypes::class, 'table_id')->where('table_name', 'stipend_calcs');
    }
}
