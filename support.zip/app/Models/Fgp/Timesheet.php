<?php

namespace App\Models\Fgp;

use App\Models\Member;
use App\Models\User;
use Illuminate\Database\Eloquent\Model;

class Timesheet extends Model
{
    protected $guarded = [];

    protected $appends = ['formatted_total_hrs', 'formatted_time_in', 'formatted_time_out', 'formatted_break_in', 'formatted_break_out', 'formatted_date', 'formatted_week_day'];

    // public function setTotalHrsAttribute($value){
    //     $this->attributes['total_hrs'] = (strtotime($this->time_out) - strtotime($this->time_in))/ 3600;
    // }

    // owner volunteer
    public function volunteer()
    {
        return $this->belongsTo(Volunteer::class, 'volunteer_id', 'id');
    }

    // owner site
    public function site()
    {
        return $this->belongsTo(Site::class, 'site_id', 'id');
    }

    // related pay period
    public function pay_period()
    {
        return $this->belongsTo(PayPeriod::class, 'period_id', 'id');
    }

    // related timesheet items
    public function timesheetItems()
    {
        return $this->hasMany(TimeSheetItem::class, 'time_sheet_id', 'id');
    }

    public function item()
    {
        return $this->belongsTo(StipendItem::class, 'type_label');
    }

    public function getFormattedTotalHrsAttribute()
    {

        return $this->formatTime($this->total_hrs);
    }

    public function getFormattedTimeInAttribute()
    {

        return $this->formatTime($this->time_in);
    }

    public function getFormattedTimeOutAttribute()
    {

        return $this->formatTime($this->time_out);
    }

    public function getFormattedBreakInAttribute()
    {

        return $this->formatTime($this->break_in);
    }

    public function getFormattedBreakOutAttribute()
    {

        return $this->formatTime($this->break_out);
    }

    public function getFormattedDateAttribute()
    {
        return date('m/d/y', strtotime($this->date));
    }

    public function getFormattedWeekDayAttribute()
    {
        $week_day = date_create($this->date)->format("w");

        switch ($week_day) {
            case 6:
                $w = "Sa";
                break;
            case 0:
                $w = "S";
                break;
            case 1:
                $w = "M";
                break;
            case 2:
                $w = "T";
                break;
            case 3:
                $w = "W";
                break;
            case 4:
                $w = "Th";
                break;
            case 5:
                $w = "F";
                break;

            default:
                # code...
                break;
        }

        return $w;
    }

    public function formatTime($field)
    {
        return $field ? date_create($field)->format('G:i') : '0.00';

    }

    public function user()
    {
        return $this->belongsTo(User::class, 'userc_id', 'id');
    }

    public function member()
    {
        return $this->belongsTo(Member::class, 'userc_id', 'user_id');
    }

    public function approvals()
    {
        // incomplete without other conditions

        return $this->hasMany(ApprovalTable::class, 'period_id', 'period_id')
            ->where('site_id', $this->site_id)->where('vol_id', $this->volunteer_id)->groupBy('user_approved_id');
    }
}
