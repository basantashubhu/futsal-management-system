<?php

namespace App\Models\Fgp;

use App\Models\Role;
use Illuminate\Database\Eloquent\Model;

class ApprovalFlow extends Model
{
    protected $table = 'approval_flow';

    protected $fillable = ['seq_num','role','role_id','code'];


    public function roles(){
        return $this->belongsTo(Role::class,'role_id');
    }
}
