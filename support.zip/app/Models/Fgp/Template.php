<?php

namespace App\Models\Fgp;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\Relation;
use App\Models\Settings\Lookups;

class Template extends Model
{

    protected $guarded = [];

    public function details()
    {
        return $this->hasMany(TemplateComponent::class);
    }

    public static function boot()
    {
        parent::boot();
        Relation::morphMap([
            'volunteers' => Volunteer::class,
        ]);
    }

    public function category(){
        return $this->belongsTo(Lookups::class, 'category_id', 'id');
    }

    public function volunteer()
    {
        return $this->morphTo(Volunteer::class, 'table', 'table_name', 'table_id');
    }
}
