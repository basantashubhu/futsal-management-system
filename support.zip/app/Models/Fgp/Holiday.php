<?php

namespace App\Models\Fgp;

use Illuminate\Database\Eloquent\Model;

class Holiday extends Model
{
	protected $table='holiday';
	protected $fillable = [
        'name','hol_date','description', 'cal_type', 'state_r','eto_eligibility','is_active','paid_flag'
    ];
}
