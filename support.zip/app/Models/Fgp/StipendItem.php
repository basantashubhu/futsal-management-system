<?php

namespace App\Models\Fgp;

use App\Models\Settings\Lookups;
use Illuminate\Database\Eloquent\Model;

class StipendItem extends Model
{
    protected $fillable = ([
        'is_deleted','is_fsy','year',
        'item_name','year', 'item_code', 'description', 'unit_amount', 'max_amount', 'category', 'project_code', 
                'fund_code', 'department_code', 'account_code', 'program_code', 'business_unit','is_active','is_eto',
                'field_type',
    ]);

    public function getUnitAmountAttribute($value){
        return number_format($value, 2, '.', '');
    }

    public function getCodeName($value){
        if (isset($value)):
    	    $desc =  Lookups::select('description')->where('value',$value)->first();
            if ($desc==null):
                return "";
            else:
                return $desc->description;
            endif;
        else:
            return "";
        endif;
    }
}
