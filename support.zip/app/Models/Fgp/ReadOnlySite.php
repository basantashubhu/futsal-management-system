<?php

namespace App\Models\Fgp;

class ReadOnlySite extends Site
{
    protected $appends = [];
    protected $guarded = ['*'];
    protected $table = 'sites';
    protected $fillable = [];

    /**
     * Reading site phone in regular US standard
     *
     * @param string $site_phone
     * @return string actual us standard phone format
     */
    public function getSitePhoneAttribute($site_phone)
    {
        if (!preg_match('/\([\d]{3}\) ([\d]{3})-([\d]{4})/', $site_phone)) {
            $site_phone = preg_replace('/([\d]{3})([\d]{3})([\d]{4})/', '($1) $2-$3', $site_phone);
        }
        return $site_phone;
    }

    /**
     * Reading site alt phone in regular US standard
     *
     * @param string $site_phone
     * @return string actual us standard phone format
     */
    public function getSiteAltPhoneAttribute($site_alt_phone)
    {
        if (!preg_match('/\([\d]{3}\) ([\d]{3})-([\d]{4})/', $site_alt_phone)) {
            $site_alt_phone = preg_replace('/([\d]{3})([\d]{3})([\d]{4})/', '($1) $2-$3', $site_alt_phone);
        }
        return $site_alt_phone;
    }
}
