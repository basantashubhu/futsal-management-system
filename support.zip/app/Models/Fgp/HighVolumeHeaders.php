<?php

namespace App\Models\Fgp;

use Illuminate\Database\Eloquent\Model;

class HighVolumeHeaders extends Model
{
    
	protected $guarded = [];

}
