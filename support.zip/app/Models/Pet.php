<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Pet extends Model
{
    public function client()
    {
        return $this->belongsTo(Client::class);
    }

    public function applications()
    {
        return $this->belongsToMany(Application::class);
    }

    public function invoiceItem()
    {
        return $this->hasMany(InvoiceItem::class, 'animal_id');
    }

    public function provider()
    {
        return $this->belongsToMany(Organization::class, 'application_pet', 'provider_id', 'pet_id');
    }

    public function appPetTreatment($appId, $tid)
    {
        return ApplicationPetTreatments::where('application_id', $appId)->where('pet_id', $this->id)->where('treatment_id', $tid)->first();
    }


    public function getRate($tid)
    {
        $species = strtolower($this->species);
        $sex = strtolower($this->sex);
        $weight = $this->weight;

        $ratePlan = RatePlan::where('is_active', 1)->where('is_custom', 0)->first();

        $rates = Rate::where([
            ['plan_id', $ratePlan->id],
            ['treatment_id', $tid],
        ])
            ->whereRaw("lower(rates.animal_type)='$species'")
            ->whereRaw("lower(rates.sex)='$sex'")->get();

        foreach ($rates as $rate) {
            $rateType = RateType::find($rate->rate_type_id);
            $res = $this->performComparision($weight, $rateType->rate_metrics);
            if ($res)
                return $rate->cost;
        }
        return 0;
    }

    private function performComparision($data, $compareString)
    {
        $list = ['<=', '==', '>'];
        foreach ($list as $l) {
            if (hasOperator($compareString, $l)) {
                $d = (int)str_replace($l, '', $compareString);
                if (is_int($d) && $d != 0) {
                    switch ($l) {
                        case '<':
                            return $data < $d;
                        case '<=':
                            return $data <= $d;
                        case '>':
                            return $data > $d;
                        case '>=':
                            return $data >= $d;
                        case '==':
                            return $data == $d;
                        default:
                            return false;
                    }
                } else
                    return false;

            }
        }
        return false;
    }

    public function getCopay($appId)
    {
        $inv = InvoiceItem::where('animal_id',$this->id)->where('application_id',$appId)->where('service_description','like','copay%')->first();
        if($inv)
            return $inv->amount_total*(-1);
        else
            return 0;
    }
}
