<?php
/**
 * DEVELOPERS
 * ----------------------------------------------
 * SUMAN  THAPA - LEAD  (NEPALNME@GMAIL.COM)
 * ----------------------------------------------
 * - BASANTA TAJPURIYA
 * - RAKESH SHRESTHA
 * - LEKH RAJ RAI 
 * -----------------------------------------------
 * Created On: 08/02/2019
 *
 * THIS INTELLECTUAL PROPERTY IS COPYRIGHT Ⓒ 2019
 * ZEUSLOGIC, INC. ALL RIGHT RESERVED
 */

namespace App\Models;

use Illuminate\Support\Facades\Crypt;


class Client extends BaseModel
{
    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'ssn'
    ];


    /**
     * @param $ssn
     */
    public function setssnAttribute($ssn)
    {
        $this->attributes['ssn'] = Crypt::encryptString(Crypt::encryptString($ssn));
    }
  /*  public function setdobAttribute($ssn)
    {
        $this->attributes['dob'] = Crypt::encryptString($ssn);
    }*/
    public function getssnAttributes()
    {
        return Crypt::decryptString(Crypt::decryptString($this->attributes['ssn']));
    }

    public function getmnameAttributes()
    {
        if($this->attributes['mname'] && strlen($this->attributes['mname'])==1)
        {
            return $this->attributes['mname'].'.';
        }
        return $this->attributes['mname'];
    }
  /*  public function getdob()
    {
        return Crypt::decryptString($this->dob);
    }*/

    public function getSSn()
    {
        return Crypt::decryptString(Crypt::decryptString($this->ssn));
    }


    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function pets()
    {
        return $this->hasMany(Pet::class);
    }

    public function contact()
    {
        return $this->hasOne(Contact::class, 'client_id');
    }

    public function address()
    {
        return $this->hasOne(Address::class, 'client_id')->with('zip');
    }

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function organization()
    {
        return $this->belongsTo(Organization::class, 'org_id');
    }

    public function fullname()
    {
        if($this->mname==null)
            return $this->fname . ' ' . $this->lname;
        else
            return $this->fname . ' '.$this->mname.' '. $this->lname;
    }
}
