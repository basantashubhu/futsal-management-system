<?php

namespace App\Importer;

use Illuminate\Database\Eloquent\Model;

class Data extends Model
{
    protected $guarded = [];
}
